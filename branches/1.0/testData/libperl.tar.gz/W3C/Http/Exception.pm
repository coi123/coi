#Copyright Massachusetts Institute of technology, 2000.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

# $Id: Exception.pm,v 1.5 2004/06/09 09:19:06 eric Exp $

use strict;

package W3C::Http::HttpMessageException;
use vars qw(@ISA);
@ISA = qw(W3C::Util::Exception);

use W3C::Util::Exception;
use W3C::Http::Message;

sub new {
    my ($proto, @parms) = @_;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new(@parms);
    if ($self->{-httpMessage}) {
    } else {
	$self->missingParm('-statusCode') if (!$self->{-statusCode});
	$self->missingParm('-headers') if (!$self->{-headers});
	$self->missingParm('-body') if (!$self->{-body});
	$self->{-httpMessage} = new W3C::Http::Message(-statusCode => delete $self->{-statusCode}, 
						   -headers => delete $self->{-headers}, 
						   -body => delete $self->{-body});
    }
    $self->fillInStackTrace;
    return $self;
}

sub getHttpMessage {return $_[0]->{-httpMessage};}

sub toString {
    my ($self) = @_;
    return $self->getHttpMessage()->toString();
}

package W3C::Http::Exception;

sub HaltAndCatchFire { # static
    my ($message) = @_;
    my $ex = new W3C::Util::Exception();
    my $out = "status: 200\ncontent-type: text/plain\n\n$message";
    $ex->printStackTrace(\$out);
    print $out;
    exit(0);
}

1;

__END__

=head1 NAME

W3C::Http::Exception - HTTP Exceptions

=head1 SYNOPSIS

    use W3C::Http::Exception;
    throw(new W3C::Http::MessageException(-statusCode => 401
        -headers => {}, 
        -body => "
    <html xmlns="http://www.w3.org/1999/xhtml">
        <head><title>denied</title></head>
        <body><h1>denide</h1>
              <p>no dice</p></body>
    </html>"));
    }

=head1 DESCRIPTION

This module is part of the W3C::Http CPAN module.

The module holds exceptions associated with Http classes. see: L<HttpMessageException|/"HttpMessageException">.

=head2 HttpMessageException

This is a convient exception to return an W3C::Http::Message (or whatever was passed in as the B<-httpMessage> parameter). Its B<toString> method returns a valid HTTP message. This is most usefull in scenarios where the script has a variety of return points, as is common in scripting where the server may return messages like AuthReqired or Redirect instead of serving the requested content.

=head3 Constructor ( PARMS )

Where PARMS are:
  C<-statusCode>: HTTP Status Codes ala 200, 401, 403...
  C<-headers>: array of headers
  C<-body>: text body of the HTTP message to send

=head1 AUTHOR

Eric Prud'hommeaux <eric@w3.org>

=head1 SEE ALSO

L<W3C::Http::Message>
L<W3C::Util::Exception>

=cut
