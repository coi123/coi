#!/usr/bin/perl
####################################################################
#
#    This file was generated using Parse::Yapp version 1.05.
#
#        Don't edit this file, use source file instead.
#
#             ANY CHANGE MADE HERE WILL BE LOST !
#
####################################################################
package W3C::Rdf::_RdqlParser;
use vars qw ( @ISA );
use strict;

@ISA= qw ( Parse::Yapp::Driver );
# use Parse::Yapp::Driver; @@ replaced by W3C::Util::YappDriver

#line 9 "RdqlParser.yp"

    #BEGIN {unshift@INC,('../..');}
    use W3C::Util::YappDriver;
    @ISA= qw (W3C::Util::YappDriver);

    use W3C::Rdf::AlgaeCompileTree qw($DISJUNCTION $NEGATION $OUTER);


sub new {
        my($class)=shift;
        ref($class)
    and $class=ref($class);

    my($self)=$class->SUPER::new( yyversion => '1.05',
                                  yystates =>
[
	{#State 0
		ACTIONS => {
			"SELECT" => 1,
			"select" => 6
		},
		GOTOS => {
			'QueryPlus' => 2,
			'CompilationUnit' => 4,
			'Query' => 3,
			'SelectClause' => 5,
			'SELECT' => 7
		}
	},
	{#State 1
		DEFAULT => -103
	},
	{#State 2
		DEFAULT => -1
	},
	{#State 3
		DEFAULT => -4
	},
	{#State 4
		ACTIONS => {
			'' => 8
		}
	},
	{#State 5
		ACTIONS => {
			"FROM" => 10,
			"SOURCE" => 12,
			"from" => 13,
			"source" => 14
		},
		DEFAULT => -11,
		GOTOS => {
			'SourceClauseOpt' => 9,
			'FROM' => 11,
			'SOURCE' => 15,
			'SourceClause' => 16
		}
	},
	{#State 6
		DEFAULT => -104
	},
	{#State 7
		ACTIONS => {
			"?" => 18,
			"*" => 17
		},
		GOTOS => {
			'STAR' => 19,
			'Var' => 20
		}
	},
	{#State 8
		DEFAULT => 0
	},
	{#State 9
		ACTIONS => {
			"where" => 21,
			"WHERE" => 23
		},
		GOTOS => {
			'WHERE' => 22,
			'TriplePatternClause' => 24
		}
	},
	{#State 10
		DEFAULT => -105
	},
	{#State 11
		ACTIONS => {
			'QuotedURI' => 26,
			'NSPrefix' => 29
		},
		GOTOS => {
			'URI' => 25,
			'SourceSelector' => 27,
			'QName' => 28
		}
	},
	{#State 12
		DEFAULT => -107
	},
	{#State 13
		DEFAULT => -106
	},
	{#State 14
		DEFAULT => -108
	},
	{#State 15
		ACTIONS => {
			'QuotedURI' => 26,
			'NSPrefix' => 29
		},
		GOTOS => {
			'URI' => 25,
			'SourceSelector' => 30,
			'QName' => 28
		}
	},
	{#State 16
		DEFAULT => -12
	},
	{#State 17
		DEFAULT => -134
	},
	{#State 18
		ACTIONS => {
			"where" => 21,
			"SELECT" => 1,
			'IDENTIFIER' => 37,
			"eq" => 31,
			'FOR' => 32,
			"WHERE" => 23,
			'PREFIXES' => 33,
			"source" => 14,
			"NE" => 34,
			"FROM" => 10,
			"SOURCE" => 12,
			"from" => 13,
			"select" => 6,
			"ne" => 42,
			"EQ" => 36
		},
		GOTOS => {
			'FROM' => 39,
			'WHERE' => 40,
			'Identifier' => 41,
			'SELECT' => 43,
			'SOURCE' => 44,
			'STR_NE' => 35,
			'STR_EQ' => 38
		}
	},
	{#State 19
		DEFAULT => -8
	},
	{#State 20
		DEFAULT => -9,
		GOTOS => {
			'CommaOptVarStar' => 45
		}
	},
	{#State 21
		DEFAULT => -110
	},
	{#State 22
		ACTIONS => {
			"(" => 48
		},
		GOTOS => {
			'TriplePattern' => 47,
			'LPAREN' => 46
		}
	},
	{#State 23
		DEFAULT => -109
	},
	{#State 24
		ACTIONS => {
			"AND" => 50,
			"and" => 52
		},
		DEFAULT => -21,
		GOTOS => {
			'AND' => 51,
			'ConstraintClauseOpt' => 53,
			'ConstraintClause' => 49
		}
	},
	{#State 25
		DEFAULT => -17
	},
	{#State 26
		DEFAULT => -90
	},
	{#State 27
		DEFAULT => -15,
		GOTOS => {
			't1Star' => 54
		}
	},
	{#State 28
		DEFAULT => -91
	},
	{#State 29
		ACTIONS => {
			":" => 55
		}
	},
	{#State 30
		DEFAULT => -15,
		GOTOS => {
			't1Star' => 56
		}
	},
	{#State 31
		DEFAULT => -129
	},
	{#State 32
		DEFAULT => -100
	},
	{#State 33
		DEFAULT => -99
	},
	{#State 34
		DEFAULT => -130
	},
	{#State 35
		DEFAULT => -102
	},
	{#State 36
		DEFAULT => -128
	},
	{#State 37
		DEFAULT => -94
	},
	{#State 38
		DEFAULT => -101
	},
	{#State 39
		DEFAULT => -97
	},
	{#State 40
		DEFAULT => -98
	},
	{#State 41
		DEFAULT => -32
	},
	{#State 42
		DEFAULT => -131
	},
	{#State 43
		DEFAULT => -95
	},
	{#State 44
		DEFAULT => -96
	},
	{#State 45
		ACTIONS => {
			"?" => -2,
			"," => 57
		},
		DEFAULT => -7,
		GOTOS => {
			'COMMA' => 59,
			'CommaOpt' => 58
		}
	},
	{#State 46
		ACTIONS => {
			"?" => 18,
			'QuotedURI' => 26,
			'NSPrefix' => 29
		},
		GOTOS => {
			'URI' => 62,
			'QName' => 28,
			'VarOrURI' => 60,
			'Var' => 61
		}
	},
	{#State 47
		DEFAULT => -19,
		GOTOS => {
			't2Star' => 63
		}
	},
	{#State 48
		DEFAULT => -115
	},
	{#State 49
		DEFAULT => -22
	},
	{#State 50
		DEFAULT => -111
	},
	{#State 51
		ACTIONS => {
			"-" => 64,
			'STRING_LITERAL1' => 79,
			"?" => 18,
			"+" => 87,
			"~" => 69,
			'INTEGER_LITERAL' => 88,
			'BOOLEAN_LITERAL' => 81,
			"!" => 73,
			"(" => 48,
			'QuotedURI' => 26,
			'PATTERN_LITERAL' => 75,
			'STRING_LITERAL2' => 76,
			'FLOATING_POINT_LITERAL' => 97,
			'NULL_LITERAL' => 85,
			'NSPrefix' => 29
		},
		GOTOS => {
			'BANG' => 66,
			'BooleanLiteral' => 65,
			'UnaryExpressionNotPlusMinus' => 67,
			'MINUS' => 86,
			'RelationalExpression' => 68,
			'LPAREN' => 70,
			'MultiplicativeExpression' => 72,
			'PLUS' => 71,
			'EqualityExpression' => 89,
			'TextLiteral' => 74,
			'QName' => 28,
			'NumericLiteral' => 77,
			'ConditionalOrExpression' => 90,
			'Var' => 78,
			'URI' => 93,
			'PatternLiteral' => 92,
			'Expression' => 91,
			'ArithmeticCondition' => 94,
			'NullLiteral' => 80,
			'ConditionalAndExpression' => 95,
			'PrimaryExpression' => 82,
			'TILDE' => 83,
			'UnaryExpression' => 84,
			'AdditiveExpression' => 96,
			'Const' => 98,
			'StringEqualityExpression' => 99
		}
	},
	{#State 52
		DEFAULT => -112
	},
	{#State 53
		ACTIONS => {
			"SELECT" => 1,
			"USING" => 102,
			"select" => 6,
			"using" => 101
		},
		DEFAULT => -33,
		GOTOS => {
			'QueryPlus' => 104,
			'PrefixesClauseOpt' => 105,
			'Query' => 3,
			'SelectClause' => 5,
			'USING' => 100,
			'SELECT' => 7,
			'PrefixesClause' => 103
		}
	},
	{#State 54
		ACTIONS => {
			"where" => -14,
			"WHERE" => -14,
			"," => 57
		},
		DEFAULT => -2,
		GOTOS => {
			'COMMA' => 59,
			'CommaOpt' => 106
		}
	},
	{#State 55
		ACTIONS => {
			'LocalPart' => 107
		},
		DEFAULT => -92
	},
	{#State 56
		ACTIONS => {
			"where" => -13,
			"WHERE" => -13,
			"," => 57
		},
		DEFAULT => -2,
		GOTOS => {
			'COMMA' => 59,
			'CommaOpt' => 106
		}
	},
	{#State 57
		DEFAULT => -117
	},
	{#State 58
		ACTIONS => {
			"?" => 18
		},
		GOTOS => {
			'Var' => 108
		}
	},
	{#State 59
		DEFAULT => -3
	},
	{#State 60
		ACTIONS => {
			"," => 57
		},
		DEFAULT => -2,
		GOTOS => {
			'COMMA' => 59,
			'CommaOpt' => 109
		}
	},
	{#State 61
		DEFAULT => -28
	},
	{#State 62
		DEFAULT => -29
	},
	{#State 63
		ACTIONS => {
			"," => 57,
			"(" => -2
		},
		DEFAULT => -18,
		GOTOS => {
			'COMMA' => 59,
			'CommaOpt' => 110
		}
	},
	{#State 64
		DEFAULT => -133
	},
	{#State 65
		DEFAULT => -77
	},
	{#State 66
		ACTIONS => {
			"-" => 64,
			'STRING_LITERAL1' => 79,
			"?" => 18,
			"+" => 87,
			"~" => 69,
			'INTEGER_LITERAL' => 88,
			"!" => 73,
			"(" => 48,
			'BOOLEAN_LITERAL' => 81,
			'QuotedURI' => 26,
			'STRING_LITERAL2' => 76,
			'FLOATING_POINT_LITERAL' => 97,
			'NULL_LITERAL' => 85,
			'NSPrefix' => 29
		},
		GOTOS => {
			'BANG' => 66,
			'BooleanLiteral' => 65,
			'UnaryExpressionNotPlusMinus' => 67,
			'MINUS' => 86,
			'LPAREN' => 70,
			'PLUS' => 71,
			'TextLiteral' => 74,
			'QName' => 28,
			'NumericLiteral' => 77,
			'Var' => 78,
			'URI' => 93,
			'NullLiteral' => 80,
			'PrimaryExpression' => 82,
			'TILDE' => 83,
			'UnaryExpression' => 111,
			'Const' => 98
		}
	},
	{#State 67
		DEFAULT => -65
	},
	{#State 68
		ACTIONS => {
			"==" => 113,
			"!=" => 115
		},
		DEFAULT => -50,
		GOTOS => {
			'EQ' => 114,
			'NEQ' => 112
		}
	},
	{#State 69
		DEFAULT => -121
	},
	{#State 70
		ACTIONS => {
			"-" => 64,
			'STRING_LITERAL1' => 79,
			"?" => 18,
			"+" => 87,
			"~" => 69,
			'INTEGER_LITERAL' => 88,
			'BOOLEAN_LITERAL' => 81,
			"!" => 73,
			"(" => 48,
			'QuotedURI' => 26,
			'PATTERN_LITERAL' => 75,
			'STRING_LITERAL2' => 76,
			'FLOATING_POINT_LITERAL' => 97,
			'NULL_LITERAL' => 85,
			'NSPrefix' => 29
		},
		GOTOS => {
			'BANG' => 66,
			'BooleanLiteral' => 65,
			'UnaryExpressionNotPlusMinus' => 67,
			'MINUS' => 86,
			'RelationalExpression' => 68,
			'LPAREN' => 70,
			'MultiplicativeExpression' => 72,
			'PLUS' => 71,
			'EqualityExpression' => 89,
			'TextLiteral' => 74,
			'QName' => 28,
			'NumericLiteral' => 77,
			'ConditionalOrExpression' => 90,
			'Var' => 78,
			'Expression' => 116,
			'PatternLiteral' => 92,
			'URI' => 93,
			'ArithmeticCondition' => 94,
			'NullLiteral' => 80,
			'ConditionalAndExpression' => 95,
			'PrimaryExpression' => 82,
			'TILDE' => 83,
			'UnaryExpression' => 84,
			'AdditiveExpression' => 96,
			'Const' => 98,
			'StringEqualityExpression' => 99
		}
	},
	{#State 71
		ACTIONS => {
			"-" => 64,
			'STRING_LITERAL1' => 79,
			"?" => 18,
			"+" => 87,
			"~" => 69,
			'INTEGER_LITERAL' => 88,
			"!" => 73,
			"(" => 48,
			'BOOLEAN_LITERAL' => 81,
			'QuotedURI' => 26,
			'STRING_LITERAL2' => 76,
			'FLOATING_POINT_LITERAL' => 97,
			'NULL_LITERAL' => 85,
			'NSPrefix' => 29
		},
		GOTOS => {
			'BANG' => 66,
			'BooleanLiteral' => 65,
			'UnaryExpressionNotPlusMinus' => 67,
			'MINUS' => 86,
			'LPAREN' => 70,
			'PLUS' => 71,
			'TextLiteral' => 74,
			'QName' => 28,
			'NumericLiteral' => 77,
			'Var' => 78,
			'URI' => 93,
			'NullLiteral' => 80,
			'PrimaryExpression' => 82,
			'TILDE' => 83,
			'UnaryExpression' => 117,
			'Const' => 98
		}
	},
	{#State 72
		ACTIONS => {
			"-" => 64,
			"+" => 87
		},
		DEFAULT => -58,
		GOTOS => {
			'MINUS' => 119,
			'PLUS' => 118
		}
	},
	{#State 73
		DEFAULT => -120
	},
	{#State 74
		DEFAULT => -76
	},
	{#State 75
		DEFAULT => -87
	},
	{#State 76
		ACTIONS => {
			"\@" => 120
		},
		DEFAULT => -83,
		GOTOS => {
			't10Opt' => 122,
			'AT' => 121
		}
	},
	{#State 77
		DEFAULT => -75
	},
	{#State 78
		DEFAULT => -71
	},
	{#State 79
		ACTIONS => {
			"\@" => 120
		},
		DEFAULT => -83,
		GOTOS => {
			't10Opt' => 123,
			'AT' => 121
		}
	},
	{#State 80
		DEFAULT => -78
	},
	{#State 81
		DEFAULT => -88
	},
	{#State 82
		DEFAULT => -70
	},
	{#State 83
		ACTIONS => {
			"-" => 64,
			'STRING_LITERAL1' => 79,
			"?" => 18,
			"+" => 87,
			"~" => 69,
			'INTEGER_LITERAL' => 88,
			"!" => 73,
			"(" => 48,
			'BOOLEAN_LITERAL' => 81,
			'QuotedURI' => 26,
			'STRING_LITERAL2' => 76,
			'FLOATING_POINT_LITERAL' => 97,
			'NULL_LITERAL' => 85,
			'NSPrefix' => 29
		},
		GOTOS => {
			'BANG' => 66,
			'BooleanLiteral' => 65,
			'UnaryExpressionNotPlusMinus' => 67,
			'MINUS' => 86,
			'LPAREN' => 70,
			'PLUS' => 71,
			'TextLiteral' => 74,
			'QName' => 28,
			'NumericLiteral' => 77,
			'Var' => 78,
			'URI' => 93,
			'NullLiteral' => 80,
			'PrimaryExpression' => 82,
			'TILDE' => 83,
			'UnaryExpression' => 124,
			'Const' => 98
		}
	},
	{#State 84
		ACTIONS => {
			"%" => 125,
			"*" => 17,
			"/" => 129
		},
		DEFAULT => -61,
		GOTOS => {
			'REM' => 127,
			'STAR' => 128,
			'SLASH' => 126
		}
	},
	{#State 85
		DEFAULT => -89
	},
	{#State 86
		ACTIONS => {
			"-" => 64,
			'STRING_LITERAL1' => 79,
			"?" => 18,
			"+" => 87,
			"~" => 69,
			'INTEGER_LITERAL' => 88,
			"!" => 73,
			"(" => 48,
			'BOOLEAN_LITERAL' => 81,
			'QuotedURI' => 26,
			'STRING_LITERAL2' => 76,
			'FLOATING_POINT_LITERAL' => 97,
			'NULL_LITERAL' => 85,
			'NSPrefix' => 29
		},
		GOTOS => {
			'BANG' => 66,
			'BooleanLiteral' => 65,
			'UnaryExpressionNotPlusMinus' => 67,
			'MINUS' => 86,
			'LPAREN' => 70,
			'PLUS' => 71,
			'TextLiteral' => 74,
			'QName' => 28,
			'NumericLiteral' => 77,
			'Var' => 78,
			'URI' => 93,
			'NullLiteral' => 80,
			'PrimaryExpression' => 82,
			'TILDE' => 83,
			'UnaryExpression' => 130,
			'Const' => 98
		}
	},
	{#State 87
		DEFAULT => -132
	},
	{#State 88
		DEFAULT => -79
	},
	{#State 89
		DEFAULT => -49
	},
	{#State 90
		DEFAULT => -39
	},
	{#State 91
		DEFAULT => -24,
		GOTOS => {
			't3Star' => 131
		}
	},
	{#State 92
		ACTIONS => {
			"!~" => 135,
			"=~" => 134,
			"~~" => 133
		},
		GOTOS => {
			'STR_MATCH' => 132,
			'STR_NMATCH' => 136
		}
	},
	{#State 93
		DEFAULT => -74
	},
	{#State 94
		ACTIONS => {
			"eq" => 31,
			"NE" => 34,
			"EQ" => 36,
			"ne" => 42
		},
		DEFAULT => -44,
		GOTOS => {
			'STR_NE' => 137,
			'STR_EQ' => 138
		}
	},
	{#State 95
		ACTIONS => {
			"||" => 139
		},
		DEFAULT => -40,
		GOTOS => {
			'SC_OR' => 140
		}
	},
	{#State 96
		ACTIONS => {
			"<" => 141,
			">=" => 142,
			"<=" => 143,
			">" => 144
		},
		DEFAULT => -53,
		GOTOS => {
			'LE' => 148,
			'GE' => 145,
			'LT' => 147,
			'GT' => 146
		}
	},
	{#State 97
		DEFAULT => -80
	},
	{#State 98
		DEFAULT => -72
	},
	{#State 99
		ACTIONS => {
			"&&" => 150
		},
		DEFAULT => -42,
		GOTOS => {
			'SC_AND' => 149
		}
	},
	{#State 100
		ACTIONS => {
			"where" => 21,
			"SELECT" => 1,
			'IDENTIFIER' => 37,
			"eq" => 31,
			'FOR' => 32,
			"WHERE" => 23,
			'PREFIXES' => 33,
			"source" => 14,
			"NE" => 34,
			"FROM" => 10,
			"SOURCE" => 12,
			"from" => 13,
			"select" => 6,
			"EQ" => 36,
			"ne" => 42
		},
		GOTOS => {
			'PrefixDecl' => 151,
			'STR_NE' => 35,
			'STR_EQ' => 38,
			'FROM' => 39,
			'WHERE' => 40,
			'Identifier' => 152,
			'SELECT' => 43,
			'SOURCE' => 44
		}
	},
	{#State 101
		DEFAULT => -114
	},
	{#State 102
		DEFAULT => -113
	},
	{#State 103
		DEFAULT => -34
	},
	{#State 104
		DEFAULT => -5
	},
	{#State 105
		DEFAULT => -6
	},
	{#State 106
		ACTIONS => {
			'QuotedURI' => 26,
			'NSPrefix' => 29
		},
		GOTOS => {
			'URI' => 25,
			'SourceSelector' => 153,
			'QName' => 28
		}
	},
	{#State 107
		DEFAULT => -93
	},
	{#State 108
		DEFAULT => -10
	},
	{#State 109
		ACTIONS => {
			"?" => 18,
			'QuotedURI' => 26,
			'NSPrefix' => 29
		},
		GOTOS => {
			'URI' => 62,
			'QName' => 28,
			'VarOrURI' => 154,
			'Var' => 61
		}
	},
	{#State 110
		ACTIONS => {
			"(" => 48
		},
		GOTOS => {
			'TriplePattern' => 155,
			'LPAREN' => 46
		}
	},
	{#State 111
		DEFAULT => -69
	},
	{#State 112
		ACTIONS => {
			"-" => 64,
			'STRING_LITERAL1' => 79,
			"?" => 18,
			"+" => 87,
			"~" => 69,
			'INTEGER_LITERAL' => 88,
			"!" => 73,
			"(" => 48,
			'BOOLEAN_LITERAL' => 81,
			'QuotedURI' => 26,
			'STRING_LITERAL2' => 76,
			'FLOATING_POINT_LITERAL' => 97,
			'NULL_LITERAL' => 85,
			'NSPrefix' => 29
		},
		GOTOS => {
			'BANG' => 66,
			'BooleanLiteral' => 65,
			'UnaryExpressionNotPlusMinus' => 67,
			'MINUS' => 86,
			'RelationalExpression' => 156,
			'LPAREN' => 70,
			'MultiplicativeExpression' => 72,
			'PLUS' => 71,
			'TextLiteral' => 74,
			'QName' => 28,
			'NumericLiteral' => 77,
			'Var' => 78,
			'URI' => 93,
			'NullLiteral' => 80,
			'PrimaryExpression' => 82,
			'TILDE' => 83,
			'UnaryExpression' => 84,
			'AdditiveExpression' => 96,
			'Const' => 98
		}
	},
	{#State 113
		DEFAULT => -122
	},
	{#State 114
		ACTIONS => {
			"-" => 64,
			'STRING_LITERAL1' => 79,
			"?" => 18,
			"+" => 87,
			"~" => 69,
			'INTEGER_LITERAL' => 88,
			"!" => 73,
			"(" => 48,
			'BOOLEAN_LITERAL' => 81,
			'QuotedURI' => 26,
			'STRING_LITERAL2' => 76,
			'FLOATING_POINT_LITERAL' => 97,
			'NULL_LITERAL' => 85,
			'NSPrefix' => 29
		},
		GOTOS => {
			'BANG' => 66,
			'BooleanLiteral' => 65,
			'UnaryExpressionNotPlusMinus' => 67,
			'MINUS' => 86,
			'RelationalExpression' => 157,
			'LPAREN' => 70,
			'MultiplicativeExpression' => 72,
			'PLUS' => 71,
			'TextLiteral' => 74,
			'QName' => 28,
			'NumericLiteral' => 77,
			'Var' => 78,
			'URI' => 93,
			'NullLiteral' => 80,
			'PrimaryExpression' => 82,
			'TILDE' => 83,
			'UnaryExpression' => 84,
			'AdditiveExpression' => 96,
			'Const' => 98
		}
	},
	{#State 115
		DEFAULT => -123
	},
	{#State 116
		ACTIONS => {
			")" => 159
		},
		GOTOS => {
			'RPAREN' => 158
		}
	},
	{#State 117
		DEFAULT => -66
	},
	{#State 118
		ACTIONS => {
			"-" => 64,
			'STRING_LITERAL1' => 79,
			"?" => 18,
			"+" => 87,
			"~" => 69,
			'INTEGER_LITERAL' => 88,
			"!" => 73,
			"(" => 48,
			'BOOLEAN_LITERAL' => 81,
			'QuotedURI' => 26,
			'STRING_LITERAL2' => 76,
			'FLOATING_POINT_LITERAL' => 97,
			'NULL_LITERAL' => 85,
			'NSPrefix' => 29
		},
		GOTOS => {
			'BANG' => 66,
			'BooleanLiteral' => 65,
			'UnaryExpressionNotPlusMinus' => 67,
			'MINUS' => 86,
			'LPAREN' => 70,
			'MultiplicativeExpression' => 160,
			'PLUS' => 71,
			'TextLiteral' => 74,
			'QName' => 28,
			'NumericLiteral' => 77,
			'Var' => 78,
			'URI' => 93,
			'NullLiteral' => 80,
			'PrimaryExpression' => 82,
			'TILDE' => 83,
			'UnaryExpression' => 84,
			'Const' => 98
		}
	},
	{#State 119
		ACTIONS => {
			"-" => 64,
			'STRING_LITERAL1' => 79,
			"?" => 18,
			"+" => 87,
			"~" => 69,
			'INTEGER_LITERAL' => 88,
			"!" => 73,
			"(" => 48,
			'BOOLEAN_LITERAL' => 81,
			'QuotedURI' => 26,
			'STRING_LITERAL2' => 76,
			'FLOATING_POINT_LITERAL' => 97,
			'NULL_LITERAL' => 85,
			'NSPrefix' => 29
		},
		GOTOS => {
			'BANG' => 66,
			'BooleanLiteral' => 65,
			'UnaryExpressionNotPlusMinus' => 67,
			'MINUS' => 86,
			'LPAREN' => 70,
			'MultiplicativeExpression' => 161,
			'PLUS' => 71,
			'TextLiteral' => 74,
			'QName' => 28,
			'NumericLiteral' => 77,
			'Var' => 78,
			'URI' => 93,
			'NullLiteral' => 80,
			'PrimaryExpression' => 82,
			'TILDE' => 83,
			'UnaryExpression' => 84,
			'Const' => 98
		}
	},
	{#State 120
		DEFAULT => -141
	},
	{#State 121
		ACTIONS => {
			"where" => 21,
			"SELECT" => 1,
			'IDENTIFIER' => 37,
			"eq" => 31,
			'FOR' => 32,
			"WHERE" => 23,
			'PREFIXES' => 33,
			"source" => 14,
			"NE" => 34,
			"FROM" => 10,
			"SOURCE" => 12,
			"from" => 13,
			"select" => 6,
			"EQ" => 36,
			"ne" => 42
		},
		GOTOS => {
			'FROM' => 39,
			'WHERE' => 40,
			'Identifier' => 162,
			'SELECT' => 43,
			'SOURCE' => 44,
			'STR_NE' => 35,
			'STR_EQ' => 38
		}
	},
	{#State 122
		ACTIONS => {
			"^^" => 165
		},
		DEFAULT => -85,
		GOTOS => {
			'DATATYPE' => 163,
			't11Opt' => 164
		}
	},
	{#State 123
		ACTIONS => {
			"^^" => 165
		},
		DEFAULT => -85,
		GOTOS => {
			'DATATYPE' => 163,
			't11Opt' => 166
		}
	},
	{#State 124
		DEFAULT => -68
	},
	{#State 125
		DEFAULT => -136
	},
	{#State 126
		ACTIONS => {
			"-" => 64,
			'STRING_LITERAL1' => 79,
			"?" => 18,
			"+" => 87,
			"~" => 69,
			'INTEGER_LITERAL' => 88,
			"!" => 73,
			"(" => 48,
			'BOOLEAN_LITERAL' => 81,
			'QuotedURI' => 26,
			'STRING_LITERAL2' => 76,
			'FLOATING_POINT_LITERAL' => 97,
			'NULL_LITERAL' => 85,
			'NSPrefix' => 29
		},
		GOTOS => {
			'BANG' => 66,
			'BooleanLiteral' => 65,
			'UnaryExpressionNotPlusMinus' => 67,
			'MINUS' => 86,
			'LPAREN' => 70,
			'MultiplicativeExpression' => 167,
			'PLUS' => 71,
			'TextLiteral' => 74,
			'QName' => 28,
			'NumericLiteral' => 77,
			'Var' => 78,
			'URI' => 93,
			'NullLiteral' => 80,
			'PrimaryExpression' => 82,
			'TILDE' => 83,
			'UnaryExpression' => 84,
			'Const' => 98
		}
	},
	{#State 127
		ACTIONS => {
			"-" => 64,
			'STRING_LITERAL1' => 79,
			"?" => 18,
			"+" => 87,
			"~" => 69,
			'INTEGER_LITERAL' => 88,
			"!" => 73,
			"(" => 48,
			'BOOLEAN_LITERAL' => 81,
			'QuotedURI' => 26,
			'STRING_LITERAL2' => 76,
			'FLOATING_POINT_LITERAL' => 97,
			'NULL_LITERAL' => 85,
			'NSPrefix' => 29
		},
		GOTOS => {
			'BANG' => 66,
			'BooleanLiteral' => 65,
			'UnaryExpressionNotPlusMinus' => 67,
			'MINUS' => 86,
			'LPAREN' => 70,
			'MultiplicativeExpression' => 168,
			'PLUS' => 71,
			'TextLiteral' => 74,
			'QName' => 28,
			'NumericLiteral' => 77,
			'Var' => 78,
			'URI' => 93,
			'NullLiteral' => 80,
			'PrimaryExpression' => 82,
			'TILDE' => 83,
			'UnaryExpression' => 84,
			'Const' => 98
		}
	},
	{#State 128
		ACTIONS => {
			"-" => 64,
			'STRING_LITERAL1' => 79,
			"?" => 18,
			"+" => 87,
			"~" => 69,
			'INTEGER_LITERAL' => 88,
			"!" => 73,
			"(" => 48,
			'BOOLEAN_LITERAL' => 81,
			'QuotedURI' => 26,
			'STRING_LITERAL2' => 76,
			'FLOATING_POINT_LITERAL' => 97,
			'NULL_LITERAL' => 85,
			'NSPrefix' => 29
		},
		GOTOS => {
			'BANG' => 66,
			'BooleanLiteral' => 65,
			'UnaryExpressionNotPlusMinus' => 67,
			'MINUS' => 86,
			'LPAREN' => 70,
			'MultiplicativeExpression' => 169,
			'PLUS' => 71,
			'TextLiteral' => 74,
			'QName' => 28,
			'NumericLiteral' => 77,
			'Var' => 78,
			'URI' => 93,
			'NullLiteral' => 80,
			'PrimaryExpression' => 82,
			'TILDE' => 83,
			'UnaryExpression' => 84,
			'Const' => 98
		}
	},
	{#State 129
		DEFAULT => -135
	},
	{#State 130
		DEFAULT => -67
	},
	{#State 131
		ACTIONS => {
			"AND" => 50,
			"," => 57,
			"and" => 52
		},
		DEFAULT => -23,
		GOTOS => {
			'AND' => 170,
			'COMMA' => 171
		}
	},
	{#State 132
		ACTIONS => {
			"-" => 64,
			'STRING_LITERAL1' => 79,
			"?" => 18,
			"+" => 87,
			"~" => 69,
			'INTEGER_LITERAL' => 88,
			'BOOLEAN_LITERAL' => 81,
			"!" => 73,
			"(" => 48,
			'QuotedURI' => 26,
			'PATTERN_LITERAL' => 75,
			'STRING_LITERAL2' => 76,
			'FLOATING_POINT_LITERAL' => 97,
			'NULL_LITERAL' => 85,
			'NSPrefix' => 29
		},
		GOTOS => {
			'BANG' => 66,
			'BooleanLiteral' => 65,
			'UnaryExpressionNotPlusMinus' => 67,
			'MINUS' => 86,
			'RelationalExpression' => 68,
			'LPAREN' => 70,
			'MultiplicativeExpression' => 72,
			'PLUS' => 71,
			'EqualityExpression' => 89,
			'TextLiteral' => 74,
			'QName' => 28,
			'NumericLiteral' => 77,
			'Var' => 78,
			'PatternLiteral' => 92,
			'URI' => 93,
			'ArithmeticCondition' => 94,
			'NullLiteral' => 80,
			'PrimaryExpression' => 82,
			'TILDE' => 83,
			'UnaryExpression' => 84,
			'AdditiveExpression' => 96,
			'Const' => 98,
			'StringEqualityExpression' => 172
		}
	},
	{#State 133
		DEFAULT => -138
	},
	{#State 134
		DEFAULT => -137
	},
	{#State 135
		DEFAULT => -139
	},
	{#State 136
		ACTIONS => {
			"-" => 64,
			'STRING_LITERAL1' => 79,
			"?" => 18,
			"+" => 87,
			"~" => 69,
			'INTEGER_LITERAL' => 88,
			'BOOLEAN_LITERAL' => 81,
			"!" => 73,
			"(" => 48,
			'QuotedURI' => 26,
			'PATTERN_LITERAL' => 75,
			'STRING_LITERAL2' => 76,
			'FLOATING_POINT_LITERAL' => 97,
			'NULL_LITERAL' => 85,
			'NSPrefix' => 29
		},
		GOTOS => {
			'BANG' => 66,
			'BooleanLiteral' => 65,
			'UnaryExpressionNotPlusMinus' => 67,
			'MINUS' => 86,
			'RelationalExpression' => 68,
			'LPAREN' => 70,
			'MultiplicativeExpression' => 72,
			'PLUS' => 71,
			'EqualityExpression' => 89,
			'TextLiteral' => 74,
			'QName' => 28,
			'NumericLiteral' => 77,
			'Var' => 78,
			'PatternLiteral' => 92,
			'URI' => 93,
			'ArithmeticCondition' => 94,
			'NullLiteral' => 80,
			'PrimaryExpression' => 82,
			'TILDE' => 83,
			'UnaryExpression' => 84,
			'AdditiveExpression' => 96,
			'Const' => 98,
			'StringEqualityExpression' => 173
		}
	},
	{#State 137
		ACTIONS => {
			"-" => 64,
			'STRING_LITERAL1' => 79,
			"?" => 18,
			"+" => 87,
			"~" => 69,
			'INTEGER_LITERAL' => 88,
			'BOOLEAN_LITERAL' => 81,
			"!" => 73,
			"(" => 48,
			'QuotedURI' => 26,
			'PATTERN_LITERAL' => 75,
			'STRING_LITERAL2' => 76,
			'FLOATING_POINT_LITERAL' => 97,
			'NULL_LITERAL' => 85,
			'NSPrefix' => 29
		},
		GOTOS => {
			'BANG' => 66,
			'BooleanLiteral' => 65,
			'UnaryExpressionNotPlusMinus' => 67,
			'MINUS' => 86,
			'RelationalExpression' => 68,
			'LPAREN' => 70,
			'MultiplicativeExpression' => 72,
			'PLUS' => 71,
			'EqualityExpression' => 89,
			'TextLiteral' => 74,
			'QName' => 28,
			'NumericLiteral' => 77,
			'Var' => 78,
			'PatternLiteral' => 92,
			'URI' => 93,
			'ArithmeticCondition' => 94,
			'NullLiteral' => 80,
			'PrimaryExpression' => 82,
			'TILDE' => 83,
			'UnaryExpression' => 84,
			'AdditiveExpression' => 96,
			'Const' => 98,
			'StringEqualityExpression' => 174
		}
	},
	{#State 138
		ACTIONS => {
			"-" => 64,
			'STRING_LITERAL1' => 79,
			"?" => 18,
			"+" => 87,
			"~" => 69,
			'INTEGER_LITERAL' => 88,
			'BOOLEAN_LITERAL' => 81,
			"!" => 73,
			"(" => 48,
			'QuotedURI' => 26,
			'PATTERN_LITERAL' => 75,
			'STRING_LITERAL2' => 76,
			'FLOATING_POINT_LITERAL' => 97,
			'NULL_LITERAL' => 85,
			'NSPrefix' => 29
		},
		GOTOS => {
			'BANG' => 66,
			'BooleanLiteral' => 65,
			'UnaryExpressionNotPlusMinus' => 67,
			'MINUS' => 86,
			'RelationalExpression' => 68,
			'LPAREN' => 70,
			'MultiplicativeExpression' => 72,
			'PLUS' => 71,
			'EqualityExpression' => 89,
			'TextLiteral' => 74,
			'QName' => 28,
			'NumericLiteral' => 77,
			'Var' => 78,
			'PatternLiteral' => 92,
			'URI' => 93,
			'ArithmeticCondition' => 94,
			'NullLiteral' => 80,
			'PrimaryExpression' => 82,
			'TILDE' => 83,
			'UnaryExpression' => 84,
			'AdditiveExpression' => 96,
			'Const' => 98,
			'StringEqualityExpression' => 175
		}
	},
	{#State 139
		DEFAULT => -126
	},
	{#State 140
		ACTIONS => {
			"-" => 64,
			'STRING_LITERAL1' => 79,
			"?" => 18,
			"+" => 87,
			"~" => 69,
			'INTEGER_LITERAL' => 88,
			'BOOLEAN_LITERAL' => 81,
			"!" => 73,
			"(" => 48,
			'QuotedURI' => 26,
			'PATTERN_LITERAL' => 75,
			'STRING_LITERAL2' => 76,
			'FLOATING_POINT_LITERAL' => 97,
			'NULL_LITERAL' => 85,
			'NSPrefix' => 29
		},
		GOTOS => {
			'BANG' => 66,
			'BooleanLiteral' => 65,
			'UnaryExpressionNotPlusMinus' => 67,
			'MINUS' => 86,
			'RelationalExpression' => 68,
			'LPAREN' => 70,
			'MultiplicativeExpression' => 72,
			'PLUS' => 71,
			'EqualityExpression' => 89,
			'TextLiteral' => 74,
			'QName' => 28,
			'NumericLiteral' => 77,
			'ConditionalOrExpression' => 176,
			'Var' => 78,
			'PatternLiteral' => 92,
			'URI' => 93,
			'ArithmeticCondition' => 94,
			'NullLiteral' => 80,
			'ConditionalAndExpression' => 95,
			'PrimaryExpression' => 82,
			'TILDE' => 83,
			'UnaryExpression' => 84,
			'AdditiveExpression' => 96,
			'Const' => 98,
			'StringEqualityExpression' => 99
		}
	},
	{#State 141
		DEFAULT => -119
	},
	{#State 142
		DEFAULT => -125
	},
	{#State 143
		DEFAULT => -124
	},
	{#State 144
		DEFAULT => -118
	},
	{#State 145
		ACTIONS => {
			"-" => 64,
			'STRING_LITERAL1' => 79,
			"?" => 18,
			"+" => 87,
			"~" => 69,
			'INTEGER_LITERAL' => 88,
			"!" => 73,
			"(" => 48,
			'BOOLEAN_LITERAL' => 81,
			'QuotedURI' => 26,
			'STRING_LITERAL2' => 76,
			'FLOATING_POINT_LITERAL' => 97,
			'NULL_LITERAL' => 85,
			'NSPrefix' => 29
		},
		GOTOS => {
			'BANG' => 66,
			'BooleanLiteral' => 65,
			'UnaryExpressionNotPlusMinus' => 67,
			'MINUS' => 86,
			'LPAREN' => 70,
			'MultiplicativeExpression' => 72,
			'PLUS' => 71,
			'TextLiteral' => 74,
			'QName' => 28,
			'NumericLiteral' => 77,
			'Var' => 78,
			'URI' => 93,
			'NullLiteral' => 80,
			'PrimaryExpression' => 82,
			'TILDE' => 83,
			'UnaryExpression' => 84,
			'AdditiveExpression' => 177,
			'Const' => 98
		}
	},
	{#State 146
		ACTIONS => {
			"-" => 64,
			'STRING_LITERAL1' => 79,
			"?" => 18,
			"+" => 87,
			"~" => 69,
			'INTEGER_LITERAL' => 88,
			"!" => 73,
			"(" => 48,
			'BOOLEAN_LITERAL' => 81,
			'QuotedURI' => 26,
			'STRING_LITERAL2' => 76,
			'FLOATING_POINT_LITERAL' => 97,
			'NULL_LITERAL' => 85,
			'NSPrefix' => 29
		},
		GOTOS => {
			'BANG' => 66,
			'BooleanLiteral' => 65,
			'UnaryExpressionNotPlusMinus' => 67,
			'MINUS' => 86,
			'LPAREN' => 70,
			'MultiplicativeExpression' => 72,
			'PLUS' => 71,
			'TextLiteral' => 74,
			'QName' => 28,
			'NumericLiteral' => 77,
			'Var' => 78,
			'URI' => 93,
			'NullLiteral' => 80,
			'PrimaryExpression' => 82,
			'TILDE' => 83,
			'UnaryExpression' => 84,
			'AdditiveExpression' => 178,
			'Const' => 98
		}
	},
	{#State 147
		ACTIONS => {
			"-" => 64,
			'STRING_LITERAL1' => 79,
			"?" => 18,
			"+" => 87,
			"~" => 69,
			'INTEGER_LITERAL' => 88,
			"!" => 73,
			"(" => 48,
			'BOOLEAN_LITERAL' => 81,
			'QuotedURI' => 26,
			'STRING_LITERAL2' => 76,
			'FLOATING_POINT_LITERAL' => 97,
			'NULL_LITERAL' => 85,
			'NSPrefix' => 29
		},
		GOTOS => {
			'BANG' => 66,
			'BooleanLiteral' => 65,
			'UnaryExpressionNotPlusMinus' => 67,
			'MINUS' => 86,
			'LPAREN' => 70,
			'MultiplicativeExpression' => 72,
			'PLUS' => 71,
			'TextLiteral' => 74,
			'QName' => 28,
			'NumericLiteral' => 77,
			'Var' => 78,
			'URI' => 93,
			'NullLiteral' => 80,
			'PrimaryExpression' => 82,
			'TILDE' => 83,
			'UnaryExpression' => 84,
			'AdditiveExpression' => 179,
			'Const' => 98
		}
	},
	{#State 148
		ACTIONS => {
			"-" => 64,
			'STRING_LITERAL1' => 79,
			"?" => 18,
			"+" => 87,
			"~" => 69,
			'INTEGER_LITERAL' => 88,
			"!" => 73,
			"(" => 48,
			'BOOLEAN_LITERAL' => 81,
			'QuotedURI' => 26,
			'STRING_LITERAL2' => 76,
			'FLOATING_POINT_LITERAL' => 97,
			'NULL_LITERAL' => 85,
			'NSPrefix' => 29
		},
		GOTOS => {
			'BANG' => 66,
			'BooleanLiteral' => 65,
			'UnaryExpressionNotPlusMinus' => 67,
			'MINUS' => 86,
			'LPAREN' => 70,
			'MultiplicativeExpression' => 72,
			'PLUS' => 71,
			'TextLiteral' => 74,
			'QName' => 28,
			'NumericLiteral' => 77,
			'Var' => 78,
			'URI' => 93,
			'NullLiteral' => 80,
			'PrimaryExpression' => 82,
			'TILDE' => 83,
			'UnaryExpression' => 84,
			'AdditiveExpression' => 180,
			'Const' => 98
		}
	},
	{#State 149
		ACTIONS => {
			"-" => 64,
			'STRING_LITERAL1' => 79,
			"?" => 18,
			"+" => 87,
			"~" => 69,
			'INTEGER_LITERAL' => 88,
			'BOOLEAN_LITERAL' => 81,
			"!" => 73,
			"(" => 48,
			'QuotedURI' => 26,
			'PATTERN_LITERAL' => 75,
			'STRING_LITERAL2' => 76,
			'FLOATING_POINT_LITERAL' => 97,
			'NULL_LITERAL' => 85,
			'NSPrefix' => 29
		},
		GOTOS => {
			'BANG' => 66,
			'BooleanLiteral' => 65,
			'UnaryExpressionNotPlusMinus' => 67,
			'MINUS' => 86,
			'RelationalExpression' => 68,
			'LPAREN' => 70,
			'MultiplicativeExpression' => 72,
			'PLUS' => 71,
			'EqualityExpression' => 89,
			'TextLiteral' => 74,
			'QName' => 28,
			'NumericLiteral' => 77,
			'Var' => 78,
			'PatternLiteral' => 92,
			'URI' => 93,
			'ArithmeticCondition' => 94,
			'NullLiteral' => 80,
			'ConditionalAndExpression' => 181,
			'PrimaryExpression' => 82,
			'TILDE' => 83,
			'UnaryExpression' => 84,
			'AdditiveExpression' => 96,
			'Const' => 98,
			'StringEqualityExpression' => 99
		}
	},
	{#State 150
		DEFAULT => -127
	},
	{#State 151
		DEFAULT => -36,
		GOTOS => {
			't4Star' => 182
		}
	},
	{#State 152
		ACTIONS => {
			'FOR' => 183
		}
	},
	{#State 153
		DEFAULT => -16
	},
	{#State 154
		ACTIONS => {
			"," => 57
		},
		DEFAULT => -2,
		GOTOS => {
			'COMMA' => 59,
			'CommaOpt' => 184
		}
	},
	{#State 155
		DEFAULT => -20
	},
	{#State 156
		DEFAULT => -52
	},
	{#State 157
		DEFAULT => -51
	},
	{#State 158
		DEFAULT => -73
	},
	{#State 159
		DEFAULT => -116
	},
	{#State 160
		DEFAULT => -59
	},
	{#State 161
		DEFAULT => -60
	},
	{#State 162
		DEFAULT => -84
	},
	{#State 163
		ACTIONS => {
			'QuotedURI' => 26,
			'NSPrefix' => 29
		},
		GOTOS => {
			'URI' => 185,
			'QName' => 28
		}
	},
	{#State 164
		DEFAULT => -82
	},
	{#State 165
		DEFAULT => -140
	},
	{#State 166
		DEFAULT => -81
	},
	{#State 167
		DEFAULT => -63
	},
	{#State 168
		DEFAULT => -64
	},
	{#State 169
		DEFAULT => -62
	},
	{#State 170
		ACTIONS => {
			"-" => 64,
			'STRING_LITERAL1' => 79,
			"?" => 18,
			"+" => 87,
			"~" => 69,
			'INTEGER_LITERAL' => 88,
			'BOOLEAN_LITERAL' => 81,
			"!" => 73,
			"(" => 48,
			'QuotedURI' => 26,
			'PATTERN_LITERAL' => 75,
			'STRING_LITERAL2' => 76,
			'FLOATING_POINT_LITERAL' => 97,
			'NULL_LITERAL' => 85,
			'NSPrefix' => 29
		},
		GOTOS => {
			'BANG' => 66,
			'BooleanLiteral' => 65,
			'UnaryExpressionNotPlusMinus' => 67,
			'MINUS' => 86,
			'RelationalExpression' => 68,
			'LPAREN' => 70,
			'MultiplicativeExpression' => 72,
			'PLUS' => 71,
			'EqualityExpression' => 89,
			'TextLiteral' => 74,
			'QName' => 28,
			'NumericLiteral' => 77,
			'ConditionalOrExpression' => 90,
			'Var' => 78,
			'Expression' => 186,
			'PatternLiteral' => 92,
			'URI' => 93,
			'ArithmeticCondition' => 94,
			'NullLiteral' => 80,
			'ConditionalAndExpression' => 95,
			'PrimaryExpression' => 82,
			'TILDE' => 83,
			'UnaryExpression' => 84,
			'AdditiveExpression' => 96,
			'Const' => 98,
			'StringEqualityExpression' => 99
		}
	},
	{#State 171
		ACTIONS => {
			"-" => 64,
			'STRING_LITERAL1' => 79,
			"?" => 18,
			"+" => 87,
			"~" => 69,
			'INTEGER_LITERAL' => 88,
			'BOOLEAN_LITERAL' => 81,
			"!" => 73,
			"(" => 48,
			'QuotedURI' => 26,
			'PATTERN_LITERAL' => 75,
			'STRING_LITERAL2' => 76,
			'FLOATING_POINT_LITERAL' => 97,
			'NULL_LITERAL' => 85,
			'NSPrefix' => 29
		},
		GOTOS => {
			'BANG' => 66,
			'BooleanLiteral' => 65,
			'UnaryExpressionNotPlusMinus' => 67,
			'MINUS' => 86,
			'RelationalExpression' => 68,
			'LPAREN' => 70,
			'MultiplicativeExpression' => 72,
			'PLUS' => 71,
			'EqualityExpression' => 89,
			'TextLiteral' => 74,
			'QName' => 28,
			'NumericLiteral' => 77,
			'ConditionalOrExpression' => 90,
			'Var' => 78,
			'Expression' => 187,
			'PatternLiteral' => 92,
			'URI' => 93,
			'ArithmeticCondition' => 94,
			'NullLiteral' => 80,
			'ConditionalAndExpression' => 95,
			'PrimaryExpression' => 82,
			'TILDE' => 83,
			'UnaryExpression' => 84,
			'AdditiveExpression' => 96,
			'Const' => 98,
			'StringEqualityExpression' => 99
		}
	},
	{#State 172
		DEFAULT => -47
	},
	{#State 173
		DEFAULT => -48
	},
	{#State 174
		DEFAULT => -46
	},
	{#State 175
		DEFAULT => -45
	},
	{#State 176
		DEFAULT => -41
	},
	{#State 177
		DEFAULT => -57
	},
	{#State 178
		DEFAULT => -55
	},
	{#State 179
		DEFAULT => -54
	},
	{#State 180
		DEFAULT => -56
	},
	{#State 181
		DEFAULT => -43
	},
	{#State 182
		ACTIONS => {
			'' => -35,
			"," => 57
		},
		DEFAULT => -2,
		GOTOS => {
			'COMMA' => 59,
			'CommaOpt' => 188
		}
	},
	{#State 183
		ACTIONS => {
			'QuotedURI' => 189
		}
	},
	{#State 184
		ACTIONS => {
			'STRING_LITERAL1' => 79,
			"?" => 18,
			'INTEGER_LITERAL' => 88,
			'BOOLEAN_LITERAL' => 81,
			'QuotedURI' => 26,
			'STRING_LITERAL2' => 76,
			'FLOATING_POINT_LITERAL' => 97,
			'NULL_LITERAL' => 85,
			'NSPrefix' => 29
		},
		GOTOS => {
			'BooleanLiteral' => 65,
			'URI' => 93,
			'VarOrConst' => 191,
			'NullLiteral' => 80,
			'TextLiteral' => 74,
			'QName' => 28,
			'Const' => 192,
			'NumericLiteral' => 77,
			'Var' => 190
		}
	},
	{#State 185
		DEFAULT => -86
	},
	{#State 186
		DEFAULT => -26
	},
	{#State 187
		DEFAULT => -25
	},
	{#State 188
		ACTIONS => {
			"where" => 21,
			"SELECT" => 1,
			'IDENTIFIER' => 37,
			"eq" => 31,
			'FOR' => 32,
			"WHERE" => 23,
			'PREFIXES' => 33,
			"source" => 14,
			"NE" => 34,
			"FROM" => 10,
			"SOURCE" => 12,
			"from" => 13,
			"select" => 6,
			"EQ" => 36,
			"ne" => 42
		},
		GOTOS => {
			'PrefixDecl' => 193,
			'STR_NE' => 35,
			'STR_EQ' => 38,
			'FROM' => 39,
			'WHERE' => 40,
			'Identifier' => 152,
			'SELECT' => 43,
			'SOURCE' => 44
		}
	},
	{#State 189
		DEFAULT => -38
	},
	{#State 190
		DEFAULT => -30
	},
	{#State 191
		ACTIONS => {
			")" => 159
		},
		GOTOS => {
			'RPAREN' => 194
		}
	},
	{#State 192
		DEFAULT => -31
	},
	{#State 193
		DEFAULT => -37
	},
	{#State 194
		DEFAULT => -27
	}
],
                                  yyrules  =>
[
	[#Rule 0
		 '$start', 2, undef
	],
	[#Rule 1
		 'CompilationUnit', 1, undef
	],
	[#Rule 2
		 'CommaOpt', 0, undef
	],
	[#Rule 3
		 'CommaOpt', 1, undef
	],
	[#Rule 4
		 'QueryPlus', 1, undef
	],
	[#Rule 5
		 'QueryPlus', 5,
sub
#line 31 "RdqlParser.yp"
{
    $_[3]->setLastConstraints($_[4]);
    $_[0]->resolveQNames();
    if ($_[0]->YYData->{COLLECTSTAR}) {
	$_[0]->YYData->{COLLECTSTAR}->expandCollects();
    }
    [@{$_[2]}, $_[0]->YYData->{ALGAE2}->ask($_[3], undef), $_[1], @{$_[5]}];
}
	],
	[#Rule 6
		 'Query', 5,
sub
#line 43 "RdqlParser.yp"
{
    $_[3]->setLastConstraints($_[4]);
    $_[0]->resolveQNames();
    if ($_[0]->YYData->{COLLECTSTAR}) {
	$_[0]->YYData->{COLLECTSTAR}->expandCollects();
    }
    [@{$_[5]}, @{$_[2]}, $_[0]->YYData->{ALGAE2}->ask($_[3], undef), $_[1]];
}
	],
	[#Rule 7
		 'SelectClause', 3,
sub
#line 54 "RdqlParser.yp"
{
    $_[0]->YYData->{ALGAE2}->collect([$_[2], @{$_[3]}]);
}
	],
	[#Rule 8
		 'SelectClause', 2,
sub
#line 58 "RdqlParser.yp"
{
    $_[0]->YYData->{COLLECTSTAR} = $_[0]->YYData->{ALGAE2}->collectStar();
}
	],
	[#Rule 9
		 'CommaOptVarStar', 0,
sub
#line 64 "RdqlParser.yp"
{[]}
	],
	[#Rule 10
		 'CommaOptVarStar', 3,
sub
#line 66 "RdqlParser.yp"
{
    push (@{$_[1]}, $_[3]);
    $_[1];
}
	],
	[#Rule 11
		 'SourceClauseOpt', 0,
sub
#line 73 "RdqlParser.yp"
{[]}
	],
	[#Rule 12
		 'SourceClauseOpt', 1, undef
	],
	[#Rule 13
		 'SourceClause', 3,
sub
#line 78 "RdqlParser.yp"
{
    push (@{$_[3]}, $_[2]);
    $_[3];
}
	],
	[#Rule 14
		 'SourceClause', 3,
sub
#line 83 "RdqlParser.yp"
{
    push (@{$_[3]}, $_[2]);
    $_[3];
}
	],
	[#Rule 15
		 't1Star', 0, undef
	],
	[#Rule 16
		 't1Star', 3,
sub
#line 91 "RdqlParser.yp"
{
    push (@{$_[1]}, $_[3]);
    $_[1];
}
	],
	[#Rule 17
		 'SourceSelector', 1,
sub
#line 99 "RdqlParser.yp"
{
    $_[0]->YYData->{ALGAE2}->slurp($_[1], [], undef);
}
	],
	[#Rule 18
		 'TriplePatternClause', 3,
sub
#line 105 "RdqlParser.yp"
{
    $_[3] ? 
	new W3C::Rdf::AlgaeCompileTree::Conjunction($_[2], $_[3], $_[0]) : 
	$_[2];
}
	],
	[#Rule 19
		 't2Star', 0, undef
	],
	[#Rule 20
		 't2Star', 3,
sub
#line 114 "RdqlParser.yp"
{
    $_[1] ? 
	new W3C::Rdf::AlgaeCompileTree::Conjunction($_[1], $_[3], $_[0]) : 
	$_[3];
}
	],
	[#Rule 21
		 'ConstraintClauseOpt', 0,
sub
#line 122 "RdqlParser.yp"
{[]}
	],
	[#Rule 22
		 'ConstraintClauseOpt', 1, undef
	],
	[#Rule 23
		 'ConstraintClause', 3,
sub
#line 128 "RdqlParser.yp"
{
    push (@{$_[3]}, new W3C::Rdf::AlgaeCompileTree::Constraint($_[2], $_[0]));
    $_[3];
}
	],
	[#Rule 24
		 't3Star', 0,
sub
#line 135 "RdqlParser.yp"
{[]}
	],
	[#Rule 25
		 't3Star', 3,
sub
#line 137 "RdqlParser.yp"
{
    push (@{$_[1]}, 
	  new W3C::Rdf::AlgaeCompileTree::Constraint($_[3][0], $_[0]));
    $_[1];
}
	],
	[#Rule 26
		 't3Star', 3,
sub
#line 144 "RdqlParser.yp"
{
    push (@{$_[1]}, 
	  new W3C::Rdf::AlgaeCompileTree::Constraint($_[3][0], $_[0]));
    $_[1];
}
	],
	[#Rule 27
		 'TriplePattern', 7,
sub
#line 152 "RdqlParser.yp"
{
    $_[0]->newDecl([[$_[2], [[$_[4], [[$_[6]]]]]]]); # hugly re-use ack
}
	],
	[#Rule 28
		 'VarOrURI', 1, undef
	],
	[#Rule 29
		 'VarOrURI', 1, undef
	],
	[#Rule 30
		 'VarOrConst', 1, undef
	],
	[#Rule 31
		 'VarOrConst', 1, undef
	],
	[#Rule 32
		 'Var', 2,
sub
#line 166 "RdqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Var($_[2], 1, $_[0]);
}
	],
	[#Rule 33
		 'PrefixesClauseOpt', 0,
sub
#line 172 "RdqlParser.yp"
{[]}
	],
	[#Rule 34
		 'PrefixesClauseOpt', 1, undef
	],
	[#Rule 35
		 'PrefixesClause', 3,
sub
#line 178 "RdqlParser.yp"
{
    [$_[2], @{$_[3]}];
}
	],
	[#Rule 36
		 't4Star', 0,
sub
#line 184 "RdqlParser.yp"
{[]}
	],
	[#Rule 37
		 't4Star', 3,
sub
#line 186 "RdqlParser.yp"
{
    [@{$_[1]}, $_[3]];
}
	],
	[#Rule 38
		 'PrefixDecl', 3,
sub
#line 192 "RdqlParser.yp"
{
    $_[0]->YYData->{ALGAE2}->namespace($_[1], 
			    new W3C::Rdf::AlgaeCompileTree::Url($_[3], undef, $_[0]));
}
	],
	[#Rule 39
		 'Expression', 1, undef
	],
	[#Rule 40
		 'ConditionalOrExpression', 1, undef
	],
	[#Rule 41
		 'ConditionalOrExpression', 3,
sub
#line 203 "RdqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Or($_[1], $_[3], $_[0]);
}
	],
	[#Rule 42
		 'ConditionalAndExpression', 1, undef
	],
	[#Rule 43
		 'ConditionalAndExpression', 3,
sub
#line 210 "RdqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::And($_[1], $_[3], $_[0]);
}
	],
	[#Rule 44
		 'StringEqualityExpression', 1, undef
	],
	[#Rule 45
		 'StringEqualityExpression', 3,
sub
#line 217 "RdqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Eq($_[1], $_[3], $_[0]);
}
	],
	[#Rule 46
		 'StringEqualityExpression', 3,
sub
#line 221 "RdqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Ne($_[1], $_[3], $_[0]);
}
	],
	[#Rule 47
		 'StringEqualityExpression', 3,
sub
#line 225 "RdqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Glob($_[1], $_[3], $_[0]);
}
	],
	[#Rule 48
		 'StringEqualityExpression', 3,
sub
#line 229 "RdqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Not(
	 new W3C::Rdf::AlgaeCompileTree::Str_Glob($_[1], $_[3], $_[0]), $_[0]);
}
	],
	[#Rule 49
		 'ArithmeticCondition', 1, undef
	],
	[#Rule 50
		 'EqualityExpression', 1, undef
	],
	[#Rule 51
		 'EqualityExpression', 3,
sub
#line 240 "RdqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Eq($_[1], $_[3], $_[0]);
}
	],
	[#Rule 52
		 'EqualityExpression', 3,
sub
#line 244 "RdqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Ne($_[1], $_[3], $_[0]);
}
	],
	[#Rule 53
		 'RelationalExpression', 1, undef
	],
	[#Rule 54
		 'RelationalExpression', 3,
sub
#line 251 "RdqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Lt($_[1], $_[3], $_[0]);
}
	],
	[#Rule 55
		 'RelationalExpression', 3,
sub
#line 255 "RdqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Gt($_[1], $_[3], $_[0]);
}
	],
	[#Rule 56
		 'RelationalExpression', 3,
sub
#line 259 "RdqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Le($_[1], $_[3], $_[0]);
}
	],
	[#Rule 57
		 'RelationalExpression', 3,
sub
#line 263 "RdqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Ge($_[1], $_[3], $_[0]);
}
	],
	[#Rule 58
		 'AdditiveExpression', 1, undef
	],
	[#Rule 59
		 'AdditiveExpression', 3,
sub
#line 270 "RdqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Plus($_[1], $_[3], $_[0]);
}
	],
	[#Rule 60
		 'AdditiveExpression', 3,
sub
#line 274 "RdqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Minus($_[1], $_[3], $_[0]);
}
	],
	[#Rule 61
		 'MultiplicativeExpression', 1, undef
	],
	[#Rule 62
		 'MultiplicativeExpression', 3,
sub
#line 281 "RdqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Multiply($_[1], $_[3], $_[0]);
}
	],
	[#Rule 63
		 'MultiplicativeExpression', 3,
sub
#line 285 "RdqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Divide($_[1], $_[3], $_[0]);
}
	],
	[#Rule 64
		 'MultiplicativeExpression', 3,
sub
#line 289 "RdqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Modulo($_[1], $_[3], $_[0]);
}
	],
	[#Rule 65
		 'UnaryExpression', 1, undef
	],
	[#Rule 66
		 'UnaryExpression', 2,
sub
#line 296 "RdqlParser.yp"
{
    $_[2];
}
	],
	[#Rule 67
		 'UnaryExpression', 2,
sub
#line 300 "RdqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Neg($_[2], $_[0]);
}
	],
	[#Rule 68
		 'UnaryExpressionNotPlusMinus', 2,
sub
#line 306 "RdqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::BitFlip($_[2], $_[0]);
}
	],
	[#Rule 69
		 'UnaryExpressionNotPlusMinus', 2,
sub
#line 310 "RdqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Not($_[2], $_[0]);
}
	],
	[#Rule 70
		 'UnaryExpressionNotPlusMinus', 1, undef
	],
	[#Rule 71
		 'PrimaryExpression', 1, undef
	],
	[#Rule 72
		 'PrimaryExpression', 1, undef
	],
	[#Rule 73
		 'PrimaryExpression', 3, undef
	],
	[#Rule 74
		 'Const', 1, undef
	],
	[#Rule 75
		 'Const', 1, undef
	],
	[#Rule 76
		 'Const', 1,
sub
#line 324 "RdqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Literal($_[1], undef, undef, $_[0]);
}
	],
	[#Rule 77
		 'Const', 1, undef
	],
	[#Rule 78
		 'Const', 1, undef
	],
	[#Rule 79
		 'NumericLiteral', 1,
sub
#line 332 "RdqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Int($_[1], $_[0]);
}
	],
	[#Rule 80
		 'NumericLiteral', 1,
sub
#line 336 "RdqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Float($_[1], $_[0]);
}
	],
	[#Rule 81
		 'TextLiteral', 3, undef
	],
	[#Rule 82
		 'TextLiteral', 3, undef
	],
	[#Rule 83
		 't10Opt', 0, undef
	],
	[#Rule 84
		 't10Opt', 2, undef
	],
	[#Rule 85
		 't11Opt', 0, undef
	],
	[#Rule 86
		 't11Opt', 2, undef
	],
	[#Rule 87
		 'PatternLiteral', 1, undef
	],
	[#Rule 88
		 'BooleanLiteral', 1, undef
	],
	[#Rule 89
		 'NullLiteral', 1, undef
	],
	[#Rule 90
		 'URI', 1,
sub
#line 362 "RdqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Url($_[1], undef, $_[0]);
}
	],
	[#Rule 91
		 'URI', 1, undef
	],
	[#Rule 92
		 'QName', 2,
sub
#line 370 "RdqlParser.yp"
{
    my $r = new W3C::Rdf::AlgaeCompileTree::DelayedQName('',    $_[3], $_[0]);
    push (@{$_[0]->YYData->{QNAMES}}, $r);
    $r;
}
	],
	[#Rule 93
		 'QName', 3,
sub
#line 376 "RdqlParser.yp"
{
    my $r = new W3C::Rdf::AlgaeCompileTree::DelayedQName($_[1], $_[3], $_[0]);
    push (@{$_[0]->YYData->{QNAMES}}, $r);
    $r;
}
	],
	[#Rule 94
		 'Identifier', 1, undef
	],
	[#Rule 95
		 'Identifier', 1, undef
	],
	[#Rule 96
		 'Identifier', 1, undef
	],
	[#Rule 97
		 'Identifier', 1, undef
	],
	[#Rule 98
		 'Identifier', 1, undef
	],
	[#Rule 99
		 'Identifier', 1, undef
	],
	[#Rule 100
		 'Identifier', 1, undef
	],
	[#Rule 101
		 'Identifier', 1, undef
	],
	[#Rule 102
		 'Identifier', 1, undef
	],
	[#Rule 103
		 'SELECT', 1, undef
	],
	[#Rule 104
		 'SELECT', 1, undef
	],
	[#Rule 105
		 'FROM', 1, undef
	],
	[#Rule 106
		 'FROM', 1, undef
	],
	[#Rule 107
		 'SOURCE', 1, undef
	],
	[#Rule 108
		 'SOURCE', 1, undef
	],
	[#Rule 109
		 'WHERE', 1, undef
	],
	[#Rule 110
		 'WHERE', 1, undef
	],
	[#Rule 111
		 'AND', 1, undef
	],
	[#Rule 112
		 'AND', 1, undef
	],
	[#Rule 113
		 'USING', 1, undef
	],
	[#Rule 114
		 'USING', 1, undef
	],
	[#Rule 115
		 'LPAREN', 1, undef
	],
	[#Rule 116
		 'RPAREN', 1, undef
	],
	[#Rule 117
		 'COMMA', 1, undef
	],
	[#Rule 118
		 'GT', 1, undef
	],
	[#Rule 119
		 'LT', 1, undef
	],
	[#Rule 120
		 'BANG', 1, undef
	],
	[#Rule 121
		 'TILDE', 1, undef
	],
	[#Rule 122
		 'EQ', 1, undef
	],
	[#Rule 123
		 'NEQ', 1, undef
	],
	[#Rule 124
		 'LE', 1, undef
	],
	[#Rule 125
		 'GE', 1, undef
	],
	[#Rule 126
		 'SC_OR', 1, undef
	],
	[#Rule 127
		 'SC_AND', 1, undef
	],
	[#Rule 128
		 'STR_EQ', 1, undef
	],
	[#Rule 129
		 'STR_EQ', 1, undef
	],
	[#Rule 130
		 'STR_NE', 1, undef
	],
	[#Rule 131
		 'STR_NE', 1, undef
	],
	[#Rule 132
		 'PLUS', 1, undef
	],
	[#Rule 133
		 'MINUS', 1, undef
	],
	[#Rule 134
		 'STAR', 1, undef
	],
	[#Rule 135
		 'SLASH', 1, undef
	],
	[#Rule 136
		 'REM', 1, undef
	],
	[#Rule 137
		 'STR_MATCH', 1, undef
	],
	[#Rule 138
		 'STR_MATCH', 1, undef
	],
	[#Rule 139
		 'STR_NMATCH', 1, undef
	],
	[#Rule 140
		 'DATATYPE', 1, undef
	],
	[#Rule 141
		 'AT', 1, undef
	]
],
                                  @_);
    bless($self,$class);
}

#line 446 "RdqlParser.yp"


#BEGIN {unshift@INC,('../..');}
use W3C::Util::Exception qw(&throw &catch);

#QuotedURI:			'<' URI characters (from RFC 2396) '>';
#NSPrefix:			NCName As defined in XML Namespace v1.1 and XML 1.1;
#LocalPart:			NCName As defined in XML Namespace v1.1 and XML 1.1;
#Identifier:			([a-z][A-Z][0-9][-_.])+;
#EOF:				End of file -- implicit in parser style
#INTEGER_LITERAL:		([0-9])+;
#FLOATING_POINT_LITERAL:	([0-9])*'.'([0-9])+('e'('+'|'-')?([0-9])+)?;
#STRING_LITERAL1:		'"'UTF-8 characters'"' (with escaped \");
#STRING_LITERAL2:		"'"UTF-8 characters"'" (with escaped \');

my ($QuotedURI, $NSPrefix, $LocalPart, $Identifier, 
    $INTEGER_LITERAL, $FLOATING_POINT_LITERAL, 
    $STRING_LITERAL1, $STRING_LITERAL2) = 
    (\ 'QuotedURI', \ 'NSPrefix', \ 'LocalPart', \ 'Identifier', 
     \ 'INTEGER_LITERAL', \ 'FLOATING_POINT_LITERAL', 
     \ 'STRING_LITERAL1', \ 'STRING_LITERAL2');

my %KeyWords = ('select' => 'SELECT', 'SELECT' => 'SELECT', 
		'where' => 'WHERE', 'WHERE' => 'WHERE', 
		'using' => 'USING', 'USING' => 'USING', 
		'for' => 'FOR', 'FOR' => 'FOR' , 
		'and' => 'AND', 'AND' => 'AND', 
		'from' => 'FROM', 'FROM' => 'FROM');

sub _Error {
    my ($self) = @_;
    if (exists $self->YYData->{EXCEPTION}) {
	&throw($self->YYData->{EXCEPTION});
    }
    if (exists $self->YYData->{ERRMSG}) {
	&throw(new W3C::Util::YappDriver::GrammarException(
				      -message => $self->YYData->{ERRMSG}, 
				      -location => $self->YYData->{LOCATION}));
        delete $self->YYData->{ERRMSG};
        return;
    }
    &throw(new W3C::Util::YappDriver::MesgYappContextException($self, 
				      -location => $self->YYData->{LOCATION}));
}

sub _Lexer {
    my($self)=shift;

    if (defined $self->YYData->{INPUT} && 
	pos $self->YYData->{INPUT} < length ($self->YYData->{INPUT})) {
    } else {
	if ($self->YYData->{my_DONE}) {
	    return ('', undef);
	}
	if (0) {
	if (!($self->YYData->{INPUT} = $self->nextChunk())) {
	    undef $self->YYData->{INPUT};
	    return ('', undef);
	}
	} else {
	my $pos = pos $self->YYData->{INPUT};
	my $chunk = $self->nextChunk();
	#print "\nchunk: $chunk\n";
	if (!$chunk) {
	    undef $self->YYData->{INPUT};
	    return ('', undef);
	}
	$self->YYData->{INPUT} .= $chunk;
	pos $self->YYData->{INPUT} = $pos;
	}
	#my $txt = $self->YYData->{INPUT};
	#print "\ntxt: $txt\n";
    }

    my ($token, $value) = ('', undef);
    while ($self->YYData->{INPUT} =~ m/\G\s*\#[^\n]*\n/gc) {}
    $self->YYData->{INPUT} =~ m/\G\s*/gc;
    $self->YYData->{my_LASTPOS} = pos $self->YYData->{INPUT};
    my $expect = $self->YYData->{NEXT};
#EOF:				End of file -- implicit in parser style
    if ($expect eq ':') {
	#LocalPart:		NCName As defined in XML Namespace v1.1 and XML 1.1;
	if ($self->YYData->{INPUT} =~ m/\G:/gc) {
	    if ($self->YYData->{INPUT} =~ m/\G(?=[A-Za-z][A-Za-z0-9_-])/gc) {
		$self->YYData->{NEXT} = 'LocalPart';
	    } else {
		$self->YYData->{NEXT} = undef;
	    }
	    ($token, $value) = (':', ':');
	} else {
	    &throw();
	}
    } elsif ($expect eq 'LocalPart') {
	#LocalPart:		NCName As defined in XML Namespace v1.1 and XML 1.1;
	if ($self->YYData->{INPUT} =~ m/\G([A-Za-z][A-Za-z0-9_-]*)/gc) {
	    ($token, $value) = ('LocalPart', $1);
	} else {
	    &throw();
	}
	$self->YYData->{NEXT} = undef;
#QuotedURI:			'<' URI characters (from RFC 2396) '>';
    } elsif ($self->YYData->{INPUT} =~ m/\G<([^>]+)>/gc) {
	($token, $value) = ('QuotedURI', $1);
#NSPrefix:			NCName As defined in XML Namespace v1.1 and XML 1.1;
    } elsif ($self->YYData->{INPUT} =~ m/\G([A-Za-z][A-Za-z0-9_-]*)(?=:)/gc) {
	($token, $value) = ('NSPrefix', $1);
	$self->YYData->{NEXT} = ':';
#INTEGER_LITERAL:		([0-9])+;
    } elsif ($self->YYData->{INPUT} =~ m/\G([0-9]+)/gc) {
	($token, $value) = ('INTEGER_LITERAL',$1);
#FLOATING_POINT_LITERAL:	([0-9])*'.'([0-9])+('e'('+'|'-')?([0-9])+)?;
    } elsif ($self->YYData->{INPUT} =~ m/\G((?:[0-9])*'.'(?:[0-9])+(?:'e'(?:'+'|'-')?(?:[0-9])+)?)/gc) {
	($token, $value) = ('FLOATING_POINT_LITERAL',$1);
#Identifier:			([a-z][A-Z][0-9][-_.])+;
    } elsif ($self->YYData->{INPUT} =~ m/\G((?:[a-zA-Z0-9\_\.-])+)/gc) {
	($token, $value) = ($KeyWords{lc $1} || 'IDENTIFIER', $1);
#STRING_LITERAL1:		'"'UTF-8 characters'"' (with escaped \");
    } elsif ($self->YYData->{INPUT} =~ m/\G\"([^\"]*)\"/gc) {
	my $str = $1;
	while (substr($str, length($str) - 1, 1) eq '"') {
	    if ($self->YYData->{INPUT} =~ m/\G([^\"]*)\"/gc) {
		$str = substr($str, 0, length($str) - 1).$1;
	    } else {
		&throw(new W3C::Util::YappDriver::MesgYappContextException($self, 
					-location => $self->YYData->{LOCATION}));
	    }
	}
	($token, $value) = ('STRING_LITERAL1', $str);
#STRING_LITERAL2:		"'"UTF-8 characters"'" (with escaped \');
    } elsif ($self->YYData->{INPUT} =~ m/\G\'([^\']*)\'/gc) {
	my $str = $1;
	while (substr($str, length($str) - 1, 1) eq "'") {
	    if ($self->YYData->{INPUT} =~ m/\G([^\']*)\'/gc) {
		$str = substr($str, 0, length($str) - 1).$1;
	    } else {
		&throw(new W3C::Util::YappDriver::MesgYappContextException($self, 
					-location => $self->YYData->{LOCATION}));
	    }
	}
	($token, $value) = ('STRING_LITERAL1', $str);
    } elsif ($self->YYData->{INPUT} =~ m/\G([A-Za-z][A-Za-z0-9_-]*)/gc) {
	($token, $value) = ($1,$1);
    } elsif ($self->YYData->{INPUT} =~ m/\G(==|\!=|<=|>=|\|\||\&\&)/gc) {
	($token, $value) = ($1,$1);
    } elsif ($self->YYData->{INPUT} =~ m/\G(.)/gc) {
	($token, $value) = ($1,$1);
    }
    my $pos = pos $self->YYData->{INPUT};
    #print "\n$pos,$token,$value\n";
    return ($token, $value);
}

sub parse {
    my ($self, @args) = @_;
    $self->YYData->{NEXT} = undef;
    return $self->SUPER::parse(@args);
}

# Provide (one) chunk of text to parse.
sub nextChunk {
    my ($self) = @_;
    #return shift (@{$self->YYData->{my_CHUNKS}});
    #return shift (@ARGV);
    return <STDIN>;
}

# Handy debugging wrapper for calling semantics actions.
sub _wrap {
    my ($self, $obj, $method, @args) = @_;
    my @ret;
    eval {
	@ret = $obj->$method(@args);
    }; if ($@) {if (my $ex = &catch('W3C::Util::CachedContextException')) {
	&throw($ex);;
    } elsif ($ex = &catch('W3C::Util::Exception')) {
	my $newEx = new 
	    W3C::Util::CachedContextException(-str => $self->YYData->{INPUT}, 
					      -pos => $self->YYData->{my_LASTPOS}+1, 
					      -errorMessage => $ex->toString);
	$newEx->assumeStackTrace($ex);
	&throw($newEx);
    } else {
	my $newEx = 
	    new W3C::Util::CachedContextException(-str => $self->YYData->{INPUT}, 
						  -pos => $self->YYData->{my_LASTPOS}+1, 
						  -errorMessage => "$obj->$method: $@");
	&throw($newEx);
    }}
    return wantarray ? @ret : $ret[-1];
}

sub printArgs {
    return;
    print ':';
    foreach my $arg (@_) {
	print " $arg";
    }
    print ' Curtok:',$_[0]->YYCurtok;
    print ' Curval:',$_[0]->YYCurval;
    print ' Expect:',$_[0]->YYExpect;
    print ' Lexer:',$_[0]->YYLexer;
    print ' Data:',$_[0]->YYData;
    print "\n";
}

# Used by -M invocation:
#   perl -MW3C::Rdf::RdqlParser -e '(new W3C::Rdf::RLRdqlParser())->Run' '...'
sub main {
    my ($self) = @_;
    $self->Run();
}

# <parser state support>
sub newDecl {
    my ($self, $parm) = @_;
    my $ret;
    foreach my $decl (@$parm) {
	my ($subject, $propValList) = @$decl;
	foreach my $propVal (@$propValList) {
	    my ($property, $valueList) = @$propVal;
	    foreach my $valuePair (@$valueList) {
		my ($value, $constraints) = @$valuePair;
		# print $subject->toString.' '.$property->toString.' '.$value->toString."\n";
		my $toAdd = [];
		if (ref $value eq 'ARRAY') {
		    # we've got an object and a bunch of Decls about that object.
		    $toAdd = [$value->[1]];
		    $value = $value->[0];
		}
		my $newTerm = new W3C::Rdf::AlgaeCompileTree::Decl([$property, $subject, $value], 
								   $constraints, $self);
		foreach my $term ($newTerm, @$toAdd) {
		    if ($ret) {
			$ret = new W3C::Rdf::AlgaeCompileTree::Conjunction($ret, $term, $self);
		    } else {
			$ret = $term;
		    }
		}
	    }
	}
    }
    return $ret;
}

sub resolveQNames {
    my ($self) = @_;
    foreach my $qname (@{$self->YYData->{QNAMES}}) {
	$qname->resolveNS();
    }
}

# </parser state support>

package W3C::Rdf::RdqlParser;
@W3C::Rdf::RdqlParser::ISA = qw(W3C::Rdf::_RdqlParser);
sub new {
    my ($proto, $rdqlString, $algae2, $location, @yappParms) = @_;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new(@yappParms);
    $self->YYData->{RDQL_STRING} = $rdqlString;
    $self->YYData->{LOCATION} = $location;
 
    $self->YYData->{ALGAE2} = $algae2;
    $self->YYData->{QNAMES} = [];
    return $self;
}

sub nextChunk {
    my ($self) = @_;
    my $ret = $self->YYData->{RDQL_STRING};
    $self->YYData->{RDQL_STRING} = undef;
    return $ret;
}

# Interactive ReadLine parser -- under development
package W3C::Rdf::RLRdqlParser;
use W3C::Util::Exception;
use vars qw(@ISA);
@ISA = qw(W3C::Rdf::RdqlParser);
sub new {
    my ($proto, @parms) = @_;
    my $class = ref($proto) || $proto;

    # Change the parser driver to the readline driver.
    @W3C::Rdf::RdqlParser::ISA= qw (W3C::Util::rlDriver);

    my $self = $class->SUPER::new(@parms);
    $self->YYData->{ACTIONS} = [];
    return $self;
}

sub nextChunk {
    my ($self) = @_;
    my $ret = undef;
    if ($self->{rl_COMPLETE_MODE}) {
	if ($self->{rl_SO_FAR}) {
	    $ret = $self->{rl_SO_FAR};
	    $self->{rl_SO_FAR} = undef;
	    #print "nextChunk: $ret\n";
	}
    } else {
	if (@{$self->YYData->{my_CHUNKS}}) {
	    $ret = shift (@{$self->YYData->{my_CHUNKS}});
	} else {
	    #return shift (@ARGV);
	    $ret = $self->readline('')."\n";
	    #print "ret: $ret";
	}
    }
    return $ret;
}

# perl -MW3C::Rdf::RdqlParser -e '(new W3C::Rdf::RLRdqlParser())->Run' 'asdf'
# b /usr/share/perl5/Parse/Yapp/Driver.pm:343

##!/usr/bin/perl
#BEGIN {unshift@INC,('../..');}
#use W3C::Rdf::RdqlParser;
#$p = new W3C::Rdf::RLRdqlParser();
#$p->main;

#./RdqlParser "(ask '(<ab:cd> (?asdf ?s ?o)) assert '(ef:gh (?a ?b ?c)))"

1;

__END__

=head1 NAME

W3C::Rdf::RdqlParser - a Parse::Yapp grammer for the RDQL language

=head1 SYNOPSIS

  use W3C::Rdf::RdqlParser;
  my $p = new W3C::Rdf::RdqlParser($rdqlString, $query, "query.txt");
  my $actions = $p->parse($debug);
  foreach my $action (@$actions) {
    $action->delayedEvaluate($self->{RESULT_SET});
  }
  return $self->getReport();

=head1 DESCRIPTION

The RdqlParser module binds a yapp grammar to semantic actions that build an
AlgaeCompileTree. In general, client applicatiosn have no direct interaction
with RdqlParser. Devlopers wishing to extend the RDQL query language
  http://www.w3.org/Submission/RDQL/

will need the perl yapp modules. The Makefile included with the W3C::Rdf CPAN
module has a target to re-compile the RdqlParser grammar. Invoke this with
  make RdqlParser.pm
It is likely that someone extending the RdqlParser grammar will also want to
extended AlgaeCompileTree.

This module is part of the W3C::Rdf CPAN module.

=head1 AUTHOR

Eric Prud\'hommeaux <eric@w3.org>

=head1 SEE ALSO

W3C::Rdf::AlgaeCompileTree(3) W3C::Rdf::Algae2(3) perl(1).

=cut

1;
