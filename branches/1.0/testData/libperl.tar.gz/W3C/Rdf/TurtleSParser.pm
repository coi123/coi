#!/usr/bin/perl
####################################################################
#
#    This file was generated using Parse::Yapp version 1.05.
#
#        Don't edit this file, use source file instead.
#
#             ANY CHANGE MADE HERE WILL BE LOST !
#
####################################################################
package W3C::Rdf::_TurtleSParser;
use vars qw ( @ISA );
use strict;

@ISA= qw ( Parse::Yapp::Driver );
# use Parse::Yapp::Driver; @@ replaced by W3C::Util::YappDriver

#line 1 "TurtleSParser.yp"

    #BEGIN {unshift@INC,('../..');}
    use W3C::Util::YappDriver;
    @ISA= qw (W3C::Util::YappDriver);

    use W3C::Util::Exception;
    use W3C::Rdf::AlgaeCompileTree qw($DISJUNCTION $NEGATION $OUTER);
#line 10 "TurtleSParser.yp"

# START TokenBlock
my $IT_BASE = "\@base";
my $IT_PREFIX = "\@prefix";
my $GT_DOT = "\\.";
my $GT_COMMA = ",";
my $GT_LPAREN = "\\(";
my $GT_RPAREN = "\\)";
my $GT_SEMI = ";";
my $IT_a = "a";
my $GT_LBRACKET = "\\[";
my $GT_RBRACKET = "\\]";
my $GT_MINUS = "-";
my $GT_PLUS = "\\+";
my $GT_DTYPE = "\\^\\^";
my $IT_true = "true";
my $IT_false = "false";
my $Q_IRI_REFT = "<(?:(?:[!-&\\(-;=\\?-\\]_a-z~-\x{10FFFE}]))*>";
my $LANGTAGT = "\@(?:[A-Za-z])+(?:(?:-(?:[0-9A-Za-z])+))*";
my $INTEGER = "(?:[0-9])+";
my $DECIMAL = "(?:(?:[0-9])+\\.(?:[0-9])*)|(?:\\.(?:[0-9])+)";
my $EXPONENT = "[Ee](?:[\\+-])?(?:[0-9])+";
my $DOUBLE = "(?:(?:[0-9])+\\.(?:[0-9])*(?:${EXPONENT}))|(?:(?:\\.(?:(?:[0-9]))+(?:${EXPONENT}))|(?:(?:(?:[0-9]))+(?:${EXPONENT})))";
my $ECHAR = "\\\\[\\\"\\'\\\\bfnrt]";
my $STRING_LITERAL_LONG2 = "\\\"\\\"\\\"(?:(?:(?:(?:(?:\\\")|(?:\\\"\\\")))?(?:(?:[\x{0000}-!#-\\[\\]-\x{10FFFE}])|(?:(?:${ECHAR})))))*\\\"\\\"\\\"";
my $STRING_LITERAL_LONG1 = "\\'\\'\\'(?:(?:(?:(?:(?:\\')|(?:\\'\\')))?(?:(?:[\x{0000}-&\\(-\\[\\]-\x{10FFFE}])|(?:(?:${ECHAR})))))*\\'\\'\\'";
my $STRING_LITERAL2 = "\\\"(?:(?:(?:(?:[\x{0000}-\\t\x{000B}-\x{000C}\x{000E}-!#-\\[\\]-\x{10FFFE}]))|(?:(?:${ECHAR}))))*\\\"";
my $STRING_LITERAL1 = "\\'(?:(?:(?:(?:[\x{0000}-\\t\x{000B}-\x{000C}\x{000E}-&\\(-\\[\\]-\x{10FFFE}]))|(?:(?:${ECHAR}))))*\\'";
my $WS = "(?: )|(?:(?:\\t)|(?:(?:\\r)|(?:(?:\\n)|(?:#(?:[\x{0000}-\\t\x{000B}-\x{000C}\x{000E}-\x{10FFFD}])*))))";
my $NIL = "\\((?:(?:${WS}))*\\)";
my $ANON = "\\[(?:(?:${WS}))*\\]";
my $NCCHAR1P = "(?:[A-Z])|(?:(?:[a-z])|(?:(?:[\x{00C0}-\x{00D6}])|(?:(?:[\x{00D8}-\x{00F6}])|(?:(?:[\x{00F8}-\x{02FF}])|(?:(?:[\x{0370}-\x{037D}])|(?:(?:[\x{037F}-\x{1FFF}])|(?:(?:[\x{200C}-\x{200D}])|(?:(?:[\x{2070}-\x{218F}])|(?:(?:[\x{2C00}-\x{2FEF}])|(?:(?:[\x{3001}-\x{D7FF}])|(?:(?:[\x{F900}-\x{FDCF}])|(?:(?:[\x{FDF0}-\x{FFFD}])|(?:[\x{10000}-\x{EFFFF}])))))))))))))";
my $NCCHAR1 = "(?:(?:${NCCHAR1P}))|(?:_)";
my $VARNAME = "(?:(?:(?:${NCCHAR1}))|(?:[0-9]))(?:(?:(?:(?:${NCCHAR1}))|(?:(?:[0-9])|(?:(?:\x{00B7})|(?:(?:[\x{0300}-\x{036F}])|(?:[\x{203F}-\x{2040}]))))))*";
my $VAR2T = "\\\$(?:${VARNAME})";
my $VAR1T = "\\?(?:${VARNAME})";
my $NCCHAR = "(?:(?:${NCCHAR1}))|(?:(?:-)|(?:(?:[0-9])|(?:(?:\x{00B7})|(?:(?:[\x{0300}-\x{036F}])|(?:[\x{203F}-\x{2040}])))))";
my $NCNAME_PREFIX = "(?:${NCCHAR1P})(?:(?:(?:(?:(?:(?:${NCCHAR}))|(?:\\.)))*(?:${NCCHAR})))?";
my $QNAME_NST = "(?:(?:${NCNAME_PREFIX}))?:";
my $NCNAME = "(?:${NCCHAR1})(?:(?:(?:(?:(?:(?:${NCCHAR}))|(?:\\.)))*(?:${NCCHAR})))?";
my $BLANK_NODE_LABELT = "_:(?:${NCNAME})";
my $QNAME_LN = "(?:${QNAME_NST})(?:${NCNAME})";
my $PASSED_TOKENS = "(?:(?:(?:${WS}))+)|(?:#(?:[\x{0000}-\\t\x{000B}-\x{10FFFE}])*\\n)";
my $Tokens = [[0, qr/$PASSED_TOKENS/, undef],
              [0, qr/$IT_BASE/i, 'IT_BASE'],
              [0, qr/$IT_PREFIX/i, 'IT_PREFIX'],
              [0, qr/$GT_DOT/i, 'GT_DOT'],
              [0, qr/$GT_COMMA/i, 'GT_COMMA'],
              [0, qr/$GT_LPAREN/i, 'GT_LPAREN'],
              [0, qr/$GT_RPAREN/i, 'GT_RPAREN'],
              [0, qr/$GT_SEMI/i, 'GT_SEMI'],
              [0, qr/$IT_a/i, 'IT_a'],
              [0, qr/$GT_LBRACKET/i, 'GT_LBRACKET'],
              [0, qr/$GT_RBRACKET/i, 'GT_RBRACKET'],
              [0, qr/$GT_MINUS/i, 'GT_MINUS'],
              [0, qr/$GT_PLUS/i, 'GT_PLUS'],
              [0, qr/$GT_DTYPE/i, 'GT_DTYPE'],
              [0, qr/$IT_true/i, 'IT_true'],
              [0, qr/$IT_false/i, 'IT_false'],
              [0, qr/$Q_IRI_REFT/, 'Q_IRI_REFT'],
              [0, qr/$QNAME_NST/, 'QNAME_NST'],
              [0, qr/$QNAME_LN/, 'QNAME_LN'],
              [0, qr/$BLANK_NODE_LABELT/, 'BLANK_NODE_LABELT'],
              [0, qr/$VAR1T/, 'VAR1T'],
              [0, qr/$VAR2T/, 'VAR2T'],
              [0, qr/$LANGTAGT/, 'LANGTAGT'],
              [0, qr/$INTEGER/, 'INTEGER'],
              [0, qr/$DECIMAL/, 'DECIMAL'],
              [0, qr/$DOUBLE/, 'DOUBLE'],
              [0, qr/$STRING_LITERAL1/, 'STRING_LITERAL1'],
              [0, qr/$STRING_LITERAL2/, 'STRING_LITERAL2'],
              [0, qr/$STRING_LITERAL_LONG1/, 'STRING_LITERAL_LONG1'],
              [0, qr/$STRING_LITERAL_LONG2/, 'STRING_LITERAL_LONG2'],
              [0, qr/$NIL/, 'NIL'],
              [0, qr/$ANON/, 'ANON']];
# END TokenBlock


sub new {
        my($class)=shift;
        ref($class)
    and $class=ref($class);

    my($self)=$class->SUPER::new( yyversion => '1.05',
                                  yystates =>
[
	{#State 0
		ACTIONS => {
			'IT_BASE' => 1
		},
		DEFAULT => -3,
		GOTOS => {
			'Query' => 2,
			'BaseDecl' => 3,
			'Prolog' => 4,
			'_QBaseDecl_E_Opt' => 5
		}
	},
	{#State 1
		ACTIONS => {
			'Q_IRI_REFT' => 7
		},
		GOTOS => {
			'Q_IRI_REF' => 6
		}
	},
	{#State 2
		ACTIONS => {
			'' => 8
		}
	},
	{#State 3
		DEFAULT => -4
	},
	{#State 4
		ACTIONS => {
			'' => -9,
			'QNAME_NST' => 24,
			'GT_LPAREN' => 26,
			'STRING_LITERAL_LONG2' => 10,
			'IT_true' => 12,
			'STRING_LITERAL_LONG1' => 13,
			'GT_MINUS' => 28,
			'NIL' => 27,
			'STRING_LITERAL2' => 14,
			'STRING_LITERAL1' => 16,
			'BLANK_NODE_LABELT' => 32,
			'GT_PLUS' => 17,
			'QNAME_LN' => 18,
			'ANON' => 19,
			'GT_LBRACKET' => 36,
			'Q_IRI_REFT' => 7,
			'IT_false' => 43
		},
		DEFAULT => -52,
		GOTOS => {
			'BooleanLiteral' => 9,
			'Q_IRI_REF' => 25,
			'String' => 11,
			'TriplesSameSubject' => 29,
			'ConstructQuery' => 15,
			'QName' => 30,
			'VarOrTerm' => 31,
			'QNAME_NS' => 33,
			'_Q_O_QGT_MINUS_E_Or_QGT_PLUS_E_C_E_Opt' => 34,
			'GraphTerm' => 35,
			'TriplesNode' => 37,
			'BLANK_NODE_LABEL' => 38,
			'_O_QGT_MINUS_E_Or_QGT_PLUS_E_C' => 40,
			'ConstructTemplate' => 39,
			'QNAME' => 41,
			'BlankNode' => 42,
			'ConstructTriples' => 20,
			'IRIref' => 23,
			'Collection' => 22,
			'BlankNodePropertyList' => 21,
			'RDFLiteral' => 44
		}
	},
	{#State 5
		DEFAULT => -5,
		GOTOS => {
			'_QPrefixDecl_E_Star' => 45
		}
	},
	{#State 6
		ACTIONS => {
			'GT_DOT' => 46
		}
	},
	{#State 7
		DEFAULT => -75
	},
	{#State 8
		DEFAULT => 0
	},
	{#State 9
		DEFAULT => -47
	},
	{#State 10
		DEFAULT => -68
	},
	{#State 11
		ACTIONS => {
			'LANGTAGT' => 50,
			'GT_DTYPE' => 52
		},
		DEFAULT => -58,
		GOTOS => {
			'LANGTAG' => 47,
			'_Q_O_QLANGTAG_E_Or_QGT_DTYPE_E_S_QIRIref_E_C_E_Opt' => 51,
			'_O_QGT_DTYPE_E_S_QIRIref_E_C' => 48,
			'_O_QLANGTAG_E_Or_QGT_DTYPE_E_S_QIRIref_E_C' => 49
		}
	},
	{#State 12
		DEFAULT => -63
	},
	{#State 13
		DEFAULT => -67
	},
	{#State 14
		DEFAULT => -66
	},
	{#State 15
		DEFAULT => -1
	},
	{#State 16
		DEFAULT => -65
	},
	{#State 17
		DEFAULT => -51
	},
	{#State 18
		DEFAULT => -77
	},
	{#State 19
		DEFAULT => -74
	},
	{#State 20
		DEFAULT => -11
	},
	{#State 21
		DEFAULT => -34
	},
	{#State 22
		DEFAULT => -33
	},
	{#State 23
		DEFAULT => -44
	},
	{#State 24
		DEFAULT => -76
	},
	{#State 25
		DEFAULT => -69
	},
	{#State 26
		DEFAULT => -36,
		GOTOS => {
			'@1-1' => 53
		}
	},
	{#State 27
		DEFAULT => -49
	},
	{#State 28
		DEFAULT => -50
	},
	{#State 29
		ACTIONS => {
			'GT_DOT' => 55
		},
		DEFAULT => -16,
		GOTOS => {
			'_Q_O_QGT_DOT_E_S_QConstructTriples_E_Opt_C_E_Opt' => 56,
			'_O_QGT_DOT_E_S_QConstructTriples_E_Opt_C' => 54
		}
	},
	{#State 30
		DEFAULT => -70
	},
	{#State 31
		ACTIONS => {
			'QNAME_NST' => 24,
			'IT_a' => 61,
			'Q_IRI_REFT' => 7,
			'QNAME_LN' => 18
		},
		GOTOS => {
			'QNAME_NS' => 33,
			'Q_IRI_REF' => 25,
			'PropertyListNotEmpty' => 57,
			'QNAME' => 41,
			'VarOrIRIref' => 60,
			'IRIref' => 59,
			'QName' => 30,
			'Verb' => 58
		}
	},
	{#State 32
		DEFAULT => -78
	},
	{#State 33
		DEFAULT => -72
	},
	{#State 34
		ACTIONS => {
			'INTEGER' => 64,
			'DOUBLE' => 65,
			'DECIMAL' => 62
		},
		GOTOS => {
			'NumericLiteral' => 63
		}
	},
	{#State 35
		DEFAULT => -42
	},
	{#State 36
		ACTIONS => {
			'QNAME_NST' => 24,
			'IT_a' => 61,
			'Q_IRI_REFT' => 7,
			'QNAME_LN' => 18
		},
		GOTOS => {
			'QNAME_NS' => 33,
			'Q_IRI_REF' => 25,
			'PropertyListNotEmpty' => 66,
			'QNAME' => 41,
			'VarOrIRIref' => 60,
			'IRIref' => 59,
			'QName' => 30,
			'Verb' => 58
		}
	},
	{#State 37
		ACTIONS => {
			'QNAME_NST' => 24,
			'IT_a' => 61,
			'Q_IRI_REFT' => 7,
			'QNAME_LN' => 18
		},
		DEFAULT => -21,
		GOTOS => {
			'QNAME_NS' => 33,
			'Q_IRI_REF' => 25,
			'_QPropertyListNotEmpty_E_Opt' => 68,
			'Verb' => 58,
			'PropertyListNotEmpty' => 67,
			'QNAME' => 41,
			'PropertyList' => 69,
			'IRIref' => 59,
			'VarOrIRIref' => 60,
			'QName' => 30
		}
	},
	{#State 38
		DEFAULT => -73
	},
	{#State 39
		DEFAULT => -10
	},
	{#State 40
		DEFAULT => -53
	},
	{#State 41
		DEFAULT => -71
	},
	{#State 42
		DEFAULT => -48
	},
	{#State 43
		DEFAULT => -64
	},
	{#State 44
		DEFAULT => -45
	},
	{#State 45
		ACTIONS => {
			'IT_PREFIX' => 71
		},
		DEFAULT => -2,
		GOTOS => {
			'PrefixDecl' => 70
		}
	},
	{#State 46
		DEFAULT => -7
	},
	{#State 47
		DEFAULT => -56
	},
	{#State 48
		DEFAULT => -57
	},
	{#State 49
		DEFAULT => -59
	},
	{#State 50
		DEFAULT => -79
	},
	{#State 51
		DEFAULT => -54
	},
	{#State 52
		ACTIONS => {
			'QNAME_NST' => 24,
			'Q_IRI_REFT' => 7,
			'QNAME_LN' => 18
		},
		GOTOS => {
			'QNAME_NS' => 33,
			'Q_IRI_REF' => 25,
			'QNAME' => 41,
			'IRIref' => 72,
			'QName' => 30
		}
	},
	{#State 53
		ACTIONS => {
			'QNAME_NST' => 24,
			'GT_LPAREN' => 26,
			'STRING_LITERAL_LONG2' => 10,
			'IT_true' => 12,
			'STRING_LITERAL_LONG1' => 13,
			'NIL' => 27,
			'GT_MINUS' => 28,
			'STRING_LITERAL2' => 14,
			'STRING_LITERAL1' => 16,
			'BLANK_NODE_LABELT' => 32,
			'GT_PLUS' => 17,
			'QNAME_LN' => 18,
			'ANON' => 19,
			'GT_LBRACKET' => 36,
			'Q_IRI_REFT' => 7,
			'IT_false' => 43
		},
		DEFAULT => -52,
		GOTOS => {
			'VarOrTerm' => 75,
			'GraphNode' => 74,
			'BooleanLiteral' => 9,
			'QNAME_NS' => 33,
			'Q_IRI_REF' => 25,
			'String' => 11,
			'_Q_O_QGT_MINUS_E_Or_QGT_PLUS_E_C_E_Opt' => 34,
			'TriplesNode' => 76,
			'GraphTerm' => 35,
			'BLANK_NODE_LABEL' => 38,
			'_QGraphNode_E_Plus' => 73,
			'_O_QGT_MINUS_E_Or_QGT_PLUS_E_C' => 40,
			'QNAME' => 41,
			'BlankNode' => 42,
			'IRIref' => 23,
			'BlankNodePropertyList' => 21,
			'Collection' => 22,
			'QName' => 30,
			'RDFLiteral' => 44
		}
	},
	{#State 54
		DEFAULT => -17
	},
	{#State 55
		ACTIONS => {
			'' => -13,
			'QNAME_NST' => 24,
			'GT_LPAREN' => 26,
			'STRING_LITERAL_LONG2' => 10,
			'IT_true' => 12,
			'STRING_LITERAL_LONG1' => 13,
			'NIL' => 27,
			'GT_MINUS' => 28,
			'STRING_LITERAL2' => 14,
			'STRING_LITERAL1' => 16,
			'BLANK_NODE_LABELT' => 32,
			'GT_PLUS' => 17,
			'QNAME_LN' => 18,
			'ANON' => 19,
			'GT_LBRACKET' => 36,
			'Q_IRI_REFT' => 7,
			'IT_false' => 43
		},
		DEFAULT => -52,
		GOTOS => {
			'BooleanLiteral' => 9,
			'Q_IRI_REF' => 25,
			'String' => 11,
			'TriplesSameSubject' => 29,
			'_QConstructTriples_E_Opt' => 77,
			'QName' => 30,
			'VarOrTerm' => 31,
			'QNAME_NS' => 33,
			'_Q_O_QGT_MINUS_E_Or_QGT_PLUS_E_C_E_Opt' => 34,
			'BLANK_NODE_LABEL' => 38,
			'GraphTerm' => 35,
			'TriplesNode' => 37,
			'_O_QGT_MINUS_E_Or_QGT_PLUS_E_C' => 40,
			'QNAME' => 41,
			'BlankNode' => 42,
			'ConstructTriples' => 78,
			'Collection' => 22,
			'BlankNodePropertyList' => 21,
			'IRIref' => 23,
			'RDFLiteral' => 44
		}
	},
	{#State 56
		DEFAULT => -12
	},
	{#State 57
		DEFAULT => -18
	},
	{#State 58
		ACTIONS => {
			'QNAME_NST' => 24,
			'GT_LPAREN' => 26,
			'STRING_LITERAL_LONG2' => 10,
			'IT_true' => 12,
			'STRING_LITERAL_LONG1' => 13,
			'NIL' => 27,
			'GT_MINUS' => 28,
			'STRING_LITERAL2' => 14,
			'STRING_LITERAL1' => 16,
			'BLANK_NODE_LABELT' => 32,
			'GT_PLUS' => 17,
			'QNAME_LN' => 18,
			'ANON' => 19,
			'GT_LBRACKET' => 36,
			'Q_IRI_REFT' => 7,
			'IT_false' => 43
		},
		DEFAULT => -52,
		GOTOS => {
			'VarOrTerm' => 75,
			'GraphNode' => 80,
			'BooleanLiteral' => 9,
			'QNAME_NS' => 33,
			'Q_IRI_REF' => 25,
			'ObjectList' => 79,
			'String' => 11,
			'_Q_O_QGT_MINUS_E_Or_QGT_PLUS_E_C_E_Opt' => 34,
			'TriplesNode' => 76,
			'GraphTerm' => 35,
			'BLANK_NODE_LABEL' => 38,
			'_O_QGT_MINUS_E_Or_QGT_PLUS_E_C' => 40,
			'QNAME' => 41,
			'BlankNode' => 42,
			'IRIref' => 23,
			'BlankNodePropertyList' => 21,
			'Collection' => 22,
			'QName' => 30,
			'RDFLiteral' => 44
		}
	},
	{#State 59
		DEFAULT => -43
	},
	{#State 60
		DEFAULT => -31
	},
	{#State 61
		DEFAULT => -32
	},
	{#State 62
		DEFAULT => -61
	},
	{#State 63
		DEFAULT => -46
	},
	{#State 64
		DEFAULT => -60
	},
	{#State 65
		DEFAULT => -62
	},
	{#State 66
		ACTIONS => {
			'GT_RBRACKET' => 81
		}
	},
	{#State 67
		DEFAULT => -22
	},
	{#State 68
		DEFAULT => -20
	},
	{#State 69
		DEFAULT => -19
	},
	{#State 70
		DEFAULT => -6
	},
	{#State 71
		ACTIONS => {
			'QNAME_NST' => 24
		},
		GOTOS => {
			'QNAME_NS' => 82
		}
	},
	{#State 72
		DEFAULT => -55
	},
	{#State 73
		ACTIONS => {
			'QNAME_NST' => 24,
			'GT_LPAREN' => 26,
			'STRING_LITERAL_LONG2' => 10,
			'IT_true' => 12,
			'STRING_LITERAL_LONG1' => 13,
			'NIL' => 27,
			'GT_MINUS' => 28,
			'STRING_LITERAL2' => 14,
			'STRING_LITERAL1' => 16,
			'BLANK_NODE_LABELT' => 32,
			'GT_PLUS' => 17,
			'QNAME_LN' => 18,
			'ANON' => 19,
			'GT_LBRACKET' => 36,
			'Q_IRI_REFT' => 7,
			'GT_RPAREN' => 83,
			'IT_false' => 43
		},
		DEFAULT => -52,
		GOTOS => {
			'VarOrTerm' => 75,
			'GraphNode' => 84,
			'BooleanLiteral' => 9,
			'QNAME_NS' => 33,
			'Q_IRI_REF' => 25,
			'String' => 11,
			'_Q_O_QGT_MINUS_E_Or_QGT_PLUS_E_C_E_Opt' => 34,
			'TriplesNode' => 76,
			'GraphTerm' => 35,
			'BLANK_NODE_LABEL' => 38,
			'_O_QGT_MINUS_E_Or_QGT_PLUS_E_C' => 40,
			'QNAME' => 41,
			'BlankNode' => 42,
			'IRIref' => 23,
			'BlankNodePropertyList' => 21,
			'Collection' => 22,
			'QName' => 30,
			'RDFLiteral' => 44
		}
	},
	{#State 74
		DEFAULT => -38
	},
	{#State 75
		DEFAULT => -40
	},
	{#State 76
		DEFAULT => -41
	},
	{#State 77
		DEFAULT => -15
	},
	{#State 78
		DEFAULT => -14
	},
	{#State 79
		ACTIONS => {
			'GT_SEMI' => 87
		},
		DEFAULT => -25,
		GOTOS => {
			'_O_QGT_SEMI_E_S_QPropertyList_E_C' => 86,
			'_Q_O_QGT_SEMI_E_S_QPropertyList_E_C_E_Opt' => 85
		}
	},
	{#State 80
		ACTIONS => {
			'GT_COMMA' => 88
		},
		DEFAULT => -29,
		GOTOS => {
			'_O_QGT_COMMA_E_S_QObjectList_E_C' => 89,
			'_Q_O_QGT_COMMA_E_S_QObjectList_E_C_E_Opt' => 90
		}
	},
	{#State 81
		DEFAULT => -35
	},
	{#State 82
		ACTIONS => {
			'Q_IRI_REFT' => 7
		},
		GOTOS => {
			'Q_IRI_REF' => 91
		}
	},
	{#State 83
		DEFAULT => -37
	},
	{#State 84
		DEFAULT => -39
	},
	{#State 85
		DEFAULT => -23
	},
	{#State 86
		DEFAULT => -26
	},
	{#State 87
		ACTIONS => {
			'QNAME_NST' => 24,
			'IT_a' => 61,
			'QNAME_LN' => 18,
			'Q_IRI_REFT' => 7
		},
		DEFAULT => -21,
		GOTOS => {
			'QNAME_NS' => 33,
			'Q_IRI_REF' => 25,
			'_QPropertyListNotEmpty_E_Opt' => 68,
			'Verb' => 58,
			'PropertyListNotEmpty' => 67,
			'QNAME' => 41,
			'PropertyList' => 92,
			'IRIref' => 59,
			'VarOrIRIref' => 60,
			'QName' => 30
		}
	},
	{#State 88
		ACTIONS => {
			'QNAME_NST' => 24,
			'GT_LPAREN' => 26,
			'STRING_LITERAL_LONG2' => 10,
			'IT_true' => 12,
			'STRING_LITERAL_LONG1' => 13,
			'NIL' => 27,
			'GT_MINUS' => 28,
			'STRING_LITERAL2' => 14,
			'STRING_LITERAL1' => 16,
			'BLANK_NODE_LABELT' => 32,
			'GT_PLUS' => 17,
			'QNAME_LN' => 18,
			'ANON' => 19,
			'GT_LBRACKET' => 36,
			'Q_IRI_REFT' => 7,
			'IT_false' => 43
		},
		DEFAULT => -52,
		GOTOS => {
			'VarOrTerm' => 75,
			'GraphNode' => 80,
			'BooleanLiteral' => 9,
			'QNAME_NS' => 33,
			'Q_IRI_REF' => 25,
			'ObjectList' => 93,
			'String' => 11,
			'_Q_O_QGT_MINUS_E_Or_QGT_PLUS_E_C_E_Opt' => 34,
			'TriplesNode' => 76,
			'GraphTerm' => 35,
			'BLANK_NODE_LABEL' => 38,
			'_O_QGT_MINUS_E_Or_QGT_PLUS_E_C' => 40,
			'QNAME' => 41,
			'BlankNode' => 42,
			'IRIref' => 23,
			'BlankNodePropertyList' => 21,
			'Collection' => 22,
			'QName' => 30,
			'RDFLiteral' => 44
		}
	},
	{#State 89
		DEFAULT => -30
	},
	{#State 90
		DEFAULT => -27
	},
	{#State 91
		ACTIONS => {
			'GT_DOT' => 94
		}
	},
	{#State 92
		DEFAULT => -24
	},
	{#State 93
		DEFAULT => -28
	},
	{#State 94
		DEFAULT => -8
	}
],
                                  yyrules  =>
[
	[#Rule 0
		 '$start', 2, undef
	],
	[#Rule 1
		 'Query', 2,
sub
#line 91 "TurtleSParser.yp"
{
    my ($self, $Prolog, $ConstructQuery) = @_;
    $self->resolveQNames();
    [@$Prolog, @$ConstructQuery];
}
	],
	[#Rule 2
		 'Prolog', 2,
sub
#line 99 "TurtleSParser.yp"
{
    my ($self, $_QBaseDecl_E_Opt, $_QPrefixDecl_E_Star) = @_;
    $_QPrefixDecl_E_Star;
}
	],
	[#Rule 3
		 '_QBaseDecl_E_Opt', 0,
sub
#line 106 "TurtleSParser.yp"
{
    my ($self, ) = @_;
    [];
}
	],
	[#Rule 4
		 '_QBaseDecl_E_Opt', 1, undef
	],
	[#Rule 5
		 '_QPrefixDecl_E_Star', 0,
sub
#line 114 "TurtleSParser.yp"
{
    my ($self, ) = @_;
    [];
}
	],
	[#Rule 6
		 '_QPrefixDecl_E_Star', 2,
sub
#line 119 "TurtleSParser.yp"
{
    my ($self, $_QPrefixDecl_E_Star, $PrefixDecl) = @_;
    [@$_QPrefixDecl_E_Star, $PrefixDecl];
}
	],
	[#Rule 7
		 'BaseDecl', 3,
sub
#line 126 "TurtleSParser.yp"
{
    my ($self, $BASE, $Q_IRI_REF) = @_;
    [$self->YYData->{BASE} = $Q_IRI_REF];
}
	],
	[#Rule 8
		 'PrefixDecl', 4,
sub
#line 133 "TurtleSParser.yp"
{
    my ($self, $PREFIX, $QNAME_NS, $Q_IRI_REF) = @_;
    $self->addNamespace($QNAME_NS, $Q_IRI_REF);
    $self->YYData->{ALGAE2}->namespace($QNAME_NS, $Q_IRI_REF);
}
	],
	[#Rule 9
		 'ConstructQuery', 0,
sub
#line 141 "TurtleSParser.yp"
{
    [];
}
	],
	[#Rule 10
		 'ConstructQuery', 1,
sub
#line 145 "TurtleSParser.yp"
{
    my ($self, $ConstructTemplate) = @_;
    [$self->YYData->{ALGAE2}->assert($ConstructTemplate, undef)];
}
	],
	[#Rule 11
		 'ConstructTemplate', 1,
sub
#line 152 "TurtleSParser.yp"
{
    my ($self, $ConstructTriples) = @_;
    $ConstructTriples;
}
	],
	[#Rule 12
		 'ConstructTriples', 2,
sub
#line 159 "TurtleSParser.yp"
{
    my ($self, $TriplesSameSubject, $_Q_O_QGT_DOT_E_S_QConstructTriples_E_Opt_C_E_Opt) = @_;
    $_Q_O_QGT_DOT_E_S_QConstructTriples_E_Opt_C_E_Opt ? 
	new W3C::Rdf::AlgaeCompileTree::Conjunction($TriplesSameSubject, $_Q_O_QGT_DOT_E_S_QConstructTriples_E_Opt_C_E_Opt, $self) : 
	$TriplesSameSubject;
}
	],
	[#Rule 13
		 '_QConstructTriples_E_Opt', 0,
sub
#line 168 "TurtleSParser.yp"
{
    undef;
}
	],
	[#Rule 14
		 '_QConstructTriples_E_Opt', 1, undef
	],
	[#Rule 15
		 '_O_QGT_DOT_E_S_QConstructTriples_E_Opt_C', 2,
sub
#line 175 "TurtleSParser.yp"
{
    my ($self, $GT_DOT, $_QConstructTriples_E_Opt) = @_;
    return $_QConstructTriples_E_Opt;
}
	],
	[#Rule 16
		 '_Q_O_QGT_DOT_E_S_QConstructTriples_E_Opt_C_E_Opt', 0, undef
	],
	[#Rule 17
		 '_Q_O_QGT_DOT_E_S_QConstructTriples_E_Opt_C_E_Opt', 1, undef
	],
	[#Rule 18
		 'TriplesSameSubject', 2,
sub
#line 186 "TurtleSParser.yp"
{
    my ($self, $VarOrTerm, $PropertyListNotEmpty) = @_;
    $self->newDecl([[$VarOrTerm, $PropertyListNotEmpty]]);
}
	],
	[#Rule 19
		 'TriplesSameSubject', 2,
sub
#line 191 "TurtleSParser.yp"
{
    my ($self, $TriplesNode, $PropertyList) = @_;

    # Because [ p1 o1; p2 o2 ] breaks the usual pattern, we have to pass it back
    # up as an array of the new node and the exprs that were encompassed inside
    # it. In this case, we want only the exprs.

    return $PropertyList ? 
	new W3C::Rdf::AlgaeCompileTree::Conjunction($TriplesNode->[1], $self->newDecl([[$TriplesNode->[0], $PropertyList]]), $self) : 
	$TriplesNode->[1];
}
	],
	[#Rule 20
		 'PropertyList', 1, undef
	],
	[#Rule 21
		 '_QPropertyListNotEmpty_E_Opt', 0, undef
	],
	[#Rule 22
		 '_QPropertyListNotEmpty_E_Opt', 1, undef
	],
	[#Rule 23
		 'PropertyListNotEmpty', 3,
sub
#line 212 "TurtleSParser.yp"
{
    my ($self, $Verb, $ObjectList, $_Q_O_QGT_SEMI_E_S_QPropertyList_E_C_E_Opt) = @_;
    [[$Verb, $ObjectList], $_Q_O_QGT_SEMI_E_S_QPropertyList_E_C_E_Opt ? @$_Q_O_QGT_SEMI_E_S_QPropertyList_E_C_E_Opt : ()];
}
	],
	[#Rule 24
		 '_O_QGT_SEMI_E_S_QPropertyList_E_C', 2,
sub
#line 219 "TurtleSParser.yp"
{
    my ($self, $SEMI, $PropertyList) = @_;
    $PropertyList;
}
	],
	[#Rule 25
		 '_Q_O_QGT_SEMI_E_S_QPropertyList_E_C_E_Opt', 0, undef
	],
	[#Rule 26
		 '_Q_O_QGT_SEMI_E_S_QPropertyList_E_C_E_Opt', 1, undef
	],
	[#Rule 27
		 'ObjectList', 2,
sub
#line 230 "TurtleSParser.yp"
{ #1 750
    my ($self, $GraphNode, $_Q_O_QGT_COMMA_E_S_QObjectList_E_C_E_Opt) = @_;
    [$GraphNode, @$_Q_O_QGT_COMMA_E_S_QObjectList_E_C_E_Opt];
}
	],
	[#Rule 28
		 '_O_QGT_COMMA_E_S_QObjectList_E_C', 2,
sub
#line 237 "TurtleSParser.yp"
{
    my ($self, $COMMA, $ObjectList) = @_;
    $ObjectList; # ???
}
	],
	[#Rule 29
		 '_Q_O_QGT_COMMA_E_S_QObjectList_E_C_E_Opt', 0,
sub
#line 244 "TurtleSParser.yp"
{
    my ($self, ) = @_;
    [];
}
	],
	[#Rule 30
		 '_Q_O_QGT_COMMA_E_S_QObjectList_E_C_E_Opt', 1,
sub
#line 249 "TurtleSParser.yp"
{
    my ($self, $_O_QGT_COMMA_E_S_QObjectList_E_C) = @_;
    $_O_QGT_COMMA_E_S_QObjectList_E_C;
}
	],
	[#Rule 31
		 'Verb', 1, undef
	],
	[#Rule 32
		 'Verb', 1,
sub
#line 257 "TurtleSParser.yp"
{
    my ($self, $a) = @_;
    new W3C::Rdf::AlgaeCompileTree::Url('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', undef, $self);
}
	],
	[#Rule 33
		 'TriplesNode', 1, undef
	],
	[#Rule 34
		 'TriplesNode', 1, undef
	],
	[#Rule 35
		 'BlankNodePropertyList', 3,
sub
#line 268 "TurtleSParser.yp"
{
    my ($self, $GT_LBRACKET, $PropertyListNotEmpty, $GT_RBRACKET) = @_;
    my $node = $self->createBNode(undef);
    [$node, $self->newDecl([[$node, $PropertyListNotEmpty]])];
}
	],
	[#Rule 36
		 '@1-1', 0,
sub
#line 276 "TurtleSParser.yp"
{
    my ($self, $LPAREN) = @_;
    $self->startList();
}
	],
	[#Rule 37
		 'Collection', 4,
sub
#line 281 "TurtleSParser.yp"
{
    my ($self, $LPAREN, $head, $_QGraphNode_E_Plus, $RPAREN) = @_;
    $self->stopList();
}
	],
	[#Rule 38
		 '_QGraphNode_E_Plus', 1,
sub
#line 288 "TurtleSParser.yp"
{
    my ($self, $GraphNode) = @_;
    $self->addListNode($GraphNode);
}
	],
	[#Rule 39
		 '_QGraphNode_E_Plus', 2,
sub
#line 293 "TurtleSParser.yp"
{
    my ($self, $_QGraphNode_E_Plus, $GraphNode) = @_;
    $self->addListNode($GraphNode);
}
	],
	[#Rule 40
		 'GraphNode', 1, undef
	],
	[#Rule 41
		 'GraphNode', 1, undef
	],
	[#Rule 42
		 'VarOrTerm', 1, undef
	],
	[#Rule 43
		 'VarOrIRIref', 1, undef
	],
	[#Rule 44
		 'GraphTerm', 1, undef
	],
	[#Rule 45
		 'GraphTerm', 1, undef
	],
	[#Rule 46
		 'GraphTerm', 2,
sub
#line 312 "TurtleSParser.yp"
{
    my ($self, $_Q_O_QGT_MINUS_E_Or_QGT_PLUS_E_C_E_Opt, $NumericLiteral) = @_;
    $NumericLiteral->[0]->new("$_Q_O_QGT_MINUS_E_Or_QGT_PLUS_E_C_E_Opt$NumericLiteral->[1]", $self);
}
	],
	[#Rule 47
		 'GraphTerm', 1, undef
	],
	[#Rule 48
		 'GraphTerm', 1, undef
	],
	[#Rule 49
		 'GraphTerm', 1,
sub
#line 319 "TurtleSParser.yp"
{ #1
    my ($self, $NIL) = @_;
    new W3C::Rdf::AlgaeCompileTree::Url('http://www.w3.org/1999/02/22-rdf-syntax-ns#nil', undef, $self);
}
	],
	[#Rule 50
		 '_O_QGT_MINUS_E_Or_QGT_PLUS_E_C', 1, undef
	],
	[#Rule 51
		 '_O_QGT_MINUS_E_Or_QGT_PLUS_E_C', 1, undef
	],
	[#Rule 52
		 '_Q_O_QGT_MINUS_E_Or_QGT_PLUS_E_C_E_Opt', 0, undef
	],
	[#Rule 53
		 '_Q_O_QGT_MINUS_E_Or_QGT_PLUS_E_C_E_Opt', 1, undef
	],
	[#Rule 54
		 'RDFLiteral', 2,
sub
#line 334 "TurtleSParser.yp"
{
    my ($self, $String, $_Q_O_QLANGTAG_E_Or_QGT_DTYPE_E_S_QIRIref_E_C_E_Opt) = @_;
    new W3C::Rdf::AlgaeCompileTree::Literal($String, @$_Q_O_QLANGTAG_E_Or_QGT_DTYPE_E_S_QIRIref_E_C_E_Opt, $self);
}
	],
	[#Rule 55
		 '_O_QGT_DTYPE_E_S_QIRIref_E_C', 2,
sub
#line 341 "TurtleSParser.yp"
{
    my ($self, $DTYPE, $IRIref) = @_;
    $IRIref;
}
	],
	[#Rule 56
		 '_O_QLANGTAG_E_Or_QGT_DTYPE_E_S_QIRIref_E_C', 1,
sub
#line 348 "TurtleSParser.yp"
{
    my ($self, $LANGTAG) = @_;
    [undef, $LANGTAG];
}
	],
	[#Rule 57
		 '_O_QLANGTAG_E_Or_QGT_DTYPE_E_S_QIRIref_E_C', 1,
sub
#line 353 "TurtleSParser.yp"
{
    my ($self, $_O_QGT_DTYPE_E_S_QIRIref_E_C) = @_;
    [$_O_QGT_DTYPE_E_S_QIRIref_E_C, undef];
}
	],
	[#Rule 58
		 '_Q_O_QLANGTAG_E_Or_QGT_DTYPE_E_S_QIRIref_E_C_E_Opt', 0,
sub
#line 360 "TurtleSParser.yp"
{
    my ($self, ) = @_;
    [undef, undef];
}
	],
	[#Rule 59
		 '_Q_O_QLANGTAG_E_Or_QGT_DTYPE_E_S_QIRIref_E_C_E_Opt', 1, undef
	],
	[#Rule 60
		 'NumericLiteral', 1,
sub
#line 368 "TurtleSParser.yp"
{
    my ($self, $INTEGER) = @_;
    ['W3C::Rdf::AlgaeCompileTree::Int', $INTEGER];
}
	],
	[#Rule 61
		 'NumericLiteral', 1,
sub
#line 373 "TurtleSParser.yp"
{
    my ($self, $DECIMAL) = @_;
    ['W3C::Rdf::AlgaeCompileTree::Decimal', $DECIMAL];
}
	],
	[#Rule 62
		 'NumericLiteral', 1,
sub
#line 378 "TurtleSParser.yp"
{
    my ($self, $DOUBLE) = @_;
    ['W3C::Rdf::AlgaeCompileTree::Double', $DOUBLE];
}
	],
	[#Rule 63
		 'BooleanLiteral', 1,
sub
#line 385 "TurtleSParser.yp"
{
    my ($self, $true) = @_;
    new W3C::Rdf::AlgaeCompileTree::Boolean('true', $self);
}
	],
	[#Rule 64
		 'BooleanLiteral', 1,
sub
#line 390 "TurtleSParser.yp"
{
    my ($self, $false) = @_;
    new W3C::Rdf::AlgaeCompileTree::Boolean('false', $self);
}
	],
	[#Rule 65
		 'String', 1,
sub
#line 397 "TurtleSParser.yp"
{
    my ($self, $STRING_LITERAL1) = @_;
    &_literalToken($STRING_LITERAL1, 1);
}
	],
	[#Rule 66
		 'String', 1,
sub
#line 402 "TurtleSParser.yp"
{
    my ($self, $STRING_LITERAL2) = @_;
    &_literalToken($STRING_LITERAL2, 1);
}
	],
	[#Rule 67
		 'String', 1,
sub
#line 407 "TurtleSParser.yp"
{
    my ($self, $STRING_LITERAL_LONG1) = @_;
    &_literalToken($STRING_LITERAL_LONG1, 3);
}
	],
	[#Rule 68
		 'String', 1,
sub
#line 412 "TurtleSParser.yp"
{
    my ($self, $STRING_LITERAL_LONG2) = @_;
    &_literalToken($STRING_LITERAL_LONG2, 3);
}
	],
	[#Rule 69
		 'IRIref', 1, undef
	],
	[#Rule 70
		 'IRIref', 1, undef
	],
	[#Rule 71
		 'QName', 1, undef
	],
	[#Rule 72
		 'QName', 1,
sub
#line 424 "TurtleSParser.yp"
{
    my ($self, $QNAME_NS) = @_;
    my ($prefix, $localName) = split(':', $QNAME_NS, 2);
    new W3C::Rdf::AlgaeCompileTree::QName($prefix, $localName, $self);
}
	],
	[#Rule 73
		 'BlankNode', 1, undef
	],
	[#Rule 74
		 'BlankNode', 1,
sub
#line 433 "TurtleSParser.yp"
{ #1
    my ($self, $ANON) = @_;
    $self->createBNode(undef);
}
	],
	[#Rule 75
		 'Q_IRI_REF', 1,
sub
#line 440 "TurtleSParser.yp"
{
    my ($self, $Q_IRI_REFT) = @_;
    new W3C::Rdf::AlgaeCompileTree::Url(substr($Q_IRI_REFT, 1, length($Q_IRI_REFT)-2), $self->YYData->{BASE}, $self)
}
	],
	[#Rule 76
		 'QNAME_NS', 1,
sub
#line 447 "TurtleSParser.yp"
{
    my ($self, $QNAME_NST) = @_;
    substr($QNAME_NST, 0, length($QNAME_NST)-1);
}
	],
	[#Rule 77
		 'QNAME', 1,
sub
#line 454 "TurtleSParser.yp"
{
    my ($self, $QNAME_LN) = @_;
    my ($prefix, $localName) = split(':', $QNAME_LN, 2);
    new W3C::Rdf::AlgaeCompileTree::QName($prefix, $localName, $self);
}
	],
	[#Rule 78
		 'BLANK_NODE_LABEL', 1,
sub
#line 462 "TurtleSParser.yp"
{
    my ($self, $BLANK_NODE_LABELT) = @_;
    my $curPatternId = $self->YYData->{patternIdStack}[-1];
    if ($self->YYData->{inFilter}) {
	&throw(new W3C::Util::ProgramFlowException());
    }
    if (my $patternId = $self->YYData->{patternIdByNamedBNode}{$BLANK_NODE_LABELT}) {
	#print "|$curPatternId| $BLANK_NODE_LABELT => $patternId\n";
	if ($patternId != $curPatternId) {
	    &throw(new W3C::Util::ProgramFlowException());
	}
    } else {
	#print "|$curPatternId| $BLANK_NODE_LABELT <= $curPatternId\n";
	$self->YYData->{patternIdByNamedBNode}{$BLANK_NODE_LABELT} = $curPatternId;
    }
    my $node = $self->YYData->{BNODES_BY_NAME}{$BLANK_NODE_LABELT};
    if (!$node) {
	$node = $self->YYData->{BNODES_BY_NAME}{$BLANK_NODE_LABELT} = $self->createBNode($BLANK_NODE_LABELT);
    }
    $node;
}
	],
	[#Rule 79
		 'LANGTAG', 1,
sub
#line 486 "TurtleSParser.yp"
{
    my ($self, $LANGTAGT) = @_;
    new W3C::Rdf::AlgaeCompileTree::Literal(substr($LANGTAGT, 1), undef, undef, $self);
}
	]
],
                                  @_);
    bless($self,$class);
}

#line 543 "TurtleSParser.yp"


my $LanguageName = 'TurtleSParser';
# -*- Mode: cperl; coding: utf-8; cperl-indent-level: 4 -*-
# START LexerBlock
#
# YappTemplate: used by yacker to create yapp input files.
#
# Use: yacker -l perl -s -n <name> <name>.txt
#
# to generate a yapp input module called TurtleS.yp.


# $Id: TurtleSParser.pm,v 1.4 2007/08/14 22:27:37 eric Exp $

sub _Error {
    my ($self, $getMessage) = @_;
        exists $self->YYData->{ERRMSG}
    and do {
        print $self->YYData->{ERRMSG};
        delete $self->YYData->{ERRMSG};
        return;
    };
    my $pos = pos $self->YYData->{INPUT};
    my $lastPos = $self->YYData->{my_LASTPOS};
    my $excerpt = substr($self->YYData->{INPUT}, $lastPos, $pos - $lastPos);
    my $expect = @{$self->{STACK}} ? join (' | ', sort {(!(lc $a cmp lc $b)) ? $b cmp $a : lc $a cmp lc $b} map {&_terminalString($_)} $self->YYExpect()) : 'INVALID INITIALIZER';
    if (ref $expect) {
	# Flag unexpected (by the author at this point) refs with '?ref'.
	if (ref $expect eq 'HASH') {
	    if (exists $expect->{NEXT}) {
		$expect = $ {$expect->{NEXT}};
	    } else {
		$expect = "?ref {%$expect}";
	    }
	} elsif (ref $expect eq 'ARRAY') {
	    $expect = "?ref [@$expect]";
	} elsif (ref $expect eq 'SCALAR') {
	    $expect = "?ref $$expect";
	} elsif (ref $expect eq 'GLOB') {
	    $expect = "?ref \**$expect";
	} else {
	    $expect = "?ref ??? $expect";
	}
    }
    my $token = &_terminalString($self->YYData->{my_LASTTOKEN});
    my $value = $self->YYData->{my_LASTVALUE};
    my $message = "expected \"$expect\", got ($token, $value) from \"$excerpt\" at offset $lastPos.\n";
    if ($getMessage) {
	return $message;
    } else {
	die $message;
    }
}

sub _terminalString { # static
    my ($token) = @_;
    if ($token =~ m{^I_T_(.+)$}) {
	$token = "'$1'";
    } elsif ($token =~ m{^T_(.+)$}) {
	if (my $base = $ARGV[0]) {
	    $token = "&lt;<a href=\"${base}$token\">$1</a>&gt;";
	} else {
	    $token = "<$1>";
	}
    }
    return $token;
}

my $AtStart;

sub _Lexer {
    my($self)=shift;

    my ($token, $value) = ('', undef);

  top:
    if (defined $self->YYData->{INPUT} && 
	pos $self->YYData->{INPUT} < length ($self->YYData->{INPUT})) {
	# still some chars left.
    } else {
	return ('', undef);
    }

    $self->YYData->{my_LASTPOS} = pos $self->YYData->{INPUT};
    my $startPos = pos $self->YYData->{INPUT};
    my ($mText, $mLen, $mI, $mLookAhead) = ('', 0, undef, undef);
    for (my $i = 0; $i < @$Tokens; $i++) {
	my $rule = $Tokens->[$i];
	my ($start, $regexp, $action) = @$rule;
	if ($start && !$AtStart) {
	    next;
	}
	eval {
	    if ($self->YYData->{INPUT} =~ m/\G($regexp)/gc) {
		my $lookAhead = length $2;
		my $len = (pos $self->YYData->{INPUT}) - $startPos + $lookAhead;
		if ($len > $mLen) {
		    $mText = substr($self->YYData->{INPUT}, $startPos, $len - $lookAhead);
		    $mLen = $len;
		    $mI = $i;
		    $mLookAhead = $lookAhead
		}
		pos $self->YYData->{INPUT} = $startPos;
	    }
	}; if ($@) {
	    die "error processing $action: $@";
	}
    }
    if ($mLen) {
	my ($start, $regexp, $action) = @{$Tokens->[$mI]};
	pos $self->YYData->{INPUT} += $mLen - $mLookAhead;
	$AtStart = $mText =~ m/\z/gc;
	($token, $value) = ($action, $mText);
    } else {
	my $excerpt = substr($self->YYData->{INPUT}, pos $self->YYData->{INPUT}, 40);
	&utf8::encode($excerpt);
	die "lexer couldn't parse at \"$excerpt\"\n";
    }
    if (!defined $token) {
	# We just parsed whitespace or comment.
	goto top;
    }
#    my $pos = pos $self->YYData->{INPUT};
#    print "\n$pos,$token,$value\n";
    $self->YYData->{my_LASTTOKEN} = $token;
    $self->YYData->{my_LASTVALUE} = $value;
    return ($token, $value);
}

sub addNamespace {
    my ($self, $prefix, $namespace) = @_;
    $self->YYData->{-namespaceHandler}->addNamespace($prefix, $namespace->getUrl());
}

sub mapNamespace {
    my ($self, $qnameStr) = @_;
    return $self->YYData->{-namespaceHandler}->mapNamespace($qnameStr);
}

sub parse {
    my ($self, @args) = @_;
    $self->YYData->{NEXT} = undef;
    $self->YYData->{AnonymousBNodes} = 0;
    return $self->SUPER::parse(@args);
}

# Provide (one) chunk of text to parse.
sub nextChunk {
    my ($self) = @_;
    #return shift (@{$self->YYData->{my_CHUNKS}});
    #return shift (@ARGV);
    return <STDIN>;
}

# Handy debugging wrapper for calling semantics actions.
sub _wrap {
    my ($self, $obj, $method, @args) = @_;
    my @ret;
    eval {
	@ret = $obj->$method(@args);
    }; if ($@) {if (my $ex = &catch('W3C::Util::CachedContextException')) {
	&throw($ex);;
    } elsif ($ex = &catch('W3C::Util::Exception')) {
	my $newEx = new 
	    W3C::Util::CachedContextException(-str => $self->YYData->{INPUT}, 
					      -pos => $self->YYData->{my_LASTPOS}+1, 
					      -errorMessage => $ex->toString);
	$newEx->assumeStackTrace($ex);
	&throw($newEx);
    } else {
	my $newEx = 
	    new W3C::Util::CachedContextException(-str => $self->YYData->{INPUT}, 
						  -pos => $self->YYData->{my_LASTPOS}+1, 
						  -errorMessage => "$obj->$method: $@");
	&throw($newEx);
    }}
    return wantarray ? @ret : $ret[-1];
}

sub printArgs {
    my ($self) = @_;
    return;
    print ':';
    foreach my $arg (@_) {
	print " $arg";
    }
    print ' Curtok:',$self->YYCurtok;
    print ' Curval:',$self->YYCurval;
    print ' Expect:',$self->YYExpect;
    print ' Lexer:',$self->YYLexer;
    print ' Data:',$self->YYData;
    print "\n";
}

# Used by -M invocation:
#   perl -MW3C::Rdf::TurtleSParser -e '(new W3C::Rdf::RLTurtleSParser())->Run' '...'
sub main {
    my ($self) = @_;
    $self->Run();
}

# <parser state support>
sub createBNode {
    my ($self, $label) = @_;
    if (!defined $label) {
	my $n = $self->YYData->{AnonymousBNodes}++;
	$label = "[$n]"
    }
    my $t = $self->YYData->{ALGAE2}->getSourceAttribution;
    $self->YYData->{ALGAE2}->setSourceAttribution($self->YYData->{Attribution} || $t);
    my $ret = new W3C::Rdf::AlgaeCompileTree::BNode($self);
    $self->YYData->{ALGAE2}->setSourceAttribution($t);
    return $ret;
}

sub startList {
    my ($self) = @_;
    return $self->YYData->{list} = [];
}
sub addListNode {
    my ($self, $GraphNode) = @_;
    push (@{$self->YYData->{list}}, $GraphNode);
    return $self->YYData->{list};
}
sub stopList {
    my ($self) = @_;
    my $d =undef;
    my $tail = undef;
    my @nodes;
    foreach my $GraphNode (reverse @{$self->YYData->{list}}) {
	my ($node, $decls) = ref $GraphNode eq 'ARRAY' ? @$GraphNode : ($GraphNode, undef);
	push (@nodes, $node);
	my $n = $self->YYData->{listHead} = $self->createBNode(undef);
	my $first = new W3C::Rdf::AlgaeCompileTree::Url('http://www.w3.org/1999/02/22-rdf-syntax-ns#first', undef, $self);
	my $firstDecl = new W3C::Rdf::AlgaeCompileTree::Decl([$first, $n, $node], undef, $self);
	$d = $d ? new W3C::Rdf::AlgaeCompileTree::Conjunction($d, $firstDecl, $self) : $firstDecl;
	my $rest = new W3C::Rdf::AlgaeCompileTree::Url('http://www.w3.org/1999/02/22-rdf-syntax-ns#rest', undef, $self);
	if (!$tail) {
	    $tail = new W3C::Rdf::AlgaeCompileTree::Url('http://www.w3.org/1999/02/22-rdf-syntax-ns#nil', undef, $self);
	}
	$d = new W3C::Rdf::AlgaeCompileTree::Conjunction($d, new W3C::Rdf::AlgaeCompileTree::Decl([$rest, $n, $tail], undef, $self), $self);

	$d = new W3C::Rdf::AlgaeCompileTree::Conjunction($d, new W3C::Rdf::AlgaeCompileTree::Decl([
							     new W3C::Rdf::AlgaeCompileTree::Url('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', undef, $self), $n, 
							     new W3C::Rdf::AlgaeCompileTree::Url('http://www.w3.org/1999/02/22-rdf-syntax-ns#List', undef, $self)], undef, $self), $self);

	if ($decls) {
	    $d = new W3C::Rdf::AlgaeCompileTree::Conjunction($d, $decls, $self);
	}
	$tail = $n;
    }
    if ($self->YYData->{ALGAE2}{-logicExtensions}{'http://jena.hpl.hp.com/ARQ/list#member'} && @nodes) {
	my $m = new W3C::Rdf::AlgaeCompileTree::Url('http://jena.hpl.hp.com/ARQ/list#member', undef, $self);
	foreach my $node (reverse @nodes) {
	    $d = new W3C::Rdf::AlgaeCompileTree::Conjunction($d, new W3C::Rdf::AlgaeCompileTree::Decl([$m, $tail, $node], undef, $self), $self);
	}
    }

    $self->YYData->{list} = undef;
    return [$tail, $d];
}

sub getDecl {
    my $constraints = $_[1] ? [new W3C::Rdf::AlgaeCompileTree::Constraint(
	new W3C::Rdf::AlgaeCompileTree::Assign($_[1], 
	    new W3C::Rdf::AlgaeCompileTree::KeyName('ATTRIB', 1, $_[0]), $_[0]), $_[0])] : [];
    $_[0]->newDecl([[$_[3], [[$_[5], [[$_[7], $constraints]]]]]]); # hugly re-use ack
}

sub newDecl {
    my ($self, $parm) = @_;
    my $ret;
    foreach my $decl (@$parm) {
	my ($subject, $propValList) = @$decl;
	foreach my $propVal (@$propValList) {
	    my ($property, $valueList) = @$propVal;
	    foreach my $valuePair (@$valueList) {
		my ($value) = $valuePair; # , $constraints) = @$valuePair;
		# print $subject->toString.' '.$property->toString.' '.$value->toString."\n";
		my $toAdd = [];
		if (ref $value eq 'ARRAY') {
		    # we've got an object and a bunch of Decls about that object.
		    $toAdd = [$value->[1]];
		    $value = $value->[0];
		}
		my $newTerm = new W3C::Rdf::AlgaeCompileTree::Decl([$property, $subject, $value], 
								   undef, $self); # $constraints, $self);
		if ($self->YYData->{ALGAE2}{-logicExtensions}{'http://www.w3.org/TR/rdf-schema/#ch_member'} && 
		    $property->getUrl =~ m|^\Qhttp://www.w3.org/1999/02/22-rdf-syntax-ns#\E_[1-9][0-9]*$|) {
		    my $m = new W3C::Rdf::AlgaeCompileTree::Url('http://www.w3.org/2000/01/rdf-schema#member', undef, $self);
		    push (@$toAdd, new W3C::Rdf::AlgaeCompileTree::Decl([$m, $subject, $value], 
									undef, $self)); # $constraints, $self);
		}
		foreach my $term ($newTerm, @$toAdd) {
		    if ($ret) {
			$ret = new W3C::Rdf::AlgaeCompileTree::Conjunction($ret, $term, $self);
		    } else {
			$ret = $term;
		    }
		}
	    }
	}
    }
    return $ret;
}

sub _literalToken { # static
    my ($str, $trim) = @_;
    $str = substr($str, $trim, (length $str) - 2*$trim);
    $str =~ s/\\\\/\\/g;
    $str =~ s/\\t/\t/g;
    $str =~ s/\\n/\n/g;
    $str =~ s/\\r/\r/g;
    $str =~ s/\\b/\b/g;
    $str =~ s/\\f/\f/g;
    $str =~ s/\\'/\'/g;
    $str =~ s/\\"/\"/g;
    return $str;
}

sub resolveQNames {
    my ($self) = @_;
    foreach my $qname (@{$self->YYData->{QNAMES}}) {
	$qname->resolveNS();
    }
}

# </parser state support>

package W3C::Rdf::TurtleSParser;
@W3C::Rdf::TurtleSParser::ISA = qw(W3C::Rdf::_TurtleSParser);
sub new {
    my ($proto, $brqlString, $algae2, $location, %flags) = @_;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new();
    $self->YYData->{INPUT} = $brqlString;
    $self->YYData->{ALGAE2} = $algae2;
    $self->YYData->{BASE} = new W3C::Rdf::AlgaeCompileTree::Url($location, undef, $self); 
    my $source = $self->YYData->{ALGAE2}{-atomDictionary}->getUri($location);
    $self->YYData->{Attribution} = $self->YYData->{ALGAE2}{-atomDictionary}->getGroundFactAttribution($source, undef, undef, undef);

    $self->YYData->{QNAMES} = [];
    $self->YYData->{FLAGS} = {%flags};
    $self->YYData->{patternIdStack} = [];
    $self->YYData->{patternIdByNamedBNode} = {};
    return $self;
}

sub nextChunk {
    my ($self) = @_;
    my $ret = $self->YYData->{SPARQL_STRING};
    $self->YYData->{SPARQL_STRING} = undef;
    return $ret;
}

# Interactive ReadLine parser -- under development
package W3C::Rdf::RLTurtleSParser;
use W3C::Util::Exception;
@W3C::Rdf::RLTurtleSParser::ISA = qw(W3C::Rdf::TurtleSParser);
sub new {
    my ($proto, @parms) = @_;
    my $class = ref($proto) || $proto;

    # Change the parser driver to the readline driver.
    @W3C::Rdf::_TurtleSParser::ISA = qw (W3C::Util::rlDriver);

    my $self = $class->SUPER::new(@parms);
    $self->YYData->{ACTIONS} = [];
    return $self;
}

sub nextChunk {
    my ($self) = @_;
    my $ret = undef;
    if ($self->{rl_COMPLETE_MODE}) {
	if ($self->{rl_SO_FAR}) {
	    $ret = $self->{rl_SO_FAR};
	    $self->{rl_SO_FAR} = undef;
	    #print "nextChunk: $ret\n";
	}
    } else {
	if (@{$self->YYData->{my_CHUNKS}}) {
	    $ret = shift (@{$self->YYData->{my_CHUNKS}});
	} else {
	    #return shift (@ARGV);
	    $ret = $self->readline('')."\n";
	    #print "ret: $ret";
	}
    }
    return $ret;
}

# perl -MW3C::Rdf::TurtleSParser -e '(new W3C::Rdf::RLTurtleSParser())->Run' 'asdf'
# b /usr/share/perl5/Parse/Yapp/Driver.pm:343

##!/usr/bin/perl
#BEGIN {unshift@INC,('../..');}
#use W3C::Rdf::TurtleSParser;
#$p = new W3C::Rdf::RLTurtleSParser();
#$p->main;

#./TurtleSParser "(ask '(<ab:cd> (?asdf ?s ?o)) assert '(ef:gh (?a ?b ?c)))"

1;

__END__

=head1 NAME

W3C::Rdf::TurtleSParser - a Parse::Yapp grammer for the SPARQL language

=head1 SYNOPSIS

  use W3C::Rdf::TurtleSParser;
  my $p = new W3C::Rdf::TurtleSParser($brqlString, $query, "query.txt");
  my $actions = $p->parse($debug);
  foreach my $action (@$actions) {
    $action->delayedEvaluate($self->{RESULT_SET});
  }
  return $self->getReport();

=head1 DESCRIPTION

The TurtleSParser module binds a yapp grammar to semantic actions that build an
AlgaeCompileTree. In general, client applicatiosn have no direct interaction
with TurtleSParser. Devlopers wishing to extend the SPARQL query language
  http://www.w3.org/2001/sw/DataAccess/rq23/

will need the perl yapp modules. The Makefile included with the W3C::Rdf CPAN
module has a target to re-compile the TurtleSParser grammar. Invoke this with
  make TurtleSParser.pm
It is likely that someone extending the TurtleSParser grammar will also want to
extended AlgaeCompileTree.

This module is part of the W3C::Rdf CPAN module.

=head1 AUTHOR

Eric Prud\'hommeaux <eric@w3.org>

=head1 SEE ALSO

W3C::Rdf::AlgaeCompileTree(3) W3C::Rdf::Algae2(3) perl(1).

=cut

1;
