package W3C::Rdf::SomeParser;
use strict;

sub _last {
    return @_ > 1 ? $_[@_-1] : ();
}

sub XXX {
    &_last;
}

1;
