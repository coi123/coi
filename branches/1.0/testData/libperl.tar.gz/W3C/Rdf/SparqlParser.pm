#!/usr/bin/perl
####################################################################
#
#    This file was generated using Parse::Yapp version 1.05.
#
#        Don't edit this file, use source file instead.
#
#             ANY CHANGE MADE HERE WILL BE LOST !
#
####################################################################
package W3C::Rdf::_SparqlParser;
use vars qw ( @ISA );
use strict;

@ISA= qw ( Parse::Yapp::Driver );
# use Parse::Yapp::Driver; @@ replaced by W3C::Util::YappDriver

#line 1 "SparqlParser.yp"

    #BEGIN {unshift@INC,('../..');}
    use W3C::Util::YappDriver;
    @ISA= qw (W3C::Util::YappDriver);

    use W3C::Util::Exception;
    use W3C::Rdf::AlgaeCompileTree qw($DISJUNCTION $NEGATION $OUTER);
#line 10 "SparqlParser.yp"

# START TokenBlock
my $IT_SHUTDOWN = "SHUTDOWN";
my $IT_NOTE = "NOTE";
my $IT_INSERT = "INSERT";
my $IT_DELETE = "DELETE";
my $IT_CREATE = "CREATE";
my $IT_DROP = "DROP";
my $IT_PATHPATTERN = "PATHPATTERN";
my $IT_BINDINGS = "BINDINGS";
my $GT_LCURLEY = "\\{";
my $GT_RCURLEY = "\\}";
my $GT_LPAREN = "\\(";
my $GT_RPAREN = "\\)";
my $IT_NULL = "NULL";
my $IT_BASE = "BASE";
my $IT_PREFIX = "PREFIX";
my $IT_SELECT = "SELECT";
my $IT_DISTINCT = "DISTINCT";
my $IT_REDUCED = "REDUCED";
my $GT_TIMES = "\\*";
my $IT_CONSTRUCT = "CONSTRUCT";
my $IT_DESCRIBE = "DESCRIBE";
my $IT_ASK = "ASK";
my $IT_FROM = "FROM";
my $IT_NAMED = "NAMED";
my $IT_WHERE = "WHERE";
my $IT_ORDER = "ORDER";
my $IT_BY = "BY";
my $IT_ASC = "ASC";
my $IT_DESC = "DESC";
my $IT_LIMIT = "LIMIT";
my $IT_OFFSET = "OFFSET";
my $GT_DOT = "\\.";
my $IT_OPTIONAL = "OPTIONAL";
my $IT_GRAPH = "GRAPH";
my $IT_UNION = "UNION";
my $IT_FILTER = "FILTER";
my $GT_COMMA = ",";
my $GT_SEMI = ";";
my $IT_a = "a";
my $GT_LBRACKET = "\\[";
my $GT_RBRACKET = "\\]";
my $IT_LIST = "LIST";
my $IT_MEMBERS = "MEMBERS";
my $IT_XPATH = "XPATH";
my $GT_OR = "\\|\\|";
my $GT_AND = "&&";
my $GT_EQUAL = "=";
my $GT_NEQUAL = "!=";
my $GT_LT = "<";
my $GT_GT = ">";
my $GT_LE = "<=";
my $GT_GE = ">=";
my $GT_PLUS = "\\+";
my $GT_MINUS = "-";
my $GT_DIVIDE = "\\/";
my $GT_NOT = "!";
my $IT_STR = "STR";
my $IT_LANG = "LANG";
my $IT_LANGMATCHES = "LANGMATCHES";
my $IT_DATATYPE = "DATATYPE";
my $IT_BOUND = "BOUND";
my $IT_sameTerm = "sameTerm";
my $IT_isIRI = "isIRI";
my $IT_isURI = "isURI";
my $IT_isBLANK = "isBLANK";
my $IT_isLITERAL = "isLITERAL";
my $IT_REGEX = "REGEX";
my $GT_DTYPE = "\\^\\^";
my $IT_true = "true";
my $IT_false = "false";
my $IRI_REFT = "<(?:(?:[#-;=\\?-\\[\\]_a-z~-\x{10FFFD}]))*>";
my $LANGTAGT = "\@(?:[A-Za-z])+(?:(?:-(?:[0-9A-Za-z])+))*";
my $INTEGER = "(?:[0-9])+";
my $DECIMAL = "(?:(?:[0-9])+\\.(?:[0-9])*)|(?:\\.(?:[0-9])+)";
my $INTEGER_POSITIVE = "\\+(?:${INTEGER})";
my $DECIMAL_POSITIVE = "\\+(?:${DECIMAL})";
my $INTEGER_NEGATIVE = "-(?:${INTEGER})";
my $DECIMAL_NEGATIVE = "-(?:${DECIMAL})";
my $EXPONENT = "[Ee](?:[\\+-])?(?:[0-9])+";
my $DOUBLE = "(?:(?:[0-9])+\\.(?:[0-9])*(?:${EXPONENT}))|(?:(?:\\.(?:(?:[0-9]))+(?:${EXPONENT}))|(?:(?:(?:[0-9]))+(?:${EXPONENT})))";
my $DOUBLE_NEGATIVE = "-(?:${DOUBLE})";
my $DOUBLE_POSITIVE = "\\+(?:${DOUBLE})";
my $ECHAR = "\\\\[\\\"\\'\\\\bfnrt]";
my $STRING_LITERAL_LONG2 = "\\\"\\\"\\\"(?:(?:(?:(?:(?:\\\")|(?:\\\"\\\")))?(?:(?:[\x{0000}-!#-\\[\\]-\x{10FFFD}])|(?:(?:${ECHAR})))))*\\\"\\\"\\\"";
my $STRING_LITERAL_LONG1 = "\\'\\'\\'(?:(?:(?:(?:(?:\\')|(?:\\'\\')))?(?:(?:[\x{0000}-&\\(-\\[\\]-\x{10FFFD}])|(?:(?:${ECHAR})))))*\\'\\'\\'";
my $STRING_LITERAL2 = "\\\"(?:(?:(?:(?:[\x{0000}-\\t\x{000B}-\x{000C}\x{000E}-!#-\\[\\]-\x{10FFFD}]))|(?:(?:${ECHAR}))))*\\\"";
my $STRING_LITERAL1 = "\\'(?:(?:(?:(?:[\x{0000}-\\t\x{000B}-\x{000C}\x{000E}-&\\(-\\[\\]-\x{10FFFD}]))|(?:(?:${ECHAR}))))*\\'";
my $WS = "(?: )|(?:(?:\\t)|(?:(?:\\r)|(?:\\n)))";
my $NIL = "\\((?:(?:${WS}))*\\)";
my $ANON = "\\[(?:(?:${WS}))*\\]";
my $PN_CHARS_BASE = "(?:[A-Z])|(?:(?:[a-z])|(?:(?:[\x{00C0}-\x{00D6}])|(?:(?:[\x{00D8}-\x{00F6}])|(?:(?:[\x{00F8}-\x{02FF}])|(?:(?:[\x{0370}-\x{037D}])|(?:(?:[\x{037F}-\x{1FFF}])|(?:(?:[\x{200C}-\x{200D}])|(?:(?:[\x{2070}-\x{218F}])|(?:(?:[\x{2C00}-\x{2FEF}])|(?:(?:[\x{3001}-\x{D7FF}])|(?:(?:[\x{F900}-\x{FDCF}])|(?:(?:[\x{FDF0}-\x{FFFD}])|(?:[\x{10000}-\x{EFFFF}])))))))))))))";
my $PN_CHARS_U = "(?:(?:${PN_CHARS_BASE}))|(?:_)";
my $VARNAME = "(?:(?:(?:${PN_CHARS_U}))|(?:[0-9]))(?:(?:(?:(?:${PN_CHARS_U}))|(?:(?:[0-9])|(?:(?:\x{00B7})|(?:(?:[\x{0300}-\x{036F}])|(?:[\x{203F}-\x{2040}]))))))*";
my $VAR2T = "\\\$(?:${VARNAME})";
my $VAR1T = "\\?(?:${VARNAME})";
my $PN_CHARS = "(?:(?:${PN_CHARS_U}))|(?:(?:-)|(?:(?:[0-9])|(?:(?:\x{00B7})|(?:(?:[\x{0300}-\x{036F}])|(?:[\x{203F}-\x{2040}])))))";
my $PN_PREFIX = "(?:${PN_CHARS_BASE})(?:(?:(?:(?:(?:(?:${PN_CHARS}))|(?:\\.)))*(?:${PN_CHARS})))?";
my $PNAME_NST = "(?:(?:${PN_PREFIX}))?:";
my $PN_LOCAL = "(?:(?:(?:${PN_CHARS_U}))|(?:[0-9]))(?:(?:(?:(?:(?:(?:${PN_CHARS}))|(?:\\.)))*(?:${PN_CHARS})))?";
my $BLANK_NODE_LABELT = "_:(?:${PN_LOCAL})";
my $PNAME_LNT = "(?:${PNAME_NST})(?:${PN_LOCAL})";
my $PASSED_TOKENS = "(?:(?:(?:${WS}))+)|(?:#(?:[\x{0000}-\\t\x{000B}-\x{10FFFD}])*\\n)";
my $Tokens = [[0, qr/$PASSED_TOKENS/, undef],
              [0, qr/$IT_SHUTDOWN/i, 'IT_SHUTDOWN'],
              [0, qr/$IT_NOTE/i, 'IT_NOTE'],
              [0, qr/$IT_INSERT/i, 'IT_INSERT'],
              [0, qr/$IT_DELETE/i, 'IT_DELETE'],
              [0, qr/$IT_CREATE/i, 'IT_CREATE'],
              [0, qr/$IT_DROP/i, 'IT_DROP'],
              [0, qr/$IT_PATHPATTERN/i, 'IT_PATHPATTERN'],
              [0, qr/$IT_BINDINGS/i, 'IT_BINDINGS'],
              [0, qr/$GT_LCURLEY/i, 'GT_LCURLEY'],
              [0, qr/$GT_RCURLEY/i, 'GT_RCURLEY'],
              [0, qr/$GT_LPAREN/i, 'GT_LPAREN'],
              [0, qr/$GT_RPAREN/i, 'GT_RPAREN'],
              [0, qr/$IT_NULL/i, 'IT_NULL'],
              [0, qr/$IT_BASE/i, 'IT_BASE'],
              [0, qr/$IT_PREFIX/i, 'IT_PREFIX'],
              [0, qr/$IT_SELECT/i, 'IT_SELECT'],
              [0, qr/$IT_DISTINCT/i, 'IT_DISTINCT'],
              [0, qr/$IT_REDUCED/i, 'IT_REDUCED'],
              [0, qr/$GT_TIMES/i, 'GT_TIMES'],
              [0, qr/$IT_CONSTRUCT/i, 'IT_CONSTRUCT'],
              [0, qr/$IT_DESCRIBE/i, 'IT_DESCRIBE'],
              [0, qr/$IT_ASK/i, 'IT_ASK'],
              [0, qr/$IT_FROM/i, 'IT_FROM'],
              [0, qr/$IT_NAMED/i, 'IT_NAMED'],
              [0, qr/$IT_WHERE/i, 'IT_WHERE'],
              [0, qr/$IT_ORDER/i, 'IT_ORDER'],
              [0, qr/$IT_BY/i, 'IT_BY'],
              [0, qr/$IT_ASC/i, 'IT_ASC'],
              [0, qr/$IT_DESC/i, 'IT_DESC'],
              [0, qr/$IT_LIMIT/i, 'IT_LIMIT'],
              [0, qr/$IT_OFFSET/i, 'IT_OFFSET'],
              [0, qr/$GT_DOT/i, 'GT_DOT'],
              [0, qr/$IT_OPTIONAL/i, 'IT_OPTIONAL'],
              [0, qr/$IT_GRAPH/i, 'IT_GRAPH'],
              [0, qr/$IT_UNION/i, 'IT_UNION'],
              [0, qr/$IT_FILTER/i, 'IT_FILTER'],
              [0, qr/$GT_COMMA/i, 'GT_COMMA'],
              [0, qr/$GT_SEMI/i, 'GT_SEMI'],
              [0, qr/$IT_a/i, 'IT_a'],
              [0, qr/$GT_LBRACKET/i, 'GT_LBRACKET'],
              [0, qr/$GT_RBRACKET/i, 'GT_RBRACKET'],
              [0, qr/$IT_LIST/i, 'IT_LIST'],
              [0, qr/$IT_MEMBERS/i, 'IT_MEMBERS'],
              [0, qr/$IT_XPATH/i, 'IT_XPATH'],
              [0, qr/$GT_OR/i, 'GT_OR'],
              [0, qr/$GT_AND/i, 'GT_AND'],
              [0, qr/$GT_EQUAL/i, 'GT_EQUAL'],
              [0, qr/$GT_NEQUAL/i, 'GT_NEQUAL'],
              [0, qr/$GT_LT/i, 'GT_LT'],
              [0, qr/$GT_GT/i, 'GT_GT'],
              [0, qr/$GT_LE/i, 'GT_LE'],
              [0, qr/$GT_GE/i, 'GT_GE'],
              [0, qr/$GT_PLUS/i, 'GT_PLUS'],
              [0, qr/$GT_MINUS/i, 'GT_MINUS'],
              [0, qr/$GT_DIVIDE/i, 'GT_DIVIDE'],
              [0, qr/$GT_NOT/i, 'GT_NOT'],
              [0, qr/$IT_STR/i, 'IT_STR'],
              [0, qr/$IT_LANG/i, 'IT_LANG'],
              [0, qr/$IT_LANGMATCHES/i, 'IT_LANGMATCHES'],
              [0, qr/$IT_DATATYPE/i, 'IT_DATATYPE'],
              [0, qr/$IT_BOUND/i, 'IT_BOUND'],
              [0, qr/$IT_sameTerm/i, 'IT_sameTerm'],
              [0, qr/$IT_isIRI/i, 'IT_isIRI'],
              [0, qr/$IT_isURI/i, 'IT_isURI'],
              [0, qr/$IT_isBLANK/i, 'IT_isBLANK'],
              [0, qr/$IT_isLITERAL/i, 'IT_isLITERAL'],
              [0, qr/$IT_REGEX/i, 'IT_REGEX'],
              [0, qr/$GT_DTYPE/i, 'GT_DTYPE'],
              [0, qr/$IT_true/i, 'IT_true'],
              [0, qr/$IT_false/i, 'IT_false'],
              [0, qr/$IRI_REFT/, 'IRI_REFT'],
              [0, qr/$PNAME_NST/, 'PNAME_NST'],
              [0, qr/$PNAME_LNT/, 'PNAME_LNT'],
              [0, qr/$BLANK_NODE_LABELT/, 'BLANK_NODE_LABELT'],
              [0, qr/$VAR1T/, 'VAR1T'],
              [0, qr/$VAR2T/, 'VAR2T'],
              [0, qr/$LANGTAGT/, 'LANGTAGT'],
              [0, qr/$INTEGER/, 'INTEGER'],
              [0, qr/$DECIMAL/, 'DECIMAL'],
              [0, qr/$DOUBLE/, 'DOUBLE'],
              [0, qr/$INTEGER_POSITIVE/, 'INTEGER_POSITIVE'],
              [0, qr/$DECIMAL_POSITIVE/, 'DECIMAL_POSITIVE'],
              [0, qr/$DOUBLE_POSITIVE/, 'DOUBLE_POSITIVE'],
              [0, qr/$INTEGER_NEGATIVE/, 'INTEGER_NEGATIVE'],
              [0, qr/$DECIMAL_NEGATIVE/, 'DECIMAL_NEGATIVE'],
              [0, qr/$DOUBLE_NEGATIVE/, 'DOUBLE_NEGATIVE'],
              [0, qr/$STRING_LITERAL1/, 'STRING_LITERAL1'],
              [0, qr/$STRING_LITERAL2/, 'STRING_LITERAL2'],
              [0, qr/$STRING_LITERAL_LONG1/, 'STRING_LITERAL_LONG1'],
              [0, qr/$STRING_LITERAL_LONG2/, 'STRING_LITERAL_LONG2'],
              [0, qr/$NIL/, 'NIL'],
              [0, qr/$ANON/, 'ANON']];
# END TokenBlock


sub new {
        my($class)=shift;
        ref($class)
    and $class=ref($class);

    my($self)=$class->SUPER::new( yyversion => '1.05',
                                  yystates =>
[
	{#State 0
		ACTIONS => {
			'IT_PATHPATTERN' => 3,
			'IT_SHUTDOWN' => 2,
			'IT_BASE' => 5,
			'IT_NOTE' => 9
		},
		DEFAULT => -39,
		GOTOS => {
			'PathPattern' => 6,
			'Prologue' => 8,
			'Query' => 7,
			'BaseDecl' => 1,
			'Start' => 4,
			'_QBaseDecl_E_Opt' => 10
		}
	},
	{#State 1
		DEFAULT => -40
	},
	{#State 2
		ACTIONS => {
			'STRING_LITERAL_LONG1' => 15,
			'STRING_LITERAL1' => 11,
			'STRING_LITERAL2' => 16,
			'STRING_LITERAL_LONG2' => 12
		},
		DEFAULT => -5,
		GOTOS => {
			'String' => 13,
			'_QString_E_Opt' => 14
		}
	},
	{#State 3
		DEFAULT => -26,
		GOTOS => {
			'@2-1' => 17
		}
	},
	{#State 4
		ACTIONS => {
			'' => 18
		}
	},
	{#State 5
		ACTIONS => {
			'IRI_REFT' => 20
		},
		GOTOS => {
			'IRI_REF' => 19
		}
	},
	{#State 6
		DEFAULT => -4
	},
	{#State 7
		DEFAULT => -1
	},
	{#State 8
		ACTIONS => {
			'IT_DESCRIBE' => 22,
			'IT_CONSTRUCT' => 24
		},
		DEFAULT => -16,
		GOTOS => {
			'DescribeQuery' => 23,
			'_O_QSelectQuery_E_Or_QInsertQuery_E_Or_QDeleteQuery_E_Or_QBindingClause_E_Or_QAskQuery_E_Or_QWhereClause_E_Or_QCreateQuery_E_Or_QDropQuery_E_Star_Or_QConstructQuery_E_Or_QDescribeQuery_E_C' => 25,
			'ConstructQuery' => 26,
			'_Q_O_QSelectQuery_E_Or_QInsertQuery_E_Or_QDeleteQuery_E_Or_QBindingClause_E_Or_QAskQuery_E_Or_QWhereClause_E_Or_QCreateQuery_E_Or_QDropQuery_E_C_E_Star' => 21
		}
	},
	{#State 9
		ACTIONS => {
			'STRING_LITERAL_LONG1' => 15,
			'STRING_LITERAL1' => 11,
			'STRING_LITERAL2' => 16,
			'STRING_LITERAL_LONG2' => 12
		},
		DEFAULT => -5,
		GOTOS => {
			'String' => 13,
			'_QString_E_Opt' => 27
		}
	},
	{#State 10
		DEFAULT => -41,
		GOTOS => {
			'_QPrefixDecl_E_Star' => 28
		}
	},
	{#State 11
		DEFAULT => -275
	},
	{#State 12
		DEFAULT => -278
	},
	{#State 13
		DEFAULT => -6
	},
	{#State 14
		DEFAULT => -2
	},
	{#State 15
		DEFAULT => -277
	},
	{#State 16
		DEFAULT => -276
	},
	{#State 17
		ACTIONS => {
			'GT_LCURLEY' => 30
		},
		GOTOS => {
			'ConstructTemplate' => 29
		}
	},
	{#State 18
		DEFAULT => 0
	},
	{#State 19
		DEFAULT => -43
	},
	{#State 20
		DEFAULT => -285
	},
	{#State 21
		ACTIONS => {
			'IT_ASK' => 33,
			'IT_WHERE' => 31,
			'IT_CREATE' => 41,
			'IT_SELECT' => 36,
			'IT_DELETE' => 37,
			'IT_INSERT' => 42,
			'GT_LCURLEY' => -79,
			'IT_DROP' => 44,
			'IT_BINDINGS' => 45
		},
		DEFAULT => -18,
		GOTOS => {
			'_QIT_WHERE_E_Opt' => 32,
			'AskQuery' => 34,
			'CreateQuery' => 35,
			'DropQuery' => 38,
			'SelectQuery' => 43,
			'DeleteQuery' => 39,
			'InsertQuery' => 40,
			'WhereClause' => 48,
			'_O_QSelectQuery_E_Or_QInsertQuery_E_Or_QDeleteQuery_E_Or_QBindingClause_E_Or_QAskQuery_E_Or_QWhereClause_E_Or_QCreateQuery_E_Or_QDropQuery_E_C' => 46,
			'BindingClause' => 47
		}
	},
	{#State 22
		ACTIONS => {
			'PNAME_NST' => 64,
			'GT_TIMES' => 54,
			'VAR1T' => 57,
			'IRI_REFT' => 20,
			'PNAME_LNT' => 51,
			'VAR2T' => 50
		},
		GOTOS => {
			'_QVarOrIRIref_E_Plus' => 49,
			'PrefixedName' => 58,
			'VAR1' => 52,
			'PNAME_LN' => 59,
			'_O_QVarOrIRIref_E_Plus_Or_QGT_TIMES_E_C' => 60,
			'PNAME_NS' => 61,
			'IRI_REF' => 53,
			'VarOrIRIref' => 63,
			'IRIref' => 62,
			'VAR2' => 55,
			'Var' => 56
		}
	},
	{#State 23
		DEFAULT => -20
	},
	{#State 24
		DEFAULT => -59,
		GOTOS => {
			'@3-1' => 65
		}
	},
	{#State 25
		DEFAULT => -7
	},
	{#State 26
		DEFAULT => -19
	},
	{#State 27
		DEFAULT => -3
	},
	{#State 28
		ACTIONS => {
			'IT_PREFIX' => 67
		},
		DEFAULT => -38,
		GOTOS => {
			'PrefixDecl' => 66
		}
	},
	{#State 29
		ACTIONS => {
			'IT_ORDER' => 70
		},
		DEFAULT => -82,
		GOTOS => {
			'SolutionModifier' => 69,
			'_QOrderClause_E_Opt' => 68,
			'OrderClause' => 71
		}
	},
	{#State 30
		ACTIONS => {
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 93,
			'STRING_LITERAL_LONG2' => 12,
			'IT_true' => 74,
			'PNAME_LNT' => 51,
			'VAR2T' => 50,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'NIL' => 96,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'DECIMAL_NEGATIVE' => 98,
			'INTEGER' => 80,
			'DOUBLE' => 101,
			'BLANK_NODE_LABELT' => 100,
			'STRING_LITERAL1' => 11,
			'IT_XPATH' => 81,
			'INTEGER_POSITIVE' => 102,
			'VAR1T' => 57,
			'ANON' => 82,
			'GT_LBRACKET' => 105,
			'DECIMAL_POSITIVE' => 83,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 85,
			'IT_false' => 108,
			'IT_MEMBERS' => 87,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20
		},
		DEFAULT => -143,
		GOTOS => {
			'BooleanLiteral' => 72,
			'NumericLiteralPositive' => 91,
			'String' => 73,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'TriplesSameSubject' => 97,
			'IRI_REF' => 53,
			'_QConstructTriples_E_Opt' => 77,
			'NumericLiteral' => 78,
			'VAR2' => 55,
			'Var' => 79,
			'VarOrTerm' => 99,
			'GraphTerm' => 106,
			'TriplesNode' => 104,
			'BLANK_NODE_LABEL' => 103,
			'PrefixedName' => 58,
			'PNAME_LN' => 59,
			'BlankNode' => 107,
			'PNAME_NS' => 61,
			'ConstructTriples' => 86,
			'IRIref' => 88,
			'BlankNodePropertyList' => 89,
			'Collection' => 90,
			'RDFLiteral' => 109
		}
	},
	{#State 31
		DEFAULT => -80
	},
	{#State 32
		ACTIONS => {
			'GT_LCURLEY' => 110
		},
		GOTOS => {
			'GroupGraphPattern' => 111
		}
	},
	{#State 33
		DEFAULT => -57,
		GOTOS => {
			'_QDatasetClause_E_Star' => 112
		}
	},
	{#State 34
		DEFAULT => -12
	},
	{#State 35
		DEFAULT => -14
	},
	{#State 36
		ACTIONS => {
			'IT_DISTINCT' => 114,
			'IT_REDUCED' => 115
		},
		DEFAULT => -48,
		GOTOS => {
			'_O_QIT_DISTINCT_E_Or_QIT_REDUCED_E_C' => 113,
			'_Q_O_QIT_DISTINCT_E_Or_QIT_REDUCED_E_C_E_Opt' => 116
		}
	},
	{#State 37
		ACTIONS => {
			'GT_LCURLEY' => 110
		},
		GOTOS => {
			'GroupGraphPattern' => 117
		}
	},
	{#State 38
		DEFAULT => -15
	},
	{#State 39
		DEFAULT => -10
	},
	{#State 40
		DEFAULT => -9
	},
	{#State 41
		ACTIONS => {
			'PNAME_NST' => 64,
			'VAR1T' => 57,
			'PNAME_LNT' => 51,
			'VAR2T' => 50,
			'IRI_REFT' => 20
		},
		GOTOS => {
			'PrefixedName' => 58,
			'VAR1' => 52,
			'PNAME_LN' => 59,
			'IRI_REF' => 53,
			'PNAME_NS' => 61,
			'IRIref' => 62,
			'VarOrIRIref' => 118,
			'VAR2' => 55,
			'Var' => 56
		}
	},
	{#State 42
		DEFAULT => -21,
		GOTOS => {
			'@1-1' => 119
		}
	},
	{#State 43
		DEFAULT => -8
	},
	{#State 44
		ACTIONS => {
			'PNAME_NST' => 64,
			'VAR1T' => 57,
			'PNAME_LNT' => 51,
			'VAR2T' => 50,
			'IRI_REFT' => 20
		},
		GOTOS => {
			'PrefixedName' => 58,
			'VAR1' => 52,
			'PNAME_LN' => 59,
			'IRI_REF' => 53,
			'PNAME_NS' => 61,
			'IRIref' => 62,
			'VarOrIRIref' => 120,
			'VAR2' => 55,
			'Var' => 56
		}
	},
	{#State 45
		ACTIONS => {
			'VAR1T' => 57,
			'VAR2T' => 50
		},
		GOTOS => {
			'VAR1' => 52,
			'_QVar_E_Plus' => 122,
			'Var' => 121,
			'VAR2' => 55
		}
	},
	{#State 46
		DEFAULT => -17
	},
	{#State 47
		DEFAULT => -11
	},
	{#State 48
		DEFAULT => -13
	},
	{#State 49
		ACTIONS => {
			'VAR1T' => 57,
			'PNAME_LNT' => 51,
			'VAR2T' => 50,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20
		},
		DEFAULT => -67,
		GOTOS => {
			'PrefixedName' => 58,
			'VAR1' => 52,
			'PNAME_LN' => 59,
			'IRI_REF' => 53,
			'PNAME_NS' => 61,
			'IRIref' => 62,
			'VarOrIRIref' => 123,
			'VAR2' => 55,
			'Var' => 56
		}
	},
	{#State 50
		DEFAULT => -290
	},
	{#State 51
		DEFAULT => -287
	},
	{#State 52
		DEFAULT => -181
	},
	{#State 53
		DEFAULT => -279
	},
	{#State 54
		DEFAULT => -68
	},
	{#State 55
		DEFAULT => -182
	},
	{#State 56
		DEFAULT => -179
	},
	{#State 57
		DEFAULT => -289
	},
	{#State 58
		DEFAULT => -280
	},
	{#State 59
		DEFAULT => -281
	},
	{#State 60
		DEFAULT => -57,
		GOTOS => {
			'_QDatasetClause_E_Star' => 124
		}
	},
	{#State 61
		DEFAULT => -282
	},
	{#State 62
		DEFAULT => -180
	},
	{#State 63
		DEFAULT => -65
	},
	{#State 64
		DEFAULT => -286
	},
	{#State 65
		ACTIONS => {
			'GT_LCURLEY' => 30
		},
		GOTOS => {
			'ConstructTemplate' => 125
		}
	},
	{#State 66
		DEFAULT => -42
	},
	{#State 67
		ACTIONS => {
			'PNAME_NST' => 64
		},
		GOTOS => {
			'PNAME_NS' => 126
		}
	},
	{#State 68
		ACTIONS => {
			'IT_OFFSET' => 127,
			'IT_LIMIT' => 133
		},
		DEFAULT => -84,
		GOTOS => {
			'LimitOffsetClauses' => 130,
			'LimitClause' => 131,
			'_O_QLimitClause_E_S_QOffsetClause_E_Opt_Or_QOffsetClause_E_S_QLimitClause_E_Opt_C' => 132,
			'_QLimitOffsetClauses_E_Opt' => 128,
			'OffsetClause' => 129
		}
	},
	{#State 69
		DEFAULT => -27
	},
	{#State 70
		ACTIONS => {
			'IT_BY' => 134
		}
	},
	{#State 71
		DEFAULT => -83
	},
	{#State 72
		DEFAULT => -186
	},
	{#State 73
		ACTIONS => {
			'LANGTAGT' => 138,
			'GT_DTYPE' => 140
		},
		DEFAULT => -259,
		GOTOS => {
			'LANGTAG' => 135,
			'_Q_O_QLANGTAG_E_Or_QGT_DTYPE_E_S_QIRIref_E_C_E_Opt' => 139,
			'_O_QGT_DTYPE_E_S_QIRIref_E_C' => 136,
			'_O_QLANGTAG_E_Or_QGT_DTYPE_E_S_QIRIref_E_C' => 137
		}
	},
	{#State 74
		DEFAULT => -273
	},
	{#State 75
		DEFAULT => -270
	},
	{#State 76
		DEFAULT => -265
	},
	{#State 77
		ACTIONS => {
			'GT_RCURLEY' => 141
		}
	},
	{#State 78
		DEFAULT => -185
	},
	{#State 79
		DEFAULT => -177
	},
	{#State 80
		DEFAULT => -264
	},
	{#State 81
		ACTIONS => {
			'GT_LPAREN' => 142
		}
	},
	{#State 82
		DEFAULT => -284
	},
	{#State 83
		DEFAULT => -268
	},
	{#State 84
		DEFAULT => -272
	},
	{#State 85
		ACTIONS => {
			'GT_LPAREN' => 143
		}
	},
	{#State 86
		DEFAULT => -144
	},
	{#State 87
		ACTIONS => {
			'GT_LPAREN' => 144
		}
	},
	{#State 88
		DEFAULT => -183
	},
	{#State 89
		DEFAULT => -169
	},
	{#State 90
		DEFAULT => -168
	},
	{#State 91
		DEFAULT => -262
	},
	{#State 92
		DEFAULT => -269
	},
	{#State 93
		DEFAULT => -171,
		GOTOS => {
			'@8-1' => 145
		}
	},
	{#State 94
		DEFAULT => -263
	},
	{#State 95
		DEFAULT => -261
	},
	{#State 96
		DEFAULT => -191
	},
	{#State 97
		ACTIONS => {
			'GT_DOT' => 147
		},
		DEFAULT => -147,
		GOTOS => {
			'_Q_O_QGT_DOT_E_S_QConstructTriples_E_Opt_C_E_Opt' => 148,
			'_O_QGT_DOT_E_S_QConstructTriples_E_Opt_C' => 146
		}
	},
	{#State 98
		DEFAULT => -271
	},
	{#State 99
		ACTIONS => {
			'IT_a' => 152,
			'PNAME_NST' => 64,
			'VAR1T' => 57,
			'PNAME_LNT' => 51,
			'VAR2T' => 50,
			'IRI_REFT' => 20
		},
		GOTOS => {
			'Verb' => 150,
			'PrefixedName' => 58,
			'VAR1' => 52,
			'PropertyListNotEmpty' => 149,
			'PNAME_LN' => 59,
			'PNAME_NS' => 61,
			'IRI_REF' => 53,
			'IRIref' => 62,
			'VarOrIRIref' => 151,
			'VAR2' => 55,
			'Var' => 56
		}
	},
	{#State 100
		DEFAULT => -288
	},
	{#State 101
		DEFAULT => -266
	},
	{#State 102
		DEFAULT => -267
	},
	{#State 103
		DEFAULT => -283
	},
	{#State 104
		ACTIONS => {
			'IT_a' => 152,
			'VAR1T' => 57,
			'PNAME_LNT' => 51,
			'VAR2T' => 50,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20
		},
		DEFAULT => -159,
		GOTOS => {
			'_QPropertyListNotEmpty_E_Opt' => 154,
			'Verb' => 150,
			'PrefixedName' => 58,
			'VAR1' => 52,
			'PropertyListNotEmpty' => 153,
			'PNAME_LN' => 59,
			'PNAME_NS' => 61,
			'IRI_REF' => 53,
			'PropertyList' => 155,
			'IRIref' => 62,
			'VarOrIRIref' => 151,
			'VAR2' => 55,
			'Var' => 56
		}
	},
	{#State 105
		ACTIONS => {
			'IT_a' => 152,
			'PNAME_NST' => 64,
			'VAR1T' => 57,
			'PNAME_LNT' => 51,
			'VAR2T' => 50,
			'IRI_REFT' => 20
		},
		GOTOS => {
			'Verb' => 150,
			'PrefixedName' => 58,
			'VAR1' => 52,
			'PropertyListNotEmpty' => 156,
			'PNAME_LN' => 59,
			'PNAME_NS' => 61,
			'IRI_REF' => 53,
			'IRIref' => 62,
			'VarOrIRIref' => 151,
			'VAR2' => 55,
			'Var' => 56
		}
	},
	{#State 106
		DEFAULT => -178
	},
	{#State 107
		DEFAULT => -187
	},
	{#State 108
		DEFAULT => -274
	},
	{#State 109
		DEFAULT => -184
	},
	{#State 110
		DEFAULT => -105,
		GOTOS => {
			'@5-1' => 157
		}
	},
	{#State 111
		DEFAULT => -78
	},
	{#State 112
		ACTIONS => {
			'IT_WHERE' => 31,
			'IT_FROM' => 158
		},
		DEFAULT => -79,
		GOTOS => {
			'_QIT_WHERE_E_Opt' => 32,
			'WhereClause' => 160,
			'DatasetClause' => 159
		}
	},
	{#State 113
		DEFAULT => -49
	},
	{#State 114
		DEFAULT => -46
	},
	{#State 115
		DEFAULT => -47
	},
	{#State 116
		ACTIONS => {
			'IT_REGEX' => 167,
			'IT_LANGMATCHES' => 174,
			'GT_LPAREN' => 175,
			'IT_LANG' => 161,
			'IT_DATATYPE' => 162,
			'IT_STR' => 178,
			'VAR1T' => 57,
			'VAR2T' => 50,
			'IT_isBLANK' => 169,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'GT_TIMES' => 164,
			'IT_isIRI' => 179,
			'IT_isLITERAL' => 165,
			'IT_BOUND' => 172
		},
		GOTOS => {
			'RegexExpression' => 173,
			'BrackettedExpression' => 168,
			'VAR1' => 52,
			'_O_QVar_E_Or_QBrackettedExpression_E_Or_QBuiltInCall_E_C' => 163,
			'BuiltInCall' => 170,
			'_O_QVar_E_Or_QBrackettedExpression_E_Or_QBuiltInCall_E_Plus_Or_QGT_TIMES_E_C' => 171,
			'_Q_O_QVar_E_Or_QBrackettedExpression_E_Or_QBuiltInCall_E_C_E_Plus' => 180,
			'VAR2' => 55,
			'Var' => 166
		}
	},
	{#State 117
		DEFAULT => -23
	},
	{#State 118
		DEFAULT => -24
	},
	{#State 119
		ACTIONS => {
			'GT_LCURLEY' => 110
		},
		GOTOS => {
			'GroupGraphPattern' => 181
		}
	},
	{#State 120
		DEFAULT => -25
	},
	{#State 121
		DEFAULT => -29
	},
	{#State 122
		ACTIONS => {
			'GT_LCURLEY' => 182,
			'VAR1T' => 57,
			'VAR2T' => 50
		},
		GOTOS => {
			'VAR1' => 52,
			'Var' => 183,
			'VAR2' => 55
		}
	},
	{#State 123
		DEFAULT => -66
	},
	{#State 124
		ACTIONS => {
			'IT_WHERE' => 31,
			'GT_LCURLEY' => -79,
			'IT_FROM' => 158
		},
		DEFAULT => -69,
		GOTOS => {
			'_QWhereClause_E_Opt' => 185,
			'_QIT_WHERE_E_Opt' => 32,
			'DatasetClause' => 159,
			'WhereClause' => 184
		}
	},
	{#State 125
		DEFAULT => -60,
		GOTOS => {
			'@4-3' => 186
		}
	},
	{#State 126
		ACTIONS => {
			'IRI_REFT' => 20
		},
		GOTOS => {
			'IRI_REF' => 187
		}
	},
	{#State 127
		ACTIONS => {
			'INTEGER' => 188
		}
	},
	{#State 128
		DEFAULT => -81
	},
	{#State 129
		ACTIONS => {
			'IT_LIMIT' => 133
		},
		DEFAULT => -89,
		GOTOS => {
			'LimitClause' => 190,
			'_QLimitClause_E_Opt' => 189
		}
	},
	{#State 130
		DEFAULT => -85
	},
	{#State 131
		ACTIONS => {
			'IT_OFFSET' => 127
		},
		DEFAULT => -87,
		GOTOS => {
			'_QOffsetClause_E_Opt' => 191,
			'OffsetClause' => 192
		}
	},
	{#State 132
		DEFAULT => -86
	},
	{#State 133
		ACTIONS => {
			'INTEGER' => 193
		}
	},
	{#State 134
		ACTIONS => {
			'IT_LANGMATCHES' => 174,
			'GT_LPAREN' => 175,
			'IT_LANG' => 161,
			'IT_DESC' => 194,
			'IT_DATATYPE' => 162,
			'PNAME_LNT' => 51,
			'VAR2T' => 50,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'IT_ASC' => 195,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'IT_STR' => 178,
			'VAR1T' => 57,
			'IT_isBLANK' => 169,
			'PNAME_NST' => 64,
			'IT_isIRI' => 179,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172
		},
		GOTOS => {
			'RegexExpression' => 173,
			'_O_QIT_ASC_E_Or_QIT_DESC_E_C' => 203,
			'VAR1' => 52,
			'Constraint' => 205,
			'FunctionCall' => 204,
			'IRI_REF' => 53,
			'VAR2' => 55,
			'Var' => 196,
			'_QOrderCondition_E_Plus' => 197,
			'_O_QConstraint_E_Or_QVar_E_C' => 198,
			'BrackettedExpression' => 199,
			'PrefixedName' => 58,
			'BuiltInCall' => 200,
			'PNAME_LN' => 59,
			'OrderCondition' => 206,
			'PNAME_NS' => 61,
			'IRIref' => 201,
			'_O_QIT_ASC_E_Or_QIT_DESC_E_S_QBrackettedExpression_E_C' => 202
		}
	},
	{#State 135
		DEFAULT => -257
	},
	{#State 136
		DEFAULT => -258
	},
	{#State 137
		DEFAULT => -260
	},
	{#State 138
		DEFAULT => -291
	},
	{#State 139
		DEFAULT => -255
	},
	{#State 140
		ACTIONS => {
			'PNAME_NST' => 64,
			'PNAME_LNT' => 51,
			'IRI_REFT' => 20
		},
		GOTOS => {
			'PNAME_LN' => 59,
			'PNAME_NS' => 61,
			'IRI_REF' => 53,
			'IRIref' => 207,
			'PrefixedName' => 58
		}
	},
	{#State 141
		DEFAULT => -142
	},
	{#State 142
		ACTIONS => {
			'STRING_LITERAL_LONG1' => 15,
			'STRING_LITERAL1' => 11,
			'STRING_LITERAL2' => 16,
			'STRING_LITERAL_LONG2' => 12
		},
		GOTOS => {
			'String' => 208
		}
	},
	{#State 143
		ACTIONS => {
			'VAR1T' => 57,
			'VAR2T' => 50
		},
		GOTOS => {
			'VAR1' => 52,
			'Var' => 209,
			'VAR2' => 55
		}
	},
	{#State 144
		ACTIONS => {
			'VAR1T' => 57,
			'VAR2T' => 50
		},
		GOTOS => {
			'VAR1' => 52,
			'Var' => 210,
			'VAR2' => 55
		}
	},
	{#State 145
		ACTIONS => {
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 93,
			'STRING_LITERAL_LONG2' => 12,
			'IT_true' => 74,
			'PNAME_LNT' => 51,
			'VAR2T' => 50,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'NIL' => 96,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'DECIMAL_NEGATIVE' => 98,
			'INTEGER' => 80,
			'DOUBLE' => 101,
			'BLANK_NODE_LABELT' => 100,
			'STRING_LITERAL1' => 11,
			'IT_XPATH' => 81,
			'INTEGER_POSITIVE' => 102,
			'VAR1T' => 57,
			'ANON' => 82,
			'GT_LBRACKET' => 105,
			'DECIMAL_POSITIVE' => 83,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 85,
			'IT_false' => 108,
			'IT_MEMBERS' => 87,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20
		},
		GOTOS => {
			'GraphNode' => 212,
			'BooleanLiteral' => 72,
			'NumericLiteralPositive' => 91,
			'String' => 73,
			'NumericLiteralNegative' => 94,
			'_QGraphNode_E_Plus' => 211,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericLiteral' => 78,
			'VAR2' => 55,
			'Var' => 79,
			'VarOrTerm' => 213,
			'TriplesNode' => 214,
			'GraphTerm' => 106,
			'BLANK_NODE_LABEL' => 103,
			'PrefixedName' => 58,
			'PNAME_LN' => 59,
			'BlankNode' => 107,
			'PNAME_NS' => 61,
			'IRIref' => 88,
			'BlankNodePropertyList' => 89,
			'Collection' => 90,
			'RDFLiteral' => 109
		}
	},
	{#State 146
		DEFAULT => -148
	},
	{#State 147
		ACTIONS => {
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 93,
			'STRING_LITERAL_LONG2' => 12,
			'IT_true' => 74,
			'PNAME_LNT' => 51,
			'VAR2T' => 50,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'NIL' => 96,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'DECIMAL_NEGATIVE' => 98,
			'INTEGER' => 80,
			'DOUBLE' => 101,
			'BLANK_NODE_LABELT' => 100,
			'STRING_LITERAL1' => 11,
			'IT_XPATH' => 81,
			'INTEGER_POSITIVE' => 102,
			'VAR1T' => 57,
			'ANON' => 82,
			'GT_LBRACKET' => 105,
			'DECIMAL_POSITIVE' => 83,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 85,
			'IT_false' => 108,
			'IT_MEMBERS' => 87,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20
		},
		DEFAULT => -143,
		GOTOS => {
			'BooleanLiteral' => 72,
			'NumericLiteralPositive' => 91,
			'String' => 73,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'TriplesSameSubject' => 97,
			'IRI_REF' => 53,
			'_QConstructTriples_E_Opt' => 215,
			'NumericLiteral' => 78,
			'VAR2' => 55,
			'Var' => 79,
			'VarOrTerm' => 99,
			'TriplesNode' => 104,
			'GraphTerm' => 106,
			'BLANK_NODE_LABEL' => 103,
			'PrefixedName' => 58,
			'PNAME_LN' => 59,
			'BlankNode' => 107,
			'PNAME_NS' => 61,
			'ConstructTriples' => 86,
			'IRIref' => 88,
			'BlankNodePropertyList' => 89,
			'Collection' => 90,
			'RDFLiteral' => 109
		}
	},
	{#State 148
		DEFAULT => -145
	},
	{#State 149
		DEFAULT => -149
	},
	{#State 150
		ACTIONS => {
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 93,
			'STRING_LITERAL_LONG2' => 12,
			'IT_true' => 74,
			'PNAME_LNT' => 51,
			'VAR2T' => 50,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'NIL' => 96,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'DECIMAL_NEGATIVE' => 98,
			'INTEGER' => 80,
			'DOUBLE' => 101,
			'BLANK_NODE_LABELT' => 100,
			'STRING_LITERAL1' => 11,
			'IT_XPATH' => 81,
			'INTEGER_POSITIVE' => 102,
			'VAR1T' => 57,
			'ANON' => 82,
			'GT_LBRACKET' => 105,
			'DECIMAL_POSITIVE' => 83,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 85,
			'IT_false' => 108,
			'IT_MEMBERS' => 87,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20
		},
		GOTOS => {
			'GraphNode' => 217,
			'BooleanLiteral' => 72,
			'NumericLiteralPositive' => 91,
			'String' => 73,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'Object' => 218,
			'NumericLiteral' => 78,
			'VAR2' => 55,
			'Var' => 79,
			'VarOrTerm' => 213,
			'ObjectList' => 216,
			'TriplesNode' => 214,
			'GraphTerm' => 106,
			'BLANK_NODE_LABEL' => 103,
			'PrefixedName' => 58,
			'PNAME_LN' => 59,
			'BlankNode' => 107,
			'PNAME_NS' => 61,
			'IRIref' => 88,
			'BlankNodePropertyList' => 89,
			'Collection' => 90,
			'RDFLiteral' => 109
		}
	},
	{#State 151
		DEFAULT => -166
	},
	{#State 152
		DEFAULT => -167
	},
	{#State 153
		DEFAULT => -160
	},
	{#State 154
		DEFAULT => -158
	},
	{#State 155
		DEFAULT => -150
	},
	{#State 156
		ACTIONS => {
			'GT_RBRACKET' => 219
		}
	},
	{#State 157
		ACTIONS => {
			'STRING_LITERAL_LONG2' => 12,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'IT_XPATH' => 81,
			'VAR1T' => 57,
			'ANON' => 82,
			'DECIMAL_POSITIVE' => 83,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 85,
			'IT_MEMBERS' => 87,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 93,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'NIL' => 96,
			'DECIMAL_NEGATIVE' => 98,
			'BLANK_NODE_LABELT' => 100,
			'DOUBLE' => 101,
			'INTEGER_POSITIVE' => 102,
			'GT_LBRACKET' => 105,
			'IT_false' => 108
		},
		DEFAULT => -107,
		GOTOS => {
			'BooleanLiteral' => 72,
			'NumericLiteralPositive' => 91,
			'String' => 73,
			'_QTriplesBlock_E_Opt' => 220,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'TriplesSameSubject' => 222,
			'IRI_REF' => 53,
			'TriplesBlock' => 221,
			'NumericLiteral' => 78,
			'VAR2' => 55,
			'Var' => 79,
			'VarOrTerm' => 99,
			'TriplesNode' => 104,
			'GraphTerm' => 106,
			'BLANK_NODE_LABEL' => 103,
			'PrefixedName' => 58,
			'PNAME_LN' => 59,
			'BlankNode' => 107,
			'PNAME_NS' => 61,
			'IRIref' => 88,
			'BlankNodePropertyList' => 89,
			'Collection' => 90,
			'RDFLiteral' => 109
		}
	},
	{#State 158
		ACTIONS => {
			'IT_NAMED' => 227,
			'PNAME_NST' => 64,
			'PNAME_LNT' => 51,
			'IRI_REFT' => 20
		},
		GOTOS => {
			'NamedGraphClause' => 228,
			'DefaultGraphClause' => 225,
			'SourceSelector' => 223,
			'_O_QDefaultGraphClause_E_Or_QNamedGraphClause_E_C' => 224,
			'PrefixedName' => 58,
			'PNAME_LN' => 59,
			'PNAME_NS' => 61,
			'IRI_REF' => 53,
			'IRIref' => 226
		}
	},
	{#State 159
		DEFAULT => -58
	},
	{#State 160
		DEFAULT => -71
	},
	{#State 161
		ACTIONS => {
			'GT_LPAREN' => 229
		}
	},
	{#State 162
		ACTIONS => {
			'GT_LPAREN' => 230
		}
	},
	{#State 163
		DEFAULT => -53
	},
	{#State 164
		DEFAULT => -56
	},
	{#State 165
		ACTIONS => {
			'GT_LPAREN' => 231
		}
	},
	{#State 166
		DEFAULT => -50
	},
	{#State 167
		ACTIONS => {
			'GT_LPAREN' => 232
		}
	},
	{#State 168
		DEFAULT => -51
	},
	{#State 169
		ACTIONS => {
			'GT_LPAREN' => 233
		}
	},
	{#State 170
		DEFAULT => -52
	},
	{#State 171
		DEFAULT => -57,
		GOTOS => {
			'_QDatasetClause_E_Star' => 234
		}
	},
	{#State 172
		ACTIONS => {
			'GT_LPAREN' => 235
		}
	},
	{#State 173
		DEFAULT => -248
	},
	{#State 174
		ACTIONS => {
			'GT_LPAREN' => 236
		}
	},
	{#State 175
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'GT_NOT' => 241,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'GT_PLUS' => 251,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'GT_MINUS' => 255,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'RelationalExpression' => 238,
			'String' => 73,
			'ValueLogical' => 239,
			'MultiplicativeExpression' => 240,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericLiteral' => 250,
			'NumericExpression' => 249,
			'IRIrefOrFunction' => 242,
			'ConditionalOrExpression' => 256,
			'VAR2' => 55,
			'Var' => 243,
			'Expression' => 257,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'ConditionalAndExpression' => 258,
			'PrimaryExpression' => 244,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'UnaryExpression' => 247,
			'PNAME_NS' => 61,
			'AdditiveExpression' => 259,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 176
		ACTIONS => {
			'GT_LPAREN' => 260
		}
	},
	{#State 177
		ACTIONS => {
			'GT_LPAREN' => 261
		}
	},
	{#State 178
		ACTIONS => {
			'GT_LPAREN' => 262
		}
	},
	{#State 179
		ACTIONS => {
			'GT_LPAREN' => 263
		}
	},
	{#State 180
		ACTIONS => {
			'IT_LANGMATCHES' => 174,
			'IT_LANG' => 161,
			'GT_LPAREN' => 175,
			'IT_DATATYPE' => 162,
			'VAR2T' => 50,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'IT_STR' => 178,
			'VAR1T' => 57,
			'IT_isBLANK' => 169,
			'IT_isIRI' => 179,
			'IT_BOUND' => 172
		},
		DEFAULT => -55,
		GOTOS => {
			'VAR1' => 52,
			'RegexExpression' => 173,
			'_O_QVar_E_Or_QBrackettedExpression_E_Or_QBuiltInCall_E_C' => 264,
			'BuiltInCall' => 170,
			'BrackettedExpression' => 168,
			'VAR2' => 55,
			'Var' => 166
		}
	},
	{#State 181
		DEFAULT => -22
	},
	{#State 182
		DEFAULT => -31,
		GOTOS => {
			'_QBinding_E_Star' => 265
		}
	},
	{#State 183
		DEFAULT => -30
	},
	{#State 184
		DEFAULT => -70
	},
	{#State 185
		ACTIONS => {
			'IT_BINDINGS' => 45
		},
		DEFAULT => -62,
		GOTOS => {
			'_QBindingClause_E_Opt' => 266,
			'BindingClause' => 267
		}
	},
	{#State 186
		DEFAULT => -57,
		GOTOS => {
			'_QDatasetClause_E_Star' => 268
		}
	},
	{#State 187
		DEFAULT => -44
	},
	{#State 188
		DEFAULT => -104
	},
	{#State 189
		DEFAULT => -92
	},
	{#State 190
		DEFAULT => -90
	},
	{#State 191
		DEFAULT => -91
	},
	{#State 192
		DEFAULT => -88
	},
	{#State 193
		DEFAULT => -103
	},
	{#State 194
		DEFAULT => -99
	},
	{#State 195
		DEFAULT => -98
	},
	{#State 196
		DEFAULT => -102
	},
	{#State 197
		ACTIONS => {
			'IT_LANG' => 161,
			'IT_DATATYPE' => 162,
			'IT_DESC' => 194,
			'IT_ASC' => 195,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'VAR1T' => 57,
			'IT_isBLANK' => 169,
			'PNAME_NST' => 64,
			'IT_BOUND' => 172,
			'IRI_REFT' => 20,
			'IT_LANGMATCHES' => 174,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'IT_STR' => 178,
			'IT_isIRI' => 179
		},
		DEFAULT => -93,
		GOTOS => {
			'RegexExpression' => 173,
			'_O_QIT_ASC_E_Or_QIT_DESC_E_C' => 203,
			'VAR1' => 52,
			'FunctionCall' => 204,
			'Constraint' => 205,
			'IRI_REF' => 53,
			'VAR2' => 55,
			'Var' => 196,
			'_O_QConstraint_E_Or_QVar_E_C' => 198,
			'BrackettedExpression' => 199,
			'PrefixedName' => 58,
			'BuiltInCall' => 200,
			'PNAME_LN' => 59,
			'PNAME_NS' => 61,
			'OrderCondition' => 269,
			'IRIref' => 201,
			'_O_QIT_ASC_E_Or_QIT_DESC_E_S_QBrackettedExpression_E_C' => 202
		}
	},
	{#State 198
		DEFAULT => -97
	},
	{#State 199
		DEFAULT => -132
	},
	{#State 200
		DEFAULT => -133
	},
	{#State 201
		ACTIONS => {
			'NIL' => 272,
			'GT_LPAREN' => 271
		},
		GOTOS => {
			'ArgList' => 273,
			'_O_QNIL_E_Or_QGT_LPAREN_E_S_QExpression_E_S_QGT_COMMA_E_S_QExpression_E_Star_S_QGT_RPAREN_E_C' => 270
		}
	},
	{#State 202
		DEFAULT => -96
	},
	{#State 203
		ACTIONS => {
			'GT_LPAREN' => 175
		},
		GOTOS => {
			'BrackettedExpression' => 274
		}
	},
	{#State 204
		DEFAULT => -134
	},
	{#State 205
		DEFAULT => -101
	},
	{#State 206
		DEFAULT => -94
	},
	{#State 207
		DEFAULT => -256
	},
	{#State 208
		ACTIONS => {
			'GT_RPAREN' => 275
		}
	},
	{#State 209
		ACTIONS => {
			'GT_RPAREN' => 276
		}
	},
	{#State 210
		ACTIONS => {
			'GT_RPAREN' => 277
		}
	},
	{#State 211
		ACTIONS => {
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 93,
			'STRING_LITERAL_LONG2' => 12,
			'IT_true' => 74,
			'PNAME_LNT' => 51,
			'INTEGER_NEGATIVE' => 75,
			'VAR2T' => 50,
			'STRING_LITERAL_LONG1' => 15,
			'NIL' => 96,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'DECIMAL_NEGATIVE' => 98,
			'INTEGER' => 80,
			'BLANK_NODE_LABELT' => 100,
			'STRING_LITERAL1' => 11,
			'DOUBLE' => 101,
			'IT_XPATH' => 81,
			'ANON' => 82,
			'VAR1T' => 57,
			'INTEGER_POSITIVE' => 102,
			'DECIMAL_POSITIVE' => 83,
			'GT_LBRACKET' => 105,
			'DOUBLE_NEGATIVE' => 84,
			'GT_RPAREN' => 278,
			'IT_LIST' => 85,
			'IT_false' => 108,
			'IT_MEMBERS' => 87,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20
		},
		GOTOS => {
			'GraphNode' => 279,
			'BooleanLiteral' => 72,
			'NumericLiteralPositive' => 91,
			'String' => 73,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericLiteral' => 78,
			'VAR2' => 55,
			'Var' => 79,
			'VarOrTerm' => 213,
			'GraphTerm' => 106,
			'BLANK_NODE_LABEL' => 103,
			'TriplesNode' => 214,
			'PrefixedName' => 58,
			'PNAME_LN' => 59,
			'PNAME_NS' => 61,
			'BlankNode' => 107,
			'BlankNodePropertyList' => 89,
			'Collection' => 90,
			'IRIref' => 88,
			'RDFLiteral' => 109
		}
	},
	{#State 212
		DEFAULT => -173
	},
	{#State 213
		DEFAULT => -175
	},
	{#State 214
		DEFAULT => -176
	},
	{#State 215
		DEFAULT => -146
	},
	{#State 216
		DEFAULT => -156,
		GOTOS => {
			'_Q_O_QGT_SEMI_E_S_QVerb_E_S_QObjectList_E_Opt_C_E_Star' => 280
		}
	},
	{#State 217
		DEFAULT => -165
	},
	{#State 218
		DEFAULT => -163,
		GOTOS => {
			'_Q_O_QGT_COMMA_E_S_QObject_E_C_E_Star' => 281
		}
	},
	{#State 219
		DEFAULT => -170
	},
	{#State 220
		DEFAULT => -114,
		GOTOS => {
			'_Q_O_QGraphPatternNotTriples_E_Or_QFilter_E_S_QGT_DOT_E_Opt_S_QTriplesBlock_E_Opt_C_E_Star' => 282
		}
	},
	{#State 221
		DEFAULT => -108
	},
	{#State 222
		ACTIONS => {
			'GT_DOT' => 284
		},
		DEFAULT => -118,
		GOTOS => {
			'_O_QGT_DOT_E_S_QTriplesBlock_E_Opt_C' => 283,
			'_Q_O_QGT_DOT_E_S_QTriplesBlock_E_Opt_C_E_Opt' => 285
		}
	},
	{#State 223
		DEFAULT => -75
	},
	{#State 224
		DEFAULT => -72
	},
	{#State 225
		DEFAULT => -73
	},
	{#State 226
		DEFAULT => -77
	},
	{#State 227
		ACTIONS => {
			'PNAME_NST' => 64,
			'PNAME_LNT' => 51,
			'IRI_REFT' => 20
		},
		GOTOS => {
			'PNAME_LN' => 59,
			'PNAME_NS' => 61,
			'IRI_REF' => 53,
			'IRIref' => 226,
			'SourceSelector' => 286,
			'PrefixedName' => 58
		}
	},
	{#State 228
		DEFAULT => -74
	},
	{#State 229
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'GT_NOT' => 241,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'GT_PLUS' => 251,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'GT_MINUS' => 255,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'RelationalExpression' => 238,
			'String' => 73,
			'ValueLogical' => 239,
			'MultiplicativeExpression' => 240,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericExpression' => 249,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'ConditionalOrExpression' => 256,
			'VAR2' => 55,
			'Var' => 243,
			'Expression' => 287,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'ConditionalAndExpression' => 258,
			'PrimaryExpression' => 244,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'UnaryExpression' => 247,
			'PNAME_NS' => 61,
			'AdditiveExpression' => 259,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 230
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'GT_NOT' => 241,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'GT_PLUS' => 251,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'GT_MINUS' => 255,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'RelationalExpression' => 238,
			'String' => 73,
			'ValueLogical' => 239,
			'MultiplicativeExpression' => 240,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericExpression' => 249,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'ConditionalOrExpression' => 256,
			'VAR2' => 55,
			'Var' => 243,
			'Expression' => 288,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'ConditionalAndExpression' => 258,
			'PrimaryExpression' => 244,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'UnaryExpression' => 247,
			'PNAME_NS' => 61,
			'AdditiveExpression' => 259,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 231
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'GT_NOT' => 241,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'GT_PLUS' => 251,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'GT_MINUS' => 255,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'RelationalExpression' => 238,
			'String' => 73,
			'ValueLogical' => 239,
			'MultiplicativeExpression' => 240,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericExpression' => 249,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'ConditionalOrExpression' => 256,
			'VAR2' => 55,
			'Var' => 243,
			'Expression' => 289,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'ConditionalAndExpression' => 258,
			'PrimaryExpression' => 244,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'UnaryExpression' => 247,
			'PNAME_NS' => 61,
			'AdditiveExpression' => 259,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 232
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'GT_NOT' => 241,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'GT_PLUS' => 251,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'GT_MINUS' => 255,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'RelationalExpression' => 238,
			'String' => 73,
			'ValueLogical' => 239,
			'MultiplicativeExpression' => 240,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericExpression' => 249,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'ConditionalOrExpression' => 256,
			'VAR2' => 55,
			'Var' => 243,
			'Expression' => 290,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'ConditionalAndExpression' => 258,
			'PrimaryExpression' => 244,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'UnaryExpression' => 247,
			'PNAME_NS' => 61,
			'AdditiveExpression' => 259,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 233
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'GT_NOT' => 241,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'GT_PLUS' => 251,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'GT_MINUS' => 255,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'RelationalExpression' => 238,
			'String' => 73,
			'ValueLogical' => 239,
			'MultiplicativeExpression' => 240,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericExpression' => 249,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'ConditionalOrExpression' => 256,
			'VAR2' => 55,
			'Var' => 243,
			'Expression' => 291,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'ConditionalAndExpression' => 258,
			'PrimaryExpression' => 244,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'UnaryExpression' => 247,
			'PNAME_NS' => 61,
			'AdditiveExpression' => 259,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 234
		ACTIONS => {
			'IT_WHERE' => 31,
			'IT_FROM' => 158
		},
		DEFAULT => -79,
		GOTOS => {
			'_QIT_WHERE_E_Opt' => 32,
			'DatasetClause' => 159,
			'WhereClause' => 292
		}
	},
	{#State 235
		ACTIONS => {
			'VAR1T' => 57,
			'VAR2T' => 50
		},
		GOTOS => {
			'VAR1' => 52,
			'VAR2' => 55,
			'Var' => 293
		}
	},
	{#State 236
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'GT_NOT' => 241,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'GT_PLUS' => 251,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'GT_MINUS' => 255,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'RelationalExpression' => 238,
			'String' => 73,
			'ValueLogical' => 239,
			'MultiplicativeExpression' => 240,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericExpression' => 249,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'ConditionalOrExpression' => 256,
			'VAR2' => 55,
			'Var' => 243,
			'Expression' => 294,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'ConditionalAndExpression' => 258,
			'PrimaryExpression' => 244,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'UnaryExpression' => 247,
			'PNAME_NS' => 61,
			'AdditiveExpression' => 259,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 237
		DEFAULT => -233
	},
	{#State 238
		DEFAULT => -201
	},
	{#State 239
		DEFAULT => -199,
		GOTOS => {
			'_Q_O_QGT_AND_E_S_QValueLogical_E_C_E_Star' => 295
		}
	},
	{#State 240
		DEFAULT => -217,
		GOTOS => {
			'_Q_O_QGT_PLUS_E_S_QMultiplicativeExpression_E_Or_QGT_MINUS_E_S_QMultiplicativeExpression_E_Or_QNumericLiteralPositive_E_Or_QNumericLiteralNegative_E_C_E_Star' => 296
		}
	},
	{#State 241
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'String' => 73,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'VAR2' => 55,
			'Var' => 243,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'PrimaryExpression' => 297,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'PNAME_NS' => 61,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 242
		DEFAULT => -230
	},
	{#State 243
		DEFAULT => -236
	},
	{#State 244
		DEFAULT => -227
	},
	{#State 245
		DEFAULT => -229
	},
	{#State 246
		ACTIONS => {
			'GT_LPAREN' => 298
		}
	},
	{#State 247
		DEFAULT => -222,
		GOTOS => {
			'_Q_O_QGT_TIMES_E_S_QUnaryExpression_E_Or_QGT_DIVIDE_E_S_QUnaryExpression_E_C_E_Star' => 299
		}
	},
	{#State 248
		DEFAULT => -231
	},
	{#State 249
		ACTIONS => {
			'GT_EQUAL' => 303,
			'GT_LT' => 305,
			'GT_LE' => 306,
			'GT_GT' => 300,
			'GT_GE' => 304,
			'GT_NEQUAL' => 302
		},
		DEFAULT => -209,
		GOTOS => {
			'_Q_O_QGT_EQUAL_E_S_QNumericExpression_E_Or_QGT_NEQUAL_E_S_QNumericExpression_E_Or_QGT_LT_E_S_QNumericExpression_E_Or_QGT_GT_E_S_QNumericExpression_E_Or_QGT_LE_E_S_QNumericExpression_E_Or_QGT_GE_E_S_QNumericExpression_E_C_E_Opt' => 301,
			'_O_QGT_EQUAL_E_S_QNumericExpression_E_Or_QGT_NEQUAL_E_S_QNumericExpression_E_Or_QGT_LT_E_S_QNumericExpression_E_Or_QGT_GT_E_S_QNumericExpression_E_Or_QGT_LE_E_S_QNumericExpression_E_Or_QGT_GE_E_S_QNumericExpression_E_C' => 307
		}
	},
	{#State 250
		DEFAULT => -232
	},
	{#State 251
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'String' => 73,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'VAR2' => 55,
			'Var' => 243,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'PrimaryExpression' => 308,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'PNAME_NS' => 61,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 252
		DEFAULT => -228
	},
	{#State 253
		ACTIONS => {
			'GT_LPAREN' => 309
		}
	},
	{#State 254
		ACTIONS => {
			'GT_LPAREN' => 271,
			'NIL' => 272
		},
		DEFAULT => -253,
		GOTOS => {
			'ArgList' => 311,
			'_O_QNIL_E_Or_QGT_LPAREN_E_S_QExpression_E_S_QGT_COMMA_E_S_QExpression_E_Star_S_QGT_RPAREN_E_C' => 270,
			'_QArgList_E_Opt' => 310
		}
	},
	{#State 255
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'String' => 73,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'VAR2' => 55,
			'Var' => 243,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'PrimaryExpression' => 312,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'PNAME_NS' => 61,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 256
		DEFAULT => -192
	},
	{#State 257
		ACTIONS => {
			'GT_RPAREN' => 313
		}
	},
	{#State 258
		DEFAULT => -195,
		GOTOS => {
			'_Q_O_QGT_OR_E_S_QConditionalAndExpression_E_C_E_Star' => 314
		}
	},
	{#State 259
		DEFAULT => -211
	},
	{#State 260
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'GT_NOT' => 241,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'GT_PLUS' => 251,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'GT_MINUS' => 255,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'RelationalExpression' => 238,
			'String' => 73,
			'ValueLogical' => 239,
			'MultiplicativeExpression' => 240,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericExpression' => 249,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'ConditionalOrExpression' => 256,
			'VAR2' => 55,
			'Var' => 243,
			'Expression' => 315,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'ConditionalAndExpression' => 258,
			'PrimaryExpression' => 244,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'UnaryExpression' => 247,
			'PNAME_NS' => 61,
			'AdditiveExpression' => 259,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 261
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'GT_NOT' => 241,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'GT_PLUS' => 251,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'GT_MINUS' => 255,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'RelationalExpression' => 238,
			'String' => 73,
			'ValueLogical' => 239,
			'MultiplicativeExpression' => 240,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericExpression' => 249,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'ConditionalOrExpression' => 256,
			'VAR2' => 55,
			'Var' => 243,
			'Expression' => 316,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'ConditionalAndExpression' => 258,
			'PrimaryExpression' => 244,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'UnaryExpression' => 247,
			'PNAME_NS' => 61,
			'AdditiveExpression' => 259,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 262
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'GT_NOT' => 241,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'GT_PLUS' => 251,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'GT_MINUS' => 255,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'RelationalExpression' => 238,
			'String' => 73,
			'ValueLogical' => 239,
			'MultiplicativeExpression' => 240,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericExpression' => 249,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'ConditionalOrExpression' => 256,
			'VAR2' => 55,
			'Var' => 243,
			'Expression' => 317,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'ConditionalAndExpression' => 258,
			'PrimaryExpression' => 244,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'UnaryExpression' => 247,
			'PNAME_NS' => 61,
			'AdditiveExpression' => 259,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 263
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'GT_NOT' => 241,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'GT_PLUS' => 251,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'GT_MINUS' => 255,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'RelationalExpression' => 238,
			'String' => 73,
			'ValueLogical' => 239,
			'MultiplicativeExpression' => 240,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericExpression' => 249,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'ConditionalOrExpression' => 256,
			'VAR2' => 55,
			'Var' => 243,
			'Expression' => 318,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'ConditionalAndExpression' => 258,
			'PrimaryExpression' => 244,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'UnaryExpression' => 247,
			'PNAME_NS' => 61,
			'AdditiveExpression' => 259,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 264
		DEFAULT => -54
	},
	{#State 265
		ACTIONS => {
			'GT_RCURLEY' => 321,
			'GT_LPAREN' => 320
		},
		GOTOS => {
			'Binding' => 319
		}
	},
	{#State 266
		ACTIONS => {
			'IT_ORDER' => 70
		},
		DEFAULT => -82,
		GOTOS => {
			'SolutionModifier' => 322,
			'_QOrderClause_E_Opt' => 68,
			'OrderClause' => 71
		}
	},
	{#State 267
		DEFAULT => -63
	},
	{#State 268
		ACTIONS => {
			'IT_WHERE' => 31,
			'IT_FROM' => 158
		},
		DEFAULT => -79,
		GOTOS => {
			'_QIT_WHERE_E_Opt' => 32,
			'DatasetClause' => 159,
			'WhereClause' => 323
		}
	},
	{#State 269
		DEFAULT => -95
	},
	{#State 270
		DEFAULT => -136
	},
	{#State 271
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'GT_NOT' => 241,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'GT_PLUS' => 251,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'GT_MINUS' => 255,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'RelationalExpression' => 238,
			'String' => 73,
			'ValueLogical' => 239,
			'MultiplicativeExpression' => 240,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericExpression' => 249,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'ConditionalOrExpression' => 256,
			'VAR2' => 55,
			'Var' => 243,
			'Expression' => 324,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'ConditionalAndExpression' => 258,
			'PrimaryExpression' => 244,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'UnaryExpression' => 247,
			'PNAME_NS' => 61,
			'AdditiveExpression' => 259,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 272
		DEFAULT => -140
	},
	{#State 273
		DEFAULT => -135
	},
	{#State 274
		DEFAULT => -100
	},
	{#State 275
		DEFAULT => -190
	},
	{#State 276
		DEFAULT => -188
	},
	{#State 277
		DEFAULT => -189
	},
	{#State 278
		DEFAULT => -172
	},
	{#State 279
		DEFAULT => -174
	},
	{#State 280
		ACTIONS => {
			'GT_SEMI' => 325
		},
		DEFAULT => -151,
		GOTOS => {
			'_O_QGT_SEMI_E_S_QVerb_E_S_QObjectList_E_Opt_C' => 326
		}
	},
	{#State 281
		ACTIONS => {
			'GT_COMMA' => 327
		},
		DEFAULT => -161,
		GOTOS => {
			'_O_QGT_COMMA_E_S_QObject_E_C' => 328
		}
	},
	{#State 282
		ACTIONS => {
			'GT_RCURLEY' => 339,
			'IT_FILTER' => 330,
			'GT_LCURLEY' => 110,
			'IT_OPTIONAL' => 336,
			'IT_GRAPH' => 331
		},
		GOTOS => {
			'_O_QGraphPatternNotTriples_E_Or_QFilter_E_C' => 338,
			'GroupGraphPattern' => 337,
			'Filter' => 333,
			'OptionalGraphPattern' => 329,
			'GroupOrUnionGraphPattern' => 340,
			'GraphPatternNotTriples' => 335,
			'_O_QGraphPatternNotTriples_E_Or_QFilter_E_S_QGT_DOT_E_Opt_S_QTriplesBlock_E_Opt_C' => 334,
			'GraphGraphPattern' => 332
		}
	},
	{#State 283
		DEFAULT => -119
	},
	{#State 284
		ACTIONS => {
			'STRING_LITERAL_LONG2' => 12,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'IT_XPATH' => 81,
			'ANON' => 82,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 85,
			'IT_MEMBERS' => 87,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 93,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'NIL' => 96,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'BLANK_NODE_LABELT' => 100,
			'INTEGER_POSITIVE' => 102,
			'GT_LBRACKET' => 105,
			'IT_false' => 108
		},
		DEFAULT => -107,
		GOTOS => {
			'BooleanLiteral' => 72,
			'NumericLiteralPositive' => 91,
			'String' => 73,
			'_QTriplesBlock_E_Opt' => 341,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'TriplesSameSubject' => 222,
			'IRI_REF' => 53,
			'TriplesBlock' => 221,
			'NumericLiteral' => 78,
			'VAR2' => 55,
			'Var' => 79,
			'VarOrTerm' => 99,
			'GraphTerm' => 106,
			'PrefixedName' => 58,
			'BLANK_NODE_LABEL' => 103,
			'TriplesNode' => 104,
			'PNAME_LN' => 59,
			'PNAME_NS' => 61,
			'BlankNode' => 107,
			'BlankNodePropertyList' => 89,
			'IRIref' => 88,
			'Collection' => 90,
			'RDFLiteral' => 109
		}
	},
	{#State 285
		DEFAULT => -116
	},
	{#State 286
		DEFAULT => -76
	},
	{#State 287
		ACTIONS => {
			'GT_RPAREN' => 342
		}
	},
	{#State 288
		ACTIONS => {
			'GT_RPAREN' => 343
		}
	},
	{#State 289
		ACTIONS => {
			'GT_RPAREN' => 344
		}
	},
	{#State 290
		ACTIONS => {
			'GT_COMMA' => 345
		}
	},
	{#State 291
		ACTIONS => {
			'GT_RPAREN' => 346
		}
	},
	{#State 292
		ACTIONS => {
			'IT_ORDER' => 70
		},
		DEFAULT => -82,
		GOTOS => {
			'SolutionModifier' => 347,
			'_QOrderClause_E_Opt' => 68,
			'OrderClause' => 71
		}
	},
	{#State 293
		ACTIONS => {
			'GT_RPAREN' => 348
		}
	},
	{#State 294
		ACTIONS => {
			'GT_COMMA' => 349
		}
	},
	{#State 295
		ACTIONS => {
			'GT_AND' => 351
		},
		DEFAULT => -197,
		GOTOS => {
			'_O_QGT_AND_E_S_QValueLogical_E_C' => 350
		}
	},
	{#State 296
		ACTIONS => {
			'DOUBLE_POSITIVE' => 92,
			'INTEGER_NEGATIVE' => 75,
			'GT_MINUS' => 356,
			'DECIMAL_NEGATIVE' => 98,
			'GT_PLUS' => 354,
			'INTEGER_POSITIVE' => 102,
			'DECIMAL_POSITIVE' => 83,
			'DOUBLE_NEGATIVE' => 84
		},
		DEFAULT => -212,
		GOTOS => {
			'NumericLiteralPositive' => 355,
			'_O_QGT_PLUS_E_S_QMultiplicativeExpression_E_Or_QGT_MINUS_E_S_QMultiplicativeExpression_E_Or_QNumericLiteralPositive_E_Or_QNumericLiteralNegative_E_C' => 353,
			'NumericLiteralNegative' => 352
		}
	},
	{#State 297
		DEFAULT => -224
	},
	{#State 298
		ACTIONS => {
			'VAR1T' => 57,
			'VAR2T' => 50
		},
		GOTOS => {
			'VAR1' => 52,
			'VAR2' => 55,
			'Var' => 357
		}
	},
	{#State 299
		ACTIONS => {
			'GT_TIMES' => 358,
			'GT_DIVIDE' => 359
		},
		DEFAULT => -219,
		GOTOS => {
			'_O_QGT_TIMES_E_S_QUnaryExpression_E_Or_QGT_DIVIDE_E_S_QUnaryExpression_E_C' => 360
		}
	},
	{#State 300
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'GT_NOT' => 241,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'GT_PLUS' => 251,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'GT_MINUS' => 255,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'String' => 73,
			'MultiplicativeExpression' => 240,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericExpression' => 361,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'VAR2' => 55,
			'Var' => 243,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'PrimaryExpression' => 244,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'UnaryExpression' => 247,
			'PNAME_NS' => 61,
			'AdditiveExpression' => 259,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 301
		DEFAULT => -202
	},
	{#State 302
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'GT_NOT' => 241,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'GT_PLUS' => 251,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'GT_MINUS' => 255,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'String' => 73,
			'MultiplicativeExpression' => 240,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericExpression' => 362,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'VAR2' => 55,
			'Var' => 243,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'PrimaryExpression' => 244,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'UnaryExpression' => 247,
			'PNAME_NS' => 61,
			'AdditiveExpression' => 259,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 303
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'GT_NOT' => 241,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'GT_PLUS' => 251,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'GT_MINUS' => 255,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'String' => 73,
			'MultiplicativeExpression' => 240,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericExpression' => 363,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'VAR2' => 55,
			'Var' => 243,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'PrimaryExpression' => 244,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'UnaryExpression' => 247,
			'PNAME_NS' => 61,
			'AdditiveExpression' => 259,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 304
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'GT_NOT' => 241,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'GT_PLUS' => 251,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'GT_MINUS' => 255,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'String' => 73,
			'MultiplicativeExpression' => 240,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericExpression' => 364,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'VAR2' => 55,
			'Var' => 243,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'PrimaryExpression' => 244,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'UnaryExpression' => 247,
			'PNAME_NS' => 61,
			'AdditiveExpression' => 259,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 305
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'GT_NOT' => 241,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'GT_PLUS' => 251,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'GT_MINUS' => 255,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'String' => 73,
			'MultiplicativeExpression' => 240,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericExpression' => 365,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'VAR2' => 55,
			'Var' => 243,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'PrimaryExpression' => 244,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'UnaryExpression' => 247,
			'PNAME_NS' => 61,
			'AdditiveExpression' => 259,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 306
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'GT_NOT' => 241,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'GT_PLUS' => 251,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'GT_MINUS' => 255,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'String' => 73,
			'MultiplicativeExpression' => 240,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericExpression' => 366,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'VAR2' => 55,
			'Var' => 243,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'PrimaryExpression' => 244,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'UnaryExpression' => 247,
			'PNAME_NS' => 61,
			'AdditiveExpression' => 259,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 307
		DEFAULT => -210
	},
	{#State 308
		DEFAULT => -225
	},
	{#State 309
		ACTIONS => {
			'VAR1T' => 57,
			'VAR2T' => 50
		},
		GOTOS => {
			'VAR1' => 52,
			'VAR2' => 55,
			'Var' => 367
		}
	},
	{#State 310
		DEFAULT => -252
	},
	{#State 311
		DEFAULT => -254
	},
	{#State 312
		DEFAULT => -226
	},
	{#State 313
		DEFAULT => -237
	},
	{#State 314
		ACTIONS => {
			'GT_OR' => 369
		},
		DEFAULT => -193,
		GOTOS => {
			'_O_QGT_OR_E_S_QConditionalAndExpression_E_C' => 368
		}
	},
	{#State 315
		ACTIONS => {
			'GT_COMMA' => 370
		}
	},
	{#State 316
		ACTIONS => {
			'GT_RPAREN' => 371
		}
	},
	{#State 317
		ACTIONS => {
			'GT_RPAREN' => 372
		}
	},
	{#State 318
		ACTIONS => {
			'GT_RPAREN' => 373
		}
	},
	{#State 319
		DEFAULT => -32
	},
	{#State 320
		ACTIONS => {
			'DOUBLE_POSITIVE' => 92,
			'STRING_LITERAL_LONG2' => 12,
			'IT_true' => 74,
			'PNAME_LNT' => 51,
			'INTEGER_NEGATIVE' => 75,
			'VAR2T' => 50,
			'STRING_LITERAL_LONG1' => 15,
			'NIL' => 96,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_NULL' => 375,
			'DECIMAL_NEGATIVE' => 98,
			'INTEGER' => 80,
			'BLANK_NODE_LABELT' => 100,
			'STRING_LITERAL1' => 11,
			'DOUBLE' => 101,
			'IT_XPATH' => 81,
			'ANON' => 82,
			'VAR1T' => 57,
			'INTEGER_POSITIVE' => 102,
			'DECIMAL_POSITIVE' => 83,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 85,
			'IT_false' => 108,
			'IT_MEMBERS' => 87,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20
		},
		GOTOS => {
			'BooleanLiteral' => 72,
			'NumericLiteralPositive' => 91,
			'_Q_O_QVarOrTerm_E_Or_QIT_NULL_E_C_E_Plus' => 374,
			'String' => 73,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericLiteral' => 78,
			'VAR2' => 55,
			'Var' => 79,
			'VarOrTerm' => 377,
			'GraphTerm' => 106,
			'BLANK_NODE_LABEL' => 103,
			'PrefixedName' => 58,
			'_O_QVarOrTerm_E_Or_QIT_NULL_E_C' => 376,
			'PNAME_LN' => 59,
			'BlankNode' => 107,
			'PNAME_NS' => 61,
			'IRIref' => 88,
			'RDFLiteral' => 109
		}
	},
	{#State 321
		DEFAULT => -28
	},
	{#State 322
		DEFAULT => -64
	},
	{#State 323
		ACTIONS => {
			'IT_BINDINGS' => 45
		},
		DEFAULT => -62,
		GOTOS => {
			'_QBindingClause_E_Opt' => 378,
			'BindingClause' => 267
		}
	},
	{#State 324
		DEFAULT => -138,
		GOTOS => {
			'_Q_O_QGT_COMMA_E_S_QExpression_E_C_E_Star' => 379
		}
	},
	{#State 325
		ACTIONS => {
			'IT_a' => 152,
			'VAR1T' => 57,
			'PNAME_LNT' => 51,
			'VAR2T' => 50,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20
		},
		DEFAULT => -153,
		GOTOS => {
			'Verb' => 382,
			'PrefixedName' => 58,
			'_Q_O_QVerb_E_S_QObjectList_E_C_E_Opt' => 380,
			'VAR1' => 52,
			'PNAME_LN' => 59,
			'IRI_REF' => 53,
			'PNAME_NS' => 61,
			'IRIref' => 62,
			'VarOrIRIref' => 151,
			'_O_QVerb_E_S_QObjectList_E_C' => 381,
			'Var' => 56,
			'VAR2' => 55
		}
	},
	{#State 326
		DEFAULT => -157
	},
	{#State 327
		ACTIONS => {
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 93,
			'STRING_LITERAL_LONG2' => 12,
			'IT_true' => 74,
			'PNAME_LNT' => 51,
			'INTEGER_NEGATIVE' => 75,
			'VAR2T' => 50,
			'STRING_LITERAL_LONG1' => 15,
			'NIL' => 96,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'DECIMAL_NEGATIVE' => 98,
			'INTEGER' => 80,
			'BLANK_NODE_LABELT' => 100,
			'STRING_LITERAL1' => 11,
			'DOUBLE' => 101,
			'IT_XPATH' => 81,
			'ANON' => 82,
			'VAR1T' => 57,
			'INTEGER_POSITIVE' => 102,
			'DECIMAL_POSITIVE' => 83,
			'GT_LBRACKET' => 105,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 85,
			'IT_false' => 108,
			'IT_MEMBERS' => 87,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20
		},
		GOTOS => {
			'GraphNode' => 217,
			'BooleanLiteral' => 72,
			'NumericLiteralPositive' => 91,
			'String' => 73,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'Object' => 383,
			'NumericLiteral' => 78,
			'VAR2' => 55,
			'Var' => 79,
			'VarOrTerm' => 213,
			'GraphTerm' => 106,
			'BLANK_NODE_LABEL' => 103,
			'TriplesNode' => 214,
			'PrefixedName' => 58,
			'PNAME_LN' => 59,
			'PNAME_NS' => 61,
			'BlankNode' => 107,
			'BlankNodePropertyList' => 89,
			'Collection' => 90,
			'IRIref' => 88,
			'RDFLiteral' => 109
		}
	},
	{#State 328
		DEFAULT => -164
	},
	{#State 329
		DEFAULT => -120
	},
	{#State 330
		DEFAULT => -130,
		GOTOS => {
			'@7-1' => 384
		}
	},
	{#State 331
		ACTIONS => {
			'PNAME_NST' => 64,
			'VAR1T' => 57,
			'PNAME_LNT' => 51,
			'IRI_REFT' => 20,
			'VAR2T' => 50
		},
		GOTOS => {
			'PrefixedName' => 58,
			'VAR1' => 52,
			'PNAME_LN' => 59,
			'IRI_REF' => 53,
			'PNAME_NS' => 61,
			'VarOrIRIref' => 385,
			'IRIref' => 62,
			'Var' => 56,
			'VAR2' => 55
		}
	},
	{#State 332
		DEFAULT => -122
	},
	{#State 333
		DEFAULT => -110
	},
	{#State 334
		DEFAULT => -115
	},
	{#State 335
		DEFAULT => -109
	},
	{#State 336
		ACTIONS => {
			'GT_LCURLEY' => 110
		},
		GOTOS => {
			'GroupGraphPattern' => 386
		}
	},
	{#State 337
		DEFAULT => -128,
		GOTOS => {
			'_Q_O_QIT_UNION_E_S_QGroupGraphPattern_E_C_E_Star' => 387
		}
	},
	{#State 338
		ACTIONS => {
			'GT_DOT' => 388
		},
		DEFAULT => -111,
		GOTOS => {
			'_QGT_DOT_E_Opt' => 389
		}
	},
	{#State 339
		DEFAULT => -106
	},
	{#State 340
		DEFAULT => -121
	},
	{#State 341
		DEFAULT => -117
	},
	{#State 342
		DEFAULT => -239
	},
	{#State 343
		DEFAULT => -241
	},
	{#State 344
		DEFAULT => -247
	},
	{#State 345
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'GT_NOT' => 241,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'GT_PLUS' => 251,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'GT_MINUS' => 255,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'RelationalExpression' => 238,
			'String' => 73,
			'ValueLogical' => 239,
			'MultiplicativeExpression' => 240,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericExpression' => 249,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'ConditionalOrExpression' => 256,
			'VAR2' => 55,
			'Var' => 243,
			'Expression' => 390,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'ConditionalAndExpression' => 258,
			'PrimaryExpression' => 244,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'UnaryExpression' => 247,
			'PNAME_NS' => 61,
			'AdditiveExpression' => 259,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 346
		DEFAULT => -246
	},
	{#State 347
		DEFAULT => -45
	},
	{#State 348
		DEFAULT => -242
	},
	{#State 349
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'GT_NOT' => 241,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'GT_PLUS' => 251,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'GT_MINUS' => 255,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'RelationalExpression' => 238,
			'String' => 73,
			'ValueLogical' => 239,
			'MultiplicativeExpression' => 240,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericExpression' => 249,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'ConditionalOrExpression' => 256,
			'VAR2' => 55,
			'Var' => 243,
			'Expression' => 391,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'ConditionalAndExpression' => 258,
			'PrimaryExpression' => 244,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'UnaryExpression' => 247,
			'PNAME_NS' => 61,
			'AdditiveExpression' => 259,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 350
		DEFAULT => -200
	},
	{#State 351
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'GT_NOT' => 241,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'GT_PLUS' => 251,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'GT_MINUS' => 255,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'RelationalExpression' => 238,
			'String' => 73,
			'ValueLogical' => 392,
			'MultiplicativeExpression' => 240,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericExpression' => 249,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'VAR2' => 55,
			'Var' => 243,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'PrimaryExpression' => 244,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'UnaryExpression' => 247,
			'PNAME_NS' => 61,
			'AdditiveExpression' => 259,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 352
		DEFAULT => -216
	},
	{#State 353
		DEFAULT => -218
	},
	{#State 354
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'GT_NOT' => 241,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'GT_PLUS' => 251,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'GT_MINUS' => 255,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'String' => 73,
			'MultiplicativeExpression' => 393,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'VAR2' => 55,
			'Var' => 243,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'PrimaryExpression' => 244,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'UnaryExpression' => 247,
			'PNAME_NS' => 61,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 355
		DEFAULT => -215
	},
	{#State 356
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'GT_NOT' => 241,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'GT_PLUS' => 251,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'GT_MINUS' => 255,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'String' => 73,
			'MultiplicativeExpression' => 394,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'VAR2' => 55,
			'Var' => 243,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'PrimaryExpression' => 244,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'UnaryExpression' => 247,
			'PNAME_NS' => 61,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 357
		ACTIONS => {
			'GT_RPAREN' => 395
		}
	},
	{#State 358
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'GT_NOT' => 241,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'GT_PLUS' => 251,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'GT_MINUS' => 255,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'String' => 73,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'VAR2' => 55,
			'Var' => 243,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'PrimaryExpression' => 244,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'UnaryExpression' => 396,
			'PNAME_NS' => 61,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 359
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'GT_NOT' => 241,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'GT_PLUS' => 251,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'GT_MINUS' => 255,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'String' => 73,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'VAR2' => 55,
			'Var' => 243,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'PrimaryExpression' => 244,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'UnaryExpression' => 397,
			'PNAME_NS' => 61,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 360
		DEFAULT => -223
	},
	{#State 361
		DEFAULT => -206
	},
	{#State 362
		DEFAULT => -204
	},
	{#State 363
		DEFAULT => -203
	},
	{#State 364
		DEFAULT => -208
	},
	{#State 365
		DEFAULT => -205
	},
	{#State 366
		DEFAULT => -207
	},
	{#State 367
		ACTIONS => {
			'GT_RPAREN' => 398
		}
	},
	{#State 368
		DEFAULT => -196
	},
	{#State 369
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'GT_NOT' => 241,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'GT_PLUS' => 251,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'GT_MINUS' => 255,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'RelationalExpression' => 238,
			'String' => 73,
			'ValueLogical' => 239,
			'MultiplicativeExpression' => 240,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericExpression' => 249,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'VAR2' => 55,
			'Var' => 243,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'ConditionalAndExpression' => 399,
			'PrimaryExpression' => 244,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'UnaryExpression' => 247,
			'PNAME_NS' => 61,
			'AdditiveExpression' => 259,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 370
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'GT_NOT' => 241,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'GT_PLUS' => 251,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'GT_MINUS' => 255,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'RelationalExpression' => 238,
			'String' => 73,
			'ValueLogical' => 239,
			'MultiplicativeExpression' => 240,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericExpression' => 249,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'ConditionalOrExpression' => 256,
			'VAR2' => 55,
			'Var' => 243,
			'Expression' => 400,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'ConditionalAndExpression' => 258,
			'PrimaryExpression' => 244,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'UnaryExpression' => 247,
			'PNAME_NS' => 61,
			'AdditiveExpression' => 259,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 371
		DEFAULT => -245
	},
	{#State 372
		DEFAULT => -238
	},
	{#State 373
		DEFAULT => -244
	},
	{#State 374
		ACTIONS => {
			'DOUBLE_POSITIVE' => 92,
			'STRING_LITERAL_LONG2' => 12,
			'IT_true' => 74,
			'PNAME_LNT' => 51,
			'INTEGER_NEGATIVE' => 75,
			'VAR2T' => 50,
			'STRING_LITERAL_LONG1' => 15,
			'NIL' => 96,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_NULL' => 375,
			'DECIMAL_NEGATIVE' => 98,
			'INTEGER' => 80,
			'BLANK_NODE_LABELT' => 100,
			'STRING_LITERAL1' => 11,
			'DOUBLE' => 101,
			'IT_XPATH' => 81,
			'ANON' => 82,
			'VAR1T' => 57,
			'INTEGER_POSITIVE' => 102,
			'DECIMAL_POSITIVE' => 83,
			'DOUBLE_NEGATIVE' => 84,
			'GT_RPAREN' => 401,
			'IT_LIST' => 85,
			'IT_false' => 108,
			'IT_MEMBERS' => 87,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20
		},
		GOTOS => {
			'BooleanLiteral' => 72,
			'NumericLiteralPositive' => 91,
			'String' => 73,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericLiteral' => 78,
			'VAR2' => 55,
			'Var' => 79,
			'VarOrTerm' => 377,
			'GraphTerm' => 106,
			'BLANK_NODE_LABEL' => 103,
			'PrefixedName' => 58,
			'_O_QVarOrTerm_E_Or_QIT_NULL_E_C' => 402,
			'PNAME_LN' => 59,
			'BlankNode' => 107,
			'PNAME_NS' => 61,
			'IRIref' => 88,
			'RDFLiteral' => 109
		}
	},
	{#State 375
		DEFAULT => -35
	},
	{#State 376
		DEFAULT => -36
	},
	{#State 377
		DEFAULT => -34
	},
	{#State 378
		ACTIONS => {
			'IT_ORDER' => 70
		},
		DEFAULT => -82,
		GOTOS => {
			'SolutionModifier' => 403,
			'_QOrderClause_E_Opt' => 68,
			'OrderClause' => 71
		}
	},
	{#State 379
		ACTIONS => {
			'GT_RPAREN' => 404,
			'GT_COMMA' => 405
		},
		GOTOS => {
			'_O_QGT_COMMA_E_S_QExpression_E_C' => 406
		}
	},
	{#State 380
		DEFAULT => -155
	},
	{#State 381
		DEFAULT => -154
	},
	{#State 382
		ACTIONS => {
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 93,
			'STRING_LITERAL_LONG2' => 12,
			'IT_true' => 74,
			'PNAME_LNT' => 51,
			'INTEGER_NEGATIVE' => 75,
			'VAR2T' => 50,
			'STRING_LITERAL_LONG1' => 15,
			'NIL' => 96,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'DECIMAL_NEGATIVE' => 98,
			'INTEGER' => 80,
			'BLANK_NODE_LABELT' => 100,
			'STRING_LITERAL1' => 11,
			'DOUBLE' => 101,
			'IT_XPATH' => 81,
			'ANON' => 82,
			'VAR1T' => 57,
			'INTEGER_POSITIVE' => 102,
			'DECIMAL_POSITIVE' => 83,
			'GT_LBRACKET' => 105,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 85,
			'IT_false' => 108,
			'IT_MEMBERS' => 87,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20
		},
		GOTOS => {
			'GraphNode' => 217,
			'BooleanLiteral' => 72,
			'NumericLiteralPositive' => 91,
			'String' => 73,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'Object' => 218,
			'NumericLiteral' => 78,
			'VAR2' => 55,
			'Var' => 79,
			'VarOrTerm' => 213,
			'ObjectList' => 407,
			'GraphTerm' => 106,
			'BLANK_NODE_LABEL' => 103,
			'TriplesNode' => 214,
			'PrefixedName' => 58,
			'PNAME_LN' => 59,
			'PNAME_NS' => 61,
			'BlankNode' => 107,
			'BlankNodePropertyList' => 89,
			'IRIref' => 88,
			'Collection' => 90,
			'RDFLiteral' => 109
		}
	},
	{#State 383
		DEFAULT => -162
	},
	{#State 384
		ACTIONS => {
			'IT_REGEX' => 167,
			'IT_LANGMATCHES' => 174,
			'IT_LANG' => 161,
			'GT_LPAREN' => 175,
			'IT_DATATYPE' => 162,
			'IT_STR' => 178,
			'PNAME_LNT' => 51,
			'IT_isBLANK' => 169,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'PNAME_NST' => 64,
			'IT_isIRI' => 179,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_isLITERAL' => 165
		},
		GOTOS => {
			'RegexExpression' => 173,
			'BrackettedExpression' => 199,
			'PrefixedName' => 58,
			'BuiltInCall' => 200,
			'FunctionCall' => 204,
			'Constraint' => 408,
			'PNAME_LN' => 59,
			'IRI_REF' => 53,
			'PNAME_NS' => 61,
			'IRIref' => 201
		}
	},
	{#State 385
		DEFAULT => -124,
		GOTOS => {
			'@6-2' => 409
		}
	},
	{#State 386
		DEFAULT => -123
	},
	{#State 387
		ACTIONS => {
			'IT_UNION' => 410
		},
		DEFAULT => -126,
		GOTOS => {
			'_O_QIT_UNION_E_S_QGroupGraphPattern_E_C' => 411
		}
	},
	{#State 388
		DEFAULT => -112
	},
	{#State 389
		ACTIONS => {
			'STRING_LITERAL_LONG2' => 12,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'IT_XPATH' => 81,
			'ANON' => 82,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 85,
			'IT_MEMBERS' => 87,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 93,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'NIL' => 96,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'BLANK_NODE_LABELT' => 100,
			'INTEGER_POSITIVE' => 102,
			'GT_LBRACKET' => 105,
			'IT_false' => 108
		},
		DEFAULT => -107,
		GOTOS => {
			'BooleanLiteral' => 72,
			'NumericLiteralPositive' => 91,
			'String' => 73,
			'_QTriplesBlock_E_Opt' => 412,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'TriplesSameSubject' => 222,
			'IRI_REF' => 53,
			'TriplesBlock' => 221,
			'NumericLiteral' => 78,
			'VAR2' => 55,
			'Var' => 79,
			'VarOrTerm' => 99,
			'GraphTerm' => 106,
			'PrefixedName' => 58,
			'BLANK_NODE_LABEL' => 103,
			'TriplesNode' => 104,
			'PNAME_LN' => 59,
			'PNAME_NS' => 61,
			'BlankNode' => 107,
			'BlankNodePropertyList' => 89,
			'IRIref' => 88,
			'Collection' => 90,
			'RDFLiteral' => 109
		}
	},
	{#State 390
		ACTIONS => {
			'GT_COMMA' => 405
		},
		DEFAULT => -250,
		GOTOS => {
			'_O_QGT_COMMA_E_S_QExpression_E_C' => 414,
			'_Q_O_QGT_COMMA_E_S_QExpression_E_C_E_Opt' => 413
		}
	},
	{#State 391
		ACTIONS => {
			'GT_RPAREN' => 415
		}
	},
	{#State 392
		DEFAULT => -198
	},
	{#State 393
		DEFAULT => -213
	},
	{#State 394
		DEFAULT => -214
	},
	{#State 395
		DEFAULT => -234
	},
	{#State 396
		DEFAULT => -220
	},
	{#State 397
		DEFAULT => -221
	},
	{#State 398
		DEFAULT => -235
	},
	{#State 399
		DEFAULT => -194
	},
	{#State 400
		ACTIONS => {
			'GT_RPAREN' => 416
		}
	},
	{#State 401
		DEFAULT => -33
	},
	{#State 402
		DEFAULT => -37
	},
	{#State 403
		DEFAULT => -61
	},
	{#State 404
		DEFAULT => -141
	},
	{#State 405
		ACTIONS => {
			'IT_LANG' => 161,
			'STRING_LITERAL_LONG2' => 12,
			'IT_DATATYPE' => 162,
			'IT_true' => 74,
			'INTEGER_NEGATIVE' => 75,
			'STRING_LITERAL_LONG1' => 15,
			'GT_NOT' => 241,
			'STRING_LITERAL2' => 16,
			'DECIMAL' => 76,
			'IT_isLITERAL' => 165,
			'IT_REGEX' => 167,
			'INTEGER' => 80,
			'STRING_LITERAL1' => 11,
			'GT_PLUS' => 251,
			'VAR1T' => 57,
			'DECIMAL_POSITIVE' => 83,
			'IT_isBLANK' => 169,
			'DOUBLE_NEGATIVE' => 84,
			'IT_LIST' => 246,
			'IT_MEMBERS' => 253,
			'PNAME_NST' => 64,
			'IRI_REFT' => 20,
			'IT_BOUND' => 172,
			'IT_LANGMATCHES' => 174,
			'DOUBLE_POSITIVE' => 92,
			'GT_LPAREN' => 175,
			'VAR2T' => 50,
			'PNAME_LNT' => 51,
			'GT_MINUS' => 255,
			'IT_sameTerm' => 176,
			'IT_isURI' => 177,
			'DECIMAL_NEGATIVE' => 98,
			'DOUBLE' => 101,
			'IT_STR' => 178,
			'INTEGER_POSITIVE' => 102,
			'IT_false' => 108,
			'IT_isIRI' => 179
		},
		GOTOS => {
			'BooleanLiteral' => 237,
			'NumericLiteralPositive' => 91,
			'RegexExpression' => 173,
			'RelationalExpression' => 238,
			'String' => 73,
			'ValueLogical' => 239,
			'MultiplicativeExpression' => 240,
			'NumericLiteralNegative' => 94,
			'NumericLiteralUnsigned' => 95,
			'VAR1' => 52,
			'IRI_REF' => 53,
			'NumericExpression' => 249,
			'NumericLiteral' => 250,
			'IRIrefOrFunction' => 242,
			'ConditionalOrExpression' => 256,
			'VAR2' => 55,
			'Var' => 243,
			'Expression' => 417,
			'BrackettedExpression' => 252,
			'PrefixedName' => 58,
			'ConditionalAndExpression' => 258,
			'PrimaryExpression' => 244,
			'PNAME_LN' => 59,
			'BuiltInCall' => 245,
			'UnaryExpression' => 247,
			'PNAME_NS' => 61,
			'AdditiveExpression' => 259,
			'IRIref' => 254,
			'RDFLiteral' => 248
		}
	},
	{#State 406
		DEFAULT => -139
	},
	{#State 407
		DEFAULT => -152
	},
	{#State 408
		DEFAULT => -131
	},
	{#State 409
		ACTIONS => {
			'GT_LCURLEY' => 110
		},
		GOTOS => {
			'GroupGraphPattern' => 418
		}
	},
	{#State 410
		ACTIONS => {
			'GT_LCURLEY' => 110
		},
		GOTOS => {
			'GroupGraphPattern' => 419
		}
	},
	{#State 411
		DEFAULT => -129
	},
	{#State 412
		DEFAULT => -113
	},
	{#State 413
		ACTIONS => {
			'GT_RPAREN' => 420
		}
	},
	{#State 414
		DEFAULT => -251
	},
	{#State 415
		DEFAULT => -240
	},
	{#State 416
		DEFAULT => -243
	},
	{#State 417
		DEFAULT => -137
	},
	{#State 418
		DEFAULT => -125
	},
	{#State 419
		DEFAULT => -127
	},
	{#State 420
		DEFAULT => -249
	}
],
                                  yyrules  =>
[
	[#Rule 0
		 '$start', 2, undef
	],
	[#Rule 1
		 'Start', 1, undef
	],
	[#Rule 2
		 'Start', 2,
sub
#line 214 "SparqlParser.yp"
{
    my ($self, $IT_SHUTDOWN, $_QString_E_Opt) = @_;
    &throw(new W3C::Rdf::AlgaeShutdownException(-reason => $_QString_E_Opt ? $_QString_E_Opt : "$IT_SHUTDOWN requested"));
}
	],
	[#Rule 3
		 'Start', 2,
sub
#line 219 "SparqlParser.yp"
{
    my ($self, $IT_NOTE, $_QString_E_Opt) = @_;
    print "$IT_NOTE: $_QString_E_Opt";
    [];
}
	],
	[#Rule 4
		 'Start', 1, undef
	],
	[#Rule 5
		 '_QString_E_Opt', 0, undef
	],
	[#Rule 6
		 '_QString_E_Opt', 1, undef
	],
	[#Rule 7
		 'Query', 2,
sub
#line 232 "SparqlParser.yp"
{
    my ($self, $Prologue, $_O_QSelectQuery_E_Or_QInsertQuery_E_Or_QDeleteQuery_E_Or_QBindingClause_E_Or_QAskQuery_E_Or_QWhereClause_E_Or_QCreateQuery_E_Or_QDropQuery_E_Star_Or_QConstructQuery_E_Or_QDescribeQuery_E_C) = @_;
    $self->resolveQNames();
    [@$Prologue, @$_O_QSelectQuery_E_Or_QInsertQuery_E_Or_QDeleteQuery_E_Or_QBindingClause_E_Or_QAskQuery_E_Or_QWhereClause_E_Or_QCreateQuery_E_Or_QDropQuery_E_Star_Or_QConstructQuery_E_Or_QDescribeQuery_E_C];
}
	],
	[#Rule 8
		 '_O_QSelectQuery_E_Or_QInsertQuery_E_Or_QDeleteQuery_E_Or_QBindingClause_E_Or_QAskQuery_E_Or_QWhereClause_E_Or_QCreateQuery_E_Or_QDropQuery_E_C', 1, undef
	],
	[#Rule 9
		 '_O_QSelectQuery_E_Or_QInsertQuery_E_Or_QDeleteQuery_E_Or_QBindingClause_E_Or_QAskQuery_E_Or_QWhereClause_E_Or_QCreateQuery_E_Or_QDropQuery_E_C', 1, undef
	],
	[#Rule 10
		 '_O_QSelectQuery_E_Or_QInsertQuery_E_Or_QDeleteQuery_E_Or_QBindingClause_E_Or_QAskQuery_E_Or_QWhereClause_E_Or_QCreateQuery_E_Or_QDropQuery_E_C', 1, undef
	],
	[#Rule 11
		 '_O_QSelectQuery_E_Or_QInsertQuery_E_Or_QDeleteQuery_E_Or_QBindingClause_E_Or_QAskQuery_E_Or_QWhereClause_E_Or_QCreateQuery_E_Or_QDropQuery_E_C', 1, undef
	],
	[#Rule 12
		 '_O_QSelectQuery_E_Or_QInsertQuery_E_Or_QDeleteQuery_E_Or_QBindingClause_E_Or_QAskQuery_E_Or_QWhereClause_E_Or_QCreateQuery_E_Or_QDropQuery_E_C', 1, undef
	],
	[#Rule 13
		 '_O_QSelectQuery_E_Or_QInsertQuery_E_Or_QDeleteQuery_E_Or_QBindingClause_E_Or_QAskQuery_E_Or_QWhereClause_E_Or_QCreateQuery_E_Or_QDropQuery_E_C', 1,
sub
#line 245 "SparqlParser.yp"
{
    my ($self, $WhereClause) = @_;
    [$WhereClause];
}
	],
	[#Rule 14
		 '_O_QSelectQuery_E_Or_QInsertQuery_E_Or_QDeleteQuery_E_Or_QBindingClause_E_Or_QAskQuery_E_Or_QWhereClause_E_Or_QCreateQuery_E_Or_QDropQuery_E_C', 1, undef
	],
	[#Rule 15
		 '_O_QSelectQuery_E_Or_QInsertQuery_E_Or_QDeleteQuery_E_Or_QBindingClause_E_Or_QAskQuery_E_Or_QWhereClause_E_Or_QCreateQuery_E_Or_QDropQuery_E_C', 1, undef
	],
	[#Rule 16
		 '_Q_O_QSelectQuery_E_Or_QInsertQuery_E_Or_QDeleteQuery_E_Or_QBindingClause_E_Or_QAskQuery_E_Or_QWhereClause_E_Or_QCreateQuery_E_Or_QDropQuery_E_C_E_Star', 0,
sub
#line 255 "SparqlParser.yp"
{
    [];
}
	],
	[#Rule 17
		 '_Q_O_QSelectQuery_E_Or_QInsertQuery_E_Or_QDeleteQuery_E_Or_QBindingClause_E_Or_QAskQuery_E_Or_QWhereClause_E_Or_QCreateQuery_E_Or_QDropQuery_E_C_E_Star', 2,
sub
#line 259 "SparqlParser.yp"
{
    my ($self, $_Q_O_QSelectQuery_E_Or_QInsertQuery_E_Or_QDeleteQuery_E_Or_QBindingClause_E_Or_QAskQuery_E_Or_QWhereClause_E_Or_QCreateQuery_E_Or_QDropQuery_E_C_E_Star, $_O_QSelectQuery_E_Or_QInsertQuery_E_Or_QDeleteQuery_E_Or_QBindingClause_E_Or_QAskQuery_E_Or_QWhereClause_E_Or_QCreateQuery_E_Or_QDropQuery_E_C) = @_;
    [@$_Q_O_QSelectQuery_E_Or_QInsertQuery_E_Or_QDeleteQuery_E_Or_QBindingClause_E_Or_QAskQuery_E_Or_QWhereClause_E_Or_QCreateQuery_E_Or_QDropQuery_E_C_E_Star, @$_O_QSelectQuery_E_Or_QInsertQuery_E_Or_QDeleteQuery_E_Or_QBindingClause_E_Or_QAskQuery_E_Or_QWhereClause_E_Or_QCreateQuery_E_Or_QDropQuery_E_C];
}
	],
	[#Rule 18
		 '_O_QSelectQuery_E_Or_QInsertQuery_E_Or_QDeleteQuery_E_Or_QBindingClause_E_Or_QAskQuery_E_Or_QWhereClause_E_Or_QCreateQuery_E_Or_QDropQuery_E_Star_Or_QConstructQuery_E_Or_QDescribeQuery_E_C', 1, undef
	],
	[#Rule 19
		 '_O_QSelectQuery_E_Or_QInsertQuery_E_Or_QDeleteQuery_E_Or_QBindingClause_E_Or_QAskQuery_E_Or_QWhereClause_E_Or_QCreateQuery_E_Or_QDropQuery_E_Star_Or_QConstructQuery_E_Or_QDescribeQuery_E_C', 1, undef
	],
	[#Rule 20
		 '_O_QSelectQuery_E_Or_QInsertQuery_E_Or_QDeleteQuery_E_Or_QBindingClause_E_Or_QAskQuery_E_Or_QWhereClause_E_Or_QCreateQuery_E_Or_QDropQuery_E_Star_Or_QConstructQuery_E_Or_QDescribeQuery_E_C', 1, undef
	],
	[#Rule 21
		 '@1-1', 0,
sub
#line 271 "SparqlParser.yp"
{
    my ($self, $IT_INSERT) = @_;
    $self->YYData->{CreateNovelBNodes} = 2; # !!! force BNodes -- need more control for SPDL (later)
}
	],
	[#Rule 22
		 'InsertQuery', 3,
sub
#line 276 "SparqlParser.yp"
{
    my ($self, $IT_INSERT, undef, $GroupGraphPattern) = @_;
    $self->YYData->{CreateNovelBNodes} = 0;
#    $self->YYData->{ALGAE2}->getResultSet()->setPresentationMimetype('application/rdf+xml');
    [$self->YYData->{ALGAE2}->assert($GroupGraphPattern, undef)];
}
	],
	[#Rule 23
		 'DeleteQuery', 2,
sub
#line 285 "SparqlParser.yp"
{
    my ($self, $IT_DELETE, $GroupGraphPattern) = @_;
    [$self->YYData->{ALGAE2}->delete($GroupGraphPattern, undef)];
}
	],
	[#Rule 24
		 'CreateQuery', 2,
sub
#line 292 "SparqlParser.yp"
{
    my ($self, $IT_CREATE, $VarOrIRIref) = @_;
    [$self->YYData->{ALGAE2}->attach(new W3C::Rdf::AlgaeCompileTree::Url('http://www.w3.org/1999/02/26-modules/algae#ephemeral', undef, $self), $VarOrIRIref, [])];
}
	],
	[#Rule 25
		 'DropQuery', 2,
sub
#line 299 "SparqlParser.yp"
{
    my ($self, $IT_DROP, $VarOrIRIref) = @_;
    $self->YYData->{ALGAE2}->dropSource($VarOrIRIref->getUrl);
    [];
}
	],
	[#Rule 26
		 '@2-1', 0,
sub
#line 307 "SparqlParser.yp"
{
    my ($self, $PATHPATTERN) = @_;
}
	],
	[#Rule 27
		 'PathPattern', 4,
sub
#line 311 "SparqlParser.yp"
{
    my ($self, $PATHPATTERN, undef, $ConstructTemplate, $SolutionModifier) = @_;
    [$self->YYData->{ALGAE2}->pattern($ConstructTemplate, $self->YYData->{ALGAE2}->getTemplateDB())];
}
	],
	[#Rule 28
		 'BindingClause', 5,
sub
#line 318 "SparqlParser.yp"
{
    my ($self, $IT_BINDINGS, $_QVar_E_Plus, $GT_LCURLEY, $_QBinding_E_Star, $GT_RCURLEY) = @_;
    $self->YYData->{ALGAE2}->bindings($_QVar_E_Plus, $_QBinding_E_Star);
}
	],
	[#Rule 29
		 '_QVar_E_Plus', 1,
sub
#line 325 "SparqlParser.yp"
{
    my ($self, $Var) = @_;
    [$Var];
}
	],
	[#Rule 30
		 '_QVar_E_Plus', 2,
sub
#line 330 "SparqlParser.yp"
{
    my ($self, $_QVar_E_Plus, $Var) = @_;
    [@$_QVar_E_Plus, $Var];
}
	],
	[#Rule 31
		 '_QBinding_E_Star', 0,
sub
#line 337 "SparqlParser.yp"
{
    my ($self, ) = @_;
    [];
}
	],
	[#Rule 32
		 '_QBinding_E_Star', 2,
sub
#line 342 "SparqlParser.yp"
{
    my ($self, $_QBinding_E_Star, $Binding) = @_;
    [@$_QBinding_E_Star, $Binding];
}
	],
	[#Rule 33
		 'Binding', 3,
sub
#line 349 "SparqlParser.yp"
{
    my ($self, $GT_LPAREN, $_Q_O_QVarOrTerm_E_Or_QIT_NULL_E_C_E_Plus, $GT_RPAREN) = @_;
    $_Q_O_QVarOrTerm_E_Or_QIT_NULL_E_C_E_Plus;
}
	],
	[#Rule 34
		 '_O_QVarOrTerm_E_Or_QIT_NULL_E_C', 1,
sub
#line 356 "SparqlParser.yp"
{
    my ($self, $VarOrTerm) = @_;
    $VarOrTerm;
}
	],
	[#Rule 35
		 '_O_QVarOrTerm_E_Or_QIT_NULL_E_C', 1, undef
	],
	[#Rule 36
		 '_Q_O_QVarOrTerm_E_Or_QIT_NULL_E_C_E_Plus', 1,
sub
#line 364 "SparqlParser.yp"
{
    my ($self, $_O_QVarOrTerm_E_Or_QIT_NULL_E_C) = @_;
    [$_O_QVarOrTerm_E_Or_QIT_NULL_E_C];
}
	],
	[#Rule 37
		 '_Q_O_QVarOrTerm_E_Or_QIT_NULL_E_C_E_Plus', 2,
sub
#line 369 "SparqlParser.yp"
{
    my ($self, $_Q_O_QVarOrTerm_E_Or_QIT_NULL_E_C_E_Plus, $VarOrTerm) = @_;
    [@$_Q_O_QVarOrTerm_E_Or_QIT_NULL_E_C_E_Plus, $VarOrTerm];
}
	],
	[#Rule 38
		 'Prologue', 2,
sub
#line 376 "SparqlParser.yp"
{
    my ($self, $_QBaseDecl_E_Opt, $_QPrefixDecl_E_Star) = @_;
    $_QPrefixDecl_E_Star;
}
	],
	[#Rule 39
		 '_QBaseDecl_E_Opt', 0,
sub
#line 383 "SparqlParser.yp"
{
    my ($self, ) = @_;
    [];
}
	],
	[#Rule 40
		 '_QBaseDecl_E_Opt', 1, undef
	],
	[#Rule 41
		 '_QPrefixDecl_E_Star', 0,
sub
#line 391 "SparqlParser.yp"
{
    my ($self, ) = @_;
    [];
}
	],
	[#Rule 42
		 '_QPrefixDecl_E_Star', 2,
sub
#line 396 "SparqlParser.yp"
{
    my ($self, $_QPrefixDecl_E_Star, $PrefixDecl) = @_;
    [@$_QPrefixDecl_E_Star, $PrefixDecl];
}
	],
	[#Rule 43
		 'BaseDecl', 2,
sub
#line 403 "SparqlParser.yp"
{
    my ($self, $BASE, $IRI_REF) = @_;
    [$self->YYData->{BASE} = $IRI_REF];
}
	],
	[#Rule 44
		 'PrefixDecl', 3,
sub
#line 410 "SparqlParser.yp"
{
    my ($self, $PREFIX, $PNAME_NS, $IRI_REF) = @_;
    $self->addNamespace($PNAME_NS, $IRI_REF);
    $self->YYData->{ALGAE2}->namespace($PNAME_NS, $IRI_REF);
}
	],
	[#Rule 45
		 'SelectQuery', 6,
sub
#line 418 "SparqlParser.yp"
{
    my ($self, $SELECT, $_Q_O_QIT_DISTINCT_E_Or_QIT_REDUCED_E_C_E_Opt, $_O_QVar_E_Or_QBrackettedExpression_E_Or_QBuiltInCall_E_Plus_Or_QGT_TIMES_E_C, $_QDatasetClause_E_Star, $WhereClause, $SolutionModifier) = @_;
    $self->YYData->{ALGAE2}->getResultSet()->setPresentationMimetype('application/srx+xml');
    if ($self->YYData->{COLLECTSTAR}) {
	$self->YYData->{COLLECT} = $self->YYData->{ALGAE2}->collect([$self->YYData->{COLLECTSTAR}->expandCollects()], $_Q_O_QIT_DISTINCT_E_Or_QIT_REDUCED_E_C_E_Opt);
    } else {
	$self->YYData->{COLLECT} = $self->YYData->{ALGAE2}->collect([@$_O_QVar_E_Or_QBrackettedExpression_E_Or_QBuiltInCall_E_Plus_Or_QGT_TIMES_E_C], $_Q_O_QIT_DISTINCT_E_Or_QIT_REDUCED_E_C_E_Opt);
    }
    $self->YYData->{COLLECT}->order($SolutionModifier->[0]) if (defined $SolutionModifier->[0]);
    $self->YYData->{COLLECT}->limit($SolutionModifier->[1]) if (defined $SolutionModifier->[1]);
    $self->YYData->{COLLECT}->offset($SolutionModifier->[2]) if (defined $SolutionModifier->[2]);
    $self->YYData->{ALGAE2}->getResultSet()->testTrue(0);
    [$WhereClause, $self->YYData->{COLLECT}];
}
	],
	[#Rule 46
		 '_O_QIT_DISTINCT_E_Or_QIT_REDUCED_E_C', 1,
sub
#line 435 "SparqlParser.yp"
{
    my ($self, $IT_DISTINCT) = @_;
    1;
}
	],
	[#Rule 47
		 '_O_QIT_DISTINCT_E_Or_QIT_REDUCED_E_C', 1,
sub
#line 440 "SparqlParser.yp"
{
    my ($self, $IT_REDUCED) = @_;
    -1;
}
	],
	[#Rule 48
		 '_Q_O_QIT_DISTINCT_E_Or_QIT_REDUCED_E_C_E_Opt', 0,
sub
#line 447 "SparqlParser.yp"
{
    my ($self, ) = @_;
    0;
}
	],
	[#Rule 49
		 '_Q_O_QIT_DISTINCT_E_Or_QIT_REDUCED_E_C_E_Opt', 1, undef
	],
	[#Rule 50
		 '_O_QVar_E_Or_QBrackettedExpression_E_Or_QBuiltInCall_E_C', 1,
sub
#line 455 "SparqlParser.yp"
{
    my ($self, $Var) = @_;
    [$Var];
}
	],
	[#Rule 51
		 '_O_QVar_E_Or_QBrackettedExpression_E_Or_QBuiltInCall_E_C', 1,
sub
#line 460 "SparqlParser.yp"
{
    my ($self, $BrackettedExpression) = @_;
    [$BrackettedExpression];
}
	],
	[#Rule 52
		 '_O_QVar_E_Or_QBrackettedExpression_E_Or_QBuiltInCall_E_C', 1,
sub
#line 465 "SparqlParser.yp"
{
    my ($self, $BuiltInCall) = @_;
    [$BuiltInCall];
}
	],
	[#Rule 53
		 '_Q_O_QVar_E_Or_QBrackettedExpression_E_Or_QBuiltInCall_E_C_E_Plus', 1, undef
	],
	[#Rule 54
		 '_Q_O_QVar_E_Or_QBrackettedExpression_E_Or_QBuiltInCall_E_C_E_Plus', 2,
sub
#line 473 "SparqlParser.yp"
{
    my ($self, $_Q_O_QVar_E_Or_QBrackettedExpression_E_Or_QBuiltInCall_E_C_E_Plus, $_O_QVar_E_Or_QBrackettedExpression_E_Or_QBuiltInCall_E_C) = @_;
    [@$_Q_O_QVar_E_Or_QBrackettedExpression_E_Or_QBuiltInCall_E_C_E_Plus, @$_O_QVar_E_Or_QBrackettedExpression_E_Or_QBuiltInCall_E_C];
}
	],
	[#Rule 55
		 '_O_QVar_E_Or_QBrackettedExpression_E_Or_QBuiltInCall_E_Plus_Or_QGT_TIMES_E_C', 1, undef
	],
	[#Rule 56
		 '_O_QVar_E_Or_QBrackettedExpression_E_Or_QBuiltInCall_E_Plus_Or_QGT_TIMES_E_C', 1,
sub
#line 481 "SparqlParser.yp"
{
    my ($self, $TIMES) = @_;
    $self->YYData->{COLLECTSTAR} = $self->YYData->{ALGAE2}->collectStar($self);
    [];
}
	],
	[#Rule 57
		 '_QDatasetClause_E_Star', 0,
sub
#line 489 "SparqlParser.yp"
{
    my ($self, ) = @_;
    [];
}
	],
	[#Rule 58
		 '_QDatasetClause_E_Star', 2,
sub
#line 494 "SparqlParser.yp"
{
    my ($self, $_QDatasetClause_E_Star, $DatasetClause) = @_;
    [@$_QDatasetClause_E_Star, $DatasetClause];
}
	],
	[#Rule 59
		 '@3-1', 0,
sub
#line 501 "SparqlParser.yp"
{
    my ($self, $CONSTRUCT) = @_;
    $self->YYData->{CreateNovelBNodes} = 1;
}
	],
	[#Rule 60
		 '@4-3', 0,
sub
#line 506 "SparqlParser.yp"
{
    my ($self, $CONSTRUCT, undef, $ConstructTemplate) = @_;
    $self->YYData->{CreateNovelBNodes} = 0;
}
	],
	[#Rule 61
		 'ConstructQuery', 8,
sub
#line 511 "SparqlParser.yp"
{
    my ($self, $CONSTRUCT, undef, $ConstructTemplate, undef, $_QDatasetClause_E_Star, $WhereClause, $_QBindingClause_E_Opt, $SolutionModifier) = @_;
    my $pattern = $self->YYData->{ALGAE2}->assert($ConstructTemplate, $self->YYData->{ALGAE2}->getTemplateDB());
    $self->YYData->{ALGAE2}->getResultSet()->setPresentationMimetype('application/rdf+xml');
    $self->YYData->{ALGAE2}->getResultSet()->testTrue(0);
    [@$_QBindingClause_E_Opt, $WhereClause, $pattern];
}
	],
	[#Rule 62
		 '_QBindingClause_E_Opt', 0,
sub
#line 521 "SparqlParser.yp"
{
    [];
}
	],
	[#Rule 63
		 '_QBindingClause_E_Opt', 1,
sub
#line 525 "SparqlParser.yp"
{
    my ($self, $BindingClause) = @_;
    return [$BindingClause];
}
	],
	[#Rule 64
		 'DescribeQuery', 6,
sub
#line 532 "SparqlParser.yp"
{
    my ($self, $DESCRIBE, $_O_QVarOrIRIref_E_Plus_Or_QGT_TIMES_E_C, $_QDatasetClause_E_Star, $_QWhereClause_E_Opt, $_QBindingClause_E_Opt, $SolutionModifier) = @_;
    $self->YYData->{ALGAE2}->getResultSet()->setPresentationMimetype('application/rdf+xml');
    $self->YYData->{ALGAE2}->getResultSet()->testTrue(0);
    [@$_QBindingClause_E_Opt, $self->YYData->{ALGAE2}->describe($_O_QVarOrIRIref_E_Plus_Or_QGT_TIMES_E_C, $self->YYData->{ALGAE2}->getTemplateDB()), @$_QWhereClause_E_Opt];
}
	],
	[#Rule 65
		 '_QVarOrIRIref_E_Plus', 1,
sub
#line 541 "SparqlParser.yp"
{
    my ($self, $VarOrIRIref) = @_;
    [$VarOrIRIref];
}
	],
	[#Rule 66
		 '_QVarOrIRIref_E_Plus', 2,
sub
#line 546 "SparqlParser.yp"
{
    my ($self, $_QVarOrIRIref_E_Plus, $VarOrIRIref) = @_;
    [@$_QVarOrIRIref_E_Plus, $VarOrIRIref];
}
	],
	[#Rule 67
		 '_O_QVarOrIRIref_E_Plus_Or_QGT_TIMES_E_C', 1, undef
	],
	[#Rule 68
		 '_O_QVarOrIRIref_E_Plus_Or_QGT_TIMES_E_C', 1,
sub
#line 554 "SparqlParser.yp"
{
    my ($self, $TIMES) = @_;
    [$TIMES];
}
	],
	[#Rule 69
		 '_QWhereClause_E_Opt', 0,
sub
#line 561 "SparqlParser.yp"
{
    [];
}
	],
	[#Rule 70
		 '_QWhereClause_E_Opt', 1,
sub
#line 565 "SparqlParser.yp"
{
    my ($self, $WhereClause) = @_;
    return [$WhereClause];
}
	],
	[#Rule 71
		 'AskQuery', 3,
sub
#line 572 "SparqlParser.yp"
{
    my ($self, $ASK, $_QDatasetClause_E_Star, $WhereClause) = @_;
    $self->YYData->{ALGAE2}->getResultSet()->setPresentationMimetype('application/srx+xml');
    [$WhereClause, $self->YYData->{ALGAE2}->SPARQLask($self)]; # set TruthValue after query is executed
}
	],
	[#Rule 72
		 'DatasetClause', 2, undef
	],
	[#Rule 73
		 '_O_QDefaultGraphClause_E_Or_QNamedGraphClause_E_C', 1, undef
	],
	[#Rule 74
		 '_O_QDefaultGraphClause_E_Or_QNamedGraphClause_E_C', 1, undef
	],
	[#Rule 75
		 'DefaultGraphClause', 1,
sub
#line 587 "SparqlParser.yp"
{
    my ($self, $SourceSelector) = @_;
    $self->YYData->{ALGAE2}->defaultGraph($SourceSelector, $self);
}
	],
	[#Rule 76
		 'NamedGraphClause', 2,
sub
#line 594 "SparqlParser.yp"
{
    my ($self, $NAMED, $SourceSelector) = @_;
    $self->YYData->{ALGAE2}->namedGraph($SourceSelector, $self);
}
	],
	[#Rule 77
		 'SourceSelector', 1, undef
	],
	[#Rule 78
		 'WhereClause', 2,
sub
#line 604 "SparqlParser.yp"
{
    my ($self, $_QIT_WHERE_E_Opt, $GroupGraphPattern) = @_;
    $self->YYData->{ALGAE2}->ask($GroupGraphPattern, undef);
}
	],
	[#Rule 79
		 '_QIT_WHERE_E_Opt', 0, undef
	],
	[#Rule 80
		 '_QIT_WHERE_E_Opt', 1, undef
	],
	[#Rule 81
		 'SolutionModifier', 2,
sub
#line 615 "SparqlParser.yp"
{
    my ($self, $_QOrderClause_E_Opt, $_QLimitOffsetClauses_E_Opt) = @_;
    [$_QOrderClause_E_Opt, @$_QLimitOffsetClauses_E_Opt];
}
	],
	[#Rule 82
		 '_QOrderClause_E_Opt', 0, undef
	],
	[#Rule 83
		 '_QOrderClause_E_Opt', 1, undef
	],
	[#Rule 84
		 '_QLimitOffsetClauses_E_Opt', 0,
sub
#line 626 "SparqlParser.yp"
{
    my ($self, ) = @_;
    [undef, undef];
}
	],
	[#Rule 85
		 '_QLimitOffsetClauses_E_Opt', 1, undef
	],
	[#Rule 86
		 'LimitOffsetClauses', 1, undef
	],
	[#Rule 87
		 '_QOffsetClause_E_Opt', 0, undef
	],
	[#Rule 88
		 '_QOffsetClause_E_Opt', 1, undef
	],
	[#Rule 89
		 '_QLimitClause_E_Opt', 0, undef
	],
	[#Rule 90
		 '_QLimitClause_E_Opt', 1, undef
	],
	[#Rule 91
		 '_O_QLimitClause_E_S_QOffsetClause_E_Opt_Or_QOffsetClause_E_S_QLimitClause_E_Opt_C', 2,
sub
#line 645 "SparqlParser.yp"
{
    my ($self, $LimitClause, $_QOffsetClause_E_Opt) = @_;
    return [$LimitClause, $_QOffsetClause_E_Opt];
}
	],
	[#Rule 92
		 '_O_QLimitClause_E_S_QOffsetClause_E_Opt_Or_QOffsetClause_E_S_QLimitClause_E_Opt_C', 2,
sub
#line 650 "SparqlParser.yp"
{
    my ($self, $OffsetClause, $_QLimitClause_E_Opt) = @_;
    return [$_QLimitClause_E_Opt, $OffsetClause];
}
	],
	[#Rule 93
		 'OrderClause', 3,
sub
#line 657 "SparqlParser.yp"
{
    my ($self, $ORDER, $BY, $_QOrderCondition_E_Plus) = @_;
    $_QOrderCondition_E_Plus;
}
	],
	[#Rule 94
		 '_QOrderCondition_E_Plus', 1,
sub
#line 664 "SparqlParser.yp"
{
    my ($self, $OrderCondition) = @_;
    [$OrderCondition];
}
	],
	[#Rule 95
		 '_QOrderCondition_E_Plus', 2,
sub
#line 669 "SparqlParser.yp"
{
    my ($self, $_QOrderCondition_E_Plus, $OrderCondition) = @_;
    [@$_QOrderCondition_E_Plus, $OrderCondition];
}
	],
	[#Rule 96
		 'OrderCondition', 1, undef
	],
	[#Rule 97
		 'OrderCondition', 1,
sub
#line 677 "SparqlParser.yp"
{
    my ($self, $_O_QConstraint_E_Or_QVar_E_C) = @_;
    return [$_O_QConstraint_E_Or_QVar_E_C, 1];
}
	],
	[#Rule 98
		 '_O_QIT_ASC_E_Or_QIT_DESC_E_C', 1,
sub
#line 684 "SparqlParser.yp"
{
    my ($self, $ASC) = @_;
    return 1;
}
	],
	[#Rule 99
		 '_O_QIT_ASC_E_Or_QIT_DESC_E_C', 1,
sub
#line 689 "SparqlParser.yp"
{
    my ($self, $DESC) = @_;
    return -1;
}
	],
	[#Rule 100
		 '_O_QIT_ASC_E_Or_QIT_DESC_E_S_QBrackettedExpression_E_C', 2,
sub
#line 696 "SparqlParser.yp"
{
    my ($self, $_O_QIT_ASC_E_Or_QIT_DESC_E_C, $BrackettedExpression) = @_;
    [$BrackettedExpression, $_O_QIT_ASC_E_Or_QIT_DESC_E_C];
}
	],
	[#Rule 101
		 '_O_QConstraint_E_Or_QVar_E_C', 1, undef
	],
	[#Rule 102
		 '_O_QConstraint_E_Or_QVar_E_C', 1, undef
	],
	[#Rule 103
		 'LimitClause', 2,
sub
#line 707 "SparqlParser.yp"
{
    my ($self, $LIMIT, $INTEGER) = @_;
    $INTEGER;
}
	],
	[#Rule 104
		 'OffsetClause', 2,
sub
#line 714 "SparqlParser.yp"
{
    my ($self, $OFFSET, $INTEGER) = @_;
    $INTEGER;
}
	],
	[#Rule 105
		 '@5-1', 0,
sub
#line 721 "SparqlParser.yp"
{
    my ($self, $GT_LCURLEY) = @_;
    push (@{$self->YYData->{patternIdStack}}, []);
}
	],
	[#Rule 106
		 'GroupGraphPattern', 5,
sub
#line 726 "SparqlParser.yp"
{
    my ($self, $GT_LCURLEY, undef, $_QTriplesBlock_E_Opt, $_Q_O_QGraphPatternNotTriples_E_Or_QFilter_E_S_QGT_DOT_E_Opt_S_QTriplesBlock_E_Opt_C_E_Star, $GT_RCURLEY) = @_;
    pop (@{$self->YYData->{patternIdStack}});
    $_QTriplesBlock_E_Opt && $_Q_O_QGraphPatternNotTriples_E_Or_QFilter_E_S_QGT_DOT_E_Opt_S_QTriplesBlock_E_Opt_C_E_Star ? 
	new W3C::Rdf::AlgaeCompileTree::Conjunction($_QTriplesBlock_E_Opt, $_Q_O_QGraphPatternNotTriples_E_Or_QFilter_E_S_QGT_DOT_E_Opt_S_QTriplesBlock_E_Opt_C_E_Star, $self) : 
        $_QTriplesBlock_E_Opt ? 
	    $_QTriplesBlock_E_Opt : 
	    $_Q_O_QGraphPatternNotTriples_E_Or_QFilter_E_S_QGT_DOT_E_Opt_S_QTriplesBlock_E_Opt_C_E_Star;
}
	],
	[#Rule 107
		 '_QTriplesBlock_E_Opt', 0, undef
	],
	[#Rule 108
		 '_QTriplesBlock_E_Opt', 1, undef
	],
	[#Rule 109
		 '_O_QGraphPatternNotTriples_E_Or_QFilter_E_C', 1, undef
	],
	[#Rule 110
		 '_O_QGraphPatternNotTriples_E_Or_QFilter_E_C', 1, undef
	],
	[#Rule 111
		 '_QGT_DOT_E_Opt', 0, undef
	],
	[#Rule 112
		 '_QGT_DOT_E_Opt', 1, undef
	],
	[#Rule 113
		 '_O_QGraphPatternNotTriples_E_Or_QFilter_E_S_QGT_DOT_E_Opt_S_QTriplesBlock_E_Opt_C', 3,
sub
#line 750 "SparqlParser.yp"
{
    my ($self, $_O_QGraphPatternNotTriples_E_Or_QFilter_E_C, $_QGT_DOT_E_Opt, $_QTriplesBlock_E_Opt) = @_;
    $_QTriplesBlock_E_Opt ? 
	new W3C::Rdf::AlgaeCompileTree::Conjunction($_O_QGraphPatternNotTriples_E_Or_QFilter_E_C, $_QTriplesBlock_E_Opt, $self) : 
	$_O_QGraphPatternNotTriples_E_Or_QFilter_E_C;
}
	],
	[#Rule 114
		 '_Q_O_QGraphPatternNotTriples_E_Or_QFilter_E_S_QGT_DOT_E_Opt_S_QTriplesBlock_E_Opt_C_E_Star', 0, undef
	],
	[#Rule 115
		 '_Q_O_QGraphPatternNotTriples_E_Or_QFilter_E_S_QGT_DOT_E_Opt_S_QTriplesBlock_E_Opt_C_E_Star', 2,
sub
#line 760 "SparqlParser.yp"
{
    my ($self, $_Q_O_QGraphPatternNotTriples_E_Or_QFilter_E_S_QGT_DOT_E_Opt_S_QTriplesBlock_E_Opt_C_E_Star, $_O_QGraphPatternNotTriples_E_Or_QFilter_E_S_QGT_DOT_E_Opt_S_QTriplesBlock_E_Opt_C) = @_;
    $_Q_O_QGraphPatternNotTriples_E_Or_QFilter_E_S_QGT_DOT_E_Opt_S_QTriplesBlock_E_Opt_C_E_Star ? 
	new W3C::Rdf::AlgaeCompileTree::Conjunction($_Q_O_QGraphPatternNotTriples_E_Or_QFilter_E_S_QGT_DOT_E_Opt_S_QTriplesBlock_E_Opt_C_E_Star, $_O_QGraphPatternNotTriples_E_Or_QFilter_E_S_QGT_DOT_E_Opt_S_QTriplesBlock_E_Opt_C, $self) : 
	$_O_QGraphPatternNotTriples_E_Or_QFilter_E_S_QGT_DOT_E_Opt_S_QTriplesBlock_E_Opt_C;
}
	],
	[#Rule 116
		 'TriplesBlock', 2,
sub
#line 769 "SparqlParser.yp"
{ #1 721
    my ($self, $TriplesSameSubject,  $_Q_O_QGT_DOT_E_S_QTriplesBlock_E_Opt_C_E_Opt) = @_;
    $_Q_O_QGT_DOT_E_S_QTriplesBlock_E_Opt_C_E_Opt ? 
	new W3C::Rdf::AlgaeCompileTree::Conjunction($TriplesSameSubject, $_Q_O_QGT_DOT_E_S_QTriplesBlock_E_Opt_C_E_Opt, $self) : 
	$TriplesSameSubject;
}
	],
	[#Rule 117
		 '_O_QGT_DOT_E_S_QTriplesBlock_E_Opt_C', 2,
sub
#line 778 "SparqlParser.yp"
{ #1 675 sorta
    my ($self, $DOT, $_QTriplesBlock_E_Opt) = @_;
    $_QTriplesBlock_E_Opt;
}
	],
	[#Rule 118
		 '_Q_O_QGT_DOT_E_S_QTriplesBlock_E_Opt_C_E_Opt', 0, undef
	],
	[#Rule 119
		 '_Q_O_QGT_DOT_E_S_QTriplesBlock_E_Opt_C_E_Opt', 1, undef
	],
	[#Rule 120
		 'GraphPatternNotTriples', 1, undef
	],
	[#Rule 121
		 'GraphPatternNotTriples', 1, undef
	],
	[#Rule 122
		 'GraphPatternNotTriples', 1, undef
	],
	[#Rule 123
		 'OptionalGraphPattern', 2,
sub
#line 794 "SparqlParser.yp"
{
    my ($self, $OPTIONAL, $GroupGraphPattern) = @_;
    # OPTIONAL breaks a BasicGraphPattern
    pop (@{$self->YYData->{patternIdStack}});
    push (@{$self->YYData->{patternIdStack}}, []);
    new W3C::Rdf::AlgaeCompileTree::Option($GroupGraphPattern, $self);
}
	],
	[#Rule 124
		 '@6-2', 0,
sub
#line 804 "SparqlParser.yp"
{
    my ($self, $GRAPH, $VarOrIRIref) = @_;
    my $semval2 = $self->YYData->{Attribution};
    if ($VarOrIRIref->isa('W3C::Rdf::AlgaeCompileTree::Url')) {
	if ($self->YYData->{ALGAE2}->getDefaultParms()->{GRAPHdoesFROM} && 
	    $self->YYData->{ALGAE2}->getDefaultParms()->{GRAPHdoesFROM}->getString eq 'TRUE') {
	    eval {
		$self->YYData->{ALGAE2}->getSourceByName($VarOrIRIref->getUrl, undef, $self);
	    }; if ($@) {
		my $db = new W3C::Rdf::RdfDB(-atomDictionary => $self->YYData->{ALGAE2}{-atomDictionary});
		$self->YYData->{ALGAE2}->addSource($VarOrIRIref->getUrl, $db);
	    }
	}
	my $source = $self->YYData->{ALGAE2}{-atomDictionary}->getUri($VarOrIRIref->getUrl);
	my $attrib = $self->YYData->{ALGAE2}{-atomDictionary}->getGroundFactAttribution($source, undef, undef, undef);
	$self->YYData->{Attribution} = $attrib;
    }
    return $semval2;
}
	],
	[#Rule 125
		 'GraphGraphPattern', 4,
sub
#line 824 "SparqlParser.yp"
{
    my ($self, $GRAPH, $VarOrIRIref, $semval2, $GroupGraphPattern) = @_;

    my $ctorFunc = sub {
	my ($source, $decl) = @_;
	my $db = $self->YYData->{ALGAE2}->getSourceByName($source, undef, $self);
	return $self->YYData->{ALGAE2}->ask($GroupGraphPattern, $db);
    };
    my $ret = $VarOrIRIref->isa('W3C::Rdf::AlgaeCompileTree::Var') ? 
	$self->YYData->{ALGAE2}->askAll($GroupGraphPattern, $VarOrIRIref, $ctorFunc, $self) : 
	$ctorFunc->($VarOrIRIref->getUrl, $GroupGraphPattern);
    $ret->immediateEvaluate($self->{RESULT_SET});
    $self->YYData->{Attribution} = $semval2;

    # GRAPH breaks a BasicGraphPattern
    pop (@{$self->YYData->{patternIdStack}});
    push (@{$self->YYData->{patternIdStack}}, []);

    $ret;
}
	],
	[#Rule 126
		 'GroupOrUnionGraphPattern', 2,
sub
#line 847 "SparqlParser.yp"
{
    my ($self, $GroupGraphPattern, $_Q_O_QIT_UNION_E_S_QGroupGraphPattern_E_C_E_Star) = @_;
    $_Q_O_QIT_UNION_E_S_QGroupGraphPattern_E_C_E_Star ? 
    new W3C::Rdf::AlgaeCompileTree::UnionDisjunction($GroupGraphPattern, $_Q_O_QIT_UNION_E_S_QGroupGraphPattern_E_C_E_Star, $self) : 
    $GroupGraphPattern;
}
	],
	[#Rule 127
		 '_O_QIT_UNION_E_S_QGroupGraphPattern_E_C', 2,
sub
#line 856 "SparqlParser.yp"
{
    my ($self, $UNION, $GroupGraphPattern) = @_;
    # UNION breaks a BasicGraphPattern
    pop (@{$self->YYData->{patternIdStack}});
    push (@{$self->YYData->{patternIdStack}}, []);
    $GroupGraphPattern;
}
	],
	[#Rule 128
		 '_Q_O_QIT_UNION_E_S_QGroupGraphPattern_E_C_E_Star', 0, undef
	],
	[#Rule 129
		 '_Q_O_QIT_UNION_E_S_QGroupGraphPattern_E_C_E_Star', 2,
sub
#line 867 "SparqlParser.yp"
{
    my ($self, $_Q_O_QIT_UNION_E_S_QGroupGraphPattern_E_C_E_Star, $_O_QIT_UNION_E_S_QGroupGraphPattern_E_C) = @_;
    $_Q_O_QIT_UNION_E_S_QGroupGraphPattern_E_C_E_Star ? 
	new W3C::Rdf::AlgaeCompileTree::UnionDisjunction($_Q_O_QIT_UNION_E_S_QGroupGraphPattern_E_C_E_Star, $_O_QIT_UNION_E_S_QGroupGraphPattern_E_C, $self) : 
	$_O_QIT_UNION_E_S_QGroupGraphPattern_E_C;
}
	],
	[#Rule 130
		 '@7-1', 0,
sub
#line 876 "SparqlParser.yp"
{
    my ($self, $FILTER) = @_;
    $self->YYData->{inFilter} = 1;
}
	],
	[#Rule 131
		 'Filter', 3,
sub
#line 881 "SparqlParser.yp"
{
    my ($self, $FILTER, undef, $Constraint) = @_;
    $self->YYData->{inFilter} = 0;
    new W3C::Rdf::AlgaeCompileTree::Constraint($Constraint, $self);
}
	],
	[#Rule 132
		 'Constraint', 1, undef
	],
	[#Rule 133
		 'Constraint', 1, undef
	],
	[#Rule 134
		 'Constraint', 1, undef
	],
	[#Rule 135
		 'FunctionCall', 2,
sub
#line 894 "SparqlParser.yp"
{
    my ($self, $IRIref, $ArgList) = @_;
    new W3C::Rdf::AlgaeCompileTree::FuncCall($IRIref, $ArgList, $self);
}
	],
	[#Rule 136
		 'ArgList', 1, undef
	],
	[#Rule 137
		 '_O_QGT_COMMA_E_S_QExpression_E_C', 2,
sub
#line 904 "SparqlParser.yp"
{
    my ($self, $COMMA, $Expression) = @_;
    [$Expression];
}
	],
	[#Rule 138
		 '_Q_O_QGT_COMMA_E_S_QExpression_E_C_E_Star', 0,
sub
#line 911 "SparqlParser.yp"
{
    my ($self, ) = @_;
    [];
}
	],
	[#Rule 139
		 '_Q_O_QGT_COMMA_E_S_QExpression_E_C_E_Star', 2,
sub
#line 916 "SparqlParser.yp"
{
    my ($self, $_Q_O_QGT_COMMA_E_S_QExpression_E_C_E_Star, $_O_QGT_COMMA_E_S_QExpression_E_C) = @_;
    [@$_Q_O_QGT_COMMA_E_S_QExpression_E_C_E_Star, $_O_QGT_COMMA_E_S_QExpression_E_C];
}
	],
	[#Rule 140
		 '_O_QNIL_E_Or_QGT_LPAREN_E_S_QExpression_E_S_QGT_COMMA_E_S_QExpression_E_Star_S_QGT_RPAREN_E_C', 1,
sub
#line 923 "SparqlParser.yp"
{
    my ($self, $NIL) = @_;
    [];
}
	],
	[#Rule 141
		 '_O_QNIL_E_Or_QGT_LPAREN_E_S_QExpression_E_S_QGT_COMMA_E_S_QExpression_E_Star_S_QGT_RPAREN_E_C', 4,
sub
#line 928 "SparqlParser.yp"
{
    my ($self, $LPAREN, $Expression, $_Q_O_QGT_COMMA_E_S_QExpression_E_C_E_Star, $RPAREN) = @_;
    [$Expression, @$_Q_O_QGT_COMMA_E_S_QExpression_E_C_E_Star];
}
	],
	[#Rule 142
		 'ConstructTemplate', 3,
sub
#line 935 "SparqlParser.yp"
{
    my ($self, $LCURLEY, $ConstructTriples, $RCURLEY) = @_;
    $ConstructTriples;
}
	],
	[#Rule 143
		 '_QConstructTriples_E_Opt', 0, undef
	],
	[#Rule 144
		 '_QConstructTriples_E_Opt', 1, undef
	],
	[#Rule 145
		 'ConstructTriples', 2,
sub
#line 946 "SparqlParser.yp"
{
    my ($self, $TriplesSameSubject, $_Q_O_QGT_DOT_E_S_QConstructTriples_E_Opt_C_E_Opt) = @_;
    $_Q_O_QGT_DOT_E_S_QConstructTriples_E_Opt_C_E_Opt ? 
	new W3C::Rdf::AlgaeCompileTree::Conjunction($TriplesSameSubject, $_Q_O_QGT_DOT_E_S_QConstructTriples_E_Opt_C_E_Opt, $self) : 
	$TriplesSameSubject;
}
	],
	[#Rule 146
		 '_O_QGT_DOT_E_S_QConstructTriples_E_Opt_C', 2,
sub
#line 955 "SparqlParser.yp"
{
    my ($self, $GT_DOT, $_QConstructTriples_E_Opt) = @_;
    return $_QConstructTriples_E_Opt;
}
	],
	[#Rule 147
		 '_Q_O_QGT_DOT_E_S_QConstructTriples_E_Opt_C_E_Opt', 0, undef
	],
	[#Rule 148
		 '_Q_O_QGT_DOT_E_S_QConstructTriples_E_Opt_C_E_Opt', 1, undef
	],
	[#Rule 149
		 'TriplesSameSubject', 2,
sub
#line 966 "SparqlParser.yp"
{
    my ($self, $VarOrTerm, $PropertyListNotEmpty) = @_;
    $self->newDecl([[$VarOrTerm, $PropertyListNotEmpty]]);
}
	],
	[#Rule 150
		 'TriplesSameSubject', 2,
sub
#line 971 "SparqlParser.yp"
{
    my ($self, $TriplesNode, $PropertyList) = @_;

    # Because [ p1 o1; p2 o2 ] breaks the usual pattern, we have to pass it back
    # up as an array of the new node and the exprs that were encompassed inside
    # it. In this case, we want only the exprs.

    return $PropertyList ? 
	new W3C::Rdf::AlgaeCompileTree::Conjunction($TriplesNode->[1], $self->newDecl([[$TriplesNode->[0], $PropertyList]]), $self) : 
	$TriplesNode->[1];
}
	],
	[#Rule 151
		 'PropertyListNotEmpty', 3,
sub
#line 985 "SparqlParser.yp"
{
    my ($self, $Verb, $ObjectList, $_Q_O_QGT_SEMI_E_S_QVerb_E_S_QObjectList_E_Opt_C_E_Star) = @_;
    [[$Verb, $ObjectList], @$_Q_O_QGT_SEMI_E_S_QVerb_E_S_QObjectList_E_Opt_C_E_Star];
}
	],
	[#Rule 152
		 '_O_QVerb_E_S_QObjectList_E_C', 2,
sub
#line 992 "SparqlParser.yp"
{
    my ($self, $Verb, $ObjectList) = @_;
    [[$Verb, $ObjectList]]
}
	],
	[#Rule 153
		 '_Q_O_QVerb_E_S_QObjectList_E_C_E_Opt', 0,
sub
#line 999 "SparqlParser.yp"
{
    my ($self, ) = @_;
    my $ret = [];
    return $ret;
}
	],
	[#Rule 154
		 '_Q_O_QVerb_E_S_QObjectList_E_C_E_Opt', 1, undef
	],
	[#Rule 155
		 '_O_QGT_SEMI_E_S_QVerb_E_S_QObjectList_E_Opt_C', 2,
sub
#line 1008 "SparqlParser.yp"
{
    my ($self, $GT_SEMI, $_Q_O_QVerb_E_S_QObjectList_E_C_E_Opt) = @_;
    $_Q_O_QVerb_E_S_QObjectList_E_C_E_Opt;
}
	],
	[#Rule 156
		 '_Q_O_QGT_SEMI_E_S_QVerb_E_S_QObjectList_E_Opt_C_E_Star', 0,
sub
#line 1015 "SparqlParser.yp"
{
    my ($self, ) = @_;
    [];
}
	],
	[#Rule 157
		 '_Q_O_QGT_SEMI_E_S_QVerb_E_S_QObjectList_E_Opt_C_E_Star', 2,
sub
#line 1020 "SparqlParser.yp"
{
    my ($self, $_Q_O_QGT_SEMI_E_S_QVerb_E_S_QObjectList_E_Opt_C_E_Star, $_O_QGT_SEMI_E_S_QVerb_E_S_QObjectList_E_Opt_C) = @_;
    [@$_Q_O_QGT_SEMI_E_S_QVerb_E_S_QObjectList_E_Opt_C_E_Star, @$_O_QGT_SEMI_E_S_QVerb_E_S_QObjectList_E_Opt_C];
}
	],
	[#Rule 158
		 'PropertyList', 1, undef
	],
	[#Rule 159
		 '_QPropertyListNotEmpty_E_Opt', 0, undef
	],
	[#Rule 160
		 '_QPropertyListNotEmpty_E_Opt', 1, undef
	],
	[#Rule 161
		 'ObjectList', 2,
sub
#line 1034 "SparqlParser.yp"
{
    my ($self, $Object, $_Q_O_QGT_COMMA_E_S_QObject_E_C_E_Star) = @_;
    [$Object, @$_Q_O_QGT_COMMA_E_S_QObject_E_C_E_Star];
}
	],
	[#Rule 162
		 '_O_QGT_COMMA_E_S_QObject_E_C', 2,
sub
#line 1041 "SparqlParser.yp"
{
    my ($self, $GT_COMMA, $Object) = @_;
    return $Object;
}
	],
	[#Rule 163
		 '_Q_O_QGT_COMMA_E_S_QObject_E_C_E_Star', 0,
sub
#line 1048 "SparqlParser.yp"
{
    my ($self, ) = @_;
    [];
}
	],
	[#Rule 164
		 '_Q_O_QGT_COMMA_E_S_QObject_E_C_E_Star', 2,
sub
#line 1053 "SparqlParser.yp"
{
    my ($self, $_Q_O_QGT_COMMA_E_S_QObject_E_C_E_Star, $_O_QGT_COMMA_E_S_QObject_E_C) = @_;
    return [@$_Q_O_QGT_COMMA_E_S_QObject_E_C_E_Star, $_O_QGT_COMMA_E_S_QObject_E_C];
}
	],
	[#Rule 165
		 'Object', 1, undef
	],
	[#Rule 166
		 'Verb', 1, undef
	],
	[#Rule 167
		 'Verb', 1,
sub
#line 1064 "SparqlParser.yp"
{
    my ($self, $a) = @_;
    new W3C::Rdf::AlgaeCompileTree::Url('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', undef, $self);
}
	],
	[#Rule 168
		 'TriplesNode', 1, undef
	],
	[#Rule 169
		 'TriplesNode', 1, undef
	],
	[#Rule 170
		 'BlankNodePropertyList', 3,
sub
#line 1075 "SparqlParser.yp"
{
    my ($self, $GT_LBRACKET, $PropertyListNotEmpty, $GT_RBRACKET) = @_;
    my $node = $self->createBNode(undef);
    [$node, $self->newDecl([[$node, $PropertyListNotEmpty]])];
}
	],
	[#Rule 171
		 '@8-1', 0,
sub
#line 1083 "SparqlParser.yp"
{
    my ($self, $LPAREN) = @_;
    $self->startList();
}
	],
	[#Rule 172
		 'Collection', 4,
sub
#line 1088 "SparqlParser.yp"
{
    my ($self, $LPAREN, $head, undef, $_QGraphNode_E_Plus, $RPAREN) = @_;
    $self->stopList();
}
	],
	[#Rule 173
		 '_QGraphNode_E_Plus', 1,
sub
#line 1095 "SparqlParser.yp"
{
    my ($self, $GraphNode) = @_;
    $self->addListNode($GraphNode);
}
	],
	[#Rule 174
		 '_QGraphNode_E_Plus', 2,
sub
#line 1100 "SparqlParser.yp"
{
    my ($self, $_QGraphNode_E_Plus, $GraphNode) = @_;
    $self->addListNode($GraphNode);
}
	],
	[#Rule 175
		 'GraphNode', 1, undef
	],
	[#Rule 176
		 'GraphNode', 1, undef
	],
	[#Rule 177
		 'VarOrTerm', 1, undef
	],
	[#Rule 178
		 'VarOrTerm', 1, undef
	],
	[#Rule 179
		 'VarOrIRIref', 1, undef
	],
	[#Rule 180
		 'VarOrIRIref', 1, undef
	],
	[#Rule 181
		 'Var', 1, undef
	],
	[#Rule 182
		 'Var', 1, undef
	],
	[#Rule 183
		 'GraphTerm', 1, undef
	],
	[#Rule 184
		 'GraphTerm', 1, undef
	],
	[#Rule 185
		 'GraphTerm', 1,
sub
#line 1125 "SparqlParser.yp"
{
    my ($self, $NumericLiteral) = @_;
    $NumericLiteral->[0]->new($NumericLiteral->[1], $self);
}
	],
	[#Rule 186
		 'GraphTerm', 1, undef
	],
	[#Rule 187
		 'GraphTerm', 1, undef
	],
	[#Rule 188
		 'GraphTerm', 4,
sub
#line 1132 "SparqlParser.yp"
{
    my ($self, $list, $LPAREN, $Var, $RParen) = @_;
    new W3C::Rdf::AlgaeCompileTree::List($Var, $self);
}
	],
	[#Rule 189
		 'GraphTerm', 4,
sub
#line 1137 "SparqlParser.yp"
{
    my ($self, $members, $LPAREN, $Var, $RParen) = @_;
    new W3C::Rdf::AlgaeCompileTree::Members($Var, $self);
}
	],
	[#Rule 190
		 'GraphTerm', 4,
sub
#line 1142 "SparqlParser.yp"
{
    my ($self, $XPATH, $LPAREN, $String, $RParen) = @_;
    new W3C::Rdf::AlgaeCompileTree::XPath($String, $self->YYData->{FLAGS}{-XPathContext}, $self->YYData->{FLAGS}{-XPathList}, $self);
}
	],
	[#Rule 191
		 'GraphTerm', 1,
sub
#line 1147 "SparqlParser.yp"
{ #1
    my ($self, $NIL) = @_;
    new W3C::Rdf::AlgaeCompileTree::Url('http://www.w3.org/1999/02/22-rdf-syntax-ns#nil', undef, $self);
}
	],
	[#Rule 192
		 'Expression', 1, undef
	],
	[#Rule 193
		 'ConditionalOrExpression', 2,
sub
#line 1157 "SparqlParser.yp"
{
    my ($self, $ConditionalAndExpression, $_Q_O_QGT_OR_E_S_QConditionalAndExpression_E_C_E_Star) = @_;
    $_Q_O_QGT_OR_E_S_QConditionalAndExpression_E_C_E_Star ? 
	new W3C::Rdf::AlgaeCompileTree::Or($ConditionalAndExpression, $_Q_O_QGT_OR_E_S_QConditionalAndExpression_E_C_E_Star, $self) : 
	$ConditionalAndExpression;
}
	],
	[#Rule 194
		 '_O_QGT_OR_E_S_QConditionalAndExpression_E_C', 2,
sub
#line 1166 "SparqlParser.yp"
{
    my ($self, $OR, $ConditionalAndExpression) = @_;
    $ConditionalAndExpression;
}
	],
	[#Rule 195
		 '_Q_O_QGT_OR_E_S_QConditionalAndExpression_E_C_E_Star', 0, undef
	],
	[#Rule 196
		 '_Q_O_QGT_OR_E_S_QConditionalAndExpression_E_C_E_Star', 2,
sub
#line 1174 "SparqlParser.yp"
{
    my ($self, $_Q_O_QGT_OR_E_S_QConditionalAndExpression_E_C_E_Star, $_O_QGT_OR_E_S_QConditionalAndExpression_E_C) = @_;
    $_Q_O_QGT_OR_E_S_QConditionalAndExpression_E_C_E_Star ? 
	new W3C::Rdf::AlgaeCompileTree::Or($_Q_O_QGT_OR_E_S_QConditionalAndExpression_E_C_E_Star, $_O_QGT_OR_E_S_QConditionalAndExpression_E_C, $self) : 
	$_O_QGT_OR_E_S_QConditionalAndExpression_E_C;
}
	],
	[#Rule 197
		 'ConditionalAndExpression', 2,
sub
#line 1183 "SparqlParser.yp"
{
    my ($self, $ValueLogical, $_Q_O_QGT_AND_E_S_QValueLogical_E_C_E_Star) = @_;
    $_Q_O_QGT_AND_E_S_QValueLogical_E_C_E_Star ? 
	new W3C::Rdf::AlgaeCompileTree::And($ValueLogical, $_Q_O_QGT_AND_E_S_QValueLogical_E_C_E_Star, $self) : 
	$ValueLogical;
}
	],
	[#Rule 198
		 '_O_QGT_AND_E_S_QValueLogical_E_C', 2,
sub
#line 1192 "SparqlParser.yp"
{
    my ($self, $AND, $ValueLogical) = @_;
    $ValueLogical;
}
	],
	[#Rule 199
		 '_Q_O_QGT_AND_E_S_QValueLogical_E_C_E_Star', 0, undef
	],
	[#Rule 200
		 '_Q_O_QGT_AND_E_S_QValueLogical_E_C_E_Star', 2,
sub
#line 1200 "SparqlParser.yp"
{
    my ($self, $_Q_O_QGT_AND_E_S_QValueLogical_E_C_E_Star, $_O_QGT_AND_E_S_QValueLogical_E_C) = @_;
    $_Q_O_QGT_AND_E_S_QValueLogical_E_C_E_Star ? 
	new W3C::Rdf::AlgaeCompileTree::And($_Q_O_QGT_AND_E_S_QValueLogical_E_C_E_Star, $_O_QGT_AND_E_S_QValueLogical_E_C, $self) : 
	$_O_QGT_AND_E_S_QValueLogical_E_C;
}
	],
	[#Rule 201
		 'ValueLogical', 1, undef
	],
	[#Rule 202
		 'RelationalExpression', 2,
sub
#line 1212 "SparqlParser.yp"
{
    my ($self, $NumericExpression, $_Q_O_QGT_EQUAL_E_S_QNumericExpression_E_Or_QGT_NEQUAL_E_S_QNumericExpression_E_Or_QGT_LT_E_S_QNumericExpression_E_Or_QGT_GT_E_S_QNumericExpression_E_Or_QGT_LE_E_S_QNumericExpression_E_Or_QGT_GE_E_S_QNumericExpression_E_C_E_Opt) = @_; 
    if ($_Q_O_QGT_EQUAL_E_S_QNumericExpression_E_Or_QGT_NEQUAL_E_S_QNumericExpression_E_Or_QGT_LT_E_S_QNumericExpression_E_Or_QGT_GT_E_S_QNumericExpression_E_Or_QGT_LE_E_S_QNumericExpression_E_Or_QGT_GE_E_S_QNumericExpression_E_C_E_Opt) {
	my ($op, $rExpr) = @$_Q_O_QGT_EQUAL_E_S_QNumericExpression_E_Or_QGT_NEQUAL_E_S_QNumericExpression_E_Or_QGT_LT_E_S_QNumericExpression_E_Or_QGT_GT_E_S_QNumericExpression_E_Or_QGT_LE_E_S_QNumericExpression_E_Or_QGT_GE_E_S_QNumericExpression_E_C_E_Opt;
	return $op =~ /^$GT_EQUAL$/ ? new W3C::Rdf::AlgaeCompileTree::Eq($NumericExpression, $rExpr, $self) : 
	    $op =~ /^$GT_NEQUAL$/ ? new W3C::Rdf::AlgaeCompileTree::Ne($NumericExpression, $rExpr, $self) : 
	    $op =~ /^$GT_LT$/ ? new W3C::Rdf::AlgaeCompileTree::Lt($NumericExpression, $rExpr, $self) : 
	    $op =~ /^$GT_GT$/ ? new W3C::Rdf::AlgaeCompileTree::Gt($NumericExpression, $rExpr, $self) : 
	    $op =~ /^$GT_LE$/ ? new W3C::Rdf::AlgaeCompileTree::Le($NumericExpression, $rExpr, $self) : 
	    $op =~ /^$GT_GE$/ ? new W3C::Rdf::AlgaeCompileTree::Ge($NumericExpression, $rExpr, $self) : 
	    &throw(new W3C::Util::ProgramFlowException());
    } else {
	return $NumericExpression;
    }
}
	],
	[#Rule 203
		 '_O_QGT_EQUAL_E_S_QNumericExpression_E_Or_QGT_NEQUAL_E_S_QNumericExpression_E_Or_QGT_LT_E_S_QNumericExpression_E_Or_QGT_GT_E_S_QNumericExpression_E_Or_QGT_LE_E_S_QNumericExpression_E_Or_QGT_GE_E_S_QNumericExpression_E_C', 2,
sub
#line 1230 "SparqlParser.yp"
{
    my ($self, $EQUAL, $NumericExpression) = @_;
    [$EQUAL, $NumericExpression];
}
	],
	[#Rule 204
		 '_O_QGT_EQUAL_E_S_QNumericExpression_E_Or_QGT_NEQUAL_E_S_QNumericExpression_E_Or_QGT_LT_E_S_QNumericExpression_E_Or_QGT_GT_E_S_QNumericExpression_E_Or_QGT_LE_E_S_QNumericExpression_E_Or_QGT_GE_E_S_QNumericExpression_E_C', 2,
sub
#line 1235 "SparqlParser.yp"
{
    my ($self, $NEQUAL, $NumericExpression) = @_;
    [$NEQUAL, $NumericExpression];
}
	],
	[#Rule 205
		 '_O_QGT_EQUAL_E_S_QNumericExpression_E_Or_QGT_NEQUAL_E_S_QNumericExpression_E_Or_QGT_LT_E_S_QNumericExpression_E_Or_QGT_GT_E_S_QNumericExpression_E_Or_QGT_LE_E_S_QNumericExpression_E_Or_QGT_GE_E_S_QNumericExpression_E_C', 2,
sub
#line 1240 "SparqlParser.yp"
{
    my ($self, $LT, $NumericExpression) = @_;
    [$LT, $NumericExpression];
}
	],
	[#Rule 206
		 '_O_QGT_EQUAL_E_S_QNumericExpression_E_Or_QGT_NEQUAL_E_S_QNumericExpression_E_Or_QGT_LT_E_S_QNumericExpression_E_Or_QGT_GT_E_S_QNumericExpression_E_Or_QGT_LE_E_S_QNumericExpression_E_Or_QGT_GE_E_S_QNumericExpression_E_C', 2,
sub
#line 1245 "SparqlParser.yp"
{
    my ($self, $GT, $NumericExpression) = @_;
    [$GT, $NumericExpression];
}
	],
	[#Rule 207
		 '_O_QGT_EQUAL_E_S_QNumericExpression_E_Or_QGT_NEQUAL_E_S_QNumericExpression_E_Or_QGT_LT_E_S_QNumericExpression_E_Or_QGT_GT_E_S_QNumericExpression_E_Or_QGT_LE_E_S_QNumericExpression_E_Or_QGT_GE_E_S_QNumericExpression_E_C', 2,
sub
#line 1250 "SparqlParser.yp"
{
    my ($self, $LE, $NumericExpression) = @_;
    [$LE, $NumericExpression];
}
	],
	[#Rule 208
		 '_O_QGT_EQUAL_E_S_QNumericExpression_E_Or_QGT_NEQUAL_E_S_QNumericExpression_E_Or_QGT_LT_E_S_QNumericExpression_E_Or_QGT_GT_E_S_QNumericExpression_E_Or_QGT_LE_E_S_QNumericExpression_E_Or_QGT_GE_E_S_QNumericExpression_E_C', 2,
sub
#line 1255 "SparqlParser.yp"
{
    my ($self, $GE, $NumericExpression) = @_;
    [$GE, $NumericExpression];
}
	],
	[#Rule 209
		 '_Q_O_QGT_EQUAL_E_S_QNumericExpression_E_Or_QGT_NEQUAL_E_S_QNumericExpression_E_Or_QGT_LT_E_S_QNumericExpression_E_Or_QGT_GT_E_S_QNumericExpression_E_Or_QGT_LE_E_S_QNumericExpression_E_Or_QGT_GE_E_S_QNumericExpression_E_C_E_Opt', 0, undef
	],
	[#Rule 210
		 '_Q_O_QGT_EQUAL_E_S_QNumericExpression_E_Or_QGT_NEQUAL_E_S_QNumericExpression_E_Or_QGT_LT_E_S_QNumericExpression_E_Or_QGT_GT_E_S_QNumericExpression_E_Or_QGT_LE_E_S_QNumericExpression_E_Or_QGT_GE_E_S_QNumericExpression_E_C_E_Opt', 1, undef
	],
	[#Rule 211
		 'NumericExpression', 1, undef
	],
	[#Rule 212
		 'AdditiveExpression', 2,
sub
#line 1269 "SparqlParser.yp"
{
    my ($self, $MultiplicativeExpression, $_Q_O_QGT_PLUS_E_S_QMultiplicativeExpression_E_Or_QGT_MINUS_E_S_QMultiplicativeExpression_E_Or_QNumericLiteralPositive_E_Or_QNumericLiteralNegative_E_C_E_Star) = @_;
    if ($_Q_O_QGT_PLUS_E_S_QMultiplicativeExpression_E_Or_QGT_MINUS_E_S_QMultiplicativeExpression_E_Or_QNumericLiteralPositive_E_Or_QNumericLiteralNegative_E_C_E_Star) {
	my ($op, $rExpr) = @$_Q_O_QGT_PLUS_E_S_QMultiplicativeExpression_E_Or_QGT_MINUS_E_S_QMultiplicativeExpression_E_Or_QNumericLiteralPositive_E_Or_QNumericLiteralNegative_E_C_E_Star;
	return $op =~ /^$GT_PLUS$/ ? new W3C::Rdf::AlgaeCompileTree::Plus($MultiplicativeExpression, $rExpr, $self) : 
	    $op =~ /^$GT_MINUS$/ ? new W3C::Rdf::AlgaeCompileTree::Minus($MultiplicativeExpression, $rExpr, $self) : 
	    &throw(new W3C::Util::ProgramFlowException());
    } else {
	return $MultiplicativeExpression;
    }
}
	],
	[#Rule 213
		 '_O_QGT_PLUS_E_S_QMultiplicativeExpression_E_Or_QGT_MINUS_E_S_QMultiplicativeExpression_E_Or_QNumericLiteralPositive_E_Or_QNumericLiteralNegative_E_C', 2,
sub
#line 1283 "SparqlParser.yp"
{
    my ($self, $PLUS, $MultiplicativeExpression) = @_;
    [$PLUS, $MultiplicativeExpression];
}
	],
	[#Rule 214
		 '_O_QGT_PLUS_E_S_QMultiplicativeExpression_E_Or_QGT_MINUS_E_S_QMultiplicativeExpression_E_Or_QNumericLiteralPositive_E_Or_QNumericLiteralNegative_E_C', 2,
sub
#line 1288 "SparqlParser.yp"
{
    my ($self, $MINUS, $MultiplicativeExpression) = @_;
    [$MINUS, $MultiplicativeExpression];
}
	],
	[#Rule 215
		 '_O_QGT_PLUS_E_S_QMultiplicativeExpression_E_Or_QGT_MINUS_E_S_QMultiplicativeExpression_E_Or_QNumericLiteralPositive_E_Or_QNumericLiteralNegative_E_C', 1,
sub
#line 1293 "SparqlParser.yp"
{
    my ($self, $NumericLiteralPositive) = @_;
    ['+', $NumericLiteralPositive];
}
	],
	[#Rule 216
		 '_O_QGT_PLUS_E_S_QMultiplicativeExpression_E_Or_QGT_MINUS_E_S_QMultiplicativeExpression_E_Or_QNumericLiteralPositive_E_Or_QNumericLiteralNegative_E_C', 1,
sub
#line 1298 "SparqlParser.yp"
{
    my ($self, $NumericLiteralNegative) = @_;
    ['-', $NumericLiteralNegative];
}
	],
	[#Rule 217
		 '_Q_O_QGT_PLUS_E_S_QMultiplicativeExpression_E_Or_QGT_MINUS_E_S_QMultiplicativeExpression_E_Or_QNumericLiteralPositive_E_Or_QNumericLiteralNegative_E_C_E_Star', 0, undef
	],
	[#Rule 218
		 '_Q_O_QGT_PLUS_E_S_QMultiplicativeExpression_E_Or_QGT_MINUS_E_S_QMultiplicativeExpression_E_Or_QNumericLiteralPositive_E_Or_QNumericLiteralNegative_E_C_E_Star', 2,
sub
#line 1306 "SparqlParser.yp"
{
    my ($self, $_Q_O_QGT_PLUS_E_S_QMultiplicativeExpression_E_Or_QGT_MINUS_E_S_QMultiplicativeExpression_E_Or_QNumericLiteralPositive_E_Or_QNumericLiteralNegative_E_C_E_Star, $_O_QGT_PLUS_E_S_QMultiplicativeExpression_E_Or_QGT_MINUS_E_S_QMultiplicativeExpression_E_Or_QNumericLiteralPositive_E_Or_QNumericLiteralNegative_E_C) = @_;
    if ($_Q_O_QGT_PLUS_E_S_QMultiplicativeExpression_E_Or_QGT_MINUS_E_S_QMultiplicativeExpression_E_Or_QNumericLiteralPositive_E_Or_QNumericLiteralNegative_E_C_E_Star) {
	my ($pOp, $lExpr) = @$_Q_O_QGT_PLUS_E_S_QMultiplicativeExpression_E_Or_QGT_MINUS_E_S_QMultiplicativeExpression_E_Or_QNumericLiteralPositive_E_Or_QNumericLiteralNegative_E_C_E_Star;
	my ($op, $rExpr)  = @$_O_QGT_PLUS_E_S_QMultiplicativeExpression_E_Or_QGT_MINUS_E_S_QMultiplicativeExpression_E_Or_QNumericLiteralPositive_E_Or_QNumericLiteralNegative_E_C;
	return [$pOp, $op =~ /^$GT_PLUS$/ ? new W3C::Rdf::AlgaeCompileTree::Plus($lExpr, $rExpr, $self) : 
		$op =~ /^$GT_MINUS$/ ? new W3C::Rdf::AlgaeCompileTree::Minus($lExpr, $rExpr, $self) : 
		&throw(new W3C::Util::ProgramFlowException())];
    } else {
	return $_O_QGT_PLUS_E_S_QMultiplicativeExpression_E_Or_QGT_MINUS_E_S_QMultiplicativeExpression_E_Or_QNumericLiteralPositive_E_Or_QNumericLiteralNegative_E_C;
    }
}
	],
	[#Rule 219
		 'MultiplicativeExpression', 2,
sub
#line 1321 "SparqlParser.yp"
{
    my ($self, $UnaryExpression, $_Q_O_QGT_TIMES_E_S_QUnaryExpression_E_Or_QGT_DIVIDE_E_S_QUnaryExpression_E_C_E_Star) = @_;
    if ($_Q_O_QGT_TIMES_E_S_QUnaryExpression_E_Or_QGT_DIVIDE_E_S_QUnaryExpression_E_C_E_Star) {
	my ($op, $rExpr) = @$_Q_O_QGT_TIMES_E_S_QUnaryExpression_E_Or_QGT_DIVIDE_E_S_QUnaryExpression_E_C_E_Star;
	return $op =~ /^$GT_TIMES$/ ? new W3C::Rdf::AlgaeCompileTree::Multiply($UnaryExpression, $rExpr, $self) : 
	    $op =~ /^$GT_DIVIDE$/ ? new W3C::Rdf::AlgaeCompileTree::Divide($UnaryExpression, $rExpr, $self) : 
	    &throw(new W3C::Util::ProgramFlowException());
    } else {
	return $UnaryExpression;
    }
}
	],
	[#Rule 220
		 '_O_QGT_TIMES_E_S_QUnaryExpression_E_Or_QGT_DIVIDE_E_S_QUnaryExpression_E_C', 2,
sub
#line 1335 "SparqlParser.yp"
{
    my ($self, $TIMES, $UnaryExpression) = @_;
    [$TIMES, $UnaryExpression];
}
	],
	[#Rule 221
		 '_O_QGT_TIMES_E_S_QUnaryExpression_E_Or_QGT_DIVIDE_E_S_QUnaryExpression_E_C', 2,
sub
#line 1340 "SparqlParser.yp"
{
    my ($self, $DIVIDE, $UnaryExpression) = @_;
    [$DIVIDE, $UnaryExpression];
}
	],
	[#Rule 222
		 '_Q_O_QGT_TIMES_E_S_QUnaryExpression_E_Or_QGT_DIVIDE_E_S_QUnaryExpression_E_C_E_Star', 0, undef
	],
	[#Rule 223
		 '_Q_O_QGT_TIMES_E_S_QUnaryExpression_E_Or_QGT_DIVIDE_E_S_QUnaryExpression_E_C_E_Star', 2,
sub
#line 1348 "SparqlParser.yp"
{
    my ($self, $_Q_O_QGT_TIMES_E_S_QUnaryExpression_E_Or_QGT_DIVIDE_E_S_QUnaryExpression_E_C_E_Star, $_O_QGT_TIMES_E_S_QUnaryExpression_E_Or_QGT_DIVIDE_E_S_QUnaryExpression_E_C) = @_;
    if ($_Q_O_QGT_TIMES_E_S_QUnaryExpression_E_Or_QGT_DIVIDE_E_S_QUnaryExpression_E_C_E_Star) {
	my ($pOp, $lExpr) = @$_Q_O_QGT_TIMES_E_S_QUnaryExpression_E_Or_QGT_DIVIDE_E_S_QUnaryExpression_E_C_E_Star;
	my ($op, $rExpr) = @$_O_QGT_TIMES_E_S_QUnaryExpression_E_Or_QGT_DIVIDE_E_S_QUnaryExpression_E_C;
	return [$pOp, $op =~ /^asdf$GT_TIMES$/ ? new W3C::Rdf::AlgaeCompileTree::Multiply($lExpr, $rExpr, $self) : 
		$op =~ /^$GT_DIVIDE$/ ? new W3C::Rdf::AlgaeCompileTree::Divide($rExpr, $rExpr, $self) : 
		&throw(new W3C::Util::ProgramFlowException())];
    } else {
	return $_O_QGT_TIMES_E_S_QUnaryExpression_E_Or_QGT_DIVIDE_E_S_QUnaryExpression_E_C;
    }
}
	],
	[#Rule 224
		 'UnaryExpression', 2,
sub
#line 1363 "SparqlParser.yp"
{
    my ($self, $NOT, $PrimaryExpression) = @_;
    new W3C::Rdf::AlgaeCompileTree::Not($PrimaryExpression, $self);
}
	],
	[#Rule 225
		 'UnaryExpression', 2,
sub
#line 1368 "SparqlParser.yp"
{
    my ($self, $PLUS, $PrimaryExpression) = @_;
    $PrimaryExpression;
}
	],
	[#Rule 226
		 'UnaryExpression', 2,
sub
#line 1373 "SparqlParser.yp"
{
    my ($self, $MINUS, $PrimaryExpression) = @_;
    new W3C::Rdf::AlgaeCompileTree::Neg($PrimaryExpression, $self);
}
	],
	[#Rule 227
		 'UnaryExpression', 1, undef
	],
	[#Rule 228
		 'PrimaryExpression', 1, undef
	],
	[#Rule 229
		 'PrimaryExpression', 1, undef
	],
	[#Rule 230
		 'PrimaryExpression', 1, undef
	],
	[#Rule 231
		 'PrimaryExpression', 1, undef
	],
	[#Rule 232
		 'PrimaryExpression', 1,
sub
#line 1385 "SparqlParser.yp"
{
    my ($self, $NumericLiteral) = @_;
    $NumericLiteral->[0]->new($NumericLiteral->[1], $self);
}
	],
	[#Rule 233
		 'PrimaryExpression', 1, undef
	],
	[#Rule 234
		 'PrimaryExpression', 4,
sub
#line 1391 "SparqlParser.yp"
{
    my ($self, $list, $LPAREN, $Var, $RParen) = @_;
    new W3C::Rdf::AlgaeCompileTree::List($Var, $self);
}
	],
	[#Rule 235
		 'PrimaryExpression', 4,
sub
#line 1396 "SparqlParser.yp"
{
    my ($self, $members, $LPAREN, $Var, $RParen) = @_;
    new W3C::Rdf::AlgaeCompileTree::Members($Var, $self);
}
	],
	[#Rule 236
		 'PrimaryExpression', 1, undef
	],
	[#Rule 237
		 'BrackettedExpression', 3,
sub
#line 1404 "SparqlParser.yp"
{
    my ($self, $LPAREN, $Expression, $RPAREN) = @_;
    $Expression;
}
	],
	[#Rule 238
		 'BuiltInCall', 4,
sub
#line 1411 "SparqlParser.yp"
{
    my ($self, $STR, $LPAREN, $Expression, $RPAREN) = @_;
    new W3C::Rdf::AlgaeCompileTree::Operator($STR, [$Expression], $self);
}
	],
	[#Rule 239
		 'BuiltInCall', 4,
sub
#line 1416 "SparqlParser.yp"
{
    my ($self, $LANG, $LPAREN, $Expression, $RPAREN) = @_;
    new W3C::Rdf::AlgaeCompileTree::Operator($LANG, [$Expression], $self);
}
	],
	[#Rule 240
		 'BuiltInCall', 6,
sub
#line 1421 "SparqlParser.yp"
{
    my ($self, $LANGMATCHES, $LPAREN, $Expression, $COMMA, $Expression_, $RPAREN) = @_;
    new W3C::Rdf::AlgaeCompileTree::Operator($LANGMATCHES, [$Expression, $Expression_], $self);
}
	],
	[#Rule 241
		 'BuiltInCall', 4,
sub
#line 1426 "SparqlParser.yp"
{
    my ($self, $DATATYPE, $LPAREN, $Expression, $RPAREN) = @_;
    new W3C::Rdf::AlgaeCompileTree::Operator($DATATYPE, [$Expression], $self);
}
	],
	[#Rule 242
		 'BuiltInCall', 4,
sub
#line 1431 "SparqlParser.yp"
{
    my ($self, $BOUND, $LPAREN, $Var, $RPAREN) = @_;
    new W3C::Rdf::AlgaeCompileTree::Operator($BOUND, [$Var], $self);
}
	],
	[#Rule 243
		 'BuiltInCall', 6,
sub
#line 1436 "SparqlParser.yp"
{
    my ($self, $sameTerm, $LPAREN, $Expression, $COMMA, $Expression_, $RPAREN) = @_;
    new W3C::Rdf::AlgaeCompileTree::Operator($sameTerm, [$Expression, $Expression_], $self);
}
	],
	[#Rule 244
		 'BuiltInCall', 4,
sub
#line 1441 "SparqlParser.yp"
{
    my ($self, $isIRI, $LPAREN, $Expression, $RPAREN) = @_;
    new W3C::Rdf::AlgaeCompileTree::Operator($isIRI, [$Expression], $self);
}
	],
	[#Rule 245
		 'BuiltInCall', 4,
sub
#line 1446 "SparqlParser.yp"
{
    my ($self, $isURI, $LPAREN, $Expression, $RPAREN) = @_;
    new W3C::Rdf::AlgaeCompileTree::Operator($isURI, [$Expression], $self);
}
	],
	[#Rule 246
		 'BuiltInCall', 4,
sub
#line 1451 "SparqlParser.yp"
{
    my ($self, $isBLANK, $LPAREN, $Expression, $RPAREN) = @_;
    new W3C::Rdf::AlgaeCompileTree::Operator($isBLANK, [$Expression], $self);
}
	],
	[#Rule 247
		 'BuiltInCall', 4,
sub
#line 1456 "SparqlParser.yp"
{
    my ($self, $isLITERAL, $LPAREN, $Expression, $RPAREN) = @_;
    new W3C::Rdf::AlgaeCompileTree::Operator($isLITERAL, [$Expression], $self);
}
	],
	[#Rule 248
		 'BuiltInCall', 1, undef
	],
	[#Rule 249
		 'RegexExpression', 7,
sub
#line 1464 "SparqlParser.yp"
{
    my ($self, $REGEX, $LPAREN, $Expression, $COMMA, $Expression_, $_Q_O_QGT_COMMA_E_S_QExpression_E_C_E_Opt, $RPAREN) = @_;
    new W3C::Rdf::AlgaeCompileTree::Operator($REGEX, [$Expression, $Expression_, @$_Q_O_QGT_COMMA_E_S_QExpression_E_C_E_Opt], $self);
}
	],
	[#Rule 250
		 '_Q_O_QGT_COMMA_E_S_QExpression_E_C_E_Opt', 0,
sub
#line 1471 "SparqlParser.yp"
{
    my ($self, ) = @_;
    [];
}
	],
	[#Rule 251
		 '_Q_O_QGT_COMMA_E_S_QExpression_E_C_E_Opt', 1, undef
	],
	[#Rule 252
		 'IRIrefOrFunction', 2,
sub
#line 1479 "SparqlParser.yp"
{
    my ($self, $IRIref, $_QArgList_E_Opt) = @_;
    $_QArgList_E_Opt ? new W3C::Rdf::AlgaeCompileTree::FuncCall($IRIref, $_QArgList_E_Opt, $self) : $IRIref;
}
	],
	[#Rule 253
		 '_QArgList_E_Opt', 0, undef
	],
	[#Rule 254
		 '_QArgList_E_Opt', 1, undef
	],
	[#Rule 255
		 'RDFLiteral', 2,
sub
#line 1490 "SparqlParser.yp"
{
    my ($self, $String, $_Q_O_QLANGTAG_E_Or_QGT_DTYPE_E_S_QIRIref_E_C_E_Opt) = @_;
    new W3C::Rdf::AlgaeCompileTree::Literal($String, @$_Q_O_QLANGTAG_E_Or_QGT_DTYPE_E_S_QIRIref_E_C_E_Opt, $self);
}
	],
	[#Rule 256
		 '_O_QGT_DTYPE_E_S_QIRIref_E_C', 2,
sub
#line 1497 "SparqlParser.yp"
{
    my ($self, $DTYPE, $IRIref) = @_;
    $IRIref;
}
	],
	[#Rule 257
		 '_O_QLANGTAG_E_Or_QGT_DTYPE_E_S_QIRIref_E_C', 1,
sub
#line 1504 "SparqlParser.yp"
{
    my ($self, $LANGTAG) = @_;
    [undef, $LANGTAG];
}
	],
	[#Rule 258
		 '_O_QLANGTAG_E_Or_QGT_DTYPE_E_S_QIRIref_E_C', 1,
sub
#line 1509 "SparqlParser.yp"
{
    my ($self, $_O_QGT_DTYPE_E_S_QIRIref_E_C) = @_;
    [$_O_QGT_DTYPE_E_S_QIRIref_E_C, undef];
}
	],
	[#Rule 259
		 '_Q_O_QLANGTAG_E_Or_QGT_DTYPE_E_S_QIRIref_E_C_E_Opt', 0,
sub
#line 1516 "SparqlParser.yp"
{
    my ($self, ) = @_;
    [undef, undef];
}
	],
	[#Rule 260
		 '_Q_O_QLANGTAG_E_Or_QGT_DTYPE_E_S_QIRIref_E_C_E_Opt', 1, undef
	],
	[#Rule 261
		 'NumericLiteral', 1, undef
	],
	[#Rule 262
		 'NumericLiteral', 1, undef
	],
	[#Rule 263
		 'NumericLiteral', 1, undef
	],
	[#Rule 264
		 'NumericLiteralUnsigned', 1,
sub
#line 1529 "SparqlParser.yp"
{
    my ($self, $INTEGER) = @_;
    ['W3C::Rdf::AlgaeCompileTree::Int', $INTEGER];
}
	],
	[#Rule 265
		 'NumericLiteralUnsigned', 1,
sub
#line 1534 "SparqlParser.yp"
{
    my ($self, $DECIMAL) = @_;
    ['W3C::Rdf::AlgaeCompileTree::Decimal', $DECIMAL];
}
	],
	[#Rule 266
		 'NumericLiteralUnsigned', 1,
sub
#line 1539 "SparqlParser.yp"
{
    my ($self, $DOUBLE) = @_;
    ['W3C::Rdf::AlgaeCompileTree::Double', $DOUBLE];
}
	],
	[#Rule 267
		 'NumericLiteralPositive', 1,
sub
#line 1546 "SparqlParser.yp"
{
    my ($self, $INTEGER_POSITIVE) = @_;
    ['W3C::Rdf::AlgaeCompileTree::Int', $INTEGER_POSITIVE];
}
	],
	[#Rule 268
		 'NumericLiteralPositive', 1,
sub
#line 1551 "SparqlParser.yp"
{
    my ($self, $DECIMAL_POSITIVE) = @_;
    ['W3C::Rdf::AlgaeCompileTree::Decimal', $DECIMAL_POSITIVE];
}
	],
	[#Rule 269
		 'NumericLiteralPositive', 1,
sub
#line 1556 "SparqlParser.yp"
{
    my ($self, $DOUBLE_POSITIVE) = @_;
    ['W3C::Rdf::AlgaeCompileTree::Double', $DOUBLE_POSITIVE];
}
	],
	[#Rule 270
		 'NumericLiteralNegative', 1,
sub
#line 1563 "SparqlParser.yp"
{
    my ($self, $INTEGER_NEGATIVE) = @_;
    ['W3C::Rdf::AlgaeCompileTree::Int', $INTEGER_NEGATIVE];
}
	],
	[#Rule 271
		 'NumericLiteralNegative', 1,
sub
#line 1568 "SparqlParser.yp"
{
    my ($self, $DECIMAL_NEGATIVE) = @_;
    ['W3C::Rdf::AlgaeCompileTree::Decimal', $DECIMAL_NEGATIVE];
}
	],
	[#Rule 272
		 'NumericLiteralNegative', 1,
sub
#line 1573 "SparqlParser.yp"
{
    my ($self, $DOUBLE_NEGATIVE) = @_;
    ['W3C::Rdf::AlgaeCompileTree::Double', $DOUBLE_NEGATIVE];
}
	],
	[#Rule 273
		 'BooleanLiteral', 1,
sub
#line 1580 "SparqlParser.yp"
{
    my ($self, $true) = @_;
    new W3C::Rdf::AlgaeCompileTree::Boolean('true', $self);
}
	],
	[#Rule 274
		 'BooleanLiteral', 1,
sub
#line 1585 "SparqlParser.yp"
{
    my ($self, $false) = @_;
    new W3C::Rdf::AlgaeCompileTree::Boolean('false', $self);
}
	],
	[#Rule 275
		 'String', 1,
sub
#line 1592 "SparqlParser.yp"
{
    my ($self, $STRING_LITERAL1) = @_;
    &_literalToken($STRING_LITERAL1, 1);
}
	],
	[#Rule 276
		 'String', 1,
sub
#line 1597 "SparqlParser.yp"
{
    my ($self, $STRING_LITERAL2) = @_;
    &_literalToken($STRING_LITERAL2, 1);
}
	],
	[#Rule 277
		 'String', 1,
sub
#line 1602 "SparqlParser.yp"
{
    my ($self, $STRING_LITERAL_LONG1) = @_;
    &_literalToken($STRING_LITERAL_LONG1, 3);
}
	],
	[#Rule 278
		 'String', 1,
sub
#line 1607 "SparqlParser.yp"
{
    my ($self, $STRING_LITERAL_LONG2) = @_;
    &_literalToken($STRING_LITERAL_LONG2, 3);
}
	],
	[#Rule 279
		 'IRIref', 1, undef
	],
	[#Rule 280
		 'IRIref', 1, undef
	],
	[#Rule 281
		 'PrefixedName', 1, undef
	],
	[#Rule 282
		 'PrefixedName', 1,
sub
#line 1619 "SparqlParser.yp"
{
    my ($self, $PNAME_NS) = @_;
    my ($prefix, $localName) = split(':', $PNAME_NS, 2);
    new W3C::Rdf::AlgaeCompileTree::QName($prefix, $localName, $self);
}
	],
	[#Rule 283
		 'BlankNode', 1, undef
	],
	[#Rule 284
		 'BlankNode', 1,
sub
#line 1628 "SparqlParser.yp"
{ #1
    my ($self, $ANON) = @_;
    $self->createBNode(undef);
}
	],
	[#Rule 285
		 'IRI_REF', 1,
sub
#line 1635 "SparqlParser.yp"
{
    my ($self, $IRI_REFT) = @_;
    new W3C::Rdf::AlgaeCompileTree::Url(substr($IRI_REFT, 1, length($IRI_REFT)-2), $self->YYData->{BASE}, $self)
}
	],
	[#Rule 286
		 'PNAME_NS', 1,
sub
#line 1642 "SparqlParser.yp"
{
    my ($self, $PNAME_NST) = @_;
    substr($PNAME_NST, 0, length($PNAME_NST)-1);
}
	],
	[#Rule 287
		 'PNAME_LN', 1,
sub
#line 1649 "SparqlParser.yp"
{
    my ($self, $PNAME_LNT) = @_;
    my ($prefix, $localName) = split(':', $PNAME_LNT, 2);
    new W3C::Rdf::AlgaeCompileTree::QName($prefix, $localName, $self);
}
	],
	[#Rule 288
		 'BLANK_NODE_LABEL', 1,
sub
#line 1657 "SparqlParser.yp"
{
    my ($self, $BLANK_NODE_LABELT) = @_;
    my $curPatternId = $self->YYData->{patternIdStack}[-1];
    if ($self->YYData->{inFilter}) {
	&throw(new W3C::Util::ProgramFlowException());
    }
    if (my $patternId = $self->YYData->{patternIdByNamedBNode}{$BLANK_NODE_LABELT}) {
	#print "|$curPatternId| $BLANK_NODE_LABELT => $patternId\n";
	if ($patternId != $curPatternId) {
	    &throw(new W3C::Util::ProgramFlowException());
	}
    } else {
	#print "|$curPatternId| $BLANK_NODE_LABELT <= $curPatternId\n";
	$self->YYData->{patternIdByNamedBNode}{$BLANK_NODE_LABELT} = $curPatternId;
    }
    my $node = $self->YYData->{BNODES_BY_NAME}{$BLANK_NODE_LABELT};
    if (!$node) {
	$node = $self->YYData->{BNODES_BY_NAME}{$BLANK_NODE_LABELT} = $self->createBNode($BLANK_NODE_LABELT);
    }
    $node;
}
	],
	[#Rule 289
		 'VAR1', 1,
sub
#line 1681 "SparqlParser.yp"
{
    my ($self, $VAR1T) = @_;
    new W3C::Rdf::AlgaeCompileTree::Var(substr($VAR1T, 1), 1, $self);
}
	],
	[#Rule 290
		 'VAR2', 1,
sub
#line 1688 "SparqlParser.yp"
{
    my ($self, $VAR2T) = @_;
    new W3C::Rdf::AlgaeCompileTree::Var(substr($VAR2T, 1), 1, $self);
}
	],
	[#Rule 291
		 'LANGTAG', 1,
sub
#line 1695 "SparqlParser.yp"
{
    my ($self, $LANGTAGT) = @_;
    new W3C::Rdf::AlgaeCompileTree::Literal(substr($LANGTAGT, 1), undef, undef, $self);
}
	]
],
                                  @_);
    bless($self,$class);
}

#line 1752 "SparqlParser.yp"


my $LanguageName = 'SparqlParser';
# -*- Mode: cperl; coding: utf-8; cperl-indent-level: 4 -*-
# START LexerBlock
#
# YappTemplate: used by yacker to create yapp input files.
#
# Use: yacker -l perl -s -n <name> <name>.txt
#
# to generate a yapp input module called Sparql.yp.


# $Id: SparqlParser.pm,v 1.44 2007/08/14 22:27:23 eric Exp $

sub _Error {
    my ($self, $getMessage) = @_;
        exists $self->YYData->{ERRMSG}
    and do {
        print $self->YYData->{ERRMSG};
        delete $self->YYData->{ERRMSG};
        return;
    };

    # Undo numeric encoding changes to the input string.
    foreach my $adj (@{$self->{ADJUSTMENTS}}) {
	my ($offset, $from, $to) = @$adj;
	$self->YYData->{INPUT} = substr($self->YYData->{INPUT}, 0, $offset) . $from . substr($self->YYData->{INPUT}, $offset + 1);
	if (pos $self->YYData->{INPUT} > $offset) {
	    pos $self->YYData->{INPUT} += length($from) - 1;
	}
	if ($self->YYData->{my_LASTPOS} > $offset) {
	    $self->YYData->{my_LASTPOS} += length($from) - 1;
	}
    }

    my $pos = pos $self->YYData->{INPUT};
    my $lastPos = $self->YYData->{my_LASTPOS};
    my $excerpt = substr($self->YYData->{INPUT}, $lastPos, $pos - $lastPos);
    my $expect = @{$self->{STACK}} ? join (' | ', sort {(!(lc $a cmp lc $b)) ? $b cmp $a : lc $a cmp lc $b} map {&_terminalString($_)} $self->YYExpect()) : 'INVALID INITIALIZER';
    if (ref $expect) {
	# Flag unexpected (by the author at this point) refs with '?ref'.
	if (ref $expect eq 'HASH') {
	    if (exists $expect->{NEXT}) {
		$expect = $ {$expect->{NEXT}};
	    } else {
		$expect = "?ref {%$expect}";
	    }
	} elsif (ref $expect eq 'ARRAY') {
	    $expect = "?ref [@$expect]";
	} elsif (ref $expect eq 'SCALAR') {
	    $expect = "?ref $$expect";
	} elsif (ref $expect eq 'GLOB') {
	    $expect = "?ref \**$expect";
	} else {
	    $expect = "?ref ??? $expect";
	}
    }
    my $token = &_terminalString($self->YYData->{my_LASTTOKEN});
    my $value = $self->YYData->{my_LASTVALUE};
    my $message = "expected \"$expect\", got ($token, $value) from \"$excerpt\" at offset $lastPos.\n";
    if ($getMessage) {
	return $message;
    } else {
	die $message;
    }
}

sub _terminalString { # static
    my ($token) = @_;
    if ($token =~ m{^I_T_(.+)$}) {
	$token = "'$1'";
    } elsif ($token =~ m{^T_(.+)$}) {
	if (my $base = $ARGV[0]) {
	    $token = "&lt;<a href=\"${base}$token\">$1</a>&gt;";
	} else {
	    $token = "<$1>";
	}
    }
    return $token;
}

my $AtStart;

sub _Lexer {
    my($self)=shift;

    my ($token, $value) = ('', undef);

  top:
    if (defined $self->YYData->{INPUT} && 
	pos $self->YYData->{INPUT} < length ($self->YYData->{INPUT})) {
	# still some chars left.
    } else {
	return ('', undef);
    }

    my $startPos = pos $self->YYData->{INPUT};
    $self->YYData->{my_LASTPOS} = $startPos;
    my ($mText, $mLen, $mI, $mLookAhead) = ('', 0, undef, undef);
    for (my $i = 0; $i < @$Tokens; $i++) {
	my $rule = $Tokens->[$i];
	my ($start, $regexp, $action) = @$rule;
	if ($start && !$AtStart) {
	    next;
	}
	eval {
	    if ($self->YYData->{INPUT} =~ m/\G($regexp)/gc) {
		my $lookAhead = length $2;
		my $len = (pos $self->YYData->{INPUT}) - $startPos + $lookAhead;
		if ($len > $mLen) {
		    $mText = substr($self->YYData->{INPUT}, $startPos, $len - $lookAhead);
		    $mLen = $len;
		    $mI = $i;
		    $mLookAhead = $lookAhead
		}
		pos $self->YYData->{INPUT} = $startPos;
	    }
	}; if ($@) {
	    die "error processing $action: $@";
	}
    }
    if ($mLen) {
	my ($start, $regexp, $action) = @{$Tokens->[$mI]};
	pos $self->YYData->{INPUT} += $mLen - $mLookAhead;
	$AtStart = $mText =~ m/\z/gc;
	($token, $value) = ($action, $mText);
    } else {
	my $excerpt = substr($self->YYData->{INPUT}, pos $self->YYData->{INPUT}, 40);
	&utf8::encode($excerpt);
	die "lexer couldn't parse at \"$excerpt\"\n";
    }
    if (!defined $token) {
	# We just parsed whitespace or comment.
	goto top;
    }
#    my $pos = pos $self->YYData->{INPUT};
#    print "\n$pos,$token,$value\n";
    $self->YYData->{my_LASTTOKEN} = $token;
    $self->YYData->{my_LASTVALUE} = $value;
    return ($token, $value);
}

sub addNamespace {
    my ($self, $prefix, $namespace) = @_;
    $self->YYData->{-namespaceHandler}->addNamespace($prefix, $namespace->getUrl());
}

sub mapNamespace {
    my ($self, $qnameStr) = @_;
    return $self->YYData->{-namespaceHandler}->mapNamespace($qnameStr);
}

sub parse {
    my ($self, @args) = @_;
    $self->YYData->{NEXT} = undef;
    $self->YYData->{CreateNovelBNodes} = 0; # overridden for $ConstructTemplate
    $self->YYData->{AnonymousBNodes} = 0;
    return $self->SUPER::parse(@args);
}

# Provide (one) chunk of text to parse.
sub nextChunk {
    my ($self) = @_;
    #return shift (@{$self->YYData->{my_CHUNKS}});
    #return shift (@ARGV);
    return <STDIN>;
}

# Handy debugging wrapper for calling semantics actions.
sub _wrap {
    my ($self, $obj, $method, @args) = @_;
    my @ret;
    eval {
	@ret = $obj->$method(@args);
    }; if ($@) {if (my $ex = &catch('W3C::Util::CachedContextException')) {
	&throw($ex);;
    } elsif ($ex = &catch('W3C::Util::Exception')) {
	my $newEx = new 
	    W3C::Util::CachedContextException(-str => $self->YYData->{INPUT}, 
					      -pos => $self->YYData->{my_LASTPOS}+1, 
					      -errorMessage => $ex->toString);
	$newEx->assumeStackTrace($ex);
	&throw($newEx);
    } else {
	my $newEx = 
	    new W3C::Util::CachedContextException(-str => $self->YYData->{INPUT}, 
						  -pos => $self->YYData->{my_LASTPOS}+1, 
						  -errorMessage => "$obj->$method: $@");
	&throw($newEx);
    }}
    return wantarray ? @ret : $ret[-1];
}

sub printArgs {
    my ($self) = @_;
    return;
    print ':';
    foreach my $arg (@_) {
	print " $arg";
    }
    print ' Curtok:',$self->YYCurtok;
    print ' Curval:',$self->YYCurval;
    print ' Expect:',$self->YYExpect;
    print ' Lexer:',$self->YYLexer;
    print ' Data:',$self->YYData;
    print "\n";
}

# Used by -M invocation:
#   perl -MW3C::Rdf::SparqlParser -e '(new W3C::Rdf::RLSparqlParser())->Run' '...'
sub main {
    my ($self) = @_;
    $self->Run();
}

# <parser state support>
sub createBNode {
    my ($self, $label) = @_;
    if (!defined $label) {
	my $n = $self->YYData->{AnonymousBNodes}++;
	$label = "_:_$n"
    }
    my $t = $self->YYData->{ALGAE2}->getSourceAttribution;
    $self->YYData->{ALGAE2}->setSourceAttribution($self->YYData->{Attribution} || $t);
    my $ret = $self->YYData->{CreateNovelBNodes} ? 
	$self->YYData->{CreateNovelBNodes} == 2 ? 
	new W3C::Rdf::AlgaeCompileTree::BNode($self) : 
	new W3C::Rdf::AlgaeCompileTree::NovelBNode($label, $self) : 
	new W3C::Rdf::AlgaeCompileTree::NovelVar($label, $self);
    $self->YYData->{ALGAE2}->setSourceAttribution($t);
    return $ret;
}

sub startList {
    my ($self) = @_;
    return $self->YYData->{list} = [];
}
sub addListNode {
    my ($self, $GraphNode) = @_;
    push (@{$self->YYData->{list}}, $GraphNode);
    return $self->YYData->{list};
}
sub stopList {
    my ($self) = @_;
    my $d =undef;
    my $tail = undef;
    foreach my $GraphNode (reverse @{$self->YYData->{list}}) {
	my ($node, $decls) = ref $GraphNode eq 'ARRAY' ? @$GraphNode : ($GraphNode, undef);
	my $n = $self->YYData->{listHead} = $self->createBNode(undef);

	# $n rdf:type rdf:List .
	my $type = new W3C::Rdf::AlgaeCompileTree::Url('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', undef, $self);
	my $list = new W3C::Rdf::AlgaeCompileTree::Url('http://www.w3.org/1999/02/22-rdf-syntax-ns#List', undef, $self);
	my $typeDecl = new W3C::Rdf::AlgaeCompileTree::Decl([$type, $n, $list], undef, $self);
	$d = $d ? new W3C::Rdf::AlgaeCompileTree::Conjunction($d, $typeDecl, $self) : $typeDecl;

	# $n rdf:first $node .
	my $first = new W3C::Rdf::AlgaeCompileTree::Url('http://www.w3.org/1999/02/22-rdf-syntax-ns#first', undef, $self);
	my $firstDecl = new W3C::Rdf::AlgaeCompileTree::Decl([$first, $n, $node], undef, $self);
	$d = new W3C::Rdf::AlgaeCompileTree::Conjunction($d, $firstDecl, $self);

	# $n rdf:rest $rest .
	my $rest = new W3C::Rdf::AlgaeCompileTree::Url('http://www.w3.org/1999/02/22-rdf-syntax-ns#rest', undef, $self);
	if (!$tail) {
	    $tail = new W3C::Rdf::AlgaeCompileTree::Url('http://www.w3.org/1999/02/22-rdf-syntax-ns#nil', undef, $self);
	}
	$d = new W3C::Rdf::AlgaeCompileTree::Conjunction($d, new W3C::Rdf::AlgaeCompileTree::Decl([$rest, $n, $tail], undef, $self), $self);

	if ($decls) {
	    $d = new W3C::Rdf::AlgaeCompileTree::Conjunction($d, $decls, $self);
	}
	$tail = $n;
    }
    $self->YYData->{list} = undef;
    return [$tail, $d];
}

sub getDecl {
    my $constraints = $_[1] ? [new W3C::Rdf::AlgaeCompileTree::Constraint(
	new W3C::Rdf::AlgaeCompileTree::Assign($_[1], 
	    new W3C::Rdf::AlgaeCompileTree::KeyName('ATTRIB', 1, $_[0]), $_[0]), $_[0])] : [];
    $_[0]->newDecl([[$_[3], [[$_[5], [[$_[7], $constraints]]]]]]); # hugly re-use ack
}

sub newDecl {
    my ($self, $parm) = @_;
    my $ret;
    foreach my $decl (@$parm) {
	my ($subject, $propValList) = @$decl;
	foreach my $propVal (@$propValList) {
	    my ($property, $valueList) = @$propVal;
	    foreach my $valuePair (@$valueList) {
		my ($value) = $valuePair; # , $constraints) = @$valuePair;
		# print $subject->toString.' '.$property->toString.' '.$value->toString."\n";
		my $toAdd = [];
		if (ref $value eq 'ARRAY') {
		    # we've got an object and a bunch of Decls about that object.
		    $toAdd = [$value->[1]];
		    $value = $value->[0];
		}
		my $newTerm = new W3C::Rdf::AlgaeCompileTree::Decl([$property, $subject, $value], 
								   undef, $self); # $constraints, $self);
		foreach my $term ($newTerm, @$toAdd) {
		    if ($ret) {
			$ret = new W3C::Rdf::AlgaeCompileTree::Conjunction($ret, $term, $self);
		    } else {
			$ret = $term;
		    }
		}
	    }
	}
    }
    return $ret;
}

sub _literalToken { # static
    my ($str, $trim) = @_;
    $str = substr($str, $trim, (length $str) - 2*$trim);
    $str =~ s/\\\\/\\/g;
    $str =~ s/\\t/\t/g;
    $str =~ s/\\n/\n/g;
    $str =~ s/\\r/\r/g;
    $str =~ s/\\b/\b/g;
    $str =~ s/\\f/\f/g;
    $str =~ s/\\'/\'/g;
    $str =~ s/\\"/\"/g;
    return $str;
}

sub resolveQNames {
    my ($self) = @_;
    foreach my $qname (@{$self->YYData->{QNAMES}}) {
	$qname->resolveNS();
    }
}

# </parser state support>

package W3C::Rdf::SparqlParser;
@W3C::Rdf::SparqlParser::ISA = qw(W3C::Rdf::_SparqlParser);
sub new {
    my ($proto, $sparqlString, $algae2, $location, %flags) = @_;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new();
    $self->YYData->{ADJUSTMENTS} = [];
    sub subn {
	my ($pStr, $marker, $hex) = @_;
	push (@{$self->{ADJUSTMENTS}}, [pos $$pStr, $marker, chr(hex($hex))]);
	return chr(hex($hex));
    }
    $sparqlString =~ s/(\\u([0-9a-fA-F]{4,4})|\\U([0-9a-fA-F]{8,8}))/&subn(\$sparqlString, $1, $2 || $3)/gse;
    $self->YYData->{INPUT} = $sparqlString;
    pos $self->YYData->{INPUT} = 0;
    $self->YYData->{LOCATION} = $location;
 
    $self->YYData->{ALGAE2} = $algae2;
    $self->YYData->{QNAMES} = [];
    $self->YYData->{FLAGS} = {%flags};
    $self->YYData->{patternIdStack} = [];
    $self->YYData->{patternIdByNamedBNode} = {};
    $self->YYData->{BASE} = new W3C::Rdf::AlgaeCompileTree::Url($location, undef, $self);
    return $self;
}

sub nextChunk {
    my ($self) = @_;
    my $ret = $self->YYData->{SPARQL_STRING};
    $self->YYData->{SPARQL_STRING} = undef;
    return $ret;
}

# Interactive ReadLine parser -- under development
package W3C::Rdf::RLSparqlParser;
use W3C::Util::Exception;
@W3C::Rdf::RLSparqlParser::ISA = qw(W3C::Rdf::SparqlParser);
sub new {
    my ($proto, @parms) = @_;
    my $class = ref($proto) || $proto;

    # Change the parser driver to the readline driver.
    @W3C::Rdf::_SparqlParser::ISA = qw (W3C::Util::rlDriver);

    my $self = $class->SUPER::new(@parms);
    $self->YYData->{ACTIONS} = [];
    return $self;
}

sub nextChunk {
    my ($self) = @_;
    my $ret = undef;
    if ($self->{rl_COMPLETE_MODE}) {
	if ($self->{rl_SO_FAR}) {
	    $ret = $self->{rl_SO_FAR};
	    $self->{rl_SO_FAR} = undef;
	    #print "nextChunk: $ret\n";
	}
    } else {
	if (@{$self->YYData->{my_CHUNKS}}) {
	    $ret = shift (@{$self->YYData->{my_CHUNKS}});
	} else {
	    #return shift (@ARGV);
	    $ret = $self->readline('')."\n";
	    #print "ret: $ret";
	}
    }
    return $ret;
}

# perl -MW3C::Rdf::SparqlParser -e '(new W3C::Rdf::RLSparqlParser())->Run' 'asdf'
# b /usr/share/perl5/Parse/Yapp/Driver.pm:343

##!/usr/bin/perl
#BEGIN {unshift@INC,('../..');}
#use W3C::Rdf::SparqlParser;
#$p = new W3C::Rdf::RLSparqlParser();
#$p->main;

#./SparqlParser "(ask '(<ab:cd> (?asdf ?s ?o)) assert '(ef:gh (?a ?b ?c)))"

1;

__END__

=head1 NAME

W3C::Rdf::SparqlParser - a Parse::Yapp grammer for the SPARQL language

=head1 SYNOPSIS

  use W3C::Rdf::SparqlParser;
  my $p = new W3C::Rdf::SparqlParser($brqlString, $query, "query.txt");
  my $actions = $p->parse($debug);
  foreach my $action (@$actions) {
    $action->delayedEvaluate($self->{RESULT_SET});
  }
  return $self->getReport();

=head1 DESCRIPTION

The SparqlParser module binds a yapp grammar to semantic actions that build an
AlgaeCompileTree. In general, client applicatiosn have no direct interaction
with SparqlParser. Devlopers wishing to extend the SPARQL query language
  http://www.w3.org/2001/sw/DataAccess/rq23/

will need the perl yapp modules. The Makefile included with the W3C::Rdf CPAN
module has a target to re-compile the SparqlParser grammar. Invoke this with
  make SparqlParser.pm
It is likely that someone extending the SparqlParser grammar will also want to
extended AlgaeCompileTree.

This module is part of the W3C::Rdf CPAN module.

=head1 AUTHOR

Eric Prud\'hommeaux <eric@w3.org>

=head1 SEE ALSO

W3C::Rdf::AlgaeCompileTree(3) W3C::Rdf::Algae2(3) perl(1).

=cut

1;
