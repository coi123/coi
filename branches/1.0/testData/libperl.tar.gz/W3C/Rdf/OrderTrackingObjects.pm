@W3C::Rdf::OrderTrackingObjects::Addresses::ISA = ( 'W3C::Database::ObjectBase' );
%W3C::Rdf::OrderTrackingObjects::Addresses::_TableDesc = ( '-table' => 'Addresses',
                                                                 '-class' => 'W3C::Rdf::OrderTrackingObjects::Addresses',
                                                                 '-index' => { 'u_apt_street_city_state' => { '-sequence' => [ 'apt',
                                                                                                                               'street',
                                                                                                                               'city',
                                                                                                                               'state' ],
                                                                                                              '-unique' => '1',
                                                                                                              '-fields' => { 'city' => 2,
                                                                                                                             'apt' => 0,
                                                                                                                             'street' => 1,
                                                                                                                             'state' => 3 } } },
                                                                 '-primaryKey' => 'id',
                                                                 '-fields' => { 'city' => { '-type' => 4,
                                                                                            '-size' => '80',
                                                                                            '-null' => 1 },
                                                                                'apt' => { '-type' => 4,
                                                                                           '-size' => '20',
                                                                                           '-null' => 1 },
                                                                                'street' => { '-type' => 4,
                                                                                              '-size' => '80',
                                                                                              '-null' => 1 },
                                                                                'contact' => { '-target' => [ 'Customers',
                                                                                                              'id' ],
                                                                                               '-type' => 0,
                                                                                               '-size' => '11',
                                                                                               '-null' => 1 },
                                                                                'id' => { '-type' => 0,
                                                                                          '-default' => '0',
                                                                                          '-size' => '11' },
                                                                                'state' => { '-type' => 4,
                                                                                             '-size' => '2',
                                                                                             '-null' => 1 } },
                                                                 '-fieldOrder' => [ 'id',
                                                                                    'apt',
                                                                                    'street',
                                                                                    'city',
                                                                                    'state',
                                                                                    'contact' ] );
$W3C::Rdf::OrderTrackingObjects::_AllTables{'Addresses'} = \%W3C::Rdf::OrderTrackingObjects::Addresses::_TableDesc;
sub W3C::Rdf::OrderTrackingObjects::Addresses::getTableDesc {return \%W3C::Rdf::OrderTrackingObjects::Addresses::_TableDesc;}
sub W3C::Rdf::OrderTrackingObjects::Addresses::getPrimaryKey {return $_[0]->{DB_ID};}
sub W3C::Rdf::OrderTrackingObjects::Addresses::_getId {return $_[0]->{FIELD_VALUES}{'id'};}
sub W3C::Rdf::OrderTrackingObjects::Addresses::_checkId {return ${($_[0]->check(['id']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::Addresses::_setId {$_[0]->{FIELD_VALUES}{'id'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::Addresses::_updateId {$_[0]->update({'id' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::Addresses::_getApt {return $_[0]->{FIELD_VALUES}{'apt'};}
sub W3C::Rdf::OrderTrackingObjects::Addresses::_checkApt {return ${($_[0]->check(['apt']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::Addresses::_setApt {$_[0]->{FIELD_VALUES}{'apt'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::Addresses::_updateApt {$_[0]->update({'apt' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::Addresses::_getStreet {return $_[0]->{FIELD_VALUES}{'street'};}
sub W3C::Rdf::OrderTrackingObjects::Addresses::_checkStreet {return ${($_[0]->check(['street']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::Addresses::_setStreet {$_[0]->{FIELD_VALUES}{'street'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::Addresses::_updateStreet {$_[0]->update({'street' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::Addresses::_getCity {return $_[0]->{FIELD_VALUES}{'city'};}
sub W3C::Rdf::OrderTrackingObjects::Addresses::_checkCity {return ${($_[0]->check(['city']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::Addresses::_setCity {$_[0]->{FIELD_VALUES}{'city'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::Addresses::_updateCity {$_[0]->update({'city' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::Addresses::_getState {return $_[0]->{FIELD_VALUES}{'state'};}
sub W3C::Rdf::OrderTrackingObjects::Addresses::_checkState {return ${($_[0]->check(['state']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::Addresses::_setState {$_[0]->{FIELD_VALUES}{'state'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::Addresses::_updateState {$_[0]->update({'state' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::Addresses::_getContact {return $_[0]->{FIELD_VALUES}{'contact'};}
sub W3C::Rdf::OrderTrackingObjects::Addresses::_checkContact {return ${($_[0]->check(['contact']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::Addresses::_setContact {$_[0]->{FIELD_VALUES}{'contact'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::Addresses::_updateContact {$_[0]->update({'contact' => $_[1]});}

@W3C::Rdf::OrderTrackingObjects::Customers::ISA = ( 'W3C::Database::ObjectBase' );
%W3C::Rdf::OrderTrackingObjects::Customers::_TableDesc = ( '-table' => 'Customers',
                                                                 '-class' => 'W3C::Rdf::OrderTrackingObjects::Customers',
                                                                 '-index' => { 'u_givenName_familyName_billingAddress' => { '-sequence' => [ 'givenName',
                                                                                                                                             'familyName',
                                                                                                                                             'billingAddress' ],
                                                                                                                            '-unique' => '1',
                                                                                                                            '-fields' => { 'billingAddress' => 2,
                                                                                                                                           'familyName' => 1,
                                                                                                                                           'givenName' => 0 } } },
                                                                 '-primaryKey' => 'id',
                                                                 '-fields' => { 'billingAddress' => { '-target' => [ 'Addresses',
                                                                                                                     'id' ],
                                                                                                      '-type' => 0,
                                                                                                      '-default' => '0',
                                                                                                      '-size' => '11' },
                                                                                'id' => { '-type' => 0,
                                                                                          '-default' => '0',
                                                                                          '-size' => '11' },
                                                                                'familyName' => { '-type' => 4,
                                                                                                  '-size' => '80',
                                                                                                  '-null' => 1 },
                                                                                'givenName' => { '-type' => 4,
                                                                                                 '-size' => '80',
                                                                                                 '-null' => 1 } },
                                                                 '-fieldOrder' => [ 'id',
                                                                                    'givenName',
                                                                                    'familyName',
                                                                                    'billingAddress' ] );
$W3C::Rdf::OrderTrackingObjects::_AllTables{'Customers'} = \%W3C::Rdf::OrderTrackingObjects::Customers::_TableDesc;
sub W3C::Rdf::OrderTrackingObjects::Customers::getTableDesc {return \%W3C::Rdf::OrderTrackingObjects::Customers::_TableDesc;}
sub W3C::Rdf::OrderTrackingObjects::Customers::getPrimaryKey {return $_[0]->{DB_ID};}
sub W3C::Rdf::OrderTrackingObjects::Customers::_getId {return $_[0]->{FIELD_VALUES}{'id'};}
sub W3C::Rdf::OrderTrackingObjects::Customers::_checkId {return ${($_[0]->check(['id']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::Customers::_setId {$_[0]->{FIELD_VALUES}{'id'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::Customers::_updateId {$_[0]->update({'id' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::Customers::_getGivenName {return $_[0]->{FIELD_VALUES}{'givenName'};}
sub W3C::Rdf::OrderTrackingObjects::Customers::_checkGivenName {return ${($_[0]->check(['givenName']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::Customers::_setGivenName {$_[0]->{FIELD_VALUES}{'givenName'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::Customers::_updateGivenName {$_[0]->update({'givenName' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::Customers::_getFamilyName {return $_[0]->{FIELD_VALUES}{'familyName'};}
sub W3C::Rdf::OrderTrackingObjects::Customers::_checkFamilyName {return ${($_[0]->check(['familyName']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::Customers::_setFamilyName {$_[0]->{FIELD_VALUES}{'familyName'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::Customers::_updateFamilyName {$_[0]->update({'familyName' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::Customers::_getBillingAddress {return $_[0]->{FIELD_VALUES}{'billingAddress'};}
sub W3C::Rdf::OrderTrackingObjects::Customers::_checkBillingAddress {return ${($_[0]->check(['billingAddress']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::Customers::_setBillingAddress {$_[0]->{FIELD_VALUES}{'billingAddress'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::Customers::_updateBillingAddress {$_[0]->update({'billingAddress' => $_[1]});}

@W3C::Rdf::OrderTrackingObjects::Orders::ISA = ( 'W3C::Database::ObjectBase' );
%W3C::Rdf::OrderTrackingObjects::Orders::_TableDesc = ( '-table' => 'Orders',
                                                              '-class' => 'W3C::Rdf::OrderTrackingObjects::Orders',
                                                              '-index' => { 'u_customer_product_orderDate' => { '-sequence' => [ 'customer',
                                                                                                                                 'product',
                                                                                                                                 'orderDate' ],
                                                                                                                '-unique' => '1',
                                                                                                                '-fields' => { 'customer' => 0,
                                                                                                                               'orderDate' => 2,
                                                                                                                               'product' => 1 } } },
                                                              '-primaryKey' => 'id',
                                                              '-fields' => { 'shippingAddress' => { '-target' => [ 'Addresses',
                                                                                                                   'id' ],
                                                                                                    '-type' => 0,
                                                                                                    '-size' => '11',
                                                                                                    '-null' => 1 },
                                                                             'customer' => { '-target' => [ 'Customers',
                                                                                                            'id' ],
                                                                                             '-type' => 0,
                                                                                             '-default' => '0',
                                                                                             '-size' => '11' },
                                                                             'orderDate' => { '-type' => 11,
                                                                                              '-null' => 1 },
                                                                             'product' => { '-target' => [ 'Products',
                                                                                                           'id' ],
                                                                                            '-type' => 0,
                                                                                            '-default' => '0',
                                                                                            '-size' => '11' },
                                                                             'id' => { '-type' => 0,
                                                                                       '-default' => '0',
                                                                                       '-size' => '11' } },
                                                              '-fieldOrder' => [ 'id',
                                                                                 'customer',
                                                                                 'product',
                                                                                 'orderDate',
                                                                                 'shippingAddress' ] );
$W3C::Rdf::OrderTrackingObjects::_AllTables{'Orders'} = \%W3C::Rdf::OrderTrackingObjects::Orders::_TableDesc;
sub W3C::Rdf::OrderTrackingObjects::Orders::getTableDesc {return \%W3C::Rdf::OrderTrackingObjects::Orders::_TableDesc;}
sub W3C::Rdf::OrderTrackingObjects::Orders::getPrimaryKey {return $_[0]->{DB_ID};}
sub W3C::Rdf::OrderTrackingObjects::Orders::_getId {return $_[0]->{FIELD_VALUES}{'id'};}
sub W3C::Rdf::OrderTrackingObjects::Orders::_checkId {return ${($_[0]->check(['id']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::Orders::_setId {$_[0]->{FIELD_VALUES}{'id'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::Orders::_updateId {$_[0]->update({'id' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::Orders::_getCustomer {return $_[0]->{FIELD_VALUES}{'customer'};}
sub W3C::Rdf::OrderTrackingObjects::Orders::_checkCustomer {return ${($_[0]->check(['customer']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::Orders::_setCustomer {$_[0]->{FIELD_VALUES}{'customer'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::Orders::_updateCustomer {$_[0]->update({'customer' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::Orders::_getProduct {return $_[0]->{FIELD_VALUES}{'product'};}
sub W3C::Rdf::OrderTrackingObjects::Orders::_checkProduct {return ${($_[0]->check(['product']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::Orders::_setProduct {$_[0]->{FIELD_VALUES}{'product'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::Orders::_updateProduct {$_[0]->update({'product' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::Orders::_getOrderDate {return $_[0]->{FIELD_VALUES}{'orderDate'};}
sub W3C::Rdf::OrderTrackingObjects::Orders::_checkOrderDate {return ${($_[0]->check(['orderDate']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::Orders::_setOrderDate {$_[0]->{FIELD_VALUES}{'orderDate'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::Orders::_updateOrderDate {$_[0]->update({'orderDate' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::Orders::_getShippingAddress {return $_[0]->{FIELD_VALUES}{'shippingAddress'};}
sub W3C::Rdf::OrderTrackingObjects::Orders::_checkShippingAddress {return ${($_[0]->check(['shippingAddress']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::Orders::_setShippingAddress {$_[0]->{FIELD_VALUES}{'shippingAddress'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::Orders::_updateShippingAddress {$_[0]->update({'shippingAddress' => $_[1]});}

@W3C::Rdf::OrderTrackingObjects::Products::ISA = ( 'W3C::Database::ObjectBase' );
%W3C::Rdf::OrderTrackingObjects::Products::_TableDesc = ( '-table' => 'Products',
                                                                '-class' => 'W3C::Rdf::OrderTrackingObjects::Products',
                                                                '-index' => { 'u_name' => { '-sequence' => [ 'partNo' ],
                                                                                            '-unique' => '1',
                                                                                            '-fields' => { 'partNo' => 0 } } },
                                                                '-primaryKey' => 'id',
                                                                '-fields' => { 'partNo' => { '-type' => 5,
                                                                                             '-size' => '80',
                                                                                             '-null' => 1 },
                                                                               'price' => { '-type' => 2,
                                                                                            '-size' => undef,
                                                                                            '-null' => 1 },
                                                                               'id' => { '-type' => 0,
                                                                                         '-default' => '0',
                                                                                         '-size' => '11' },
                                                                               'description' => { '-type' => 5,
                                                                                                  '-size' => '255',
                                                                                                  '-null' => 1 } },
                                                                '-fieldOrder' => [ 'id',
                                                                                   'partNo',
                                                                                   'description',
                                                                                   'price' ] );
$W3C::Rdf::OrderTrackingObjects::_AllTables{'Products'} = \%W3C::Rdf::OrderTrackingObjects::Products::_TableDesc;
sub W3C::Rdf::OrderTrackingObjects::Products::getTableDesc {return \%W3C::Rdf::OrderTrackingObjects::Products::_TableDesc;}
sub W3C::Rdf::OrderTrackingObjects::Products::getPrimaryKey {return $_[0]->{DB_ID};}
sub W3C::Rdf::OrderTrackingObjects::Products::_getId {return $_[0]->{FIELD_VALUES}{'id'};}
sub W3C::Rdf::OrderTrackingObjects::Products::_checkId {return ${($_[0]->check(['id']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::Products::_setId {$_[0]->{FIELD_VALUES}{'id'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::Products::_updateId {$_[0]->update({'id' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::Products::_getPartNo {return $_[0]->{FIELD_VALUES}{'partNo'};}
sub W3C::Rdf::OrderTrackingObjects::Products::_checkPartNo {return ${($_[0]->check(['partNo']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::Products::_setPartNo {$_[0]->{FIELD_VALUES}{'partNo'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::Products::_updatePartNo {$_[0]->update({'partNo' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::Products::_getDescription {return $_[0]->{FIELD_VALUES}{'description'};}
sub W3C::Rdf::OrderTrackingObjects::Products::_checkDescription {return ${($_[0]->check(['description']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::Products::_setDescription {$_[0]->{FIELD_VALUES}{'description'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::Products::_updateDescription {$_[0]->update({'description' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::Products::_getPrice {return $_[0]->{FIELD_VALUES}{'price'};}
sub W3C::Rdf::OrderTrackingObjects::Products::_checkPrice {return ${($_[0]->check(['price']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::Products::_setPrice {$_[0]->{FIELD_VALUES}{'price'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::Products::_updatePrice {$_[0]->update({'price' => $_[1]});}

@W3C::Rdf::OrderTrackingObjects::S::ISA = ( 'W3C::Database::ObjectBase' );
%W3C::Rdf::OrderTrackingObjects::S::_TableDesc = ( '-table' => 'S',
                                                         '-class' => 'W3C::Rdf::OrderTrackingObjects::S',
                                                         '-fields' => { 'p' => { '-type' => 4,
                                                                                 '-size' => '4',
                                                                                 '-null' => 1 },
                                                                        's' => { '-type' => 4,
                                                                                 '-size' => '4',
                                                                                 '-null' => 1 },
                                                                        'o' => { '-type' => 4,
                                                                                 '-size' => '4',
                                                                                 '-null' => 1 } },
                                                         '-fieldOrder' => [ 's',
                                                                            'p',
                                                                            'o' ] );
$W3C::Rdf::OrderTrackingObjects::_AllTables{'S'} = \%W3C::Rdf::OrderTrackingObjects::S::_TableDesc;
sub W3C::Rdf::OrderTrackingObjects::S::getTableDesc {return \%W3C::Rdf::OrderTrackingObjects::S::_TableDesc;}
sub W3C::Rdf::OrderTrackingObjects::S::_getS {return $_[0]->{FIELD_VALUES}{'s'};}
sub W3C::Rdf::OrderTrackingObjects::S::_checkS {return ${($_[0]->check(['s']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::S::_setS {$_[0]->{FIELD_VALUES}{'s'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::S::_updateS {$_[0]->update({'s' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::S::_getP {return $_[0]->{FIELD_VALUES}{'p'};}
sub W3C::Rdf::OrderTrackingObjects::S::_checkP {return ${($_[0]->check(['p']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::S::_setP {$_[0]->{FIELD_VALUES}{'p'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::S::_updateP {$_[0]->update({'p' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::S::_getO {return $_[0]->{FIELD_VALUES}{'o'};}
sub W3C::Rdf::OrderTrackingObjects::S::_checkO {return ${($_[0]->check(['o']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::S::_setO {$_[0]->{FIELD_VALUES}{'o'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::S::_updateO {$_[0]->update({'o' => $_[1]});}

@W3C::Rdf::OrderTrackingObjects::__AttrLists__::ISA = ( 'W3C::Database::ObjectBase' );
%W3C::Rdf::OrderTrackingObjects::__AttrLists__::_TableDesc = ( '-table' => '__AttrLists__',
                                                                     '-class' => 'W3C::Rdf::OrderTrackingObjects::__AttrLists__',
                                                                     '-index' => { 'u_listId_a' => { '-sequence' => [ 'listId',
                                                                                                                      'a' ],
                                                                                                     '-unique' => '1',
                                                                                                     '-fields' => { 'a' => 1,
                                                                                                                    'listId' => 0 } } },
                                                                     '-primaryKey' => 'id',
                                                                     '-fields' => { 'a' => { '-type' => 0,
                                                                                             '-default' => '0',
                                                                                             '-size' => '11' },
                                                                                    'id' => { '-type' => 0,
                                                                                              '-size' => '11' },
                                                                                    'listId' => { '-type' => 0,
                                                                                                  '-default' => '0',
                                                                                                  '-size' => '11' } },
                                                                     '-fieldOrder' => [ 'id',
                                                                                        'listId',
                                                                                        'a' ] );
$W3C::Rdf::OrderTrackingObjects::_AllTables{'__AttrLists__'} = \%W3C::Rdf::OrderTrackingObjects::__AttrLists__::_TableDesc;
sub W3C::Rdf::OrderTrackingObjects::__AttrLists__::getTableDesc {return \%W3C::Rdf::OrderTrackingObjects::__AttrLists__::_TableDesc;}
sub W3C::Rdf::OrderTrackingObjects::__AttrLists__::getPrimaryKey {return $_[0]->{DB_ID};}
sub W3C::Rdf::OrderTrackingObjects::__AttrLists__::_getId {return $_[0]->{FIELD_VALUES}{'id'};}
sub W3C::Rdf::OrderTrackingObjects::__AttrLists__::_checkId {return ${($_[0]->check(['id']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::__AttrLists__::_setId {$_[0]->{FIELD_VALUES}{'id'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::__AttrLists__::_updateId {$_[0]->update({'id' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::__AttrLists__::_getListId {return $_[0]->{FIELD_VALUES}{'listId'};}
sub W3C::Rdf::OrderTrackingObjects::__AttrLists__::_checkListId {return ${($_[0]->check(['listId']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::__AttrLists__::_setListId {$_[0]->{FIELD_VALUES}{'listId'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::__AttrLists__::_updateListId {$_[0]->update({'listId' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::__AttrLists__::_getA {return $_[0]->{FIELD_VALUES}{'a'};}
sub W3C::Rdf::OrderTrackingObjects::__AttrLists__::_checkA {return ${($_[0]->check(['a']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::__AttrLists__::_setA {$_[0]->{FIELD_VALUES}{'a'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::__AttrLists__::_updateA {$_[0]->update({'a' => $_[1]});}

@W3C::Rdf::OrderTrackingObjects::__Attributions__::ISA = ( 'W3C::Database::ObjectBase' );
$W3C::Rdf::OrderTrackingObjects::__Attributions__::type_SOURCE = 0;
$W3C::Rdf::OrderTrackingObjects::__Attributions__::type_GENERATED = 1;
$W3C::Rdf::OrderTrackingObjects::__Attributions__::type_REIFIED = 2;
%W3C::Rdf::OrderTrackingObjects::__Attributions__::type_to_string = ( '1' => 'generated',
                                                                            '0' => 'source',
                                                                            '2' => 'reified' );
%W3C::Rdf::OrderTrackingObjects::__Attributions__::string_to_type = ( 'source' => 0,
                                                                            'reified' => 2,
                                                                            'generated' => 1 );
%W3C::Rdf::OrderTrackingObjects::__Attributions__::_TableDesc = ( '-table' => '__Attributions__',
                                                                        '-class' => 'W3C::Rdf::OrderTrackingObjects::__Attributions__',
                                                                        '-index' => { 'u_type_doc' => { '-sequence' => [ 'type',
                                                                                                                         'doc' ],
                                                                                                        '-unique' => '1',
                                                                                                        '-fields' => { 'doc' => 1,
                                                                                                                       'type' => 0 } } },
                                                                        '-primaryKey' => 'id',
                                                                        '-fields' => { 'created' => { '-type' => 11,
                                                                                                      '-default' => '00000000000000',
                                                                                                      '-null' => 1 },
                                                                                       'auth' => { '-type' => 0,
                                                                                                   '-size' => '11',
                                                                                                   '-null' => 1 },
                                                                                       'doc' => { '-type' => 0,
                                                                                                  '-default' => '0',
                                                                                                  '-size' => '11' },
                                                                                       'type' => { '-type' => 3,
                                                                                                   '-default' => 'source',
                                                                                                   '-stringsTo' => \%W3C::Rdf::OrderTrackingObjects::__Attributions__::string_to_type,
                                                                                                   '-values' => [ 'source',
                                                                                                                  'generated',
                                                                                                                  'reified' ],
                                                                                                   '-toStrings' => \%W3C::Rdf::OrderTrackingObjects::__Attributions__::type_to_string },
                                                                                       'id' => { '-type' => 0,
                                                                                                 '-size' => '11' },
                                                                                       'modified' => { '-type' => 11,
                                                                                                       '-null' => 1 } },
                                                                        '-fieldOrder' => [ 'id',
                                                                                           'type',
                                                                                           'doc',
                                                                                           'auth',
                                                                                           'modified',
                                                                                           'created' ] );
$W3C::Rdf::OrderTrackingObjects::_AllTables{'__Attributions__'} = \%W3C::Rdf::OrderTrackingObjects::__Attributions__::_TableDesc;
sub W3C::Rdf::OrderTrackingObjects::__Attributions__::getTableDesc {return \%W3C::Rdf::OrderTrackingObjects::__Attributions__::_TableDesc;}
sub W3C::Rdf::OrderTrackingObjects::__Attributions__::getPrimaryKey {return $_[0]->{DB_ID};}
sub W3C::Rdf::OrderTrackingObjects::__Attributions__::_getId {return $_[0]->{FIELD_VALUES}{'id'};}
sub W3C::Rdf::OrderTrackingObjects::__Attributions__::_checkId {return ${($_[0]->check(['id']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::__Attributions__::_setId {$_[0]->{FIELD_VALUES}{'id'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::__Attributions__::_updateId {$_[0]->update({'id' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::__Attributions__::_getType {return $_[0]->{FIELD_VALUES}{'type'};}
sub W3C::Rdf::OrderTrackingObjects::__Attributions__::_checkType {return ${($_[0]->check(['type']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::__Attributions__::_setType {$_[0]->{FIELD_VALUES}{'type'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::__Attributions__::_updateType {$_[0]->update({'type' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::__Attributions__::_getDoc {return $_[0]->{FIELD_VALUES}{'doc'};}
sub W3C::Rdf::OrderTrackingObjects::__Attributions__::_checkDoc {return ${($_[0]->check(['doc']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::__Attributions__::_setDoc {$_[0]->{FIELD_VALUES}{'doc'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::__Attributions__::_updateDoc {$_[0]->update({'doc' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::__Attributions__::_getAuth {return $_[0]->{FIELD_VALUES}{'auth'};}
sub W3C::Rdf::OrderTrackingObjects::__Attributions__::_checkAuth {return ${($_[0]->check(['auth']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::__Attributions__::_setAuth {$_[0]->{FIELD_VALUES}{'auth'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::__Attributions__::_updateAuth {$_[0]->update({'auth' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::__Attributions__::_getModified {return $_[0]->{FIELD_VALUES}{'modified'};}
sub W3C::Rdf::OrderTrackingObjects::__Attributions__::_checkModified {return ${($_[0]->check(['modified']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::__Attributions__::_setModified {$_[0]->{FIELD_VALUES}{'modified'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::__Attributions__::_updateModified {$_[0]->update({'modified' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::__Attributions__::_getCreated {return $_[0]->{FIELD_VALUES}{'created'};}
sub W3C::Rdf::OrderTrackingObjects::__Attributions__::_checkCreated {return ${($_[0]->check(['created']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::__Attributions__::_setCreated {$_[0]->{FIELD_VALUES}{'created'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::__Attributions__::_updateCreated {$_[0]->update({'created' => $_[1]});}

@W3C::Rdf::OrderTrackingObjects::__Big__::ISA = ( 'W3C::Database::ObjectBase' );
%W3C::Rdf::OrderTrackingObjects::__Big__::_TableDesc = ( '-table' => '__Big__',
                                                               '-class' => 'W3C::Rdf::OrderTrackingObjects::__Big__',
                                                               '-index' => { 'u_hash' => { '-sequence' => [ 'hash' ],
                                                                                           '-unique' => '1',
                                                                                           '-fields' => { 'hash' => 0 } } },
                                                               '-primaryKey' => 'id',
                                                               '-fields' => { 'hash' => { '-type' => 5,
                                                                                          '-default' => '',
                                                                                          '-size' => '32' },
                                                                              'str' => { '-type' => 6,
                                                                                         '-default' => '',
                                                                                         '-size' => undef },
                                                                              'id' => { '-type' => 0,
                                                                                        '-size' => '10' } },
                                                               '-fieldOrder' => [ 'id',
                                                                                  'hash',
                                                                                  'str' ] );
$W3C::Rdf::OrderTrackingObjects::_AllTables{'__Big__'} = \%W3C::Rdf::OrderTrackingObjects::__Big__::_TableDesc;
sub W3C::Rdf::OrderTrackingObjects::__Big__::getTableDesc {return \%W3C::Rdf::OrderTrackingObjects::__Big__::_TableDesc;}
sub W3C::Rdf::OrderTrackingObjects::__Big__::getPrimaryKey {return $_[0]->{DB_ID};}
sub W3C::Rdf::OrderTrackingObjects::__Big__::_getId {return $_[0]->{FIELD_VALUES}{'id'};}
sub W3C::Rdf::OrderTrackingObjects::__Big__::_checkId {return ${($_[0]->check(['id']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::__Big__::_setId {$_[0]->{FIELD_VALUES}{'id'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::__Big__::_updateId {$_[0]->update({'id' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::__Big__::_getHash {return $_[0]->{FIELD_VALUES}{'hash'};}
sub W3C::Rdf::OrderTrackingObjects::__Big__::_checkHash {return ${($_[0]->check(['hash']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::__Big__::_setHash {$_[0]->{FIELD_VALUES}{'hash'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::__Big__::_updateHash {$_[0]->update({'hash' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::__Big__::_getStr {return $_[0]->{FIELD_VALUES}{'str'};}
sub W3C::Rdf::OrderTrackingObjects::__Big__::_checkStr {return ${($_[0]->check(['str']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::__Big__::_setStr {$_[0]->{FIELD_VALUES}{'str'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::__Big__::_updateStr {$_[0]->update({'str' => $_[1]});}

@W3C::Rdf::OrderTrackingObjects::__Holds__::ISA = ( 'W3C::Database::ObjectBase' );
%W3C::Rdf::OrderTrackingObjects::__Holds__::_TableDesc = ( '-table' => '__Holds__',
                                                                 '-class' => 'W3C::Rdf::OrderTrackingObjects::__Holds__',
                                                                 '-index' => { 'u_' => { '-sequence' => [ 'p',
                                                                                                          's',
                                                                                                          'o',
                                                                                                          'r',
                                                                                                          'a' ],
                                                                                         '-unique' => '1',
                                                                                         '-fields' => { 'p' => 0,
                                                                                                        'a' => 4,
                                                                                                        'r' => 3,
                                                                                                        's' => 1,
                                                                                                        'o' => 2 } } },
                                                                 '-primaryKey' => 'id',
                                                                 '-fields' => { 'p' => { '-type' => 0,
                                                                                         '-default' => '0',
                                                                                         '-size' => '10' },
                                                                                'a' => { '-type' => 0,
                                                                                         '-default' => '0',
                                                                                         '-size' => '10' },
                                                                                'r' => { '-type' => 0,
                                                                                         '-default' => '0',
                                                                                         '-size' => '10' },
                                                                                'id' => { '-type' => 0,
                                                                                          '-size' => '10' },
                                                                                's' => { '-type' => 0,
                                                                                         '-default' => '0',
                                                                                         '-size' => '10' },
                                                                                'o' => { '-type' => 0,
                                                                                         '-default' => '0',
                                                                                         '-size' => '10' } },
                                                                 '-fieldOrder' => [ 'id',
                                                                                    'p',
                                                                                    's',
                                                                                    'o',
                                                                                    'r',
                                                                                    'a' ] );
$W3C::Rdf::OrderTrackingObjects::_AllTables{'__Holds__'} = \%W3C::Rdf::OrderTrackingObjects::__Holds__::_TableDesc;
sub W3C::Rdf::OrderTrackingObjects::__Holds__::getTableDesc {return \%W3C::Rdf::OrderTrackingObjects::__Holds__::_TableDesc;}
sub W3C::Rdf::OrderTrackingObjects::__Holds__::getPrimaryKey {return $_[0]->{DB_ID};}
sub W3C::Rdf::OrderTrackingObjects::__Holds__::_getId {return $_[0]->{FIELD_VALUES}{'id'};}
sub W3C::Rdf::OrderTrackingObjects::__Holds__::_checkId {return ${($_[0]->check(['id']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::__Holds__::_setId {$_[0]->{FIELD_VALUES}{'id'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::__Holds__::_updateId {$_[0]->update({'id' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::__Holds__::_getP {return $_[0]->{FIELD_VALUES}{'p'};}
sub W3C::Rdf::OrderTrackingObjects::__Holds__::_checkP {return ${($_[0]->check(['p']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::__Holds__::_setP {$_[0]->{FIELD_VALUES}{'p'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::__Holds__::_updateP {$_[0]->update({'p' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::__Holds__::_getS {return $_[0]->{FIELD_VALUES}{'s'};}
sub W3C::Rdf::OrderTrackingObjects::__Holds__::_checkS {return ${($_[0]->check(['s']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::__Holds__::_setS {$_[0]->{FIELD_VALUES}{'s'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::__Holds__::_updateS {$_[0]->update({'s' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::__Holds__::_getO {return $_[0]->{FIELD_VALUES}{'o'};}
sub W3C::Rdf::OrderTrackingObjects::__Holds__::_checkO {return ${($_[0]->check(['o']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::__Holds__::_setO {$_[0]->{FIELD_VALUES}{'o'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::__Holds__::_updateO {$_[0]->update({'o' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::__Holds__::_getR {return $_[0]->{FIELD_VALUES}{'r'};}
sub W3C::Rdf::OrderTrackingObjects::__Holds__::_checkR {return ${($_[0]->check(['r']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::__Holds__::_setR {$_[0]->{FIELD_VALUES}{'r'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::__Holds__::_updateR {$_[0]->update({'r' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::__Holds__::_getA {return $_[0]->{FIELD_VALUES}{'a'};}
sub W3C::Rdf::OrderTrackingObjects::__Holds__::_checkA {return ${($_[0]->check(['a']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::__Holds__::_setA {$_[0]->{FIELD_VALUES}{'a'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::__Holds__::_updateA {$_[0]->update({'a' => $_[1]});}

@W3C::Rdf::OrderTrackingObjects::__Nodes__::ISA = ( 'W3C::Database::ObjectBase' );
$W3C::Rdf::OrderTrackingObjects::__Nodes__::type_URI = 0;
$W3C::Rdf::OrderTrackingObjects::__Nodes__::type_LITERAL = 1;
$W3C::Rdf::OrderTrackingObjects::__Nodes__::type_BNODE = 2;
$W3C::Rdf::OrderTrackingObjects::__Nodes__::type_TABLE = 3;
%W3C::Rdf::OrderTrackingObjects::__Nodes__::type_to_string = ( '1' => 'literal',
                                                                     '3' => 'table',
                                                                     '0' => 'uri',
                                                                     '2' => 'bnode' );
%W3C::Rdf::OrderTrackingObjects::__Nodes__::string_to_type = ( 'literal' => 1,
                                                                     'table' => 3,
                                                                     'bnode' => 2,
                                                                     'uri' => 0 );
%W3C::Rdf::OrderTrackingObjects::__Nodes__::_TableDesc = ( '-table' => '__Nodes__',
                                                                 '-class' => 'W3C::Rdf::OrderTrackingObjects::__Nodes__',
                                                                 '-index' => { 'u_type_str_big_attribOrDT' => { '-sequence' => [ 'type',
                                                                                                                                 'str',
                                                                                                                                 'big',
                                                                                                                                 'attribOrDT' ],
                                                                                                                '-unique' => '1',
                                                                                                                '-fields' => { 'attribOrDT' => 3,
                                                                                                                               'big' => 2,
                                                                                                                               'str' => 1,
                                                                                                                               'type' => 0 } },
                                                                               'u_hash' => { '-sequence' => [ 'type',
                                                                                                              'hash' ],
                                                                                             '-unique' => '1',
                                                                                             '-fields' => { 'hash' => 1,
                                                                                                            'type' => 0 } } },
                                                                 '-primaryKey' => 'id',
                                                                 '-fields' => { 'attribOrDT' => { '-type' => 0,
                                                                                                  '-default' => '0',
                                                                                                  '-size' => '10' },
                                                                                'hash' => { '-type' => 5,
                                                                                            '-default' => '',
                                                                                            '-size' => '32' },
                                                                                'big' => { '-type' => 0,
                                                                                           '-size' => '10',
                                                                                           '-null' => 1 },
                                                                                'str' => { '-type' => 5,
                                                                                           '-default' => '',
                                                                                           '-size' => '255' },
                                                                                'type' => { '-type' => 3,
                                                                                            '-stringsTo' => \%W3C::Rdf::OrderTrackingObjects::__Nodes__::string_to_type,
                                                                                            '-values' => [ 'uri',
                                                                                                           'literal',
                                                                                                           'bnode',
                                                                                                           'table' ],
                                                                                            '-null' => 1,
                                                                                            '-toStrings' => \%W3C::Rdf::OrderTrackingObjects::__Nodes__::type_to_string },
                                                                                'id' => { '-type' => 0,
                                                                                          '-size' => '10' } },
                                                                 '-fieldOrder' => [ 'id',
                                                                                    'type',
                                                                                    'hash',
                                                                                    'str',
                                                                                    'big',
                                                                                    'attribOrDT' ] );
$W3C::Rdf::OrderTrackingObjects::_AllTables{'__Nodes__'} = \%W3C::Rdf::OrderTrackingObjects::__Nodes__::_TableDesc;
sub W3C::Rdf::OrderTrackingObjects::__Nodes__::getTableDesc {return \%W3C::Rdf::OrderTrackingObjects::__Nodes__::_TableDesc;}
sub W3C::Rdf::OrderTrackingObjects::__Nodes__::getPrimaryKey {return $_[0]->{DB_ID};}
sub W3C::Rdf::OrderTrackingObjects::__Nodes__::_getId {return $_[0]->{FIELD_VALUES}{'id'};}
sub W3C::Rdf::OrderTrackingObjects::__Nodes__::_checkId {return ${($_[0]->check(['id']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::__Nodes__::_setId {$_[0]->{FIELD_VALUES}{'id'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::__Nodes__::_updateId {$_[0]->update({'id' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::__Nodes__::_getType {return $_[0]->{FIELD_VALUES}{'type'};}
sub W3C::Rdf::OrderTrackingObjects::__Nodes__::_checkType {return ${($_[0]->check(['type']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::__Nodes__::_setType {$_[0]->{FIELD_VALUES}{'type'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::__Nodes__::_updateType {$_[0]->update({'type' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::__Nodes__::_getHash {return $_[0]->{FIELD_VALUES}{'hash'};}
sub W3C::Rdf::OrderTrackingObjects::__Nodes__::_checkHash {return ${($_[0]->check(['hash']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::__Nodes__::_setHash {$_[0]->{FIELD_VALUES}{'hash'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::__Nodes__::_updateHash {$_[0]->update({'hash' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::__Nodes__::_getStr {return $_[0]->{FIELD_VALUES}{'str'};}
sub W3C::Rdf::OrderTrackingObjects::__Nodes__::_checkStr {return ${($_[0]->check(['str']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::__Nodes__::_setStr {$_[0]->{FIELD_VALUES}{'str'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::__Nodes__::_updateStr {$_[0]->update({'str' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::__Nodes__::_getBig {return $_[0]->{FIELD_VALUES}{'big'};}
sub W3C::Rdf::OrderTrackingObjects::__Nodes__::_checkBig {return ${($_[0]->check(['big']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::__Nodes__::_setBig {$_[0]->{FIELD_VALUES}{'big'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::__Nodes__::_updateBig {$_[0]->update({'big' => $_[1]});}
sub W3C::Rdf::OrderTrackingObjects::__Nodes__::_getAttribOrDT {return $_[0]->{FIELD_VALUES}{'attribOrDT'};}
sub W3C::Rdf::OrderTrackingObjects::__Nodes__::_checkAttribOrDT {return ${($_[0]->check(['attribOrDT']))[0]}[0];}
sub W3C::Rdf::OrderTrackingObjects::__Nodes__::_setAttribOrDT {$_[0]->{FIELD_VALUES}{'attribOrDT'} = $_[1];}
sub W3C::Rdf::OrderTrackingObjects::__Nodes__::_updateAttribOrDT {$_[0]->update({'attribOrDT' => $_[1]});}

@W3C::Rdf::OrderTrackingObjects::_TableOrder = ( 'Addresses',
                                                       'Customers',
                                                       'Orders',
                                                       'Products',
                                                       'S',
                                                       '__AttrLists__',
                                                       '__Attributions__',
                                                       '__Big__',
                                                       '__Holds__',
                                                       '__Nodes__' );
