#!/usr/bin/perl
####################################################################
#
#    This file was generated using Parse::Yapp version 1.05.
#
#        Don't edit this file, use source file instead.
#
#             ANY CHANGE MADE HERE WILL BE LOST !
#
####################################################################
package W3C::Rdf::_RdalParser;
use vars qw ( @ISA );
use strict;

@ISA= qw ( Parse::Yapp::Driver );
# use Parse::Yapp::Driver; @@ replaced by W3C::Util::YappDriver

#line 25 "RdalParser.yp"

    #BEGIN {unshift@INC,('../..');}
    use strict;
    use W3C::Util::YappDriver;
    @ISA= qw (W3C::Util::YappDriver);
    use W3C::Util::Exception;

    use W3C::Rdf::RdalCompileTree qw();


sub new {
        my($class)=shift;
        ref($class)
    and $class=ref($class);

    my($self)=$class->SUPER::new( yyversion => '1.05',
                                  yystates =>
[
	{#State 0
		DEFAULT => -2,
		GOTOS => {
			'input' => 2,
			'statementStar' => 1
		}
	},
	{#State 1
		ACTIONS => {
			'STR' => 13,
			"\@" => 3,
			"declare" => 6,
			"if" => 7,
			"let" => 17,
			"\$" => 11,
			'VAR' => 20,
			"." => 22
		},
		DEFAULT => -1,
		GOTOS => {
			'assignment' => 14,
			'axistest' => 15,
			'arg' => 4,
			'path' => 16,
			'attribute' => 5,
			'funcname' => 18,
			'declaration' => 8,
			'const' => 19,
			'statement' => 9,
			'expr' => 10,
			'funccall' => 12,
			'qname' => 21,
			'condition' => 23
		}
	},
	{#State 2
		ACTIONS => {
			'' => 24
		}
	},
	{#State 3
		ACTIONS => {
			'VAR' => 25
		},
		GOTOS => {
			'qname' => 26
		}
	},
	{#State 4
		DEFAULT => -17
	},
	{#State 5
		DEFAULT => -21
	},
	{#State 6
		ACTIONS => {
			"global" => 28,
			"function" => 27
		}
	},
	{#State 7
		ACTIONS => {
			"(" => 29
		}
	},
	{#State 8
		DEFAULT => -4
	},
	{#State 9
		DEFAULT => -3
	},
	{#State 10
		DEFAULT => -7
	},
	{#State 11
		ACTIONS => {
			'VAR' => 30
		}
	},
	{#State 12
		DEFAULT => -18
	},
	{#State 13
		DEFAULT => -33
	},
	{#State 14
		DEFAULT => -5
	},
	{#State 15
		DEFAULT => -19
	},
	{#State 16
		ACTIONS => {
			"/" => 31
		},
		DEFAULT => -20
	},
	{#State 17
		ACTIONS => {
			"\$" => 11
		},
		GOTOS => {
			'arg' => 32
		}
	},
	{#State 18
		ACTIONS => {
			"(" => 33
		}
	},
	{#State 19
		DEFAULT => -16
	},
	{#State 20
		ACTIONS => {
			":" => 34,
			"(" => -30
		},
		DEFAULT => -39
	},
	{#State 21
		DEFAULT => -34
	},
	{#State 22
		DEFAULT => -35
	},
	{#State 23
		DEFAULT => -6
	},
	{#State 24
		DEFAULT => 0
	},
	{#State 25
		ACTIONS => {
			":" => 35
		},
		DEFAULT => -39
	},
	{#State 26
		DEFAULT => -32
	},
	{#State 27
		ACTIONS => {
			'VAR' => 37
		},
		GOTOS => {
			'funcname' => 36
		}
	},
	{#State 28
		ACTIONS => {
			"\$" => 11
		},
		GOTOS => {
			'arg' => 38
		}
	},
	{#State 29
		ACTIONS => {
			'STR' => 13,
			"\@" => 3,
			'VAR' => 20,
			"\$" => 11,
			"." => 22
		},
		GOTOS => {
			'test' => 39,
			'axistest' => 15,
			'arg' => 4,
			'path' => 16,
			'attribute' => 5,
			'funcname' => 18,
			'const' => 19,
			'expr' => 40,
			'funccall' => 12,
			'qname' => 21
		}
	},
	{#State 30
		DEFAULT => -31
	},
	{#State 31
		ACTIONS => {
			'VAR' => 42
		},
		GOTOS => {
			'funcname' => 18,
			'funccall' => 41,
			'qname' => 43
		}
	},
	{#State 32
		ACTIONS => {
			":" => 44
		}
	},
	{#State 33
		ACTIONS => {
			'STR' => 13,
			"\@" => 3,
			'VAR' => 20,
			"\$" => 11,
			"." => 22
		},
		DEFAULT => -26,
		GOTOS => {
			'axistest' => 15,
			'arg' => 4,
			'args' => 45,
			'path' => 16,
			'attribute' => 5,
			'funcname' => 18,
			'expr' => 46,
			'const' => 19,
			'funccall' => 12,
			'qname' => 21
		}
	},
	{#State 34
		ACTIONS => {
			":" => 47,
			'VAR' => 48
		}
	},
	{#State 35
		ACTIONS => {
			'VAR' => 48
		}
	},
	{#State 36
		ACTIONS => {
			"(" => 49
		}
	},
	{#State 37
		DEFAULT => -30
	},
	{#State 38
		ACTIONS => {
			":" => 50
		}
	},
	{#State 39
		ACTIONS => {
			")" => 51
		}
	},
	{#State 40
		ACTIONS => {
			"!=" => 52
		},
		DEFAULT => -24
	},
	{#State 41
		DEFAULT => -37
	},
	{#State 42
		ACTIONS => {
			":" => 35,
			"(" => -30
		},
		DEFAULT => -39
	},
	{#State 43
		DEFAULT => -36
	},
	{#State 44
		ACTIONS => {
			"=" => 53
		}
	},
	{#State 45
		ACTIONS => {
			")" => 54
		}
	},
	{#State 46
		ACTIONS => {
			"," => 55
		},
		DEFAULT => -28,
		GOTOS => {
			'commaArgs' => 56
		}
	},
	{#State 47
		ACTIONS => {
			'VAR' => 25
		},
		GOTOS => {
			'qname' => 57
		}
	},
	{#State 48
		DEFAULT => -38
	},
	{#State 49
		ACTIONS => {
			"\$" => 11
		},
		DEFAULT => -10,
		GOTOS => {
			'declArgs' => 59,
			'arg' => 58
		}
	},
	{#State 50
		ACTIONS => {
			"=" => 60
		}
	},
	{#State 51
		ACTIONS => {
			"{" => 61
		}
	},
	{#State 52
		ACTIONS => {
			'STR' => 13,
			"\@" => 3,
			'VAR' => 20,
			"\$" => 11,
			"." => 22
		},
		GOTOS => {
			'axistest' => 15,
			'arg' => 4,
			'path' => 16,
			'attribute' => 5,
			'funcname' => 18,
			'expr' => 62,
			'const' => 19,
			'funccall' => 12,
			'qname' => 21
		}
	},
	{#State 53
		ACTIONS => {
			'STR' => 13,
			"\@" => 3,
			'VAR' => 20,
			"\$" => 11,
			"." => 22
		},
		GOTOS => {
			'axistest' => 15,
			'arg' => 4,
			'path' => 16,
			'attribute' => 5,
			'funcname' => 18,
			'expr' => 63,
			'const' => 19,
			'funccall' => 12,
			'qname' => 21
		}
	},
	{#State 54
		DEFAULT => -22
	},
	{#State 55
		ACTIONS => {
			'STR' => 13,
			"\@" => 3,
			'VAR' => 20,
			"\$" => 11,
			"." => 22
		},
		GOTOS => {
			'axistest' => 15,
			'arg' => 4,
			'path' => 16,
			'attribute' => 5,
			'funcname' => 18,
			'expr' => 64,
			'const' => 19,
			'funccall' => 12,
			'qname' => 21
		}
	},
	{#State 56
		DEFAULT => -27
	},
	{#State 57
		DEFAULT => -25
	},
	{#State 58
		ACTIONS => {
			"," => 65
		},
		DEFAULT => -12,
		GOTOS => {
			'commaDeclArgs' => 66
		}
	},
	{#State 59
		ACTIONS => {
			")" => 67
		}
	},
	{#State 60
		ACTIONS => {
			'STR' => 13,
			"\@" => 3,
			'VAR' => 20,
			"\$" => 11,
			"." => 22
		},
		GOTOS => {
			'axistest' => 15,
			'arg' => 4,
			'path' => 16,
			'attribute' => 5,
			'funcname' => 18,
			'expr' => 68,
			'const' => 19,
			'funccall' => 12,
			'qname' => 21
		}
	},
	{#State 61
		DEFAULT => -2,
		GOTOS => {
			'statementStar' => 69
		}
	},
	{#State 62
		DEFAULT => -23
	},
	{#State 63
		DEFAULT => -14
	},
	{#State 64
		ACTIONS => {
			"," => 55
		},
		DEFAULT => -28,
		GOTOS => {
			'commaArgs' => 70
		}
	},
	{#State 65
		ACTIONS => {
			"\$" => 11
		},
		GOTOS => {
			'arg' => 71
		}
	},
	{#State 66
		DEFAULT => -11
	},
	{#State 67
		DEFAULT => -8
	},
	{#State 68
		DEFAULT => -9
	},
	{#State 69
		ACTIONS => {
			'STR' => 13,
			"}" => 72,
			"\@" => 3,
			"if" => 7,
			"declare" => 6,
			"let" => 17,
			"\$" => 11,
			'VAR' => 20,
			"." => 22
		},
		GOTOS => {
			'assignment' => 14,
			'axistest' => 15,
			'arg' => 4,
			'path' => 16,
			'attribute' => 5,
			'funcname' => 18,
			'declaration' => 8,
			'const' => 19,
			'expr' => 10,
			'statement' => 9,
			'funccall' => 12,
			'qname' => 21,
			'condition' => 23
		}
	},
	{#State 70
		DEFAULT => -29
	},
	{#State 71
		ACTIONS => {
			"," => 65
		},
		DEFAULT => -12,
		GOTOS => {
			'commaDeclArgs' => 73
		}
	},
	{#State 72
		DEFAULT => -15
	},
	{#State 73
		DEFAULT => -13
	}
],
                                  yyrules  =>
[
	[#Rule 0
		 '$start', 2, undef
	],
	[#Rule 1
		 'input', 1,
sub
#line 38 "RdalParser.yp"
{new W3C::Rdf::RdalCompileTree::XQueryExpr($_[1], $_[0])}
	],
	[#Rule 2
		 'statementStar', 0, undef
	],
	[#Rule 3
		 'statementStar', 2,
sub
#line 42 "RdalParser.yp"
{push (@{$_[1]}, $_[2]); $_[1]}
	],
	[#Rule 4
		 'statement', 1, undef
	],
	[#Rule 5
		 'statement', 1, undef
	],
	[#Rule 6
		 'statement', 1, undef
	],
	[#Rule 7
		 'statement', 1, undef
	],
	[#Rule 8
		 'declaration', 6,
sub
#line 52 "RdalParser.yp"
{new W3C::Rdf::RdalCompileTree::FuncDecl($_[3], $_[5], $_[0])}
	],
	[#Rule 9
		 'declaration', 6,
sub
#line 54 "RdalParser.yp"
{new W3C::Rdf::RdalCompileTree::GlobalDecl($_[3], $_[6], $_[0])}
	],
	[#Rule 10
		 'declArgs', 0, undef
	],
	[#Rule 11
		 'declArgs', 2,
sub
#line 58 "RdalParser.yp"
{[$_[1], @{$_[2]}]}
	],
	[#Rule 12
		 'commaDeclArgs', 0,
sub
#line 61 "RdalParser.yp"
{[]}
	],
	[#Rule 13
		 'commaDeclArgs', 3,
sub
#line 62 "RdalParser.yp"
{unshift (@{$_[3]}, $_[2]); $_[3]}
	],
	[#Rule 14
		 'assignment', 5,
sub
#line 65 "RdalParser.yp"
{new W3C::Rdf::RdalCompileTree::Assign($_[2], $_[5], $_[0])}
	],
	[#Rule 15
		 'condition', 7,
sub
#line 69 "RdalParser.yp"
{new W3C::Rdf::RdalCompileTree::Condition($_[3], $_[6], $_[0])}
	],
	[#Rule 16
		 'expr', 1, undef
	],
	[#Rule 17
		 'expr', 1, undef
	],
	[#Rule 18
		 'expr', 1, undef
	],
	[#Rule 19
		 'expr', 1, undef
	],
	[#Rule 20
		 'expr', 1, undef
	],
	[#Rule 21
		 'expr', 1, undef
	],
	[#Rule 22
		 'funccall', 4,
sub
#line 80 "RdalParser.yp"
{new W3C::Rdf::RdalCompileTree::FuncCall($_[1], $_[3], $_[0])}
	],
	[#Rule 23
		 'test', 3,
sub
#line 83 "RdalParser.yp"
{new W3C::Rdf::RdalCompileTree::Ne($_[1], $_[3], $_[0])}
	],
	[#Rule 24
		 'test', 1,
sub
#line 84 "RdalParser.yp"
{$_[1]}
	],
	[#Rule 25
		 'axistest', 4,
sub
#line 87 "RdalParser.yp"
{new W3C::Rdf::RdalCompileTree::AxisTest($_[1], $_[4], $_[0])}
	],
	[#Rule 26
		 'args', 0, undef
	],
	[#Rule 27
		 'args', 2,
sub
#line 91 "RdalParser.yp"
{[$_[1], @{$_[2]}]}
	],
	[#Rule 28
		 'commaArgs', 0,
sub
#line 94 "RdalParser.yp"
{[]}
	],
	[#Rule 29
		 'commaArgs', 3,
sub
#line 95 "RdalParser.yp"
{unshift (@{$_[3]}, $_[2]); $_[3]}
	],
	[#Rule 30
		 'funcname', 1, undef
	],
	[#Rule 31
		 'arg', 2,
sub
#line 101 "RdalParser.yp"
{new W3C::Rdf::RdalCompileTree::Arg($_[2], $_[0])}
	],
	[#Rule 32
		 'attribute', 2,
sub
#line 104 "RdalParser.yp"
{new W3C::Rdf::RdalCompileTree::Attribute($_[2], $_[0])}
	],
	[#Rule 33
		 'const', 1,
sub
#line 107 "RdalParser.yp"
{new W3C::Rdf::RdalCompileTree::Literal($_[1], $_[0])}
	],
	[#Rule 34
		 'path', 1, undef
	],
	[#Rule 35
		 'path', 1,
sub
#line 111 "RdalParser.yp"
{new W3C::Rdf::RdalCompileTree::Spot($_[0])}
	],
	[#Rule 36
		 'path', 3, undef
	],
	[#Rule 37
		 'path', 3, undef
	],
	[#Rule 38
		 'qname', 3,
sub
#line 116 "RdalParser.yp"
{new W3C::Rdf::RdalCompileTree::QName($_[1], $_[3], $_[0])}
	],
	[#Rule 39
		 'qname', 1,
sub
#line 117 "RdalParser.yp"
{new W3C::Rdf::RdalCompileTree::QName('',    $_[1], $_[0])}
	]
],
                                  @_);
    bless($self,$class);
}

#line 120 "RdalParser.yp"


sub nextChunk {
    my ($self) = @_;
    my $ret = $self->YYData->{RDAL_STRING};
    $self->YYData->{RDAL_STRING} = undef;
    return $ret;
}

sub parse {
    my ($self, @args) = @_;
    return $self->SUPER::parse(@args);
}

sub _Error {
    my ($self) = @_;
    if (exists $self->YYData->{EXCEPTION}) {
	&throw($self->YYData->{EXCEPTION});
    }
    if (exists $self->YYData->{ERRMSG}) {
	&throw(new W3C::Util::YappDriver::GrammarException(-message => $self->YYData->{ERRMSG}, 
							   -location => $self->YYData->{LOCATION}));
        delete $self->YYData->{ERRMSG};
        return;
    }
    &throw(new W3C::Util::YappDriver::MesgYappContextException($self, -location => $self->YYData->{LOCATION}));
    my $trimmed = $self->YYData->{INPUT};
    $trimmed =~ s/[\r\n]*\Z//m;

    my ($token, $value, $expect, $data) = ($self->YYCurtok(), $self->YYCurval(), $self->YYExpect(), $self->YYData);
    my $tokenStr = defined $token && $token ne $value ? "$token " : '';
    my $valueStr = defined $value ? "'$value'" : 'EOF';
    my $dataStr = ref $data eq 'HASH' ? join ("\n", map {"$_: $data->{$_}"} keys %$data) : $data;
    $dataStr = substr($trimmed, $self->YYData->{my_LASTPOS}, 20);
    print "expected '$expect', got $tokenStr$valueStr at \"$dataStr\"\n";

    my $before = substr($trimmed, 0, $self->YYData->{my_LASTPOS}+1);
    $before =~ m/([^\r\n]*)\Z/m;
    my $column = length ($1) - 1;
    my $after = substr($trimmed, $self->YYData->{my_LASTPOS}+1);

    $after =~ m/([^\r\n]*)[\r\n]?(.*)/s;
    my ($line, $last) = ($1, $2);
    print "$before$line\n";
    print '=' x $column, "^\n";
    print "$last\n" if ($last);
    foreach my $entry (@{$self->{STACK}}) {
	print join (' | ', @$entry),"\n";
    }
}

sub ErrorStrArgs {
    my ($self) = @_;
    my $data = $self->YYData;
    my $ret = [[@{$self->{STACK}}], 
	       $data->{INPUT}, 
	       pos $data->{INPUT}, 
	       $data->{my_LASTPOS}];
    return $ret;
}

my $KeyWords = {'declare' => undef, 
		'function' => undef, 
		'global' => undef, 
		'if' => undef, 
		'let' => undef};

sub _Lexer {
    my($self)=shift;

    if (defined $self->YYData->{INPUT} && pos $self->YYData->{INPUT} < length ($self->YYData->{INPUT})) {
    } else {
	if ($self->YYData->{my_DONE}) {
	    return ('', undef);
	}
	if (0) {
	if (!($self->YYData->{INPUT} = $self->nextChunk())) {
	    undef $self->YYData->{INPUT};
	    return ('', undef);
	}
	} else {
	my $pos = pos $self->YYData->{INPUT};
	my $chunk = $self->nextChunk();
	#print "\nchunk: $chunk\n";
	if (!$chunk) {
	    undef $self->YYData->{INPUT};
	    return ('', undef);
	}
	$self->YYData->{INPUT} .= $chunk;
	pos $self->YYData->{INPUT} = $pos;
	}
	#my $txt = $self->YYData->{INPUT};
	#print "\ntxt: $txt\n";
    }

    my ($token, $value) = ('', undef);
    while ($self->YYData->{INPUT} =~ m/\G\s*\#[^\n]*\n/gc) {}
    $self->YYData->{INPUT} =~ m/\G\s*/gc;
    $self->YYData->{my_LASTPOS} = pos $self->YYData->{INPUT};
    if (($self->YYData->{INPUT} =~ m/\G\"([^\"]*)\"/gc || 
	 $self->YYData->{INPUT} =~ m/\G\'([^\']*)\'/gc)) {
	($token, $value) = ('STR', $1);
    } elsif ($self->YYData->{INPUT} =~ m/\G([0-9]+)/gc) {
	($token, $value) = ('INT',$1);
    } elsif ($self->YYData->{INPUT} =~ m/\G([0-9]+(?:\.[0-9]+)?)/gc) {
	($token, $value) = ('FLOAT',$1);
    } elsif ($self->YYData->{INPUT} =~ m/\G([A-Za-z][A-Za-z0-9_-]*)/gc) {
	($token, $value) = (exists $KeyWords->{$1} ? $1 : 'VAR' ,$1);
    # very pathetic attempt at a file regexp
#    } elsif ($self->YYData->{INPUT} =~ m/\G(self::)?([\.\/][\.\;\~\|\&\w\/\+\-]*)/gc) {
#	($token, $value) = ('FILE', $1);
    } elsif ($self->YYData->{INPUT} =~ m/\G(==|\!=|<=|>=|\|\||\&\&)/gc) {
	($token, $value) = ($1,$1);
    } elsif ($self->YYData->{INPUT} =~ m/\G(.)/gc) {
	($token, $value) = ($1,$1);
    }
    my $pos = pos $self->YYData->{INPUT};
    # print "\n$pos,$token,$value\n";
    return ($token, $value);
}

package W3C::Rdf::RdalParser;
use W3C::Util::Exception;
@W3C::Rdf::RdalParser::ISA = qw(W3C::Rdf::_RdalParser);

sub new {
    my ($proto, $rdalString, $rdalHandler, $context, @yappParms) = @_;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new(@yappParms);
    $self->YYData->{RDAL_STRING} = $rdalString;
    $self->YYData->{CONTEXT} = $context;
 
    $self->YYData->{RDAL_HANDLER} = $rdalHandler;
    return $self;
}

package W3C::Rdf::RdalParser;

1;

__END__

=head1 NAME

W3C::Rdf::RdalParser - Parse RDAL schema annotations

=head1 SYNOPSIS

  use W3C::Rdf::RdalParser;
  my $parser = new W3C::Rdf::RdalParser();
  my $grammar = $parser->parse('...');

=head1 DESCRIPTION

B<RdalParser> parses RDAL schema annotations and stores them in an
B<RdalCompileTree>. These annotations define semantic actions associated
with productions in a schema laguage

This module is undocumented. See RdalParser.yp for example invocations.

=head1 CLASS HIERARCHY

The isa2dot program will produce a cool graphic for viewing this hierarchy:

  isa2dot -o TB -f s/W3C::Rdf::Rdal:://ignore > sv.dot

This module is part of the W3C::Rdf CPAN module.

=head1 AUTHOR

Eric Prud'hommeaux <eric@w3.org>

=head1 SEE ALSO

L<W3C::Rdf::RdalCompileTree>

=cut


1;
