#!/usr/bin/perl
#Copyright Massachusetts Institute of technology, 2007.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium
#This file is PUBLIC DOMAIN.

# SPAT.pm -- Algae parse tree auxiliary for SPARQL Annotations
# http://www.w3.org/2007/01/SPAT/
# 
# $Id: SPAT.pm,v 1.1 2007/01/28 19:43:21 eric Exp $

use strict;
package W3C::Rdf::SPAT;
use W3C::Util::Exception;
require Exporter;
@W3C::Rdf::XPAT::ISA = qw(Exporter);
use W3C::Rdf::Algae2 qw(); # &getTripleAttribute &setTripleAttribute);
use W3C::Rdf::AlgaeCompileTree qw(); # &getTripleAttribute &setTripleAttribute);

@W3C::Rdf::AlgaeCompileTree::XPath::ISA = qw(W3C::Rdf::AlgaeCompileTree::Var);

package W3C::Rdf::AlgaeCompileTree::XPath;
use W3C::Util::Exception;
sub new {
    my ($proto, $string, $context, $list, @exprParms) = @_;
    my $class = ref($proto) || $proto;

    "$context" =~ /0x(\w+)/;
    my $contextStr = $1;
    my $self = $class->SUPER::new("XPath($string, $contextStr)", 1, @exprParms);

    my @prefixedPaths = split ('/', $string);
    $self->{Paths} = [];
    foreach my $prefixedPath (@prefixedPaths) {
	if ($prefixedPath eq '.') {
	    push (@{$self->{Paths}}, ".");
	} else {
	    my ($ns, $localName, $prefix) = $self->{PARSER}->mapNamespace($prefixedPath);
	    push (@{$self->{Paths}}, "{$ns}$localName");
	}
    }
    # $string = join ('/', @{$self->{Paths}});

    $self->{STRING} = $string;
    $self->{Context} = $context;
    $self->{ContextStr} = $contextStr;
    push (@$list, $self); # notify someone of our existence.
    return $self;
}
sub addSubstitution {
    my ($self, $substitutions) = @_;
    foreach my $path (@{$self->{Paths}}[0..-2]) {
	$substitutions = $substitutions->{$path};
    }
    $substitutions->{$self->{Paths}[-1]} = $self;
}
sub toString {
    my ($self, %flags) = &main::_defaultPrec(@_);
    my $str = $self->{STRING};
    return "XPath($str, $self->{ContextStr})";
    # return $self->{INTERNED}->toString;
}

