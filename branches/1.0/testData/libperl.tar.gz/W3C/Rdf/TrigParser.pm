#!/usr/bin/perl
####################################################################
#
#    This file was generated using Parse::Yapp version 1.05.
#
#        Don't edit this file, use source file instead.
#
#             ANY CHANGE MADE HERE WILL BE LOST !
#
####################################################################
package W3C::Rdf::_TrigParser;
use vars qw ( @ISA );
use strict;

@ISA= qw ( Parse::Yapp::Driver );
# use Parse::Yapp::Driver; @@ replaced by W3C::Util::YappDriver

#line 9 "TrigParser.yp"

    #BEGIN {unshift@INC,('../..');}
    use W3C::Util::YappDriver;
    @ISA= qw (W3C::Util::YappDriver);

    use vars qw($LEX_Token $LEX_Comment $LEX_Language $LEX_RelURI);
    ($LEX_Token $LEX_Comment $LEX_Language $LEX_RelURI) = (\ "Token", \ "Comment", \ "Languae", \ "RelURI");
    use W3C::Rdf::AlgaeCompileTree;


sub new {
        my($class)=shift;
        ref($class)
    and $class=ref($class);

    my($self)=$class->SUPER::new( yyversion => '1.05',
                                  yystates =>
[
	{#State 0
		DEFAULT => -2,
		GOTOS => {
			'TriGDoc' => 2,
			'statementStar' => 1
		}
	},
	{#State 1
		ACTIONS => {
			":" => 3,
			'WS' => 9,
			"<" => 6,
			"#" => 12,
			"\@prefix" => 16
		},
		DEFAULT => -1,
		GOTOS => {
			'resource' => 8,
			'wsPlus' => 7,
			'graphName' => 5,
			'uriref' => 4,
			'comment' => 11,
			'statement' => 10,
			'qname' => 13,
			'directive' => 14,
			'graph' => 15
		}
	},
	{#State 2
		ACTIONS => {
			'' => 17
		}
	},
	{#State 3
		ACTIONS => {
			'NAME' => 18
		},
		GOTOS => {
			'name' => 19
		}
	},
	{#State 4
		DEFAULT => -52
	},
	{#State 5
		DEFAULT => -64,
		GOTOS => {
			'wsStar' => 20
		}
	},
	{#State 6
		DEFAULT => -58,
		GOTOS => {
			'@3-1' => 21
		}
	},
	{#State 7
		ACTIONS => {
			'WS' => 22
		},
		DEFAULT => -7
	},
	{#State 8
		DEFAULT => -15
	},
	{#State 9
		DEFAULT => -62
	},
	{#State 10
		DEFAULT => -3
	},
	{#State 11
		DEFAULT => -6
	},
	{#State 12
		DEFAULT => -25,
		GOTOS => {
			'@1-1' => 23
		}
	},
	{#State 13
		DEFAULT => -53
	},
	{#State 14
		DEFAULT => -64,
		GOTOS => {
			'wsStar' => 24
		}
	},
	{#State 15
		DEFAULT => -64,
		GOTOS => {
			'wsStar' => 25
		}
	},
	{#State 16
		ACTIONS => {
			'WS' => 9
		},
		GOTOS => {
			'wsPlus' => 26
		}
	},
	{#State 17
		DEFAULT => 0
	},
	{#State 18
		DEFAULT => -61
	},
	{#State 19
		ACTIONS => {
			":" => 27
		}
	},
	{#State 20
		ACTIONS => {
			'WS' => 28,
			":-" => 29
		},
		DEFAULT => -10,
		GOTOS => {
			'impliesOpt' => 30
		}
	},
	{#State 21
		ACTIONS => {
			'RELATIVEURI' => 31
		}
	},
	{#State 22
		DEFAULT => -63
	},
	{#State 23
		ACTIONS => {
			'COMMENT' => 32
		}
	},
	{#State 24
		ACTIONS => {
			'WS' => 28,
			"." => 33
		}
	},
	{#State 25
		ACTIONS => {
			'WS' => 28
		},
		DEFAULT => -5
	},
	{#State 26
		ACTIONS => {
			":" => 34,
			'WS' => 22,
			'NAME' => 18
		},
		GOTOS => {
			'prefixID' => 36,
			'name' => 35
		}
	},
	{#State 27
		ACTIONS => {
			":" => 37
		}
	},
	{#State 28
		DEFAULT => -65
	},
	{#State 29
		DEFAULT => -11
	},
	{#State 30
		DEFAULT => -64,
		GOTOS => {
			'wsStar' => 38
		}
	},
	{#State 31
		DEFAULT => -59,
		GOTOS => {
			'@4-3' => 39
		}
	},
	{#State 32
		DEFAULT => -26
	},
	{#State 33
		DEFAULT => -64,
		GOTOS => {
			'wsStar' => 40
		}
	},
	{#State 34
		DEFAULT => -56
	},
	{#State 35
		ACTIONS => {
			":" => 41
		}
	},
	{#State 36
		ACTIONS => {
			'WS' => 9
		},
		GOTOS => {
			'wsPlus' => 42
		}
	},
	{#State 37
		ACTIONS => {
			'NAME' => 18
		},
		GOTOS => {
			'name' => 43
		}
	},
	{#State 38
		ACTIONS => {
			'WS' => 28,
			"{" => 44
		}
	},
	{#State 39
		ACTIONS => {
			">" => 45
		}
	},
	{#State 40
		ACTIONS => {
			'WS' => 28
		},
		DEFAULT => -4
	},
	{#State 41
		DEFAULT => -57
	},
	{#State 42
		ACTIONS => {
			'WS' => 22,
			"<" => 6
		},
		GOTOS => {
			'uriref' => 46
		}
	},
	{#State 43
		ACTIONS => {
			'NAME' => 18
		},
		GOTOS => {
			'name' => 47
		}
	},
	{#State 44
		ACTIONS => {
			"}" => -12,
			'WS' => -12
		},
		DEFAULT => -64,
		GOTOS => {
			'wsStar' => 48,
			'tripleCommentStar' => 49
		}
	},
	{#State 45
		DEFAULT => -60
	},
	{#State 46
		DEFAULT => -8
	},
	{#State 47
		ACTIONS => {
			":" => 50
		}
	},
	{#State 48
		ACTIONS => {
			'INTEGER' => 58,
			":" => 3,
			"<" => 6,
			"[]" => 61,
			'TYPEDSTRING' => 63,
			"(" => 65,
			'WS' => 28,
			"#" => 12,
			'QUOTEDSTRING' => 67,
			"[" => 56,
			"_:" => 68
		},
		GOTOS => {
			'uriref' => 4,
			'nodeID' => 60,
			'subject' => 59,
			'collection' => 51,
			'datatypeString' => 62,
			'resource' => 64,
			'literal' => 52,
			'triples' => 53,
			'comment' => 66,
			'integer' => 54,
			'qname' => 13,
			'blank' => 55,
			'langString' => 57
		}
	},
	{#State 49
		DEFAULT => -64,
		GOTOS => {
			'wsStar' => 69
		}
	},
	{#State 50
		ACTIONS => {
			'NAME' => 18
		},
		GOTOS => {
			'name' => 70
		}
	},
	{#State 51
		DEFAULT => -46
	},
	{#State 52
		DEFAULT => -29
	},
	{#State 53
		ACTIONS => {
			"." => 71
		}
	},
	{#State 54
		DEFAULT => -36
	},
	{#State 55
		DEFAULT => -28
	},
	{#State 56
		DEFAULT => -64,
		GOTOS => {
			'wsStar' => 72
		}
	},
	{#State 57
		DEFAULT => -34
	},
	{#State 58
		DEFAULT => -42
	},
	{#State 59
		ACTIONS => {
			'WS' => 9
		},
		GOTOS => {
			'wsPlus' => 73
		}
	},
	{#State 60
		DEFAULT => -43
	},
	{#State 61
		DEFAULT => -44
	},
	{#State 62
		DEFAULT => -35
	},
	{#State 63
		ACTIONS => {
			":" => 3,
			"<" => 6
		},
		GOTOS => {
			'uriref' => 74,
			'qname' => 75
		}
	},
	{#State 64
		DEFAULT => -27
	},
	{#State 65
		ACTIONS => {
			'INTEGER' => 58,
			":" => 3,
			"<" => 6,
			"[]" => 61,
			'TYPEDSTRING' => 63,
			"(" => 65,
			"[" => 56,
			'QUOTEDSTRING' => 67,
			")" => 80,
			"_:" => 68
		},
		GOTOS => {
			'uriref' => 4,
			'object' => 76,
			'itemList' => 77,
			'nodeID' => 60,
			'collection' => 51,
			'datatypeString' => 62,
			'resource' => 81,
			'literal' => 78,
			'integer' => 54,
			'qname' => 13,
			'blank' => 79,
			'langString' => 57
		}
	},
	{#State 66
		DEFAULT => -14
	},
	{#State 67
		ACTIONS => {
			"\@" => 82
		},
		DEFAULT => -37
	},
	{#State 68
		ACTIONS => {
			'NAME' => 18
		},
		GOTOS => {
			'name' => 83
		}
	},
	{#State 69
		ACTIONS => {
			'WS' => 28
		},
		DEFAULT => -64,
		GOTOS => {
			'wsStar' => 84
		}
	},
	{#State 70
		DEFAULT => -55
	},
	{#State 71
		DEFAULT => -13
	},
	{#State 72
		ACTIONS => {
			":" => 3,
			'WS' => 28,
			"a" => 86,
			"<" => 6
		},
		GOTOS => {
			'resource' => 89,
			'uriref' => 4,
			'predicate' => 87,
			'verb' => 88,
			'predicateObjectList' => 85,
			'qname' => 13
		}
	},
	{#State 73
		ACTIONS => {
			":" => 3,
			'WS' => 22,
			"a" => 86,
			"<" => 6
		},
		GOTOS => {
			'resource' => 89,
			'uriref' => 4,
			'predicate' => 87,
			'verb' => 88,
			'predicateObjectList' => 90,
			'qname' => 13
		}
	},
	{#State 74
		DEFAULT => -40
	},
	{#State 75
		DEFAULT => -41
	},
	{#State 76
		ACTIONS => {
			'WS' => 9
		},
		DEFAULT => -48,
		GOTOS => {
			'wsPlus' => 92,
			'objectStar' => 91
		}
	},
	{#State 77
		ACTIONS => {
			")" => 93
		}
	},
	{#State 78
		DEFAULT => -33
	},
	{#State 79
		DEFAULT => -32
	},
	{#State 80
		DEFAULT => -50
	},
	{#State 81
		DEFAULT => -31
	},
	{#State 82
		DEFAULT => -38,
		GOTOS => {
			'@2-2' => 94
		}
	},
	{#State 83
		DEFAULT => -54
	},
	{#State 84
		ACTIONS => {
			"}" => 95,
			'WS' => 28
		}
	},
	{#State 85
		DEFAULT => -64,
		GOTOS => {
			'wsStar' => 96
		}
	},
	{#State 86
		DEFAULT => -24
	},
	{#State 87
		DEFAULT => -23
	},
	{#State 88
		ACTIONS => {
			'WS' => 9
		},
		GOTOS => {
			'wsPlus' => 97
		}
	},
	{#State 89
		DEFAULT => -30
	},
	{#State 90
		DEFAULT => -16
	},
	{#State 91
		DEFAULT => -47
	},
	{#State 92
		ACTIONS => {
			'INTEGER' => 58,
			":" => 3,
			"<" => 6,
			"[]" => 61,
			'TYPEDSTRING' => 63,
			"(" => 65,
			'WS' => 22,
			'QUOTEDSTRING' => 67,
			"[" => 56,
			"_:" => 68
		},
		GOTOS => {
			'uriref' => 4,
			'object' => 98,
			'nodeID' => 60,
			'collection' => 51,
			'datatypeString' => 62,
			'literal' => 78,
			'resource' => 81,
			'integer' => 54,
			'qname' => 13,
			'blank' => 79,
			'langString' => 57
		}
	},
	{#State 93
		DEFAULT => -51
	},
	{#State 94
		ACTIONS => {
			'LANGUAGE' => 99
		}
	},
	{#State 95
		ACTIONS => {
			":" => 3,
			"<" => 6
		},
		GOTOS => {
			'resource' => 8,
			'uriref' => 4,
			'graphName' => 100,
			'qname' => 13
		}
	},
	{#State 96
		ACTIONS => {
			'WS' => 28,
			"]" => 101
		}
	},
	{#State 97
		ACTIONS => {
			'INTEGER' => 58,
			":" => 3,
			"<" => 6,
			"[]" => 61,
			'TYPEDSTRING' => 63,
			"(" => 65,
			'WS' => 22,
			'QUOTEDSTRING' => 67,
			"[" => 56,
			"_:" => 68
		},
		GOTOS => {
			'uriref' => 4,
			'object' => 102,
			'nodeID' => 60,
			'collection' => 51,
			'datatypeString' => 62,
			'literal' => 78,
			'resource' => 81,
			'objectList' => 103,
			'integer' => 54,
			'qname' => 13,
			'blank' => 79,
			'langString' => 57
		}
	},
	{#State 98
		DEFAULT => -49
	},
	{#State 99
		DEFAULT => -39
	},
	{#State 100
		DEFAULT => -64,
		GOTOS => {
			'wsStar' => 104
		}
	},
	{#State 101
		DEFAULT => -45
	},
	{#State 102
		DEFAULT => -21,
		GOTOS => {
			'continueObjectStar' => 105
		}
	},
	{#State 103
		DEFAULT => -18,
		GOTOS => {
			'continueObjectListStar' => 106
		}
	},
	{#State 104
		ACTIONS => {
			'WS' => 28,
			":-" => 29
		},
		DEFAULT => -10,
		GOTOS => {
			'impliesOpt' => 107
		}
	},
	{#State 105
		ACTIONS => {
			'WS' => 9
		},
		DEFAULT => -20,
		GOTOS => {
			'wsPlus' => 108
		}
	},
	{#State 106
		ACTIONS => {
			'WS' => 9
		},
		DEFAULT => -17,
		GOTOS => {
			'wsPlus' => 109
		}
	},
	{#State 107
		DEFAULT => -64,
		GOTOS => {
			'wsStar' => 110
		}
	},
	{#State 108
		ACTIONS => {
			'WS' => 22,
			"," => 111
		}
	},
	{#State 109
		ACTIONS => {
			'WS' => 22,
			";" => 112
		}
	},
	{#State 110
		ACTIONS => {
			'WS' => 28,
			"{" => 113
		}
	},
	{#State 111
		DEFAULT => -64,
		GOTOS => {
			'wsStar' => 114
		}
	},
	{#State 112
		DEFAULT => -64,
		GOTOS => {
			'wsStar' => 115
		}
	},
	{#State 113
		ACTIONS => {
			"#" => -64
		},
		DEFAULT => -12,
		GOTOS => {
			'wsStar' => 48,
			'tripleCommentStar' => 116
		}
	},
	{#State 114
		ACTIONS => {
			'INTEGER' => 58,
			":" => 3,
			"<" => 6,
			"[]" => 61,
			'TYPEDSTRING' => 63,
			"(" => 65,
			'WS' => 28,
			'QUOTEDSTRING' => 67,
			"[" => 56,
			"_:" => 68
		},
		GOTOS => {
			'uriref' => 4,
			'object' => 117,
			'nodeID' => 60,
			'collection' => 51,
			'datatypeString' => 62,
			'literal' => 78,
			'resource' => 81,
			'integer' => 54,
			'qname' => 13,
			'blank' => 79,
			'langString' => 57
		}
	},
	{#State 115
		ACTIONS => {
			":" => 3,
			'WS' => 28,
			"a" => 86,
			"<" => 6
		},
		GOTOS => {
			'resource' => 89,
			'uriref' => 4,
			'predicate' => 87,
			'verb' => 118,
			'qname' => 13
		}
	},
	{#State 116
		DEFAULT => -64,
		GOTOS => {
			'wsStar' => 119
		}
	},
	{#State 117
		DEFAULT => -22
	},
	{#State 118
		ACTIONS => {
			'WS' => 9
		},
		GOTOS => {
			'wsPlus' => 120
		}
	},
	{#State 119
		ACTIONS => {
			'INTEGER' => 58,
			":" => 3,
			"<" => 6,
			"[]" => 61,
			'TYPEDSTRING' => 63,
			"(" => 65,
			'WS' => 28,
			'QUOTEDSTRING' => 67,
			"[" => 56,
			"_:" => 68
		},
		GOTOS => {
			'uriref' => 4,
			'subject' => 59,
			'nodeID' => 60,
			'collection' => 51,
			'datatypeString' => 62,
			'resource' => 64,
			'literal' => 52,
			'triples' => 121,
			'integer' => 54,
			'qname' => 13,
			'blank' => 55,
			'langString' => 57
		}
	},
	{#State 120
		ACTIONS => {
			'INTEGER' => 58,
			":" => 3,
			"<" => 6,
			"[]" => 61,
			'TYPEDSTRING' => 63,
			"(" => 65,
			'WS' => 22,
			'QUOTEDSTRING' => 67,
			"[" => 56,
			"_:" => 68
		},
		GOTOS => {
			'uriref' => 4,
			'object' => 102,
			'nodeID' => 60,
			'collection' => 51,
			'datatypeString' => 62,
			'literal' => 78,
			'resource' => 81,
			'objectList' => 122,
			'integer' => 54,
			'qname' => 13,
			'blank' => 79,
			'langString' => 57
		}
	},
	{#State 121
		DEFAULT => -64,
		GOTOS => {
			'wsStar' => 123
		}
	},
	{#State 122
		DEFAULT => -19
	},
	{#State 123
		ACTIONS => {
			"}" => 124,
			'WS' => 28
		}
	},
	{#State 124
		DEFAULT => -9
	}
],
                                  yyrules  =>
[
	[#Rule 0
		 '$start', 2, undef
	],
	[#Rule 1
		 'TriGDoc', 1, undef
	],
	[#Rule 2
		 'statementStar', 0, undef
	],
	[#Rule 3
		 'statementStar', 2, undef
	],
	[#Rule 4
		 'statement', 4, undef
	],
	[#Rule 5
		 'statement', 2, undef
	],
	[#Rule 6
		 'statement', 1, undef
	],
	[#Rule 7
		 'statement', 1, undef
	],
	[#Rule 8
		 'directive', 5, undef
	],
	[#Rule 9
		 'graph', 19, undef
	],
	[#Rule 10
		 'impliesOpt', 0, undef
	],
	[#Rule 11
		 'impliesOpt', 1, undef
	],
	[#Rule 12
		 'tripleCommentStar', 0, undef
	],
	[#Rule 13
		 'tripleCommentStar', 3, undef
	],
	[#Rule 14
		 'tripleCommentStar', 2, undef
	],
	[#Rule 15
		 'graphName', 1, undef
	],
	[#Rule 16
		 'triples', 3, undef
	],
	[#Rule 17
		 'predicateObjectList', 4, undef
	],
	[#Rule 18
		 'continueObjectListStar', 0, undef
	],
	[#Rule 19
		 'continueObjectListStar', 7, undef
	],
	[#Rule 20
		 'objectList', 2, undef
	],
	[#Rule 21
		 'continueObjectStar', 0, undef
	],
	[#Rule 22
		 'continueObjectStar', 5, undef
	],
	[#Rule 23
		 'verb', 1, undef
	],
	[#Rule 24
		 'verb', 1, undef
	],
	[#Rule 25
		 '@1-1', 0,
sub
#line 89 "TrigParser.yp"
{$_[0]->_Expect($LEX_Comment)}
	],
	[#Rule 26
		 'comment', 3,
sub
#line 89 "TrigParser.yp"
{$_[0]->_Expect($LEX_Token)}
	],
	[#Rule 27
		 'subject', 1, undef
	],
	[#Rule 28
		 'subject', 1, undef
	],
	[#Rule 29
		 'subject', 1, undef
	],
	[#Rule 30
		 'predicate', 1, undef
	],
	[#Rule 31
		 'object', 1, undef
	],
	[#Rule 32
		 'object', 1, undef
	],
	[#Rule 33
		 'object', 1, undef
	],
	[#Rule 34
		 'literal', 1, undef
	],
	[#Rule 35
		 'literal', 1, undef
	],
	[#Rule 36
		 'literal', 1, undef
	],
	[#Rule 37
		 'langString', 1, undef
	],
	[#Rule 38
		 '@2-2', 0,
sub
#line 116 "TrigParser.yp"
{$_[0]->_Expect($LEX_Language)}
	],
	[#Rule 39
		 'langString', 4,
sub
#line 116 "TrigParser.yp"
{$_[0]->_Expect($Token)}
	],
	[#Rule 40
		 'datatypeString', 2, undef
	],
	[#Rule 41
		 'datatypeString', 2, undef
	],
	[#Rule 42
		 'integer', 1, undef
	],
	[#Rule 43
		 'blank', 1, undef
	],
	[#Rule 44
		 'blank', 1, undef
	],
	[#Rule 45
		 'blank', 5, undef
	],
	[#Rule 46
		 'blank', 1, undef
	],
	[#Rule 47
		 'itemList', 2, undef
	],
	[#Rule 48
		 'objectStar', 0, undef
	],
	[#Rule 49
		 'objectStar', 2, undef
	],
	[#Rule 50
		 'collection', 2, undef
	],
	[#Rule 51
		 'collection', 3, undef
	],
	[#Rule 52
		 'resource', 1, undef
	],
	[#Rule 53
		 'resource', 1, undef
	],
	[#Rule 54
		 'nodeID', 2, undef
	],
	[#Rule 55
		 'qname', 8, undef
	],
	[#Rule 56
		 'prefixID', 1, undef
	],
	[#Rule 57
		 'prefixID', 2, undef
	],
	[#Rule 58
		 '@3-1', 0,
sub
#line 180 "TrigParser.yp"
{$_[0]->_Expect($LEX_RelURI)}
	],
	[#Rule 59
		 '@4-3', 0,
sub
#line 180 "TrigParser.yp"
{$_[0]->_Expect($LEX_Token)}
	],
	[#Rule 60
		 'uriref', 5, undef
	],
	[#Rule 61
		 'name', 1, undef
	],
	[#Rule 62
		 'wsPlus', 1, undef
	],
	[#Rule 63
		 'wsPlus', 2, undef
	],
	[#Rule 64
		 'wsStar', 0, undef
	],
	[#Rule 65
		 'wsStar', 2, undef
	]
],
                                  @_);
    bless($self,$class);
}

#line 198 "TrigParser.yp"


#BEGIN {unshift@INC,('../..');}
use W3C::Util::Exception qw(&throw &catch);

sub _Expect {
    my ($self, $next) = @_;
    $self->YYData->{NEXT} = $next;
}

sub _Error {
    my ($self) = @_;
    if (exists $self->YYData->{EXCEPTION}) {
	&throw($self->YYData->{EXCEPTION});
    }
    if (exists $self->YYData->{ERRMSG}) {
	&throw(new W3C::Util::YappDriver::GrammarException(
				      -message => $self->YYData->{ERRMSG}, 
				      -location => $self->YYData->{LOCATION}));
        delete $self->YYData->{ERRMSG};
        return;
    }
    &throw(new W3C::Util::YappDriver::MesgYappContextException($self, 
				      -location => $self->YYData->{LOCATION}));
}

sub _Lexer {
    my($self)=shift;

    if (defined $self->YYData->{INPUT} && 
	pos $self->YYData->{INPUT} < length ($self->YYData->{INPUT})) {
    } else {
	if ($self->YYData->{my_DONE}) {
	    return ('', undef);
	}
	if (0) {
	if (!($self->YYData->{INPUT} = $self->nextChunk())) {
	    undef $self->YYData->{INPUT};
	    return ('', undef);
	}
	} else {
	my $pos = pos $self->YYData->{INPUT};
	my $chunk = $self->nextChunk();
	#print "\nchunk: $chunk\n";
	if (!$chunk) {
	    undef $self->YYData->{INPUT};
	    return ('', undef);
	}
	$self->YYData->{INPUT} .= $chunk;
	pos $self->YYData->{INPUT} = $pos;
	}
	#my $txt = $self->YYData->{INPUT};
	#print "\ntxt: $txt\n";
    }

    my ($token, $value) = ('', undef);
    while ($self->YYData->{INPUT} =~ m/\G\s*\#[^\n]*\n/gc) {}
    $self->YYData->{INPUT} =~ m/\G\s*/gc;
    $self->YYData->{my_LASTPOS} = pos $self->YYData->{INPUT};
    my $expect = $self->YYData->{NEXT};
#EOF:				End of file -- implicit in parser style
    if ($expect == $LEX_Token) {
	# LEX_Token

	# char definitions referenced below:
	# string: character* with escapes as defined in N-Triples
	# section 3.2 Strings
	# character: Unicode character range in the range U+0 to
	# U+10FFFF
	if ($self->YYData->{INPUT} =~ m/\G\"([^\"]*)\"/gc) {
	    # QUOTEDSTRING: '"' string '"'
	    # TYPEDSTRING: '"' string '"^^'
	    my $str = $1;
	    while (substr($str, length($str) - 1, 1) eq '"') {
		if ($self->YYData->{INPUT} =~ m/\G([^\"]*)\"/gc) {
		    $str = substr($str, 0, length($str) - 1).$1;
		} else {
		    &throw(new W3C::Util::YappDriver::MesgYappContextException(
				       $self, 
				       -location => $self->YYData->{LOCATION}));
		}
	    }
	    # ooh, lookahead
	    ($token, $value) = (m/\G(?=\^\^)/gc ? 
				'TYPEDSTRING' : 
				'QUOTEDSTRING', $str);
	} elsif ($self->YYData->{INPUT} =~ m/\G([0-9]+)/gc) {
	    # INTEGER: [0-9]+
	    ($token, $value) = ('INTEGER', $1);
	} elsif ($self->YYData->{INPUT} =~ m/\G([A-Za-z][A-Za-z0-9_]*)/gc) {
	    # NAME: [A-Za-z][A-Za-z0-9_]*
	    ($token, $value) = ('NAME', $1);
	} elsif ($self->YYData->{INPUT} =~ m/\G(\w+)/gc) {
	    # WS: #x9 | #xA | #xD | #x20
	    ($token, $value) = ('WS', $1);
	} else {
	    &throw(new W3C::Util::Exception(-message => 'relative URI not terminated'));
	}
    } elsif ($expect == $LEX_Comment) {
	# $LEX_Comment

	# COMMENT: ( character - ( #xD | #xA ) )*
	$self->YYData->{INPUT} =~ m/\G(.*)\n/gc) {
	($token, $value) = ('COMMENT', $1);
    } elsif ($expect == $LEX_Language) {
	# $LEX_Language

	if ($self->YYData->{INPUT} =~ m/\G([^>]+)\n/gc) {
	    # LANGUAGE: [a-z]+ ('-' [a-z0-9]+ )* encoding a language tag.
	    ($token, $value) = ('RELATIVEURI', $1);
	} else {
	    &throw(new W3C::Util::Exception(-message => 'relative URI not terminated'));
	}
    } elsif ($expect == $LEX_RelURI) {
	# $LEX_RelURI

	if ($self->YYData->{INPUT} =~ m/\G([^>]+)\n/gc) {
	    # RELATIVEURI: character* with escapes as defined in the
	    # N-Triples section 3.3 URI References. This is then used
	    # as a relative URI and resolved against the current base
	    # URI to give an absolute URI reference.
	    ($token, $value) = ('RELATIVEURI', $1);
	} else {
	    &throw(new W3C::Util::Exception(-message => 'relative URI not terminated'));
	}
    } else {
	&throw(new W3C::Util::Exception(-message => 'lexer in odd state: '.(ref $expect ? $$expect : $expect)));
    }

    my $pos = pos $self->YYData->{INPUT};
    #print "\n$pos,$token,$value\n";
    return ($token, $value);
}

sub parse {
    my ($self, @args) = @_;
    $self->YYData->{NEXT} = undef;
    return $self->SUPER::parse(@args);
}

# Provide (one) chunk of text to parse.
sub nextChunk {
    my ($self) = @_;
    #return shift (@{$self->YYData->{my_CHUNKS}});
    #return shift (@ARGV);
    return <STDIN>;
}

# Handy debugging wrapper for calling semantics actions.
sub _wrap {
    my ($self, $obj, $method, @args) = @_;
    my @ret;
    eval {
	@ret = $obj->$method(@args);
    }; if ($@) {if (my $ex = &catch('W3C::Util::CachedContextException')) {
	&throw($ex);;
    } elsif ($ex = &catch('W3C::Util::Exception')) {
	my $newEx = new 
	    W3C::Util::CachedContextException(-str => $self->YYData->{INPUT}, 
					      -pos => $self->YYData->{my_LASTPOS}+1, 
					      -errorMessage => $ex->toString);
	$newEx->assumeStackTrace($ex);
	&throw($newEx);
    } else {
	my $newEx = 
	    new W3C::Util::CachedContextException(-str => $self->YYData->{INPUT}, 
						  -pos => $self->YYData->{my_LASTPOS}+1, 
						  -errorMessage => "$obj->$method: $@");
	&throw($newEx);
    }}
    return wantarray ? @ret : $ret[-1];
}

sub printArgs {
    return;
    print ':';
    foreach my $arg (@_) {
	print " $arg";
    }
    print ' Curtok:',$_[0]->YYCurtok;
    print ' Curval:',$_[0]->YYCurval;
    print ' Expect:',$_[0]->YYExpect;
    print ' Lexer:',$_[0]->YYLexer;
    print ' Data:',$_[0]->YYData;
    print "\n";
}

# Used by -M invocation:
#   perl -MW3C::Rdf::RdqlParser -e '(new W3C::Rdf::RLRdqlParser())->Run' '...'
sub main {
    my ($self) = @_;
    $self->_Expect($LEX_Token);
    $self->Run();
}

# <parser state support>
sub newDecl {
    my ($self, $parm) = @_;
    my $ret;
    foreach my $decl (@$parm) {
	my ($subject, $propValList) = @$decl;
	foreach my $propVal (@$propValList) {
	    my ($property, $valueList) = @$propVal;
	    foreach my $valuePair (@$valueList) {
		my ($value, $constraints) = @$valuePair;
		# print $subject->toString.' '.$property->toString.' '.$value->toString."\n";
		my $toAdd = [];
		if (ref $value eq 'ARRAY') {
		    # we've got an object and a bunch of Decls about that object.
		    $toAdd = [$value->[1]];
		    $value = $value->[0];
		}
		my $newTerm = new W3C::Rdf::AlgaeCompileTree::Decl([$property, $subject, $value], 
								   $constraints, $self);
		foreach my $term ($newTerm, @$toAdd) {
		    if ($ret) {
			$ret = new W3C::Rdf::AlgaeCompileTree::Conjunction($ret, $term, $self);
		    } else {
			$ret = $term;
		    }
		}
	    }
	}
    }
    return $ret;
}

sub resolveQNames {
    my ($self) = @_;
    foreach my $qname (@{$self->YYData->{QNAMES}}) {
	$qname->resolveNS();
    }
}

# </parser state support>

package W3C::Rdf::RdqlParser;
@W3C::Rdf::RdqlParser::ISA = qw(W3C::Rdf::_RdqlParser);
sub new {
    my ($proto, $rdqlString, $algae2, $location, @yappParms) = @_;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new(@yappParms);
    $self->YYData->{RDQL_STRING} = $rdqlString;
    $self->YYData->{LOCATION} = $location;
 
    $self->YYData->{ALGAE2} = $algae2;
    $self->YYData->{QNAMES} = [];
    return $self;
}

sub nextChunk {
    my ($self) = @_;
    my $ret = $self->YYData->{RDQL_STRING};
    $self->YYData->{RDQL_STRING} = undef;
    return $ret;
}

# Interactive ReadLine parser -- under development
package W3C::Rdf::RLRdqlParser;
use W3C::Util::Exception;
use vars qw(@ISA);
@ISA = qw(W3C::Rdf::RdqlParser);
sub new {
    my ($proto, @parms) = @_;
    my $class = ref($proto) || $proto;

    # Change the parser driver to the readline driver.
    @W3C::Rdf::RdqlParser::ISA= qw (W3C::Util::rlDriver);

    my $self = $class->SUPER::new(@parms);
    $self->YYData->{ACTIONS} = [];
    return $self;
}

sub nextChunk {
    my ($self) = @_;
    my $ret = undef;
    if ($self->{rl_COMPLETE_MODE}) {
	if ($self->{rl_SO_FAR}) {
	    $ret = $self->{rl_SO_FAR};
	    $self->{rl_SO_FAR} = undef;
	    #print "nextChunk: $ret\n";
	}
    } else {
	if (@{$self->YYData->{my_CHUNKS}}) {
	    $ret = shift (@{$self->YYData->{my_CHUNKS}});
	} else {
	    #return shift (@ARGV);
	    $ret = $self->readline('')."\n";
	    #print "ret: $ret";
	}
    }
    return $ret;
}

# perl -MW3C::Rdf::RdqlParser -e '(new W3C::Rdf::RLRdqlParser())->Run' 'asdf'
# b /usr/share/perl5/Parse/Yapp/Driver.pm:343

##!/usr/bin/perl
#BEGIN {unshift@INC,('../..');}
#use W3C::Rdf::RdqlParser;
#$p = new W3C::Rdf::RLRdqlParser();
#$p->main;

#./RdqlParser "(ask '(<ab:cd> (?asdf ?s ?o)) assert '(ef:gh (?a ?b ?c)))"

1;

__END__

=head1 NAME

W3C::Rdf::RdqlParser - a Parse::Yapp grammer for the RDQL language

=head1 SYNOPSIS

  use W3C::Rdf::RdqlParser;
  my $p = new W3C::Rdf::RdqlParser($rdqlString, $query, "query.txt");
  my $actions = $p->parse($debug);
  foreach my $action (@$actions) {
    $action->delayedEvaluate($self->{RESULT_SET});
  }
  return $self->getReport();

=head1 DESCRIPTION

The RdqlParser module binds a yapp grammar to semantic actions that build an
AlgaeCompileTree. In general, client applicatiosn have no direct interaction
with RdqlParser. Devlopers wishing to extend the RDQL query language
  http://www.w3.org/Submission/RDQL/

will need the perl yapp modules. The Makefile included with the W3C::Rdf CPAN
module has a target to re-compile the RdqlParser grammar. Invoke this with
  make RdqlParser.pm
It is likely that someone extending the RdqlParser grammar will also want to
extended AlgaeCompileTree.

This module is part of the W3C::Rdf CPAN module.

=head1 AUTHOR

Eric Prud\'hommeaux <eric@w3.org>

=head1 SEE ALSO

W3C::Rdf::AlgaeCompileTree(3) W3C::Rdf::Algae2(3) perl(1).

=cut

1;
