#!/usr/bin/perl
####################################################################
#
#    This file was generated using Parse::Yapp version 1.05.
#
#        Don't edit this file, use source file instead.
#
#             ANY CHANGE MADE HERE WILL BE LOST !
#
####################################################################
package W3C::Rdf::_SeRQLParser;
use vars qw ( @ISA );
use strict;

@ISA= qw ( Parse::Yapp::Driver );
# use Parse::Yapp::Driver; @@ replaced by W3C::Util::YappDriver

#line 10 "SeRQLParser.yp"

    #BEGIN {unshift@INC,('../..');}
    use W3C::Util::YappDriver;
    @ISA= qw (W3C::Util::YappDriver);

    use W3C::Util::Exception;
    use W3C::Rdf::AlgaeCompileTree qw($DISJUNCTION $NEGATION $OUTER);


sub new {
        my($class)=shift;
        ref($class)
    and $class=ref($class);

    my($self)=$class->SUPER::new( yyversion => '1.05',
                                  yystates =>
[
	{#State 0
		ACTIONS => {
			'SELECT' => 4,
			'CONSTRUCT' => 6
		},
		GOTOS => {
			'Query' => 1,
			'Select_query' => 2,
			'Compilation_unit' => 3,
			'Construct_query' => 5
		}
	},
	{#State 1
		ACTIONS => {
			'USING' => 8
		},
		DEFAULT => -1,
		GOTOS => {
			'Namespace_list' => 7
		}
	},
	{#State 2
		DEFAULT => -7
	},
	{#State 3
		ACTIONS => {
			'' => 9
		}
	},
	{#State 4
		ACTIONS => {
			'DISTINCT' => 11
		},
		DEFAULT => -10,
		GOTOS => {
			'DistinctOpt' => 10
		}
	},
	{#State 5
		DEFAULT => -8
	},
	{#State 6
		ACTIONS => {
			'DISTINCT' => 11
		},
		DEFAULT => -10,
		GOTOS => {
			'DistinctOpt' => 12
		}
	},
	{#State 7
		DEFAULT => -2
	},
	{#State 8
		ACTIONS => {
			'NAMESPACE' => 13
		}
	},
	{#State 9
		DEFAULT => 0
	},
	{#State 10
		ACTIONS => {
			'Prefix' => 20,
			"*" => 21,
			'Literal' => 16,
			"null" => 15,
			'Identifier' => 22,
			"datatype" => 23,
			'Full_uri' => 19
		},
		GOTOS => {
			'Value' => 14,
			'Var_or_value' => 24,
			'Projection' => 17,
			'Var_or_valuePlus' => 25,
			'Uri' => 27,
			'Var' => 26,
			'Abbrev_uri' => 18
		}
	},
	{#State 11
		DEFAULT => -11
	},
	{#State 12
		ACTIONS => {
			"*" => 31,
			"{" => 30,
			"[" => 34
		},
		GOTOS => {
			'Path_expr_head' => 28,
			'Path_expr_list' => 29,
			'Path_expr0' => 32,
			'Path_expr' => 35,
			'Node' => 33,
			'Construct_clause' => 36
		}
	},
	{#State 13
		ACTIONS => {
			'Identifier' => 37
		},
		GOTOS => {
			'Namespace' => 38,
			'NamespacePlus' => 39
		}
	},
	{#State 14
		DEFAULT => -65
	},
	{#State 15
		DEFAULT => -71
	},
	{#State 16
		DEFAULT => -70
	},
	{#State 17
		ACTIONS => {
			'FROM' => 40
		}
	},
	{#State 18
		DEFAULT => -73
	},
	{#State 19
		DEFAULT => -72
	},
	{#State 20
		ACTIONS => {
			'Local_name' => 41
		}
	},
	{#State 21
		DEFAULT => -14
	},
	{#State 22
		DEFAULT => -66
	},
	{#State 23
		ACTIONS => {
			"(" => 42
		}
	},
	{#State 24
		ACTIONS => {
			"," => 43
		},
		DEFAULT => -16
	},
	{#State 25
		DEFAULT => -15
	},
	{#State 26
		DEFAULT => -64
	},
	{#State 27
		DEFAULT => -69
	},
	{#State 28
		ACTIONS => {
			";" => 44,
			'Full_uri' => 19,
			'Prefix' => 20,
			'Identifier' => 22,
			"datatype" => 23,
			"[" => 46
		},
		DEFAULT => -26,
		GOTOS => {
			'Path_expr_tail' => 47,
			'Path_expr_tailOpt' => 45,
			'Edge' => 50,
			'Var' => 49,
			'Uri' => 48,
			'Abbrev_uri' => 18
		}
	},
	{#State 29
		DEFAULT => -20
	},
	{#State 30
		ACTIONS => {
			"}" => 51,
			"null" => 15,
			'Literal' => 16,
			"{" => 30,
			'Full_uri' => 19,
			'Prefix' => 20,
			'Identifier' => 22,
			"datatype" => 23
		},
		GOTOS => {
			'Value' => 14,
			'Node_elem_list' => 52,
			'Reified_stat' => 55,
			'Abbrev_uri' => 18,
			'Node_elem' => 56,
			'Var_or_value' => 53,
			'Node' => 54,
			'Uri' => 27,
			'Var' => 26
		}
	},
	{#State 31
		DEFAULT => -19
	},
	{#State 32
		DEFAULT => -23
	},
	{#State 33
		ACTIONS => {
			'Prefix' => 20,
			'Identifier' => 22,
			"datatype" => 23,
			'Full_uri' => 19
		},
		GOTOS => {
			'Uri' => 48,
			'Abbrev_uri' => 18,
			'Edge' => 57,
			'Var' => 49
		}
	},
	{#State 34
		ACTIONS => {
			"{" => 30,
			"[" => 34
		},
		GOTOS => {
			'Path_expr_head' => 28,
			'Path_expr_list' => 58,
			'Path_expr0' => 32,
			'Path_expr' => 35,
			'Node' => 33
		}
	},
	{#State 35
		ACTIONS => {
			"," => 59
		},
		DEFAULT => -21
	},
	{#State 36
		ACTIONS => {
			'FROM' => 60
		}
	},
	{#State 37
		ACTIONS => {
			"=" => 61
		}
	},
	{#State 38
		ACTIONS => {
			"," => 62
		},
		DEFAULT => -4
	},
	{#State 39
		DEFAULT => -3
	},
	{#State 40
		ACTIONS => {
			"{" => 30,
			"[" => 34
		},
		GOTOS => {
			'Path_expr_head' => 28,
			'Path_expr_list' => 63,
			'Path_expr0' => 32,
			'Path_expr' => 35,
			'Node' => 33
		}
	},
	{#State 41
		DEFAULT => -77
	},
	{#State 42
		ACTIONS => {
			'Identifier' => 22
		},
		GOTOS => {
			'Var' => 64
		}
	},
	{#State 43
		ACTIONS => {
			'Prefix' => 20,
			'Literal' => 16,
			"null" => 15,
			'Identifier' => 22,
			"datatype" => 23,
			'Full_uri' => 19
		},
		GOTOS => {
			'Value' => 14,
			'Var_or_value' => 24,
			'Var_or_valuePlus' => 65,
			'Uri' => 27,
			'Abbrev_uri' => 18,
			'Var' => 26
		}
	},
	{#State 44
		ACTIONS => {
			'Prefix' => 20,
			'Identifier' => 22,
			"datatype" => 23,
			"[" => 46,
			'Full_uri' => 19
		},
		GOTOS => {
			'Path_expr_tail' => 66,
			'Uri' => 48,
			'Abbrev_uri' => 18,
			'Edge' => 50,
			'Var' => 49
		}
	},
	{#State 45
		DEFAULT => -25
	},
	{#State 46
		ACTIONS => {
			'Prefix' => 20,
			'Identifier' => 22,
			"datatype" => 23,
			'Full_uri' => 19
		},
		GOTOS => {
			'Uri' => 48,
			'Abbrev_uri' => 18,
			'Edge' => 67,
			'Var' => 49
		}
	},
	{#State 47
		DEFAULT => -27
	},
	{#State 48
		DEFAULT => -35
	},
	{#State 49
		DEFAULT => -34
	},
	{#State 50
		ACTIONS => {
			"{" => 30
		},
		GOTOS => {
			'Node' => 68
		}
	},
	{#State 51
		DEFAULT => -36
	},
	{#State 52
		ACTIONS => {
			"}" => 69
		}
	},
	{#State 53
		DEFAULT => -40
	},
	{#State 54
		ACTIONS => {
			'Prefix' => 20,
			'Identifier' => 22,
			"datatype" => 23,
			'Full_uri' => 19
		},
		GOTOS => {
			'Uri' => 48,
			'Abbrev_uri' => 18,
			'Edge' => 70,
			'Var' => 49
		}
	},
	{#State 55
		DEFAULT => -41
	},
	{#State 56
		ACTIONS => {
			"," => 71
		},
		DEFAULT => -38
	},
	{#State 57
		ACTIONS => {
			"{" => 30
		},
		GOTOS => {
			'Node' => 72
		}
	},
	{#State 58
		ACTIONS => {
			"]" => 73
		}
	},
	{#State 59
		ACTIONS => {
			"{" => 30,
			"[" => 34
		},
		GOTOS => {
			'Path_expr_head' => 28,
			'Path_expr_list' => 74,
			'Path_expr0' => 32,
			'Path_expr' => 35,
			'Node' => 33
		}
	},
	{#State 60
		ACTIONS => {
			"{" => 30,
			"[" => 34
		},
		GOTOS => {
			'Path_expr_head' => 28,
			'Path_expr_list' => 75,
			'Path_expr0' => 32,
			'Path_expr' => 35,
			'Node' => 33
		}
	},
	{#State 61
		ACTIONS => {
			'Full_uri' => 76
		}
	},
	{#State 62
		ACTIONS => {
			'Identifier' => 37
		},
		GOTOS => {
			'Namespace' => 38,
			'NamespacePlus' => 77
		}
	},
	{#State 63
		ACTIONS => {
			'WHERE' => 79
		},
		DEFAULT => -12,
		GOTOS => {
			'WhereOpt' => 78
		}
	},
	{#State 64
		ACTIONS => {
			")" => 80
		}
	},
	{#State 65
		DEFAULT => -17
	},
	{#State 66
		DEFAULT => -28
	},
	{#State 67
		ACTIONS => {
			"{" => 30
		},
		GOTOS => {
			'Node' => 81
		}
	},
	{#State 68
		ACTIONS => {
			";" => 44,
			'Full_uri' => 19,
			'Prefix' => 20,
			'Identifier' => 22,
			"datatype" => 23,
			"[" => 46
		},
		DEFAULT => -26,
		GOTOS => {
			'Path_expr_tail' => 47,
			'Path_expr_tailOpt' => 82,
			'Uri' => 48,
			'Abbrev_uri' => 18,
			'Edge' => 50,
			'Var' => 49
		}
	},
	{#State 69
		DEFAULT => -37
	},
	{#State 70
		ACTIONS => {
			"{" => 30
		},
		GOTOS => {
			'Node' => 83
		}
	},
	{#State 71
		ACTIONS => {
			'Prefix' => 20,
			'Literal' => 16,
			"null" => 15,
			'Identifier' => 22,
			"datatype" => 23,
			"{" => 30,
			'Full_uri' => 19
		},
		GOTOS => {
			'Value' => 14,
			'Node_elem_list' => 84,
			'Reified_stat' => 55,
			'Node_elem' => 56,
			'Abbrev_uri' => 18,
			'Var_or_value' => 53,
			'Node' => 54,
			'Uri' => 27,
			'Var' => 26
		}
	},
	{#State 72
		DEFAULT => -31
	},
	{#State 73
		DEFAULT => -24
	},
	{#State 74
		DEFAULT => -22
	},
	{#State 75
		ACTIONS => {
			'WHERE' => 79
		},
		DEFAULT => -12,
		GOTOS => {
			'WhereOpt' => 85
		}
	},
	{#State 76
		DEFAULT => -6
	},
	{#State 77
		DEFAULT => -5
	},
	{#State 78
		DEFAULT => -9
	},
	{#State 79
		ACTIONS => {
			'Literal' => 16,
			"null" => 15,
			"isLiteral" => 95,
			'LABEL' => 86,
			"not" => 96,
			'Full_uri' => 19,
			'Prefix' => 20,
			"(" => 97,
			'Identifier' => 22,
			"false" => 99,
			"datatype" => 23,
			"isResource" => 88,
			"true" => 89,
			'LANG' => 90
		},
		GOTOS => {
			'Boolean_query' => 94,
			'Value' => 93,
			'String_expr' => 87,
			'Abbrev_uri' => 18,
			'And_expr' => 98,
			'Const' => 100,
			'Boolean_query0' => 91,
			'Var_or_const' => 101,
			'Var' => 92,
			'Uri' => 27
		}
	},
	{#State 80
		DEFAULT => -74
	},
	{#State 81
		ACTIONS => {
			'Prefix' => 20,
			'Identifier' => 22,
			";" => 44,
			"datatype" => 23,
			"[" => 46,
			'Full_uri' => 19
		},
		DEFAULT => -26,
		GOTOS => {
			'Path_expr_tail' => 47,
			'Path_expr_tailOpt' => 102,
			'Uri' => 48,
			'Abbrev_uri' => 18,
			'Edge' => 50,
			'Var' => 49
		}
	},
	{#State 82
		DEFAULT => -32
	},
	{#State 83
		DEFAULT => -42
	},
	{#State 84
		DEFAULT => -39
	},
	{#State 85
		DEFAULT => -18
	},
	{#State 86
		ACTIONS => {
			"(" => 103
		}
	},
	{#State 87
		DEFAULT => -68
	},
	{#State 88
		ACTIONS => {
			"(" => 104
		}
	},
	{#State 89
		DEFAULT => -48
	},
	{#State 90
		ACTIONS => {
			"(" => 105
		}
	},
	{#State 91
		ACTIONS => {
			'AND' => 106
		},
		DEFAULT => -45
	},
	{#State 92
		DEFAULT => -62
	},
	{#State 93
		DEFAULT => -67
	},
	{#State 94
		DEFAULT => -13
	},
	{#State 95
		ACTIONS => {
			"(" => 107
		}
	},
	{#State 96
		ACTIONS => {
			'Literal' => 16,
			"null" => 15,
			"isLiteral" => 95,
			'LABEL' => 86,
			"not" => 96,
			'Full_uri' => 19,
			'Prefix' => 20,
			"(" => 97,
			'Identifier' => 22,
			"false" => 99,
			"datatype" => 23,
			"isResource" => 88,
			"true" => 89,
			'LANG' => 90
		},
		GOTOS => {
			'Value' => 93,
			'String_expr' => 87,
			'Abbrev_uri' => 18,
			'Const' => 100,
			'Boolean_query0' => 108,
			'Var' => 92,
			'Uri' => 27,
			'Var_or_const' => 101
		}
	},
	{#State 97
		ACTIONS => {
			'Literal' => 16,
			"null" => 15,
			"isLiteral" => 95,
			'LABEL' => 86,
			"not" => 96,
			'Full_uri' => 19,
			'Prefix' => 20,
			"(" => 97,
			'Identifier' => 22,
			"false" => 99,
			"datatype" => 23,
			"isResource" => 88,
			"true" => 89,
			'LANG' => 90
		},
		GOTOS => {
			'Boolean_query' => 109,
			'Value' => 93,
			'String_expr' => 87,
			'Abbrev_uri' => 18,
			'And_expr' => 98,
			'Const' => 100,
			'Boolean_query0' => 91,
			'Var_or_const' => 101,
			'Var' => 92,
			'Uri' => 27
		}
	},
	{#State 98
		ACTIONS => {
			'OR' => 110
		},
		DEFAULT => -43
	},
	{#State 99
		DEFAULT => -49
	},
	{#State 100
		DEFAULT => -63
	},
	{#State 101
		ACTIONS => {
			'LIKE' => 115,
			"!=" => 114,
			"<" => 111,
			"<=" => 117,
			">" => 118,
			"=" => 116,
			">=" => 113
		},
		GOTOS => {
			'Comp_op' => 112
		}
	},
	{#State 102
		ACTIONS => {
			"]" => 119
		}
	},
	{#State 103
		ACTIONS => {
			'Identifier' => 22
		},
		GOTOS => {
			'Var' => 120
		}
	},
	{#State 104
		ACTIONS => {
			'Identifier' => 22
		},
		GOTOS => {
			'Var' => 121
		}
	},
	{#State 105
		ACTIONS => {
			'Identifier' => 22
		},
		GOTOS => {
			'Var' => 122
		}
	},
	{#State 106
		ACTIONS => {
			'Literal' => 16,
			"null" => 15,
			"isLiteral" => 95,
			'LABEL' => 86,
			"not" => 96,
			'Full_uri' => 19,
			'Prefix' => 20,
			"(" => 97,
			'Identifier' => 22,
			"false" => 99,
			"datatype" => 23,
			"isResource" => 88,
			"true" => 89,
			'LANG' => 90
		},
		GOTOS => {
			'Value' => 93,
			'String_expr' => 87,
			'Abbrev_uri' => 18,
			'And_expr' => 123,
			'Const' => 100,
			'Boolean_query0' => 91,
			'Var_or_const' => 101,
			'Var' => 92,
			'Uri' => 27
		}
	},
	{#State 107
		ACTIONS => {
			'Identifier' => 22
		},
		GOTOS => {
			'Var' => 124
		}
	},
	{#State 108
		DEFAULT => -50
	},
	{#State 109
		ACTIONS => {
			")" => 125
		}
	},
	{#State 110
		ACTIONS => {
			'Literal' => 16,
			"null" => 15,
			"isLiteral" => 95,
			'LABEL' => 86,
			"not" => 96,
			'Full_uri' => 19,
			'Prefix' => 20,
			"(" => 97,
			'Identifier' => 22,
			"false" => 99,
			"datatype" => 23,
			"isResource" => 88,
			"true" => 89,
			'LANG' => 90
		},
		GOTOS => {
			'Boolean_query' => 126,
			'Value' => 93,
			'String_expr' => 87,
			'Abbrev_uri' => 18,
			'And_expr' => 98,
			'Const' => 100,
			'Boolean_query0' => 91,
			'Var_or_const' => 101,
			'Var' => 92,
			'Uri' => 27
		}
	},
	{#State 111
		DEFAULT => -58
	},
	{#State 112
		ACTIONS => {
			'Literal' => 16,
			"null" => 15,
			'String' => 127,
			'LABEL' => 86,
			'Full_uri' => 19,
			'Prefix' => 20,
			'Identifier' => 22,
			"datatype" => 23,
			'LANG' => 90
		},
		GOTOS => {
			'Value' => 93,
			'String_expr' => 87,
			'Const' => 100,
			'Var_or_const' => 128,
			'Uri' => 27,
			'Abbrev_uri' => 18,
			'Var' => 92
		}
	},
	{#State 113
		DEFAULT => -61
	},
	{#State 114
		DEFAULT => -57
	},
	{#State 115
		ACTIONS => {
			'String' => 129
		}
	},
	{#State 116
		DEFAULT => -56
	},
	{#State 117
		DEFAULT => -59
	},
	{#State 118
		DEFAULT => -60
	},
	{#State 119
		ACTIONS => {
			";" => 130
		},
		DEFAULT => -29,
		GOTOS => {
			'Path_expr_tailOpt2' => 131
		}
	},
	{#State 120
		ACTIONS => {
			")" => 132
		}
	},
	{#State 121
		ACTIONS => {
			")" => 133
		}
	},
	{#State 122
		ACTIONS => {
			")" => 134
		}
	},
	{#State 123
		DEFAULT => -46
	},
	{#State 124
		ACTIONS => {
			")" => 135
		}
	},
	{#State 125
		DEFAULT => -47
	},
	{#State 126
		DEFAULT => -44
	},
	{#State 127
		DEFAULT => -52
	},
	{#State 128
		DEFAULT => -51
	},
	{#State 129
		DEFAULT => -53
	},
	{#State 130
		ACTIONS => {
			'Prefix' => 20,
			'Identifier' => 22,
			"datatype" => 23,
			"[" => 46,
			'Full_uri' => 19
		},
		GOTOS => {
			'Path_expr_tail' => 136,
			'Uri' => 48,
			'Abbrev_uri' => 18,
			'Edge' => 50,
			'Var' => 49
		}
	},
	{#State 131
		DEFAULT => -33
	},
	{#State 132
		DEFAULT => -76
	},
	{#State 133
		DEFAULT => -55
	},
	{#State 134
		DEFAULT => -75
	},
	{#State 135
		DEFAULT => -54
	},
	{#State 136
		DEFAULT => -30
	}
],
                                  yyrules  =>
[
	[#Rule 0
		 '$start', 2, undef
	],
	[#Rule 1
		 'Compilation_unit', 1, undef
	],
	[#Rule 2
		 'Compilation_unit', 2,
sub
#line 24 "SeRQLParser.yp"
{
    $_[0]->resolveQNames();
    if ($_[0]->YYData->{COLLECTSTAR}) {
	$_[0]->YYData->{COLLECTSTAR}->expandCollects();
    }
    [@{$_[2]}, @{$_[1]}];
}
	],
	[#Rule 3
		 'Namespace_list', 3,
sub
#line 34 "SeRQLParser.yp"
{
    $_[3];
}
	],
	[#Rule 4
		 'NamespacePlus', 1,
sub
#line 40 "SeRQLParser.yp"
{
    [$_[1]];
}
	],
	[#Rule 5
		 'NamespacePlus', 3,
sub
#line 44 "SeRQLParser.yp"
{
    [$_[1], @{$_[3]}];
}
	],
	[#Rule 6
		 'Namespace', 3,
sub
#line 51 "SeRQLParser.yp"
{
    $_[0]->YYData->{ALGAE2}->namespace($_[1], 
			    new W3C::Rdf::AlgaeCompileTree::Url($_[3], undef, $_[0]));
}
	],
	[#Rule 7
		 'Query', 1, undef
	],
	[#Rule 8
		 'Query', 1, undef
	],
	[#Rule 9
		 'Select_query', 6,
sub
#line 63 "SeRQLParser.yp"
{
    if ($_[2]) {
	$_[0]->_Unsupported('DISTINCT');
    }
    $_[5]->setLastConstraints([$_[6]]);
    [$_[0]->YYData->{ALGAE2}->ask($_[5], undef), $_[3]];
}
	],
	[#Rule 10
		 'DistinctOpt', 0, undef
	],
	[#Rule 11
		 'DistinctOpt', 1, undef
	],
	[#Rule 12
		 'WhereOpt', 0, undef
	],
	[#Rule 13
		 'WhereOpt', 2,
sub
#line 78 "SeRQLParser.yp"
{
    $_[2];
}
	],
	[#Rule 14
		 'Projection', 1,
sub
#line 84 "SeRQLParser.yp"
{
    $_[0]->YYData->{COLLECTSTAR} = $_[0]->YYData->{ALGAE2}->collectStar();
}
	],
	[#Rule 15
		 'Projection', 1,
sub
#line 88 "SeRQLParser.yp"
{
    $_[0]->YYData->{ALGAE2}->collect($_[1]);
}
	],
	[#Rule 16
		 'Var_or_valuePlus', 1,
sub
#line 94 "SeRQLParser.yp"
{
    [$_[1]];
}
	],
	[#Rule 17
		 'Var_or_valuePlus', 3,
sub
#line 98 "SeRQLParser.yp"
{
    [$_[1], @{$_[3]}];
}
	],
	[#Rule 18
		 'Construct_query', 6,
sub
#line 107 "SeRQLParser.yp"
{
    if ($_[2]) {
	$_[0]->_Unsupported('DISTINCT');
    }
    $_[5]->setLastConstraints([$_[6]]);
    [$_[0]->YYData->{ALGAE2}->ask($_[5], undef), 
     $_[0]->YYData->{ALGAE2}->assert($_[3], 
				     $_[0]->YYData->{ALGAE2}->getTemplateDB())];
}
	],
	[#Rule 19
		 'Construct_clause', 1,
sub
#line 119 "SeRQLParser.yp"
{
    $_[0]->_Unsupported('CONSTRUCT *');
    # I guess this will be something like
    # $_[0]->YYData->{COLLECTSTAR} = $_[0]->YYData->{ALGAE2}->collectStar();
}
	],
	[#Rule 20
		 'Construct_clause', 1, undef
	],
	[#Rule 21
		 'Path_expr_list', 1, undef
	],
	[#Rule 22
		 'Path_expr_list', 3,
sub
#line 130 "SeRQLParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Conjunction($_[1], $_[3], $_[0]);
}
	],
	[#Rule 23
		 'Path_expr', 1, undef
	],
	[#Rule 24
		 'Path_expr', 3,
sub
#line 137 "SeRQLParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Option($_[2], $_[0]);
}
	],
	[#Rule 25
		 'Path_expr0', 2,
sub
#line 143 "SeRQLParser.yp"
{
    $_[2] ? 
	new W3C::Rdf::AlgaeCompileTree::Conjunction($_[1], $_[2], $_[0]) : 
	$_[1];
}
	],
	[#Rule 26
		 'Path_expr_tailOpt', 0, undef
	],
	[#Rule 27
		 'Path_expr_tailOpt', 1, undef
	],
	[#Rule 28
		 'Path_expr_tailOpt', 2,
sub
#line 153 "SeRQLParser.yp"
{
    $_[2];
}
	],
	[#Rule 29
		 'Path_expr_tailOpt2', 0, undef
	],
	[#Rule 30
		 'Path_expr_tailOpt2', 2, undef
	],
	[#Rule 31
		 'Path_expr_head', 3,
sub
#line 163 "SeRQLParser.yp"
{
    $_[0]->YYData->{CUR_SUBJECT} = $_[1];
    $_[0]->YYData->{CUR_PREDICATE} = $_[2];
    new W3C::Rdf::AlgaeCompileTree::Decl([$_[2], $_[1], $_[3]], undef, $_[0]);
}
	],
	[#Rule 32
		 'Path_expr_tail', 3,
sub
#line 172 "SeRQLParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Decl([$_[1], $_[0]->YYData->{CUR_SUBJECT}, $_[2]], undef, $_[0]);
}
	],
	[#Rule 33
		 'Path_expr_tail', 6, undef
	],
	[#Rule 34
		 'Edge', 1, undef
	],
	[#Rule 35
		 'Edge', 1, undef
	],
	[#Rule 36
		 'Node', 2,
sub
#line 183 "SeRQLParser.yp"
{
    [];
}
	],
	[#Rule 37
		 'Node', 3,
sub
#line 187 "SeRQLParser.yp"
{
    $_[2];
}
	],
	[#Rule 38
		 'Node_elem_list', 1, undef
	],
	[#Rule 39
		 'Node_elem_list', 3, undef
	],
	[#Rule 40
		 'Node_elem', 1, undef
	],
	[#Rule 41
		 'Node_elem', 1, undef
	],
	[#Rule 42
		 'Reified_stat', 3, undef
	],
	[#Rule 43
		 'Boolean_query', 1, undef
	],
	[#Rule 44
		 'Boolean_query', 3,
sub
#line 205 "SeRQLParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Or($_[1], $_[3], $_[0]);
}
	],
	[#Rule 45
		 'And_expr', 1, undef
	],
	[#Rule 46
		 'And_expr', 3,
sub
#line 212 "SeRQLParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::And($_[1], $_[3], $_[0]);
}
	],
	[#Rule 47
		 'Boolean_query0', 3, undef
	],
	[#Rule 48
		 'Boolean_query0', 1, undef
	],
	[#Rule 49
		 'Boolean_query0', 1, undef
	],
	[#Rule 50
		 'Boolean_query0', 2, undef
	],
	[#Rule 51
		 'Boolean_query0', 3, undef
	],
	[#Rule 52
		 'Boolean_query0', 3,
sub
#line 223 "SeRQLParser.yp"
{
    my $dt = new W3C::Rdf::AlgaeCompileTree::Literal($_[3], undef, undef, $_[0]);
    new W3C::Rdf::AlgaeCompileTree::Eq($_[1], $dt, $_[0]);
}
	],
	[#Rule 53
		 'Boolean_query0', 3, undef
	],
	[#Rule 54
		 'Boolean_query0', 4, undef
	],
	[#Rule 55
		 'Boolean_query0', 4, undef
	],
	[#Rule 56
		 'Comp_op', 1, undef
	],
	[#Rule 57
		 'Comp_op', 1, undef
	],
	[#Rule 58
		 'Comp_op', 1, undef
	],
	[#Rule 59
		 'Comp_op', 1, undef
	],
	[#Rule 60
		 'Comp_op', 1, undef
	],
	[#Rule 61
		 'Comp_op', 1, undef
	],
	[#Rule 62
		 'Var_or_const', 1, undef
	],
	[#Rule 63
		 'Var_or_const', 1, undef
	],
	[#Rule 64
		 'Var_or_value', 1, undef
	],
	[#Rule 65
		 'Var_or_value', 1, undef
	],
	[#Rule 66
		 'Var', 1,
sub
#line 244 "SeRQLParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Var($_[1], 1, $_[0]);
}
	],
	[#Rule 67
		 'Const', 1, undef
	],
	[#Rule 68
		 'Const', 1, undef
	],
	[#Rule 69
		 'Value', 1, undef
	],
	[#Rule 70
		 'Value', 1,
sub
#line 255 "SeRQLParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Literal($_[1], undef, undef, $_[0]);
}
	],
	[#Rule 71
		 'Value', 1, undef
	],
	[#Rule 72
		 'Uri', 1,
sub
#line 262 "SeRQLParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Url($_[1], undef, $_[0]);
}
	],
	[#Rule 73
		 'Uri', 1, undef
	],
	[#Rule 74
		 'Uri', 4, undef
	],
	[#Rule 75
		 'String_expr', 4,
sub
#line 270 "SeRQLParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Lang($_[3], $_[0]);
}
	],
	[#Rule 76
		 'String_expr', 4,
sub
#line 274 "SeRQLParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Label($_[3], $_[0]);
}
	],
	[#Rule 77
		 'Abbrev_uri', 2,
sub
#line 282 "SeRQLParser.yp"
{
    my $r = new W3C::Rdf::AlgaeCompileTree::DelayedQName($_[1], $_[2], $_[0]);
    push (@{$_[0]->YYData->{QNAMES}}, $r);
    $r;
}
	]
],
                                  @_);
    bless($self,$class);
}

#line 289 "SeRQLParser.yp"


#BEGIN {unshift@INC,('../..');}
use W3C::Util::Exception qw(&throw &catch);


my ($QuotedURI, $NSPrefix, $LocalPart, $Identifier, 
    $INTEGER_LITERAL, $FLOATING_POINT_LITERAL, 
    $STRING_LITERAL1, $STRING_LITERAL2) = 
    (\ 'QuotedURI', \ 'NSPrefix', \ 'LocalPart', \ 'Identifier', 
     \ 'INTEGER_LITERAL', \ 'FLOATING_POINT_LITERAL', 
     \ 'STRING_LITERAL1', \ 'STRING_LITERAL2');

my %KeyWords = ('select' => 'SELECT', 'SELECT' => 'SELECT', 
		'where' => 'WHERE', 'WHERE' => 'WHERE', 
		'using' => 'USING', 'USING' => 'USING', 
		'for' => 'FOR', 'FOR' => 'FOR' , 
		'and' => 'AND', 'AND' => 'AND', 
		'from' => 'FROM', 'FROM' => 'FROM', 
		'distinct' => 'DISTINCT', 'DISTINCT' => 'DISTINCT', 
		'construct' => 'CONSTRUCT', 'CONSTRUCT' => 'CONSTRUCT', 
		'namespace' => 'NAMESPACE', 'NAMESPACE' => 'NAMESPACE', 
		'like' => 'LIKE', 'LIKE' => 'LIKE', 
		'or' => 'OR', 'OR' => 'OR', 
		'and' => 'AND', 'AND' => 'AND', 
		'lang' => 'LANG', 'LANG' => 'LANG', 
		'label' => 'LABEL', 'LABEL' => 'LABEL', 
);

sub _Unsupported {
    my ($self, $production) = @_;
    &throw(new W3C::Util::NotImplementedException(-class => '', -method => $production, -object => $self));
}

sub _Error {
    my ($self) = @_;
    if (exists $self->YYData->{EXCEPTION}) {
	&throw($self->YYData->{EXCEPTION});
    }
    if (exists $self->YYData->{ERRMSG}) {
	&throw(new W3C::Util::YappDriver::GrammarException(
				      -message => $self->YYData->{ERRMSG}, 
				      -location => $self->YYData->{LOCATION}));
        delete $self->YYData->{ERRMSG};
        return;
    }
    &throw(new W3C::Util::YappDriver::MesgYappContextException($self, 
				      -location => $self->YYData->{LOCATION}));
}

sub _Lexer {
    my($self)=shift;

    if (defined $self->YYData->{INPUT} && 
	pos $self->YYData->{INPUT} < length ($self->YYData->{INPUT})) {
    } else {
	if ($self->YYData->{my_DONE}) {
	    return ('', undef);
	}
	if (0) {
	if (!($self->YYData->{INPUT} = $self->nextChunk())) {
	    undef $self->YYData->{INPUT};
	    return ('', undef);
	}
	} else {
	my $pos = pos $self->YYData->{INPUT};
	my $chunk = $self->nextChunk();
	#print "\nchunk: $chunk\n";
	if (!$chunk) {
	    undef $self->YYData->{INPUT};
	    return ('', undef);
	}
	$self->YYData->{INPUT} .= $chunk;
	pos $self->YYData->{INPUT} = $pos;
	}
	#my $txt = $self->YYData->{INPUT};
	#print "\ntxt: $txt\n";
    }

    my ($token, $value) = ('', undef);
    while ($self->YYData->{INPUT} =~ m/\G\s*\#[^\n]*\n/gc) {}
    $self->YYData->{INPUT} =~ m/\G\s*/gc;
    $self->YYData->{my_LASTPOS} = pos $self->YYData->{INPUT};
    my $expect = $self->YYData->{NEXT};

    if ($expect eq 'Local_name') {
	# Abbrev_uri    '<' Prefix ':' Local_name '>'
	if ($self->YYData->{INPUT} =~ m/\G([A-Za-z][A-Za-z0-9_-]*)>/gc) {
	    ($token, $value) = ('Local_name', $1);
	} else {
	    &throw();
	}
	$self->YYData->{NEXT} = undef;

    # Full_uri    '<!' (* a legal URI, see RFC 2396 *) '>'
    } elsif ($self->YYData->{INPUT} =~ m/\G<\!([^>]+)>/gc) {
	($token, $value) = ('Full_uri', $1);

    # Abbrev_uri    '<' Prefix ':' Local_name '>'
    #Prefix:
    #    (* a legal XML namespace prefix, see XML spec *)
    } elsif ($self->YYData->{INPUT} =~ m/\G<([A-Za-z][A-Za-z0-9_-]*):/gc) {
	($token, $value) = ('Prefix', $1);
	$self->YYData->{NEXT} = 'Local_name';

    #Identifier:			([a-z][A-Z][0-9][-_.])+;
    } elsif ($self->YYData->{INPUT} =~ m/\G((?:[a-zA-Z0-9\_\.-])+)/gc) {
	($token, $value) = ($KeyWords{lc $1} || 'Identifier', $1);

    # String    '"' (* zero or more (encoded) characters *) '"'
    } elsif ($self->YYData->{INPUT} =~ m/\G\"([^\"]*)\"/gc) {
	my $str = $1;
	while (substr($str, length($str) - 1, 1) eq '"') {
	    if ($self->YYData->{INPUT} =~ m/\G([^\"]*)\"/gc) {
		$str = substr($str, 0, length($str) - 1).$1;
	    } else {
		&throw(new W3C::Util::YappDriver::MesgYappContextException($self, 
					-location => $self->YYData->{LOCATION}));
	    }
	}
	($token, $value) = ('String', $str);

    # Literal    (* A SeRQL literal, see section 3.3 *)
    } elsif ($self->YYData->{INPUT} =~ m/\G([A-Za-z][A-Za-z0-9_-]*)/gc) {
	($token, $value) = ($1,$1);

    } elsif ($self->YYData->{INPUT} =~ m/\G(==|\!=|<=|>=|\|\||\&\&)/gc) {
	($token, $value) = ($1,$1);
    } elsif ($self->YYData->{INPUT} =~ m/\G(.)/gc) {
	($token, $value) = ($1,$1);
    }
    my $pos = pos $self->YYData->{INPUT};
    # print "\n$pos, _Lexer:TOKEN: $token, _Lexer:VALUE: $value\n";
    return ($token, $value);
}

sub parse {
    my ($self, @args) = @_;
    $self->YYData->{NEXT} = undef;
    return $self->SUPER::parse(@args);
}

# Provide (one) chunk of text to parse.
sub nextChunk {
    my ($self) = @_;
    #return shift (@{$self->YYData->{my_CHUNKS}});
    #return shift (@ARGV);
    return <STDIN>;
}

# Handy debugging wrapper for calling semantics actions.
sub _wrap {
    my ($self, $obj, $method, @args) = @_;
    my @ret;
    eval {
	@ret = $obj->$method(@args);
    }; if ($@) {if (my $ex = &catch('W3C::Util::CachedContextException')) {
	&throw($ex);;
    } elsif ($ex = &catch('W3C::Util::Exception')) {
	my $newEx = new 
	    W3C::Util::CachedContextException(-str => $self->YYData->{INPUT}, 
					      -pos => $self->YYData->{my_LASTPOS}+1, 
					      -errorMessage => $ex->toString);
	$newEx->assumeStackTrace($ex);
	&throw($newEx);
    } else {
	my $newEx = 
	    new W3C::Util::CachedContextException(-str => $self->YYData->{INPUT}, 
						  -pos => $self->YYData->{my_LASTPOS}+1, 
						  -errorMessage => "$obj->$method: $@");
	&throw($newEx);
    }}
    return wantarray ? @ret : $ret[-1];
}

sub printArgs {
    return;
    print ':';
    foreach my $arg (@_) {
	print " $arg";
    }
    print ' Curtok:',$_[0]->YYCurtok;
    print ' Curval:',$_[0]->YYCurval;
    print ' Expect:',$_[0]->YYExpect;
    print ' Lexer:',$_[0]->YYLexer;
    print ' Data:',$_[0]->YYData;
    print "\n";
}

# Used by -M invocation:
#   perl -MW3C::Rdf::SeRQLParser -e '(new W3C::Rdf::RLSeRQLParser())->Run' '...'
sub main {
    my ($self) = @_;
    $self->Run();
}

sub resolveQNames {
    my ($self) = @_;
    foreach my $qname (@{$self->YYData->{QNAMES}}) {
	$qname->resolveNS();
    }
}

# </parser state support>

package W3C::Rdf::SeRQLParser;
use vars qw(@ISA);
@W3C::Rdf::SeRQLParser::ISA = qw(W3C::Rdf::_SeRQLParser);
sub new {
    my ($proto, $serqlString, $algae2, $location, @yappParms) = @_;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new(@yappParms);
    $self->YYData->{SERQL_STRING} = $serqlString;
    $self->YYData->{LOCATION} = $location;
 
    $self->YYData->{ALGAE2} = $algae2;
    $self->YYData->{QNAMES} = [];
    return $self;
}

sub nextChunk {
    my ($self) = @_;
    my $ret = $self->YYData->{SERQL_STRING};
    $self->YYData->{SERQL_STRING} = undef;
    return $ret;
}

# Interactive ReadLine parser -- under development
package W3C::Rdf::RLSeRQLParser;
use W3C::Util::Exception;
use vars qw(@ISA);
@ISA = qw(W3C::Rdf::SeRQLParser);
sub new {
    my ($proto, @parms) = @_;
    my $class = ref($proto) || $proto;

    # Change the parser driver to the readline driver.
    @W3C::Rdf::SeRQLParser::ISA= qw (W3C::Util::rlDriver);

    my $self = $class->SUPER::new(@parms);
    $self->YYData->{ACTIONS} = [];
    return $self;
}

sub nextChunk {
    my ($self) = @_;
    my $ret = undef;
    if ($self->{rl_COMPLETE_MODE}) {
	if ($self->{rl_SO_FAR}) {
	    $ret = $self->{rl_SO_FAR};
	    $self->{rl_SO_FAR} = undef;
	    #print "nextChunk: $ret\n";
	}
    } else {
	if (@{$self->YYData->{my_CHUNKS}}) {
	    $ret = shift (@{$self->YYData->{my_CHUNKS}});
	} else {
	    #return shift (@ARGV);
	    $ret = $self->readline('')."\n";
	    #print "ret: $ret";
	}
    }
    return $ret;
}

# perl -MW3C::Rdf::SeRQLParser -e '(new W3C::Rdf::RLSeRQLParser())->Run' 'asdf'
# b /usr/share/perl5/Parse/Yapp/Driver.pm:343

##!/usr/bin/perl
#BEGIN {unshift@INC,('../..');}
#use W3C::Rdf::SeRQLParser;
#$p = new W3C::Rdf::RLSeRQLParser();
#$p->main;

#./SeRQLParser "(ask '(<ab:cd> (?asdf ?s ?o)) assert '(ef:gh (?a ?b ?c)))"

1;

__END__

=head1 NAME

W3C::Rdf::SeRQLParser - a Parse::Yapp grammer for the SeRQL language

=head1 SYNOPSIS

  use W3C::Rdf::SeRQLParser;
  my $p = new W3C::Rdf::SeRQLParser($serqlString, $query, "query.txt");
  my $actions = $p->parse($debug);
  foreach my $action (@$actions) {
    $action->delayedEvaluate($self->{RESULT_SET});
  }
  return $self->getReport();

=head1 DESCRIPTION

The SeRQLParser module binds a yapp grammar to semantic actions that build an
AlgaeCompileTree. In general, client applicatiosn have no direct interaction
with SeRQLParser. Devlopers wishing to extend the SeRQL query language
  http://www.openrdf.org/doc/users/ch05.html#d0e1415

will need the perl yapp modules. The Makefile included with the W3C::Rdf CPAN
module has a target to re-compile the SeRQLParser grammar. Invoke this with
  make SeRQLParser.pm
It is likely that someone extending the SeRQLParser grammar will also want to
extended AlgaeCompileTree.

This module is part of the W3C::Rdf CPAN module.

=head1 AUTHOR

Eric Prud\'hommeaux <eric@w3.org>

=head1 SEE ALSO

W3C::Rdf::AlgaeCompileTree(3) W3C::Rdf::Algae2(3) perl(1).

=cut

1;
