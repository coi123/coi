#!/usr/bin/perl
####################################################################
#
#    This file was generated using Parse::Yapp version 1.05.
#
#        Don't edit this file, use source file instead.
#
#             ANY CHANGE MADE HERE WILL BE LOST !
#
####################################################################
package W3C::Rdf::_BrqlParser;
use vars qw ( @ISA );
use strict;

@ISA= qw ( Parse::Yapp::Driver );
# use Parse::Yapp::Driver; @@ replaced by W3C::Util::YappDriver

#line 9 "BrqlParser.yp"

    #BEGIN {unshift@INC,('../..');}
    use W3C::Util::YappDriver;
    @ISA= qw (W3C::Util::YappDriver);

    use W3C::Rdf::AlgaeCompileTree qw($DISJUNCTION $NEGATION $OUTER);


sub new {
        my($class)=shift;
        ref($class)
    and $class=ref($class);

    my($self)=$class->SUPER::new( yyversion => '1.05',
                                  yystates =>
[
	{#State 0
		ACTIONS => {
			"SELECT" => 1,
			"DESCRIBE" => 6,
			"select" => 7,
			"describe" => 4,
			'CONSTRUCT' => 11
		},
		GOTOS => {
			'QueryPlus' => 2,
			'CompilationUnit' => 3,
			'DESCRIBE' => 8,
			'BRQLQuery' => 5,
			'SELECT' => 10,
			'ReportClause' => 9
		}
	},
	{#State 1
		DEFAULT => -85
	},
	{#State 2
		DEFAULT => -1
	},
	{#State 3
		ACTIONS => {
			'' => 12
		}
	},
	{#State 4
		DEFAULT => -88
	},
	{#State 5
		DEFAULT => -4
	},
	{#State 6
		DEFAULT => -87
	},
	{#State 7
		DEFAULT => -86
	},
	{#State 8
		ACTIONS => {
			"*" => 15,
			"?" => 14,
			"\$" => 17,
			'QuotedURI' => 16,
			'NSPrefix' => 20
		},
		GOTOS => {
			'URI' => 13,
			'STAR' => 19,
			'QName' => 18,
			'Var' => 21
		}
	},
	{#State 9
		ACTIONS => {
			"FROM" => 25,
			"SOURCE" => 27,
			"from" => 28,
			"source" => 23
		},
		DEFAULT => -16,
		GOTOS => {
			'SourceClauseOpt' => 22,
			'FROM' => 26,
			'SOURCE' => 29,
			'SourceClause' => 24
		}
	},
	{#State 10
		ACTIONS => {
			"*" => 15,
			"?" => 14,
			"\$" => 17
		},
		GOTOS => {
			'STAR' => 30,
			'Var' => 31
		}
	},
	{#State 11
		ACTIONS => {
			"{" => 32
		}
	},
	{#State 12
		DEFAULT => 0
	},
	{#State 13
		ACTIONS => {
			"source" => 23,
			"FROM" => 25,
			"SOURCE" => 27,
			"from" => 28
		},
		DEFAULT => -16,
		GOTOS => {
			'SourceClauseOpt' => 33,
			'FROM' => 26,
			'SOURCE' => 29,
			'SourceClause' => 24
		}
	},
	{#State 14
		ACTIONS => {
			"where" => 40,
			"SELECT" => 1,
			'IDENTIFIER' => 41,
			"eq" => 34,
			'FOR' => 35,
			"WHERE" => 42,
			'PREFIXES' => 36,
			"source" => 23,
			"NE" => 37,
			"FROM" => 25,
			"SOURCE" => 27,
			"from" => 28,
			"select" => 7,
			"ne" => 47,
			"EQ" => 39
		},
		GOTOS => {
			'FROM' => 44,
			'WHERE' => 45,
			'Identifier' => 46,
			'SELECT' => 48,
			'SOURCE' => 49,
			'STR_NE' => 38,
			'STR_EQ' => 43
		}
	},
	{#State 15
		DEFAULT => -108
	},
	{#State 16
		DEFAULT => -72
	},
	{#State 17
		ACTIONS => {
			"where" => 40,
			"SELECT" => 1,
			'IDENTIFIER' => 41,
			"eq" => 34,
			'FOR' => 35,
			"WHERE" => 42,
			'PREFIXES' => 36,
			"source" => 23,
			"NE" => 37,
			"FROM" => 25,
			"SOURCE" => 27,
			"from" => 28,
			"select" => 7,
			"ne" => 47,
			"EQ" => 39
		},
		GOTOS => {
			'FROM' => 44,
			'WHERE' => 45,
			'Identifier' => 50,
			'SELECT' => 48,
			'SOURCE' => 49,
			'STR_NE' => 38,
			'STR_EQ' => 43
		}
	},
	{#State 18
		DEFAULT => -73
	},
	{#State 19
		DEFAULT => -13
	},
	{#State 20
		ACTIONS => {
			":" => 51
		}
	},
	{#State 21
		DEFAULT => -14,
		GOTOS => {
			'CommaOptVarStar' => 52
		}
	},
	{#State 22
		ACTIONS => {
			"where" => 40,
			"WHERE" => 42
		},
		GOTOS => {
			'WHERE' => 53
		}
	},
	{#State 23
		DEFAULT => -92
	},
	{#State 24
		DEFAULT => -17
	},
	{#State 25
		DEFAULT => -89
	},
	{#State 26
		ACTIONS => {
			'QuotedURI' => 16,
			'NSPrefix' => 20
		},
		GOTOS => {
			'URI' => 55,
			'SourceSelector' => 54,
			'QName' => 18
		}
	},
	{#State 27
		DEFAULT => -91
	},
	{#State 28
		DEFAULT => -90
	},
	{#State 29
		ACTIONS => {
			'QuotedURI' => 16,
			'NSPrefix' => 20
		},
		GOTOS => {
			'URI' => 55,
			'SourceSelector' => 56,
			'QName' => 18
		}
	},
	{#State 30
		DEFAULT => -11
	},
	{#State 31
		DEFAULT => -14,
		GOTOS => {
			'CommaOptVarStar' => 57
		}
	},
	{#State 32
		ACTIONS => {
			"SOURCE" => 27,
			"source" => 23
		},
		DEFAULT => -43,
		GOTOS => {
			'Graph' => 58,
			'SourceOpt' => 59,
			'SOURCE' => 61,
			'Triple' => 60
		}
	},
	{#State 33
		ACTIONS => {
			"USING" => 64,
			"using" => 63
		},
		DEFAULT => -51,
		GOTOS => {
			'PrefixesClauseOpt' => 65,
			'USING' => 62,
			'PrefixesClause' => 66
		}
	},
	{#State 34
		DEFAULT => -105
	},
	{#State 35
		DEFAULT => -82
	},
	{#State 36
		DEFAULT => -81
	},
	{#State 37
		DEFAULT => -106
	},
	{#State 38
		DEFAULT => -84
	},
	{#State 39
		DEFAULT => -104
	},
	{#State 40
		DEFAULT => -94
	},
	{#State 41
		DEFAULT => -76
	},
	{#State 42
		DEFAULT => -93
	},
	{#State 43
		DEFAULT => -83
	},
	{#State 44
		DEFAULT => -79
	},
	{#State 45
		DEFAULT => -80
	},
	{#State 46
		DEFAULT => -49
	},
	{#State 47
		DEFAULT => -107
	},
	{#State 48
		DEFAULT => -77
	},
	{#State 49
		DEFAULT => -78
	},
	{#State 50
		DEFAULT => -50
	},
	{#State 51
		ACTIONS => {
			'LocalPart' => 67
		},
		DEFAULT => -74
	},
	{#State 52
		ACTIONS => {
			"?" => -2,
			"," => 68,
			"\$" => -2
		},
		DEFAULT => -12,
		GOTOS => {
			'COMMA' => 70,
			'CommaOpt' => 69
		}
	},
	{#State 53
		ACTIONS => {
			"{" => 71
		}
	},
	{#State 54
		DEFAULT => -20,
		GOTOS => {
			't1Star' => 72
		}
	},
	{#State 55
		DEFAULT => -22
	},
	{#State 56
		DEFAULT => -20,
		GOTOS => {
			't1Star' => 73
		}
	},
	{#State 57
		ACTIONS => {
			"?" => -2,
			"," => 68,
			"\$" => -2
		},
		DEFAULT => -10,
		GOTOS => {
			'COMMA' => 70,
			'CommaOpt' => 69
		}
	},
	{#State 58
		ACTIONS => {
			"}" => 74
		}
	},
	{#State 59
		ACTIONS => {
			'QuotedURI' => 16,
			'NSPrefix' => 20
		},
		GOTOS => {
			'URI' => 75,
			'QName' => 18
		}
	},
	{#State 60
		ACTIONS => {
			"." => 77
		},
		DEFAULT => -32,
		GOTOS => {
			'DotOpt' => 76
		}
	},
	{#State 61
		ACTIONS => {
			"?" => 78
		}
	},
	{#State 62
		ACTIONS => {
			"where" => 40,
			"SELECT" => 1,
			'IDENTIFIER' => 41,
			"eq" => 34,
			'FOR' => 35,
			"WHERE" => 42,
			'PREFIXES' => 36,
			"source" => 23,
			"NE" => 37,
			"FROM" => 25,
			"SOURCE" => 27,
			"from" => 28,
			"select" => 7,
			"ne" => 47,
			"EQ" => 39
		},
		GOTOS => {
			'PrefixDecl' => 79,
			'STR_NE' => 38,
			'STR_EQ' => 43,
			'FROM' => 44,
			'WHERE' => 45,
			'Identifier' => 80,
			'SELECT' => 48,
			'SOURCE' => 49
		}
	},
	{#State 63
		DEFAULT => -96
	},
	{#State 64
		DEFAULT => -95
	},
	{#State 65
		DEFAULT => -9
	},
	{#State 66
		DEFAULT => -52
	},
	{#State 67
		DEFAULT => -75
	},
	{#State 68
		DEFAULT => -97
	},
	{#State 69
		ACTIONS => {
			"?" => 14,
			"\$" => 17
		},
		GOTOS => {
			'Var' => 81
		}
	},
	{#State 70
		DEFAULT => -3
	},
	{#State 71
		ACTIONS => {
			"{" => 86,
			"source" => 23,
			"SOURCE" => 27
		},
		DEFAULT => -43,
		GOTOS => {
			'GraphPattern' => 83,
			'GraphPatternTerm' => 85,
			'TriplePattern' => 84,
			'SourceOpt' => 82,
			'SOURCE' => 61
		}
	},
	{#State 72
		ACTIONS => {
			"," => 68,
			'QuotedURI' => -2,
			'NSPrefix' => -2
		},
		DEFAULT => -19,
		GOTOS => {
			'COMMA' => 70,
			'CommaOpt' => 87
		}
	},
	{#State 73
		ACTIONS => {
			"," => 68,
			'QuotedURI' => -2,
			'NSPrefix' => -2
		},
		DEFAULT => -18,
		GOTOS => {
			'COMMA' => 70,
			'CommaOpt' => 87
		}
	},
	{#State 74
		ACTIONS => {
			"FROM" => 25,
			"SOURCE" => 27,
			"from" => 28,
			"source" => 23
		},
		DEFAULT => -16,
		GOTOS => {
			'SourceClauseOpt' => 88,
			'FROM' => 26,
			'SOURCE' => 29,
			'SourceClause' => 24
		}
	},
	{#State 75
		ACTIONS => {
			"," => 68
		},
		DEFAULT => -2,
		GOTOS => {
			'COMMA' => 70,
			'CommaOpt' => 89
		}
	},
	{#State 76
		DEFAULT => -30
	},
	{#State 77
		ACTIONS => {
			"}" => -33,
			"SOURCE" => 27,
			"source" => 23
		},
		DEFAULT => -43,
		GOTOS => {
			'Graph' => 90,
			'SourceOpt' => 59,
			'SOURCE' => 61,
			'Triple' => 60
		}
	},
	{#State 78
		ACTIONS => {
			"where" => 40,
			"SELECT" => 1,
			'IDENTIFIER' => 41,
			"eq" => 34,
			'FOR' => 35,
			"WHERE" => 42,
			'PREFIXES' => 36,
			"source" => 23,
			"NE" => 37,
			"FROM" => 25,
			"SOURCE" => 27,
			"from" => 28,
			"select" => 7,
			"ne" => 47,
			"EQ" => 39
		},
		GOTOS => {
			'FROM' => 44,
			'WHERE' => 45,
			'Identifier' => 91,
			'SELECT' => 48,
			'SOURCE' => 49,
			'STR_NE' => 38,
			'STR_EQ' => 43
		}
	},
	{#State 79
		DEFAULT => -54,
		GOTOS => {
			't4Star' => 92
		}
	},
	{#State 80
		ACTIONS => {
			'FOR' => 93
		}
	},
	{#State 81
		DEFAULT => -15
	},
	{#State 82
		ACTIONS => {
			"?" => 14,
			"\$" => 17,
			'QuotedURI' => 16,
			'NSPrefix' => 20
		},
		GOTOS => {
			'URI' => 96,
			'QName' => 18,
			'VarOrURI' => 94,
			'Var' => 95
		}
	},
	{#State 83
		ACTIONS => {
			"}" => 97,
			"." => 98
		}
	},
	{#State 84
		DEFAULT => -28
	},
	{#State 85
		DEFAULT => -23
	},
	{#State 86
		ACTIONS => {
			"{" => 86,
			"source" => 23,
			"SOURCE" => 27
		},
		DEFAULT => -43,
		GOTOS => {
			'GraphPattern' => 99,
			'GraphPatternTerm' => 85,
			'TriplePattern' => 84,
			'SourceOpt' => 82,
			'SOURCE' => 61
		}
	},
	{#State 87
		ACTIONS => {
			'QuotedURI' => 16,
			'NSPrefix' => 20
		},
		GOTOS => {
			'URI' => 55,
			'SourceSelector' => 100,
			'QName' => 18
		}
	},
	{#State 88
		ACTIONS => {
			"where" => 40,
			"WHERE" => 42
		},
		GOTOS => {
			'WHERE' => 101
		}
	},
	{#State 89
		ACTIONS => {
			'QuotedURI' => 16,
			'NSPrefix' => 20
		},
		GOTOS => {
			'URI' => 102,
			'QName' => 18
		}
	},
	{#State 90
		DEFAULT => -31
	},
	{#State 91
		DEFAULT => -44
	},
	{#State 92
		ACTIONS => {
			'' => -53,
			"," => 68
		},
		DEFAULT => -2,
		GOTOS => {
			'COMMA' => 70,
			'CommaOpt' => 103
		}
	},
	{#State 93
		ACTIONS => {
			'QuotedURI' => 104
		}
	},
	{#State 94
		ACTIONS => {
			"!=" => 113,
			"?" => 14,
			"<" => 105,
			"==" => 108,
			">=" => 109,
			'QuotedURI' => 16,
			"\$" => 17,
			"<=" => 117,
			">" => 118,
			'NSPrefix' => 20
		},
		GOTOS => {
			'EQ' => 112,
			'URI' => 96,
			'REL' => 114,
			'GE' => 106,
			'NEQ' => 107,
			'LT' => 115,
			'LE' => 116,
			'QName' => 18,
			'VarOrURI' => 110,
			'Var' => 95,
			'GT' => 111
		}
	},
	{#State 95
		DEFAULT => -45
	},
	{#State 96
		DEFAULT => -46
	},
	{#State 97
		ACTIONS => {
			"SELECT" => 1,
			"describe" => 4,
			"using" => 63,
			"USING" => 64,
			"DESCRIBE" => 6,
			"select" => 7,
			'CONSTRUCT' => 11
		},
		DEFAULT => -51,
		GOTOS => {
			'QueryPlus' => 119,
			'PrefixesClauseOpt' => 120,
			'DESCRIBE' => 8,
			'BRQLQuery' => 5,
			'USING' => 62,
			'SELECT' => 10,
			'ReportClause' => 9,
			'PrefixesClause' => 66
		}
	},
	{#State 98
		ACTIONS => {
			"{" => 86,
			'NOT' => 121,
			"source" => 23,
			"SOURCE" => 27,
			'OR' => 123,
			'OPTIONAL' => 124
		},
		DEFAULT => -43,
		GOTOS => {
			'GraphPattern' => 122,
			'GraphPatternTerm' => 85,
			'TriplePattern' => 84,
			'SourceOpt' => 82,
			'SOURCE' => 61
		}
	},
	{#State 99
		ACTIONS => {
			"}" => 125,
			"." => 98
		}
	},
	{#State 100
		DEFAULT => -21
	},
	{#State 101
		ACTIONS => {
			"{" => 126
		}
	},
	{#State 102
		ACTIONS => {
			"," => 68
		},
		DEFAULT => -2,
		GOTOS => {
			'COMMA' => 70,
			'CommaOpt' => 127
		}
	},
	{#State 103
		ACTIONS => {
			"where" => 40,
			"SELECT" => 1,
			'IDENTIFIER' => 41,
			"eq" => 34,
			'FOR' => 35,
			"WHERE" => 42,
			'PREFIXES' => 36,
			"source" => 23,
			"NE" => 37,
			"FROM" => 25,
			"SOURCE" => 27,
			"from" => 28,
			"select" => 7,
			"ne" => 47,
			"EQ" => 39
		},
		GOTOS => {
			'PrefixDecl' => 128,
			'STR_NE' => 38,
			'STR_EQ' => 43,
			'FROM' => 44,
			'WHERE' => 45,
			'Identifier' => 80,
			'SELECT' => 48,
			'SOURCE' => 49
		}
	},
	{#State 104
		DEFAULT => -56
	},
	{#State 105
		DEFAULT => -99
	},
	{#State 106
		DEFAULT => -40
	},
	{#State 107
		DEFAULT => -42
	},
	{#State 108
		DEFAULT => -100
	},
	{#State 109
		DEFAULT => -103
	},
	{#State 110
		ACTIONS => {
			'STRING_LITERAL1' => 135,
			"?" => 14,
			'INTEGER_LITERAL' => 130,
			'BOOLEAN_LITERAL' => 139,
			'QuotedURI' => 16,
			'STRING_LITERAL2' => 132,
			"\$" => 17,
			'FLOATING_POINT_LITERAL' => 140,
			'NULL_LITERAL' => 142,
			'NSPrefix' => 20
		},
		GOTOS => {
			'BooleanLiteral' => 129,
			'URI' => 136,
			'VarOrConst' => 137,
			'NullLiteral' => 138,
			'TextLiteral' => 131,
			'Const' => 141,
			'QName' => 18,
			'NumericLiteral' => 133,
			'Var' => 134
		}
	},
	{#State 111
		DEFAULT => -38
	},
	{#State 112
		DEFAULT => -41
	},
	{#State 113
		DEFAULT => -101
	},
	{#State 114
		ACTIONS => {
			'STRING_LITERAL1' => 135,
			"?" => 14,
			'INTEGER_LITERAL' => 130,
			'BOOLEAN_LITERAL' => 139,
			'QuotedURI' => 16,
			'STRING_LITERAL2' => 132,
			"\$" => 17,
			'FLOATING_POINT_LITERAL' => 140,
			'NULL_LITERAL' => 142,
			'NSPrefix' => 20
		},
		GOTOS => {
			'BooleanLiteral' => 129,
			'URI' => 136,
			'VarOrConst' => 143,
			'NullLiteral' => 138,
			'TextLiteral' => 131,
			'Const' => 141,
			'QName' => 18,
			'NumericLiteral' => 133,
			'Var' => 134
		}
	},
	{#State 115
		DEFAULT => -37
	},
	{#State 116
		DEFAULT => -39
	},
	{#State 117
		DEFAULT => -102
	},
	{#State 118
		DEFAULT => -98
	},
	{#State 119
		DEFAULT => -5
	},
	{#State 120
		DEFAULT => -7
	},
	{#State 121
		ACTIONS => {
			"{" => 86,
			"source" => 23,
			"SOURCE" => 27
		},
		DEFAULT => -43,
		GOTOS => {
			'GraphPattern' => 144,
			'GraphPatternTerm' => 85,
			'TriplePattern' => 84,
			'SourceOpt' => 82,
			'SOURCE' => 61
		}
	},
	{#State 122
		ACTIONS => {
			"." => 98
		},
		DEFAULT => -24
	},
	{#State 123
		ACTIONS => {
			"{" => 86,
			"source" => 23,
			"SOURCE" => 27
		},
		DEFAULT => -43,
		GOTOS => {
			'GraphPattern' => 145,
			'GraphPatternTerm' => 85,
			'TriplePattern' => 84,
			'SourceOpt' => 82,
			'SOURCE' => 61
		}
	},
	{#State 124
		ACTIONS => {
			"{" => 86,
			"source" => 23,
			"SOURCE" => 27
		},
		DEFAULT => -43,
		GOTOS => {
			'GraphPattern' => 146,
			'GraphPatternTerm' => 85,
			'TriplePattern' => 84,
			'SourceOpt' => 82,
			'SOURCE' => 61
		}
	},
	{#State 125
		DEFAULT => -29
	},
	{#State 126
		ACTIONS => {
			"{" => 86,
			"source" => 23,
			"SOURCE" => 27
		},
		DEFAULT => -43,
		GOTOS => {
			'GraphPattern' => 147,
			'GraphPatternTerm' => 85,
			'TriplePattern' => 84,
			'SourceOpt' => 82,
			'SOURCE' => 61
		}
	},
	{#State 127
		ACTIONS => {
			'BOOLEAN_LITERAL' => 139,
			'STRING_LITERAL1' => 135,
			'STRING_LITERAL2' => 132,
			'QuotedURI' => 16,
			'FLOATING_POINT_LITERAL' => 140,
			'INTEGER_LITERAL' => 130,
			'NULL_LITERAL' => 142,
			'NSPrefix' => 20
		},
		GOTOS => {
			'BooleanLiteral' => 129,
			'URI' => 136,
			'TextLiteral' => 131,
			'Const' => 148,
			'QName' => 18,
			'NumericLiteral' => 133,
			'NullLiteral' => 138
		}
	},
	{#State 128
		DEFAULT => -55
	},
	{#State 129
		DEFAULT => -60
	},
	{#State 130
		DEFAULT => -62
	},
	{#State 131
		DEFAULT => -59
	},
	{#State 132
		ACTIONS => {
			"\@" => 149
		},
		DEFAULT => -66,
		GOTOS => {
			't10Opt' => 151,
			'AT' => 150
		}
	},
	{#State 133
		DEFAULT => -58
	},
	{#State 134
		DEFAULT => -47
	},
	{#State 135
		ACTIONS => {
			"\@" => 149
		},
		DEFAULT => -66,
		GOTOS => {
			't10Opt' => 152,
			'AT' => 150
		}
	},
	{#State 136
		DEFAULT => -57
	},
	{#State 137
		DEFAULT => -35
	},
	{#State 138
		DEFAULT => -61
	},
	{#State 139
		DEFAULT => -70
	},
	{#State 140
		DEFAULT => -63
	},
	{#State 141
		DEFAULT => -48
	},
	{#State 142
		DEFAULT => -71
	},
	{#State 143
		DEFAULT => -36
	},
	{#State 144
		ACTIONS => {
			"." => 98
		},
		DEFAULT => -27
	},
	{#State 145
		ACTIONS => {
			"." => 98
		},
		DEFAULT => -25
	},
	{#State 146
		ACTIONS => {
			"." => 98
		},
		DEFAULT => -26
	},
	{#State 147
		ACTIONS => {
			"}" => 153,
			"." => 98
		}
	},
	{#State 148
		DEFAULT => -34
	},
	{#State 149
		DEFAULT => -110
	},
	{#State 150
		ACTIONS => {
			"where" => 40,
			"SELECT" => 1,
			'IDENTIFIER' => 41,
			"eq" => 34,
			'FOR' => 35,
			"WHERE" => 42,
			'PREFIXES' => 36,
			"source" => 23,
			"NE" => 37,
			"FROM" => 25,
			"SOURCE" => 27,
			"from" => 28,
			"select" => 7,
			"ne" => 47,
			"EQ" => 39
		},
		GOTOS => {
			'FROM' => 44,
			'WHERE' => 45,
			'Identifier' => 154,
			'SELECT' => 48,
			'SOURCE' => 49,
			'STR_NE' => 38,
			'STR_EQ' => 43
		}
	},
	{#State 151
		ACTIONS => {
			"^^" => 157
		},
		DEFAULT => -68,
		GOTOS => {
			'DATATYPE' => 155,
			't11Opt' => 156
		}
	},
	{#State 152
		ACTIONS => {
			"^^" => 157
		},
		DEFAULT => -68,
		GOTOS => {
			'DATATYPE' => 155,
			't11Opt' => 158
		}
	},
	{#State 153
		ACTIONS => {
			"SELECT" => 1,
			"describe" => 4,
			"using" => 63,
			"USING" => 64,
			"DESCRIBE" => 6,
			"select" => 7,
			'CONSTRUCT' => 11
		},
		DEFAULT => -51,
		GOTOS => {
			'QueryPlus' => 159,
			'PrefixesClauseOpt' => 160,
			'DESCRIBE' => 8,
			'BRQLQuery' => 5,
			'USING' => 62,
			'SELECT' => 10,
			'ReportClause' => 9,
			'PrefixesClause' => 66
		}
	},
	{#State 154
		DEFAULT => -67
	},
	{#State 155
		ACTIONS => {
			'QuotedURI' => 16,
			'NSPrefix' => 20
		},
		GOTOS => {
			'URI' => 161,
			'QName' => 18
		}
	},
	{#State 156
		DEFAULT => -65
	},
	{#State 157
		DEFAULT => -109
	},
	{#State 158
		DEFAULT => -64
	},
	{#State 159
		DEFAULT => -6
	},
	{#State 160
		DEFAULT => -8
	},
	{#State 161
		DEFAULT => -69
	}
],
                                  yyrules  =>
[
	[#Rule 0
		 '$start', 2, undef
	],
	[#Rule 1
		 'CompilationUnit', 1, undef
	],
	[#Rule 2
		 'CommaOpt', 0, undef
	],
	[#Rule 3
		 'CommaOpt', 1, undef
	],
	[#Rule 4
		 'QueryPlus', 1, undef
	],
	[#Rule 5
		 'QueryPlus', 7,
sub
#line 37 "BrqlParser.yp"
{
#    $_[5]->setLastConstraints($_[7]);
    $_[0]->resolveQNames();
    if ($_[0]->YYData->{COLLECTSTAR}) {
	$_[0]->YYData->{COLLECTSTAR}->expandCollects();
    }
    [@{$_[2]}, $_[0]->YYData->{ALGAE2}->ask($_[5], undef), $_[1], @{$_[7]}];
}
	],
	[#Rule 6
		 'QueryPlus', 10,
sub
#line 48 "BrqlParser.yp"
{
#    $_[8]->setLastConstraints($_[10]);
    $_[0]->resolveQNames();
    if ($_[0]->YYData->{COLLECTSTAR}) {
	$_[0]->YYData->{COLLECTSTAR}->expandCollects();
    }
    [@{$_[5]}, $_[0]->YYData->{ALGAE2}->ask($_[8], undef), 
     $_[0]->YYData->{ALGAE2}->assert($_[3], 
				     $_[0]->YYData->{ALGAE2}->getTemplateDB()), 
     @{$_[10]}];
}
	],
	[#Rule 7
		 'BRQLQuery', 7,
sub
#line 64 "BrqlParser.yp"
{
#    $_[5]->setLastConstraints($_[7]);
    $_[0]->resolveQNames();
    if ($_[0]->YYData->{COLLECTSTAR}) {
	$_[0]->YYData->{COLLECTSTAR}->expandCollects();
    }
    [@{$_[7]}, @{$_[2]}, $_[0]->YYData->{ALGAE2}->ask($_[5], undef), $_[1]];
}
	],
	[#Rule 8
		 'BRQLQuery', 10,
sub
#line 75 "BrqlParser.yp"
{
#    $_[8]->setLastConstraints($_[10]);
    $_[0]->resolveQNames();
    if ($_[0]->YYData->{COLLECTSTAR}) {
	$_[0]->YYData->{COLLECTSTAR}->expandCollects();
    }
    [@{$_[10]}, @{$_[5]}, 
     $_[0]->YYData->{ALGAE2}->ask($_[8], undef), 
     $_[0]->YYData->{ALGAE2}->assert($_[3], 
				     $_[0]->YYData->{ALGAE2}->getTemplateDB())];
}
	],
	[#Rule 9
		 'BRQLQuery', 4,
sub
#line 87 "BrqlParser.yp"
{
    [@{$_[4]}, @{$_[3]}, $_[0]->YYData->{ALGAE2}->describe([$_[2]])];
}
	],
	[#Rule 10
		 'ReportClause', 3,
sub
#line 93 "BrqlParser.yp"
{
    $_[0]->YYData->{ALGAE2}->collect([$_[2], @{$_[3]}]);
}
	],
	[#Rule 11
		 'ReportClause', 2,
sub
#line 97 "BrqlParser.yp"
{
    $_[0]->YYData->{COLLECTSTAR} = $_[0]->YYData->{ALGAE2}->collectStar();
}
	],
	[#Rule 12
		 'ReportClause', 3,
sub
#line 101 "BrqlParser.yp"
{
    $_[0]->YYData->{ALGAE2}->describe([$_[2], @{$_[3]}]);
}
	],
	[#Rule 13
		 'ReportClause', 2,
sub
#line 105 "BrqlParser.yp"
{
    $_[0]->YYData->{COLLECTSTAR} = $_[0]->YYData->{ALGAE2}->describeStar();
}
	],
	[#Rule 14
		 'CommaOptVarStar', 0,
sub
#line 111 "BrqlParser.yp"
{[]}
	],
	[#Rule 15
		 'CommaOptVarStar', 3,
sub
#line 113 "BrqlParser.yp"
{
    push (@{$_[1]}, $_[3]);
    $_[1];
}
	],
	[#Rule 16
		 'SourceClauseOpt', 0,
sub
#line 120 "BrqlParser.yp"
{[]}
	],
	[#Rule 17
		 'SourceClauseOpt', 1, undef
	],
	[#Rule 18
		 'SourceClause', 3,
sub
#line 125 "BrqlParser.yp"
{
    push (@{$_[3]}, $_[2]);
    $_[3];
}
	],
	[#Rule 19
		 'SourceClause', 3,
sub
#line 130 "BrqlParser.yp"
{
    push (@{$_[3]}, $_[2]);
    $_[3];
}
	],
	[#Rule 20
		 't1Star', 0, undef
	],
	[#Rule 21
		 't1Star', 3,
sub
#line 138 "BrqlParser.yp"
{
    push (@{$_[1]}, $_[3]);
    $_[1];
}
	],
	[#Rule 22
		 'SourceSelector', 1,
sub
#line 146 "BrqlParser.yp"
{
    $_[0]->YYData->{ALGAE2}->slurp($_[1], [], undef);
}
	],
	[#Rule 23
		 'GraphPattern', 1,
sub
#line 152 "BrqlParser.yp"
{$_[1]}
	],
	[#Rule 24
		 'GraphPattern', 3,
sub
#line 154 "BrqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Conjunction($_[1], $_[3], $_[0]);
}
	],
	[#Rule 25
		 'GraphPattern', 4,
sub
#line 158 "BrqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Disjunction($_[1], $_[4], $_[0]);
}
	],
	[#Rule 26
		 'GraphPattern', 4,
sub
#line 162 "BrqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Conjunction($_[1], new W3C::Rdf::AlgaeCompileTree::Option($_[4], $_[0]), $_[0]);
}
	],
	[#Rule 27
		 'GraphPattern', 4,
sub
#line 166 "BrqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Conjunction($_[1], new W3C::Rdf::AlgaeCompileTree::Negation($_[4], $_[0]), $_[0]);
}
	],
	[#Rule 28
		 'GraphPatternTerm', 1,
sub
#line 172 "BrqlParser.yp"
{$_[1]}
	],
	[#Rule 29
		 'GraphPatternTerm', 3,
sub
#line 174 "BrqlParser.yp"
{$_[2]}
	],
	[#Rule 30
		 'Graph', 2,
sub
#line 179 "BrqlParser.yp"
{$_[1]}
	],
	[#Rule 31
		 'Graph', 3,
sub
#line 181 "BrqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Conjunction($_[1], $_[3], $_[0]);
}
	],
	[#Rule 32
		 'DotOpt', 0, undef
	],
	[#Rule 33
		 'DotOpt', 1, undef
	],
	[#Rule 34
		 'Triple', 6,
sub
#line 192 "BrqlParser.yp"
{
    my ($self, $source, $subject, $property, $value) = ($_[0], $_[1], $_[2], $_[4], $_[6]);
    my $constraints = $source ? [new W3C::Rdf::AlgaeCompileTree::Constraint(
	new W3C::Rdf::AlgaeCompileTree::Assign($source, 
	    new W3C::Rdf::AlgaeCompileTree::KeyName('ATTRIB', 1, $self), $self), $self)] : [];
    return new W3C::Rdf::AlgaeCompileTree::Decl([$property, $subject, $value], 
								   $constraints, $self);
}
	],
	[#Rule 35
		 'TriplePattern', 4,
sub
#line 203 "BrqlParser.yp"
{
    my ($self, $source, $subject, $property, $value) = @_;
    my $constraints = $source ? [new W3C::Rdf::AlgaeCompileTree::Constraint(
	new W3C::Rdf::AlgaeCompileTree::Assign($source, 
	    new W3C::Rdf::AlgaeCompileTree::KeyName('ATTRIB', 1, $self), $self), $self)] : [];
    my $ret = new W3C::Rdf::AlgaeCompileTree::Decl([$property, $subject, $value], 
								   $constraints, $self);
    return $self->YYData->{PTN} = $ret;
}
	],
	[#Rule 36
		 'TriplePattern', 4,
sub
#line 213 "BrqlParser.yp"
{
    my ($self, $source, $subject, $property, $value) = @_;
    my $ptn = $self->YYData->{PTN} || &throw(new W3C::Util::Exception(-message => "constraint on what?"));
    my $ret = new W3C::Rdf::AlgaeCompileTree::Lt($subject, $value, $self);
    $ptn->addLastConstraints($ret);
    return $ptn;
}
	],
	[#Rule 37
		 'REL', 1, undef
	],
	[#Rule 38
		 'REL', 1, undef
	],
	[#Rule 39
		 'REL', 1, undef
	],
	[#Rule 40
		 'REL', 1, undef
	],
	[#Rule 41
		 'REL', 1, undef
	],
	[#Rule 42
		 'REL', 1, undef
	],
	[#Rule 43
		 'SourceOpt', 0, undef
	],
	[#Rule 44
		 'SourceOpt', 3,
sub
#line 228 "BrqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Var($_[3], 1, $_[0]);
}
	],
	[#Rule 45
		 'VarOrURI', 1, undef
	],
	[#Rule 46
		 'VarOrURI', 1, undef
	],
	[#Rule 47
		 'VarOrConst', 1, undef
	],
	[#Rule 48
		 'VarOrConst', 1, undef
	],
	[#Rule 49
		 'Var', 2,
sub
#line 242 "BrqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Var($_[2], 1, $_[0]);
}
	],
	[#Rule 50
		 'Var', 2,
sub
#line 246 "BrqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Var($_[2], 1, $_[0]);
}
	],
	[#Rule 51
		 'PrefixesClauseOpt', 0,
sub
#line 252 "BrqlParser.yp"
{[]}
	],
	[#Rule 52
		 'PrefixesClauseOpt', 1, undef
	],
	[#Rule 53
		 'PrefixesClause', 3,
sub
#line 258 "BrqlParser.yp"
{
    [$_[2], @{$_[3]}];
}
	],
	[#Rule 54
		 't4Star', 0,
sub
#line 264 "BrqlParser.yp"
{[]}
	],
	[#Rule 55
		 't4Star', 3,
sub
#line 266 "BrqlParser.yp"
{
    [@{$_[1]}, $_[3]];
}
	],
	[#Rule 56
		 'PrefixDecl', 3,
sub
#line 272 "BrqlParser.yp"
{
    $_[0]->YYData->{ALGAE2}->namespace($_[1], 
			    new W3C::Rdf::AlgaeCompileTree::Url($_[3], $_[0]));
}
	],
	[#Rule 57
		 'Const', 1, undef
	],
	[#Rule 58
		 'Const', 1, undef
	],
	[#Rule 59
		 'Const', 1,
sub
#line 281 "BrqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Literal($_[1], undef, $_[0]);
}
	],
	[#Rule 60
		 'Const', 1, undef
	],
	[#Rule 61
		 'Const', 1, undef
	],
	[#Rule 62
		 'NumericLiteral', 1,
sub
#line 289 "BrqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Int($_[1], $_[0]);
}
	],
	[#Rule 63
		 'NumericLiteral', 1,
sub
#line 293 "BrqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Float($_[1], $_[0]);
}
	],
	[#Rule 64
		 'TextLiteral', 3, undef
	],
	[#Rule 65
		 'TextLiteral', 3, undef
	],
	[#Rule 66
		 't10Opt', 0, undef
	],
	[#Rule 67
		 't10Opt', 2, undef
	],
	[#Rule 68
		 't11Opt', 0, undef
	],
	[#Rule 69
		 't11Opt', 2, undef
	],
	[#Rule 70
		 'BooleanLiteral', 1, undef
	],
	[#Rule 71
		 'NullLiteral', 1, undef
	],
	[#Rule 72
		 'URI', 1,
sub
#line 316 "BrqlParser.yp"
{
    new W3C::Rdf::AlgaeCompileTree::Url($_[1], $_[0]);
}
	],
	[#Rule 73
		 'URI', 1, undef
	],
	[#Rule 74
		 'QName', 2,
sub
#line 324 "BrqlParser.yp"
{
    my $r = new W3C::Rdf::AlgaeCompileTree::DelayedQName('',    $_[3], $_[0]);
    push (@{$_[0]->YYData->{QNAMES}}, $r);
    $r;
}
	],
	[#Rule 75
		 'QName', 3,
sub
#line 330 "BrqlParser.yp"
{
    my $r = new W3C::Rdf::AlgaeCompileTree::DelayedQName($_[1], $_[3], $_[0]);
    push (@{$_[0]->YYData->{QNAMES}}, $r);
    $r;
}
	],
	[#Rule 76
		 'Identifier', 1, undef
	],
	[#Rule 77
		 'Identifier', 1, undef
	],
	[#Rule 78
		 'Identifier', 1, undef
	],
	[#Rule 79
		 'Identifier', 1, undef
	],
	[#Rule 80
		 'Identifier', 1, undef
	],
	[#Rule 81
		 'Identifier', 1, undef
	],
	[#Rule 82
		 'Identifier', 1, undef
	],
	[#Rule 83
		 'Identifier', 1, undef
	],
	[#Rule 84
		 'Identifier', 1, undef
	],
	[#Rule 85
		 'SELECT', 1, undef
	],
	[#Rule 86
		 'SELECT', 1, undef
	],
	[#Rule 87
		 'DESCRIBE', 1, undef
	],
	[#Rule 88
		 'DESCRIBE', 1, undef
	],
	[#Rule 89
		 'FROM', 1, undef
	],
	[#Rule 90
		 'FROM', 1, undef
	],
	[#Rule 91
		 'SOURCE', 1, undef
	],
	[#Rule 92
		 'SOURCE', 1, undef
	],
	[#Rule 93
		 'WHERE', 1, undef
	],
	[#Rule 94
		 'WHERE', 1, undef
	],
	[#Rule 95
		 'USING', 1, undef
	],
	[#Rule 96
		 'USING', 1, undef
	],
	[#Rule 97
		 'COMMA', 1, undef
	],
	[#Rule 98
		 'GT', 1, undef
	],
	[#Rule 99
		 'LT', 1, undef
	],
	[#Rule 100
		 'EQ', 1, undef
	],
	[#Rule 101
		 'NEQ', 1, undef
	],
	[#Rule 102
		 'LE', 1, undef
	],
	[#Rule 103
		 'GE', 1, undef
	],
	[#Rule 104
		 'STR_EQ', 1, undef
	],
	[#Rule 105
		 'STR_EQ', 1, undef
	],
	[#Rule 106
		 'STR_NE', 1, undef
	],
	[#Rule 107
		 'STR_NE', 1, undef
	],
	[#Rule 108
		 'STAR', 1, undef
	],
	[#Rule 109
		 'DATATYPE', 1, undef
	],
	[#Rule 110
		 'AT', 1, undef
	]
],
                                  @_);
    bless($self,$class);
}

#line 388 "BrqlParser.yp"


#BEGIN {unshift@INC,('../..');}
use W3C::Util::Exception qw(&throw &catch);

#QuotedURI:			'<' URI characters (from RFC 2396) '>';
#NSPrefix:			NCName As defined in XML Namespace v1.1 and XML 1.1;
#LocalPart:			NCName As defined in XML Namespace v1.1 and XML 1.1;
#Identifier:			([a-z][A-Z][0-9][-_.])+;
#EOF:				End of file -- implicit in parser style
#INTEGER_LITERAL:		([0-9])+;
#FLOATING_POINT_LITERAL:	([0-9])*'.'([0-9])+('e'('+'|'-')?([0-9])+)?;
#STRING_LITERAL1:		'"'UTF-8 characters'"' (with escaped \");
#STRING_LITERAL2:		"'"UTF-8 characters"'" (with escaped \');

my ($QuotedURI, $NSPrefix, $LocalPart, $Identifier, 
    $INTEGER_LITERAL, $FLOATING_POINT_LITERAL, 
    $STRING_LITERAL1, $STRING_LITERAL2) = 
    (\ 'QuotedURI', \ 'NSPrefix', \ 'LocalPart', \ 'Identifier', 
     \ 'INTEGER_LITERAL', \ 'FLOATING_POINT_LITERAL', 
     \ 'STRING_LITERAL1', \ 'STRING_LITERAL2');

my %KeyWords = ('select' => 'SELECT', 'SELECT' => 'SELECT', 
		'describe' => 'DESCRIBE', 'DESCRIBE' => 'DESCRIBE', 
		'construct' => 'CONSTRUCT', 'CONSTRUCT' => 'CONSTRUCT', 
		'where' => 'WHERE', 'WHERE' => 'WHERE', 
		'using' => 'USING', 'USING' => 'USING', 
		'for' => 'FOR', 'FOR' => 'FOR' , 
		'and' => 'AND', 'AND' => 'AND', 
		'not' => 'NOT', 'NOT' => 'NOT', 
		'optional' => 'OPTIONAL', 'OPTIONAL' => 'OPTIONAL', 
		'source' => 'SOURCE', 'SOURCE' => 'SOURCE', 
		'from' => 'FROM', 'FROM' => 'FROM');

sub _Error {
    my ($self) = @_;
    if (exists $self->YYData->{EXCEPTION}) {
	&throw($self->YYData->{EXCEPTION});
    }
    if (exists $self->YYData->{ERRMSG}) {
	&throw(new W3C::Util::YappDriver::GrammarException(
				      -message => $self->YYData->{ERRMSG}, 
				      -location => $self->YYData->{LOCATION}));
        delete $self->YYData->{ERRMSG};
        return;
    }
    &throw(new W3C::Util::YappDriver::MesgYappContextException($self, 
				      -location => $self->YYData->{LOCATION}));
}

sub _Lexer {
    my($self)=shift;

    if (defined $self->YYData->{INPUT} && 
	pos $self->YYData->{INPUT} < length ($self->YYData->{INPUT})) {
    } else {
	if ($self->YYData->{my_DONE}) {
	    return ('', undef);
	}
	if (0) {
	if (!($self->YYData->{INPUT} = $self->nextChunk())) {
	    undef $self->YYData->{INPUT};
	    return ('', undef);
	}
	} else {
	my $pos = pos $self->YYData->{INPUT};
	my $chunk = $self->nextChunk();
	#print "\nchunk: $chunk\n";
	if (!$chunk) {
	    undef $self->YYData->{INPUT};
	    return ('', undef);
	}
	$self->YYData->{INPUT} .= $chunk;
	pos $self->YYData->{INPUT} = $pos;
	}
	#my $txt = $self->YYData->{INPUT};
	#print "\ntxt: $txt\n";
    }

    my ($token, $value) = ('', undef);
    while ($self->YYData->{INPUT} =~ m/\G\s*\#[^\n]*\n/gc) {}
    $self->YYData->{INPUT} =~ m/\G\s*/gc;
    $self->YYData->{my_LASTPOS} = pos $self->YYData->{INPUT};
    my $expect = $self->YYData->{NEXT};
#EOF:				End of file -- implicit in parser style
    if ($expect eq ':') {
	#LocalPart:		NCName As defined in XML Namespace v1.1 and XML 1.1;
	if ($self->YYData->{INPUT} =~ m/\G:/gc) {
	    if ($self->YYData->{INPUT} =~ m/\G(?=[A-Za-z][A-Za-z0-9_-]*)/gc) {
		$self->YYData->{NEXT} = 'LocalPart';
	    } else {
		$self->YYData->{NEXT} = undef;
	    }
	    ($token, $value) = (':', ':');
	} else {
	    &throw();
	}
    } elsif ($expect eq 'LocalPart') {
	#LocalPart:		NCName As defined in XML Namespace v1.1 and XML 1.1;
	if ($self->YYData->{INPUT} =~ m/\G([A-Za-z][A-Za-z0-9_-]*)/gc) {
	    ($token, $value) = ('LocalPart', $1);
	} else {
	    &throw();
	}
	$self->YYData->{NEXT} = undef;
#QuotedURI:			'<' URI characters (from RFC 2396) '>';
#    } elsif ($self->YYData->{INPUT} =~ m/\G<([a-zA-Z]+\:[^>]+)>/gc) {
    } elsif ($self->YYData->{INPUT} =~ m/\G<([^>]+)>/gc) {
	($token, $value) = ('QuotedURI', $1);
#NSPrefix:			NCName As defined in XML Namespace v1.1 and XML 1.1;
    } elsif ($self->YYData->{INPUT} =~ m/\G([A-Za-z][A-Za-z0-9_-]*)(?=:)/gc) {
	($token, $value) = ('NSPrefix', $1);
	$self->YYData->{NEXT} = ':';
#INTEGER_LITERAL:		([0-9])+;
    } elsif ($self->YYData->{INPUT} =~ m/\G([0-9]+)/gc) {
	($token, $value) = ('INTEGER_LITERAL',$1);
#FLOATING_POINT_LITERAL:	([0-9])*'.'([0-9])+('e'('+'|'-')?([0-9])+)?;
    } elsif ($self->YYData->{INPUT} =~ m/\G((?:[0-9])*'.'(?:[0-9])+(?:'e'(?:'+'|'-')?(?:[0-9])+)?)/gc) {
	($token, $value) = ('FLOATING_POINT_LITERAL',$1);
#Identifier:			([a-z][A-Z][0-9][-_.])+;
    } elsif ($self->YYData->{INPUT} =~ m/\G([a-zA-Z0-9\_][a-zA-Z0-9\_\.-]*)/gc) {
	($token, $value) = ($KeyWords{lc $1} || 'IDENTIFIER', $1);
#STRING_LITERAL1:		'"'UTF-8 characters'"' (with escaped \");
    } elsif ($self->YYData->{INPUT} =~ m/\G\"([^\"]*)\"/gc) {
	my $str = $1;
	while (substr($str, length($str) - 1, 1) eq '"') {
	    if ($self->YYData->{INPUT} =~ m/\G([^\"]*)\"/gc) {
		$str = substr($str, 0, length($str) - 1).$1;
	    } else {
		&throw(new W3C::Util::YappDriver::MesgYappContextException($self, 
					-location => $self->YYData->{LOCATION}));
	    }
	}
	($token, $value) = ('STRING_LITERAL1', $str);
#STRING_LITERAL2:		"'"UTF-8 characters"'" (with escaped \');
    } elsif ($self->YYData->{INPUT} =~ m/\G\'([^\']*)\'/gc) {
	my $str = $1;
	while (substr($str, length($str) - 1, 1) eq "'") {
	    if ($self->YYData->{INPUT} =~ m/\G([^\']*)\'/gc) {
		$str = substr($str, 0, length($str) - 1).$1;
	    } else {
		&throw(new W3C::Util::YappDriver::MesgYappContextException($self, 
					-location => $self->YYData->{LOCATION}));
	    }
	}
	($token, $value) = ('STRING_LITERAL1', $str);
    } elsif ($self->YYData->{INPUT} =~ m/\G([A-Za-z][A-Za-z0-9_-]*)/gc) {
	($token, $value) = ($1,$1);
    } elsif ($self->YYData->{INPUT} =~ m/\G(==|\!=|<=|>=|\|\||\.)/gc) {
	($token, $value) = ($1,$1);
    } elsif ($self->YYData->{INPUT} =~ m/\G(.)/gc) {
	($token, $value) = ($1,$1);
    }
    my $pos = pos $self->YYData->{INPUT};
    #print "\n$pos,$token,$value\n";
    return ($token, $value);
}

sub parse {
    my ($self, @args) = @_;
    $self->YYData->{NEXT} = undef;
    return $self->SUPER::parse(@args);
}

# Provide (one) chunk of text to parse.
sub nextChunk {
    my ($self) = @_;
    #return shift (@{$self->YYData->{my_CHUNKS}});
    #return shift (@ARGV);
    return <STDIN>;
}

# Handy debugging wrapper for calling semantics actions.
sub _wrap {
    my ($self, $obj, $method, @args) = @_;
    my @ret;
    eval {
	@ret = $obj->$method(@args);
    }; if ($@) {if (my $ex = &catch('W3C::Util::CachedContextException')) {
	&throw($ex);;
    } elsif ($ex = &catch('W3C::Util::Exception')) {
	my $newEx = new 
	    W3C::Util::CachedContextException(-str => $self->YYData->{INPUT}, 
					      -pos => $self->YYData->{my_LASTPOS}+1, 
					      -errorMessage => $ex->toString);
	$newEx->assumeStackTrace($ex);
	&throw($newEx);
    } else {
	my $newEx = 
	    new W3C::Util::CachedContextException(-str => $self->YYData->{INPUT}, 
						  -pos => $self->YYData->{my_LASTPOS}+1, 
						  -errorMessage => "$obj->$method: $@");
	&throw($newEx);
    }}
    return wantarray ? @ret : $ret[-1];
}

sub printArgs {
    return;
    print ':';
    foreach my $arg (@_) {
	print " $arg";
    }
    print ' Curtok:',$_[0]->YYCurtok;
    print ' Curval:',$_[0]->YYCurval;
    print ' Expect:',$_[0]->YYExpect;
    print ' Lexer:',$_[0]->YYLexer;
    print ' Data:',$_[0]->YYData;
    print "\n";
}

# Used by -M invocation:
#   perl -MW3C::Rdf::BrqlParser -e '(new W3C::Rdf::RLBrqlParser())->Run' '...'
sub main {
    my ($self) = @_;
    $self->Run();
}

# <parser state support>
sub resolveQNames {
    my ($self) = @_;
    foreach my $qname (@{$self->YYData->{QNAMES}}) {
	$qname->resolveNS();
    }
}

# </parser state support>

package W3C::Rdf::BrqlParser;
@W3C::Rdf::BrqlParser::ISA = qw(W3C::Rdf::_BrqlParser);
sub new {
    my ($proto, $brqlString, $algae2, $location, @yappParms) = @_;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new(@yappParms);
    $self->YYData->{BRQL_STRING} = $brqlString;
    $self->YYData->{LOCATION} = $location;
 
    $self->YYData->{ALGAE2} = $algae2;
    $self->YYData->{QNAMES} = [];
    return $self;
}

sub nextChunk {
    my ($self) = @_;
    my $ret = $self->YYData->{BRQL_STRING};
    $self->YYData->{BRQL_STRING} = undef;
    return $ret;
}

# Interactive ReadLine parser -- under development
package W3C::Rdf::RLBrqlParser;
use W3C::Util::Exception;
@W3C::Rdf::RLBrqlParser::ISA = qw(W3C::Rdf::BrqlParser);
sub new {
    my ($proto, @parms) = @_;
    my $class = ref($proto) || $proto;

    # Change the parser driver to the readline driver.
    @W3C::Rdf::_BrqlParser::ISA = qw (W3C::Util::rlDriver);

    my $self = $class->SUPER::new(@parms);
    $self->YYData->{ACTIONS} = [];
    return $self;
}

sub nextChunk {
    my ($self) = @_;
    my $ret = undef;
    if ($self->{rl_COMPLETE_MODE}) {
	if ($self->{rl_SO_FAR}) {
	    $ret = $self->{rl_SO_FAR};
	    $self->{rl_SO_FAR} = undef;
	    #print "nextChunk: $ret\n";
	}
    } else {
	if (@{$self->YYData->{my_CHUNKS}}) {
	    $ret = shift (@{$self->YYData->{my_CHUNKS}});
	} else {
	    #return shift (@ARGV);
	    $ret = $self->readline('')."\n";
	    #print "ret: $ret";
	}
    }
    return $ret;
}

# perl -MW3C::Rdf::BrqlParser -e '(new W3C::Rdf::RLBrqlParser())->Run' 'asdf'
# b /usr/share/perl5/Parse/Yapp/Driver.pm:343

##!/usr/bin/perl
#BEGIN {unshift@INC,('../..');}
#use W3C::Rdf::BrqlParser;
#$p = new W3C::Rdf::RLBrqlParser();
#$p->main;

#./BrqlParser "(ask '(<ab:cd> (?asdf ?s ?o)) assert '(ef:gh (?a ?b ?c)))"

1;

__END__

=head1 NAME

W3C::Rdf::BrqlParser - a Parse::Yapp grammer for the BRQL language

=head1 SYNOPSIS

  use W3C::Rdf::BrqlParser;
  my $p = new W3C::Rdf::BrqlParser($brqlString, $query, "query.txt");
  my $actions = $p->parse($debug);
  foreach my $action (@$actions) {
    $action->delayedEvaluate($self->{RESULT_SET});
  }
  return $self->getReport();

=head1 DESCRIPTION

The BrqlParser module binds a yapp grammar to semantic actions that build an
AlgaeCompileTree. In general, client applicatiosn have no direct interaction
with BrqlParser. Devlopers wishing to extend the BRQL query language
  http://www.w3.org/Submission/BRQL/

will need the perl yapp modules. The Makefile included with the W3C::Rdf CPAN
module has a target to re-compile the BrqlParser grammar. Invoke this with
  make BrqlParser.pm
It is likely that someone extending the BrqlParser grammar will also want to
extended AlgaeCompileTree.

This module is part of the W3C::Rdf CPAN module.

=head1 AUTHOR

Eric Prud\'hommeaux <eric@w3.org>

=head1 SEE ALSO

W3C::Rdf::AlgaeCompileTree(3) W3C::Rdf::Algae2(3) perl(1).

=cut

1;
