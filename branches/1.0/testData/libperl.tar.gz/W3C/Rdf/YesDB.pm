#Copyright Massachusetts Institute of technology, 1998.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

use strict;
require Exporter;

$W3C::Rdf::YesDB::REVISION = '$Id: YesDB.pm,v 1.3 2004/06/07 09:27:30 eric Exp $ ';

package W3C::Rdf::YesDB;
use vars qw($VERSION $DSLI @ISA @EXPORT @EXPORT_OK);
@ISA = qw(Exporter);
@EXPORT = qw();
$VERSION = 0.94;
$DSLI = 'adpO';

use Net::Telnet;

use W3C::Rdf::RdfDB;
package W3C::Rdf::YesDB;
@W3C::Rdf::YesDB::ISA = qw(W3C::Rdf::RdfDB);
use W3C::Util::Exception;

sub triplesMatching {
    my ($self, $view, $lookFors, $flags) = @_;

    my @results;
    foreach my $lookFor (@$lookFors) {
	my ($p, $s, $o, $c, $r, $a) = @$lookFor;

	if ($p && $s && $o) {
	    my $statement = new W3C::Rdf::MappedTriple($self, $p, $s, $o, $self->{-sourceAttribution});
	    push (@results, $statement);
	}
    }
    return @results;
}

1;

__END__

=head1 NAME

W3C::Rdf::YesDB - an agreeable RdfDB

=head1 SYNOPSIS

  use W3C::Rdf::FingerDB;
  my $FingerDB = new W3C::Rdf::FingerDB(-atomDictionary => $atoms);

=head1 DESCRIPTION

C<W3C::Rdf::FingerDB> is an RDF database following the C<W3C::Rdf::RdfDB>
interface. This database holds no triples, but agrees to every fully
constrained triple query (test for a triple pattern with no variables).

This module is part of the W3C::Rdf CPAN module.

=head1 AUTHOR

Eric Prud'hommeaux <eric@w3.org>

=head1 SEE ALSO

L<W3C::Rdf::RdfDB>
L<W3C::Rdf::Algae2>

=head1 COPYRIGHT

Copyright Massachusetts Institute of technology, 1998.

THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND COPYRIGHT HOLDERS MAKE NO REPRESENTATIONS
OR WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO, WARRANTIES OF MERCHANTABILITY OR
FITNESS FOR ANY PARTICULAR PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL NOT INFRINGE
ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER RIGHTS. 

COPYRIGHT HOLDERS WILL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF ANY USE OF THE SOFTWARE OR DOCUMENTATION. 

The name and trademarks of copyright holders may NOT be used in advertising or publicity pertaining 
to the software without specific, written prior permission. Title to copyright in this software and 
any associated documentation will at all times remain with copyright holders. 

=cut
