# Configuration for test.pl

$test::tripleStore = 1;
$test::orderTracking = 1;
$test::toxicAssoc = 0;
$test::http = 1;
$test::finger = 0;
1;
