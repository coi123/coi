#!/usr/bin/perl
####################################################################
#
#    This file was generated using Parse::Yapp version 1.05.
#
#        Don't edit this file, use source file instead.
#
#             ANY CHANGE MADE HERE WILL BE LOST !
#
####################################################################
package W3C::Rdf::_AlgaeParser;
use vars qw ( @ISA );
use strict;

@ISA= qw ( Parse::Yapp::Driver );
# use Parse::Yapp::Driver; @@ replaced by W3C::Util::YappDriver

#line 27 "AlgaeParser.yp"

    #BEGIN {unshift@INC,('../..');}
    use W3C::Util::YappDriver;
    @ISA= qw (W3C::Util::YappDriver);

    use W3C::Rdf::AlgaeCompileTree qw($BASE_FILE $BASE_HTTP);


sub new {
        my($class)=shift;
        ref($class)
    and $class=ref($class);

    my($self)=$class->SUPER::new( yyversion => '1.05',
                                  yystates =>
[
	{#State 0
		DEFAULT => -2,
		GOTOS => {
			'input' => 2,
			'@1-0' => 1,
			'cmnds' => 3
		}
	},
	{#State 1
		DEFAULT => -4,
		GOTOS => {
			'actionStar' => 4
		}
	},
	{#State 2
		ACTIONS => {
			'' => 5
		}
	},
	{#State 3
		DEFAULT => -1
	},
	{#State 4
		ACTIONS => {
			"read" => 25,
			"\@" => 8,
			"attach" => 7,
			"fwrule" => 6,
			"namespace" => 11,
			"require" => 10,
			"profileQuery" => 26,
			"ns" => 13,
			"base" => 14,
			"slurp" => 33,
			"host" => 32,
			"collect" => 15,
			"assert" => 17,
			"quit" => 36,
			"flags" => 18,
			"clear" => 37,
			"ask" => 22,
			"select" => 38
		},
		DEFAULT => -3,
		GOTOS => {
			'requireStr' => 24,
			'quit' => 35,
			'actionStr' => 9,
			'collectStr' => 19,
			'clear' => 12,
			'profileQueryStr' => 20,
			'namespaceStr' => 28,
			'assertStr' => 27,
			'fwRuleStr' => 21,
			'askStr' => 30,
			'flagsStr' => 29,
			'hostStr' => 31,
			'baseStr' => 34,
			'slurpStr' => 16,
			'attachStr' => 23
		}
	},
	{#State 5
		DEFAULT => 0
	},
	{#State 6
		ACTIONS => {
			"ask" => 22
		},
		GOTOS => {
			'askStr' => 39
		}
	},
	{#State 7
		DEFAULT => -29,
		GOTOS => {
			'@8-1' => 40
		}
	},
	{#State 8
		DEFAULT => -6,
		GOTOS => {
			'@2-2' => 41
		}
	},
	{#State 9
		DEFAULT => -5
	},
	{#State 10
		DEFAULT => -64,
		GOTOS => {
			'@29-1' => 42
		}
	},
	{#State 11
		DEFAULT => -54,
		GOTOS => {
			'@22-1' => 43
		}
	},
	{#State 12
		DEFAULT => -13
	},
	{#State 13
		DEFAULT => -52,
		GOTOS => {
			'@21-1' => 44
		}
	},
	{#State 14
		ACTIONS => {
			"uri" => 45,
			"http" => 46,
			"file" => 47
		}
	},
	{#State 15
		ACTIONS => {
			"(" => 48
		}
	},
	{#State 16
		DEFAULT => -20
	},
	{#State 17
		DEFAULT => -26,
		GOTOS => {
			'@6-1' => 49
		}
	},
	{#State 18
		ACTIONS => {
			"-" => 50,
			"+" => 52
		},
		DEFAULT => -128,
		GOTOS => {
			'setOp' => 51
		}
	},
	{#State 19
		DEFAULT => -16
	},
	{#State 20
		DEFAULT => -22
	},
	{#State 21
		DEFAULT => -15
	},
	{#State 22
		DEFAULT => -23,
		GOTOS => {
			'@4-1' => 53
		}
	},
	{#State 23
		DEFAULT => -11
	},
	{#State 24
		DEFAULT => -19
	},
	{#State 25
		DEFAULT => -60,
		GOTOS => {
			'@26-1' => 54
		}
	},
	{#State 26
		DEFAULT => -67,
		GOTOS => {
			'@30-1' => 55
		}
	},
	{#State 27
		DEFAULT => -10
	},
	{#State 28
		DEFAULT => -18
	},
	{#State 29
		DEFAULT => -14
	},
	{#State 30
		DEFAULT => -9
	},
	{#State 31
		DEFAULT => -17
	},
	{#State 32
		DEFAULT => -44,
		GOTOS => {
			'@16-1' => 56
		}
	},
	{#State 33
		DEFAULT => -56,
		GOTOS => {
			'@23-1' => 57
		}
	},
	{#State 34
		DEFAULT => -12
	},
	{#State 35
		DEFAULT => -21
	},
	{#State 36
		DEFAULT => -66
	},
	{#State 37
		DEFAULT => -37
	},
	{#State 38
		ACTIONS => {
			"(" => 58
		}
	},
	{#State 39
		ACTIONS => {
			"assert" => 17
		},
		GOTOS => {
			'assertStr' => 59
		}
	},
	{#State 40
		ACTIONS => {
			'URL' => 62,
			"?" => 65,
			'VAR' => 63
		},
		GOTOS => {
			'variable' => 64,
			'qname' => 66,
			'url' => 61,
			'urlvar' => 60
		}
	},
	{#State 41
		ACTIONS => {
			'URL' => 62,
			'FILE' => 67,
			'VAR' => 63
		},
		GOTOS => {
			'filename' => 70,
			'qname' => 66,
			'url' => 68,
			'sourceStr' => 69
		}
	},
	{#State 42
		ACTIONS => {
			'URL' => 62,
			'VAR' => 63
		},
		GOTOS => {
			'qname' => 66,
			'url' => 71
		}
	},
	{#State 43
		ACTIONS => {
			'URL' => 62,
			'VAR' => 75
		},
		GOTOS => {
			'qname' => 66,
			'name' => 73,
			'url' => 72,
			'namespaceDecl' => 74
		}
	},
	{#State 44
		ACTIONS => {
			'URL' => 62,
			'VAR' => 75
		},
		GOTOS => {
			'qname' => 66,
			'name' => 73,
			'url' => 72,
			'namespaceDecl' => 76
		}
	},
	{#State 45
		DEFAULT => -34,
		GOTOS => {
			'@10-2' => 77
		}
	},
	{#State 46
		DEFAULT => -33
	},
	{#State 47
		DEFAULT => -32
	},
	{#State 48
		DEFAULT => -38,
		GOTOS => {
			'@12-2' => 78
		}
	},
	{#State 49
		ACTIONS => {
			'URL' => 62,
			"?" => 65,
			'VAR' => 63
		},
		DEFAULT => -165,
		GOTOS => {
			'dbSpec' => 79,
			'variable' => 82,
			'qname' => 66,
			'url' => 80,
			'optDbSpec' => 81
		}
	},
	{#State 50
		DEFAULT => -130
	},
	{#State 51
		ACTIONS => {
			"(" => 83
		}
	},
	{#State 52
		DEFAULT => -129
	},
	{#State 53
		ACTIONS => {
			'URL' => 62,
			"?" => 65,
			'VAR' => 63
		},
		DEFAULT => -165,
		GOTOS => {
			'dbSpec' => 79,
			'variable' => 82,
			'qname' => 66,
			'url' => 80,
			'optDbSpec' => 84
		}
	},
	{#State 54
		ACTIONS => {
			'URL' => 62,
			'FILE' => 67,
			'VAR' => 63
		},
		GOTOS => {
			'filename' => 70,
			'qname' => 66,
			'url' => 68,
			'sourceStr' => 85
		}
	},
	{#State 55
		ACTIONS => {
			"(" => 86
		}
	},
	{#State 56
		ACTIONS => {
			'URL' => 62,
			"?" => 65,
			'VAR' => 63
		},
		DEFAULT => -165,
		GOTOS => {
			'dbSpec' => 79,
			'variable' => 82,
			'qname' => 66,
			'url' => 80,
			'optDbSpec' => 87
		}
	},
	{#State 57
		ACTIONS => {
			'URL' => 62,
			'FILE' => 67,
			'VAR' => 63
		},
		GOTOS => {
			'filename' => 70,
			'qname' => 66,
			'url' => 68,
			'sourceStr' => 88
		}
	},
	{#State 58
		DEFAULT => -41,
		GOTOS => {
			'@14-2' => 89
		}
	},
	{#State 59
		DEFAULT => -51
	},
	{#State 60
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"%" => 90,
			'DtSTR' => 95,
			'VAR' => 63
		},
		GOTOS => {
			'variable' => 64,
			'str' => 93,
			'urlvar' => 91,
			'literal' => 92,
			'urlvarlit' => 94,
			'internalName' => 99,
			'url' => 61,
			'qname' => 66
		}
	},
	{#State 61
		DEFAULT => -149
	},
	{#State 62
		DEFAULT => -170
	},
	{#State 63
		ACTIONS => {
			":" => 100
		},
		DEFAULT => -173
	},
	{#State 64
		DEFAULT => -150
	},
	{#State 65
		ACTIONS => {
			'VAR' => 101
		},
		GOTOS => {
			'variableName' => 102
		}
	},
	{#State 66
		DEFAULT => -171
	},
	{#State 67
		DEFAULT => -169
	},
	{#State 68
		DEFAULT => -135
	},
	{#State 69
		DEFAULT => -7,
		GOTOS => {
			'@3-4' => 103
		}
	},
	{#State 70
		DEFAULT => -136
	},
	{#State 71
		DEFAULT => -65
	},
	{#State 72
		DEFAULT => -127
	},
	{#State 73
		ACTIONS => {
			"=" => 104
		}
	},
	{#State 74
		DEFAULT => -55
	},
	{#State 75
		ACTIONS => {
			":" => 100,
			"=" => -164
		},
		DEFAULT => -173
	},
	{#State 76
		DEFAULT => -53
	},
	{#State 77
		ACTIONS => {
			'URL' => 62,
			'VAR' => 63
		},
		GOTOS => {
			'qname' => 66,
			'url' => 105
		}
	},
	{#State 78
		ACTIONS => {
			"?" => 108
		},
		GOTOS => {
			'knownVar' => 106,
			'knownVars' => 107
		}
	},
	{#State 79
		DEFAULT => -166
	},
	{#State 80
		DEFAULT => -167
	},
	{#State 81
		ACTIONS => {
			"(" => 109
		}
	},
	{#State 82
		DEFAULT => -168
	},
	{#State 83
		DEFAULT => -48,
		GOTOS => {
			'@19-3' => 110
		}
	},
	{#State 84
		ACTIONS => {
			"(" => 111
		}
	},
	{#State 85
		DEFAULT => -61,
		GOTOS => {
			'@27-3' => 112
		}
	},
	{#State 86
		ACTIONS => {
			'URL' => 62,
			'VAR' => 63
		},
		GOTOS => {
			'qname' => 66,
			'url' => 113
		}
	},
	{#State 87
		ACTIONS => {
			"(" => 114
		}
	},
	{#State 88
		DEFAULT => -57,
		GOTOS => {
			'@24-3' => 115
		}
	},
	{#State 89
		ACTIONS => {
			"?" => 108
		},
		GOTOS => {
			'knownVar' => 106,
			'knownVars' => 116
		}
	},
	{#State 90
		ACTIONS => {
			'VAR' => 118
		},
		GOTOS => {
			'name' => 117
		}
	},
	{#State 91
		DEFAULT => -151
	},
	{#State 92
		DEFAULT => -152
	},
	{#State 93
		DEFAULT => -157
	},
	{#State 94
		ACTIONS => {
			"(" => 119
		}
	},
	{#State 95
		ACTIONS => {
			'URL' => 62,
			'VAR' => 63
		},
		GOTOS => {
			'qname' => 66,
			'url' => 120
		}
	},
	{#State 96
		DEFAULT => -161
	},
	{#State 97
		DEFAULT => -159
	},
	{#State 98
		DEFAULT => -158
	},
	{#State 99
		DEFAULT => -153
	},
	{#State 100
		ACTIONS => {
			'VAR' => 121
		}
	},
	{#State 101
		DEFAULT => -156
	},
	{#State 102
		DEFAULT => -154
	},
	{#State 103
		DEFAULT => -8
	},
	{#State 104
		ACTIONS => {
			'URL' => 62,
			'VAR' => 63
		},
		GOTOS => {
			'qname' => 66,
			'url' => 122
		}
	},
	{#State 105
		DEFAULT => -35,
		GOTOS => {
			'@11-4' => 123
		}
	},
	{#State 106
		DEFAULT => -124
	},
	{#State 107
		ACTIONS => {
			"?" => 108,
			")" => 125
		},
		GOTOS => {
			'knownVar' => 124
		}
	},
	{#State 108
		ACTIONS => {
			'VAR' => 101
		},
		GOTOS => {
			'variableName' => 126
		}
	},
	{#State 109
		ACTIONS => {
			'URL' => 62,
			"?" => 65,
			'VAR' => 63,
			"[" => 129
		},
		GOTOS => {
			'declList' => 131,
			'variable' => 64,
			'decl' => 128,
			'subject' => 130,
			'qname' => 66,
			'url' => 61,
			'urlvar' => 127
		}
	},
	{#State 110
		DEFAULT => -122,
		GOTOS => {
			'bindingStar' => 132
		}
	},
	{#State 111
		ACTIONS => {
			'URL' => 62,
			"(" => 136,
			"!" => 134,
			"?" => 65,
			'VAR' => 63,
			"~" => 133,
			"[" => 129
		},
		GOTOS => {
			'variable' => 64,
			'subject' => 130,
			'urlvar' => 127,
			'graphPattern' => 138,
			'decl' => 135,
			'QTerm' => 137,
			'url' => 61,
			'qname' => 66
		}
	},
	{#State 112
		ACTIONS => {
			'URL' => 62,
			"?" => 65,
			'VAR' => 63
		},
		DEFAULT => -165,
		GOTOS => {
			'dbSpec' => 79,
			'variable' => 82,
			'qname' => 66,
			'url' => 80,
			'optDbSpec' => 139
		}
	},
	{#State 113
		ACTIONS => {
			"?" => 65
		},
		GOTOS => {
			'variable' => 140
		}
	},
	{#State 114
		DEFAULT => -45,
		GOTOS => {
			'@17-4' => 141
		}
	},
	{#State 115
		ACTIONS => {
			'URL' => 62,
			"?" => 65,
			'VAR' => 63
		},
		DEFAULT => -165,
		GOTOS => {
			'dbSpec' => 79,
			'variable' => 82,
			'qname' => 66,
			'url' => 80,
			'optDbSpec' => 142
		}
	},
	{#State 116
		ACTIONS => {
			"?" => 108,
			")" => 143
		},
		GOTOS => {
			'knownVar' => 124
		}
	},
	{#State 117
		DEFAULT => -148
	},
	{#State 118
		DEFAULT => -164
	},
	{#State 119
		DEFAULT => -122,
		GOTOS => {
			'bindingStar' => 144
		}
	},
	{#State 120
		DEFAULT => -160
	},
	{#State 121
		DEFAULT => -172
	},
	{#State 122
		DEFAULT => -126
	},
	{#State 123
		DEFAULT => -36
	},
	{#State 124
		DEFAULT => -125
	},
	{#State 125
		DEFAULT => -39,
		GOTOS => {
			'@13-5' => 145
		}
	},
	{#State 126
		DEFAULT => -155
	},
	{#State 127
		DEFAULT => -137
	},
	{#State 128
		DEFAULT => -70
	},
	{#State 129
		ACTIONS => {
			'URL' => 62,
			"?" => 65,
			'VAR' => 63
		},
		DEFAULT => -142,
		GOTOS => {
			'variable' => 64,
			'nulPropValList' => 149,
			'propValueList' => 148,
			'qname' => 66,
			'url' => 61,
			'property' => 147,
			'urlvar' => 146
		}
	},
	{#State 130
		ACTIONS => {
			'URL' => 62,
			"?" => 65,
			'VAR' => 63
		},
		GOTOS => {
			'variable' => 64,
			'propValueList' => 150,
			'qname' => 66,
			'url' => 61,
			'property' => 147,
			'urlvar' => 146
		}
	},
	{#State 131
		ACTIONS => {
			")" => 152,
			"." => 151
		}
	},
	{#State 132
		ACTIONS => {
			'VAR' => 118,
			"%" => 90,
			")" => 155
		},
		GOTOS => {
			'internalName' => 156,
			'name' => 154,
			'binding' => 153
		}
	},
	{#State 133
		ACTIONS => {
			'URL' => 62,
			"(" => 136,
			"!" => 134,
			"?" => 65,
			'VAR' => 63,
			"~" => 133,
			"[" => 129
		},
		GOTOS => {
			'variable' => 64,
			'QTerm' => 157,
			'decl' => 135,
			'subject' => 130,
			'qname' => 66,
			'url' => 61,
			'urlvar' => 127
		}
	},
	{#State 134
		ACTIONS => {
			'URL' => 62,
			"?" => 65,
			'VAR' => 63,
			"[" => 129
		},
		GOTOS => {
			'variable' => 64,
			'decl' => 158,
			'subject' => 130,
			'qname' => 66,
			'url' => 61,
			'urlvar' => 127
		}
	},
	{#State 135
		DEFAULT => -86
	},
	{#State 136
		ACTIONS => {
			'URL' => 62,
			"(" => 136,
			"!" => 134,
			"?" => 65,
			'VAR' => 63,
			"~" => 133,
			"[" => 129
		},
		GOTOS => {
			'variable' => 64,
			'subject' => 130,
			'urlvar' => 127,
			'graphPattern' => 159,
			'decl' => 135,
			'QTerm' => 137,
			'url' => 61,
			'qname' => 66
		}
	},
	{#State 137
		DEFAULT => -78
	},
	{#State 138
		ACTIONS => {
			"|&" => 164,
			"|-" => 163,
			"||" => 160,
			"." => 162
		},
		DEFAULT => -90,
		GOTOS => {
			'dotOpt' => 161
		}
	},
	{#State 139
		ACTIONS => {
			"(" => 165
		}
	},
	{#State 140
		ACTIONS => {
			")" => 166
		}
	},
	{#State 141
		ACTIONS => {
			"?" => 108
		},
		GOTOS => {
			'knownVar' => 106,
			'knownVars' => 167
		}
	},
	{#State 142
		ACTIONS => {
			"(" => 168
		}
	},
	{#State 143
		DEFAULT => -42,
		GOTOS => {
			'@15-5' => 169
		}
	},
	{#State 144
		ACTIONS => {
			'VAR' => 118,
			"%" => 90,
			")" => 170
		},
		GOTOS => {
			'internalName' => 156,
			'name' => 154,
			'binding' => 153
		}
	},
	{#State 145
		DEFAULT => -40
	},
	{#State 146
		DEFAULT => -139
	},
	{#State 147
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"%" => 90,
			'DtSTR' => 95,
			'VAR' => 63,
			"[" => 171
		},
		GOTOS => {
			'variable' => 64,
			'str' => 93,
			'value' => 172,
			'urlvar' => 91,
			'literal' => 92,
			'urlvarlit' => 173,
			'valueList' => 174,
			'internalName' => 99,
			'qname' => 66,
			'url' => 61
		}
	},
	{#State 148
		ACTIONS => {
			";" => 176,
			"." => 175
		},
		DEFAULT => -143
	},
	{#State 149
		ACTIONS => {
			"]" => 177
		}
	},
	{#State 150
		ACTIONS => {
			";" => 178
		},
		DEFAULT => -73
	},
	{#State 151
		ACTIONS => {
			'URL' => 62,
			"?" => 65,
			'VAR' => 63,
			"[" => 129
		},
		DEFAULT => -71,
		GOTOS => {
			'variable' => 64,
			'decl' => 179,
			'subject' => 130,
			'qname' => 66,
			'url' => 61,
			'urlvar' => 127
		}
	},
	{#State 152
		DEFAULT => -27,
		GOTOS => {
			'@7-6' => 180
		}
	},
	{#State 153
		DEFAULT => -123
	},
	{#State 154
		ACTIONS => {
			"=" => 181
		}
	},
	{#State 155
		DEFAULT => -49,
		GOTOS => {
			'@20-6' => 182
		}
	},
	{#State 156
		ACTIONS => {
			"=" => 183
		}
	},
	{#State 157
		DEFAULT => -88
	},
	{#State 158
		DEFAULT => -89
	},
	{#State 159
		ACTIONS => {
			"|&" => 164,
			"|-" => 163,
			"||" => 160,
			"." => 162
		},
		DEFAULT => -90,
		GOTOS => {
			'dotOpt' => 184
		}
	},
	{#State 160
		ACTIONS => {
			'URL' => 62,
			"(" => 136,
			"!" => 134,
			"?" => 65,
			'VAR' => 63,
			"~" => 133,
			"[" => 129
		},
		GOTOS => {
			'variable' => 64,
			'subject' => 130,
			'urlvar' => 127,
			'graphPattern' => 185,
			'decl' => 135,
			'QTerm' => 137,
			'url' => 61,
			'qname' => 66
		}
	},
	{#State 161
		ACTIONS => {
			")" => 186
		}
	},
	{#State 162
		ACTIONS => {
			'URL' => 62,
			"|&" => 189,
			"?" => 65,
			"|-" => 188,
			"||" => 187,
			"~" => 133,
			"!" => 134,
			"(" => 136,
			'VAR' => 63,
			"[" => 129
		},
		DEFAULT => -91,
		GOTOS => {
			'variable' => 64,
			'subject' => 130,
			'urlvar' => 127,
			'graphPattern' => 190,
			'decl' => 135,
			'QTerm' => 137,
			'url' => 61,
			'qname' => 66
		}
	},
	{#State 163
		ACTIONS => {
			'URL' => 62,
			"(" => 136,
			"!" => 134,
			"?" => 65,
			'VAR' => 63,
			"~" => 133,
			"[" => 129
		},
		GOTOS => {
			'variable' => 64,
			'subject' => 130,
			'urlvar' => 127,
			'graphPattern' => 191,
			'decl' => 135,
			'QTerm' => 137,
			'url' => 61,
			'qname' => 66
		}
	},
	{#State 164
		ACTIONS => {
			'URL' => 62,
			"(" => 136,
			"!" => 134,
			"?" => 65,
			'VAR' => 63,
			"~" => 133,
			"[" => 129
		},
		GOTOS => {
			'variable' => 64,
			'subject' => 130,
			'urlvar' => 127,
			'graphPattern' => 192,
			'decl' => 135,
			'QTerm' => 137,
			'url' => 61,
			'qname' => 66
		}
	},
	{#State 165
		DEFAULT => -122,
		GOTOS => {
			'bindingStar' => 193
		}
	},
	{#State 166
		DEFAULT => -68,
		GOTOS => {
			'@31-6' => 194
		}
	},
	{#State 167
		ACTIONS => {
			"?" => 108,
			")" => 195
		},
		GOTOS => {
			'knownVar' => 124
		}
	},
	{#State 168
		DEFAULT => -122,
		GOTOS => {
			'bindingStar' => 196
		}
	},
	{#State 169
		DEFAULT => -43
	},
	{#State 170
		DEFAULT => -30,
		GOTOS => {
			'@9-7' => 197
		}
	},
	{#State 171
		ACTIONS => {
			'URL' => 62,
			"?" => 65,
			'VAR' => 63
		},
		DEFAULT => -142,
		GOTOS => {
			'variable' => 64,
			'nulPropValList' => 198,
			'propValueList' => 148,
			'qname' => 66,
			'url' => 61,
			'property' => 147,
			'urlvar' => 146
		}
	},
	{#State 172
		DEFAULT => -92,
		GOTOS => {
			'constraintStar' => 199
		}
	},
	{#State 173
		DEFAULT => -140
	},
	{#State 174
		ACTIONS => {
			"," => 200
		},
		DEFAULT => -74
	},
	{#State 175
		DEFAULT => -144
	},
	{#State 176
		ACTIONS => {
			'URL' => 62,
			"?" => 65,
			'VAR' => 63,
			"." => 202
		},
		GOTOS => {
			'variable' => 64,
			'qname' => 66,
			'url' => 61,
			'property' => 201,
			'urlvar' => 146
		}
	},
	{#State 177
		DEFAULT => -138
	},
	{#State 178
		ACTIONS => {
			'URL' => 62,
			"?" => 65,
			'VAR' => 63
		},
		GOTOS => {
			'variable' => 64,
			'qname' => 66,
			'url' => 61,
			'property' => 201,
			'urlvar' => 146
		}
	},
	{#State 179
		DEFAULT => -72
	},
	{#State 180
		DEFAULT => -28
	},
	{#State 181
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"%" => 90,
			'DtSTR' => 95,
			'VAR' => 63
		},
		GOTOS => {
			'variable' => 64,
			'str' => 93,
			'urlvar' => 91,
			'literal' => 92,
			'urlvarlit' => 203,
			'internalName' => 99,
			'url' => 61,
			'qname' => 66
		}
	},
	{#State 182
		DEFAULT => -50
	},
	{#State 183
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"%" => 90,
			'DtSTR' => 95,
			'VAR' => 63
		},
		GOTOS => {
			'variable' => 64,
			'str' => 93,
			'urlvar' => 91,
			'literal' => 92,
			'urlvarlit' => 204,
			'internalName' => 99,
			'url' => 61,
			'qname' => 66
		}
	},
	{#State 184
		ACTIONS => {
			")" => 205
		}
	},
	{#State 185
		ACTIONS => {
			"|&" => 164,
			"|-" => 163,
			"||" => 160,
			"." => 206
		},
		DEFAULT => -80
	},
	{#State 186
		DEFAULT => -24,
		GOTOS => {
			'@5-7' => 207
		}
	},
	{#State 187
		ACTIONS => {
			'URL' => 62,
			"(" => 136,
			"!" => 134,
			"?" => 65,
			'VAR' => 63,
			"~" => 133,
			"[" => 129
		},
		GOTOS => {
			'variable' => 64,
			'subject' => 130,
			'urlvar' => 127,
			'graphPattern' => 208,
			'decl' => 135,
			'QTerm' => 137,
			'url' => 61,
			'qname' => 66
		}
	},
	{#State 188
		ACTIONS => {
			'URL' => 62,
			"(" => 136,
			"!" => 134,
			"?" => 65,
			'VAR' => 63,
			"~" => 133,
			"[" => 129
		},
		GOTOS => {
			'variable' => 64,
			'subject' => 130,
			'urlvar' => 127,
			'graphPattern' => 209,
			'decl' => 135,
			'QTerm' => 137,
			'url' => 61,
			'qname' => 66
		}
	},
	{#State 189
		ACTIONS => {
			'URL' => 62,
			"(" => 136,
			"!" => 134,
			"?" => 65,
			'VAR' => 63,
			"~" => 133,
			"[" => 129
		},
		GOTOS => {
			'variable' => 64,
			'subject' => 130,
			'urlvar' => 127,
			'graphPattern' => 210,
			'decl' => 135,
			'QTerm' => 137,
			'url' => 61,
			'qname' => 66
		}
	},
	{#State 190
		ACTIONS => {
			"." => 206
		},
		DEFAULT => -79
	},
	{#State 191
		ACTIONS => {
			"|-" => 163,
			"." => 206
		},
		DEFAULT => -82
	},
	{#State 192
		ACTIONS => {
			"|&" => 164,
			"|-" => 163,
			"." => 206
		},
		DEFAULT => -81
	},
	{#State 193
		ACTIONS => {
			'VAR' => 118,
			"%" => 90,
			")" => 211
		},
		GOTOS => {
			'internalName' => 156,
			'name' => 154,
			'binding' => 153
		}
	},
	{#State 194
		DEFAULT => -69
	},
	{#State 195
		DEFAULT => -46,
		GOTOS => {
			'@18-7' => 212
		}
	},
	{#State 196
		ACTIONS => {
			'VAR' => 118,
			"%" => 90,
			")" => 213
		},
		GOTOS => {
			'internalName' => 156,
			'name' => 154,
			'binding' => 153
		}
	},
	{#State 197
		DEFAULT => -31
	},
	{#State 198
		ACTIONS => {
			"]" => 214
		}
	},
	{#State 199
		ACTIONS => {
			"{" => 215
		},
		DEFAULT => -76
	},
	{#State 200
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"%" => 90,
			'DtSTR' => 95,
			'VAR' => 63,
			"[" => 171
		},
		GOTOS => {
			'variable' => 64,
			'str' => 93,
			'value' => 216,
			'urlvar' => 91,
			'literal' => 92,
			'urlvarlit' => 173,
			'internalName' => 99,
			'qname' => 66,
			'url' => 61
		}
	},
	{#State 201
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"%" => 90,
			'DtSTR' => 95,
			'VAR' => 63,
			"[" => 171
		},
		GOTOS => {
			'variable' => 64,
			'str' => 93,
			'value' => 172,
			'urlvar' => 91,
			'literal' => 92,
			'urlvarlit' => 173,
			'valueList' => 217,
			'internalName' => 99,
			'qname' => 66,
			'url' => 61
		}
	},
	{#State 202
		DEFAULT => -145
	},
	{#State 203
		DEFAULT => -162
	},
	{#State 204
		DEFAULT => -163
	},
	{#State 205
		DEFAULT => -87
	},
	{#State 206
		ACTIONS => {
			'URL' => 62,
			"|&" => 189,
			"?" => 65,
			"|-" => 188,
			"||" => 187,
			"~" => 133,
			"!" => 134,
			"(" => 136,
			'VAR' => 63,
			"[" => 129
		},
		GOTOS => {
			'variable' => 64,
			'subject' => 130,
			'urlvar' => 127,
			'graphPattern' => 190,
			'decl' => 135,
			'QTerm' => 137,
			'url' => 61,
			'qname' => 66
		}
	},
	{#State 207
		DEFAULT => -25
	},
	{#State 208
		ACTIONS => {
			"|&" => 164,
			"|-" => 163,
			"||" => 160,
			"." => 206
		},
		DEFAULT => -83
	},
	{#State 209
		ACTIONS => {
			"|-" => 163,
			"." => 206
		},
		DEFAULT => -85
	},
	{#State 210
		ACTIONS => {
			"|&" => 164,
			"|-" => 163,
			"." => 206
		},
		DEFAULT => -84
	},
	{#State 211
		DEFAULT => -62,
		GOTOS => {
			'@28-8' => 218
		}
	},
	{#State 212
		DEFAULT => -47
	},
	{#State 213
		DEFAULT => -58,
		GOTOS => {
			'@25-8' => 219
		}
	},
	{#State 214
		DEFAULT => -141
	},
	{#State 215
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			"-" => 220,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"~" => 221,
			"%" => 90,
			'DtSTR' => 95,
			"!" => 223,
			"(" => 226,
			'VAR' => 227
		},
		GOTOS => {
			'variable' => 228,
			'str' => 93,
			'literal' => 222,
			'varOrName' => 225,
			'single' => 230,
			'expr' => 229,
			'internalName' => 231,
			'qname' => 66,
			'url' => 224
		}
	},
	{#State 216
		DEFAULT => -92,
		GOTOS => {
			'constraintStar' => 232
		}
	},
	{#State 217
		ACTIONS => {
			"," => 200
		},
		DEFAULT => -75
	},
	{#State 218
		DEFAULT => -63
	},
	{#State 219
		DEFAULT => -59
	},
	{#State 220
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			"-" => 220,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"~" => 221,
			"%" => 90,
			'DtSTR' => 95,
			"!" => 223,
			"(" => 226,
			'VAR' => 227
		},
		GOTOS => {
			'single' => 234,
			'literal' => 222,
			'internalName' => 235,
			'variable' => 233,
			'str' => 93,
			'qname' => 66,
			'url' => 224
		}
	},
	{#State 221
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			"-" => 220,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"~" => 221,
			"%" => 90,
			'DtSTR' => 95,
			"!" => 223,
			"(" => 226,
			'VAR' => 227
		},
		GOTOS => {
			'single' => 236,
			'literal' => 222,
			'internalName' => 235,
			'variable' => 233,
			'str' => 93,
			'qname' => 66,
			'url' => 224
		}
	},
	{#State 222
		DEFAULT => -119
	},
	{#State 223
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			"-" => 220,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"~" => 221,
			"%" => 90,
			'DtSTR' => 95,
			"!" => 223,
			"(" => 226,
			'VAR' => 227
		},
		GOTOS => {
			'single' => 237,
			'literal' => 222,
			'internalName' => 235,
			'variable' => 233,
			'str' => 93,
			'qname' => 66,
			'url' => 224
		}
	},
	{#State 224
		DEFAULT => -120
	},
	{#State 225
		ACTIONS => {
			"\@" => 238,
			"=" => 239
		}
	},
	{#State 226
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			"-" => 220,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"~" => 221,
			"%" => 90,
			'DtSTR' => 95,
			"!" => 223,
			"(" => 226,
			'VAR' => 227
		},
		GOTOS => {
			'variable' => 228,
			'str' => 93,
			'literal' => 222,
			'varOrName' => 225,
			'single' => 230,
			'expr' => 240,
			'internalName' => 231,
			'qname' => 66,
			'url' => 224
		}
	},
	{#State 227
		ACTIONS => {
			":" => 100,
			"(" => 241
		},
		DEFAULT => -173
	},
	{#State 228
		ACTIONS => {
			"\@" => -146,
			"=" => -146
		},
		DEFAULT => -118
	},
	{#State 229
		ACTIONS => {
			"}" => 243,
			"-" => 242,
			"<" => 244,
			"+" => 253,
			"%" => 245,
			"==" => 246,
			">=" => 247,
			"^" => 254,
			"*" => 248,
			"!=" => 255,
			"||" => 249,
			"&&" => 256,
			"&" => 257,
			"/" => 258,
			"|" => 250,
			"<=" => 251,
			">" => 252
		}
	},
	{#State 230
		DEFAULT => -110
	},
	{#State 231
		ACTIONS => {
			"\@" => -147,
			"=" => -147
		},
		DEFAULT => -117
	},
	{#State 232
		ACTIONS => {
			"{" => 215
		},
		DEFAULT => -77
	},
	{#State 233
		DEFAULT => -118
	},
	{#State 234
		DEFAULT => -113
	},
	{#State 235
		DEFAULT => -117
	},
	{#State 236
		DEFAULT => -115
	},
	{#State 237
		DEFAULT => -114
	},
	{#State 238
		ACTIONS => {
			'STR' => 96
		},
		GOTOS => {
			'str' => 259
		}
	},
	{#State 239
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			"-" => 220,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"~" => 221,
			"%" => 90,
			'DtSTR' => 95,
			"!" => 223,
			"(" => 226,
			'VAR' => 227
		},
		GOTOS => {
			'variable' => 228,
			'str' => 93,
			'literal' => 222,
			'varOrName' => 225,
			'single' => 230,
			'expr' => 260,
			'internalName' => 231,
			'qname' => 66,
			'url' => 224
		}
	},
	{#State 240
		ACTIONS => {
			"-" => 242,
			"<" => 244,
			"+" => 253,
			"%" => 245,
			"==" => 246,
			">=" => 247,
			"^" => 254,
			"*" => 248,
			")" => 261,
			"!=" => 255,
			"||" => 249,
			"&&" => 256,
			"&" => 257,
			"/" => 258,
			"|" => 250,
			"<=" => 251,
			">" => 252
		}
	},
	{#State 241
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			"-" => 220,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"~" => 221,
			"%" => 90,
			'DtSTR' => 95,
			"!" => 223,
			"(" => 226,
			'VAR' => 227
		},
		DEFAULT => -131,
		GOTOS => {
			'variable' => 228,
			'str' => 93,
			'literal' => 222,
			'varOrName' => 225,
			'single' => 230,
			'internalName' => 231,
			'expr' => 263,
			'qname' => 66,
			'url' => 224,
			'exprList' => 262
		}
	},
	{#State 242
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			"-" => 220,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"~" => 221,
			"%" => 90,
			'DtSTR' => 95,
			"!" => 223,
			"(" => 226,
			'VAR' => 227
		},
		GOTOS => {
			'variable' => 228,
			'str' => 93,
			'literal' => 222,
			'varOrName' => 225,
			'single' => 230,
			'expr' => 264,
			'internalName' => 231,
			'qname' => 66,
			'url' => 224
		}
	},
	{#State 243
		DEFAULT => -93
	},
	{#State 244
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			"-" => 220,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"~" => 221,
			"%" => 90,
			'DtSTR' => 95,
			"!" => 223,
			"(" => 226,
			'VAR' => 227
		},
		GOTOS => {
			'variable' => 228,
			'str' => 93,
			'literal' => 222,
			'varOrName' => 225,
			'single' => 230,
			'expr' => 265,
			'internalName' => 231,
			'qname' => 66,
			'url' => 224
		}
	},
	{#State 245
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			"-" => 220,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"~" => 221,
			"%" => 90,
			'DtSTR' => 95,
			"!" => 223,
			"(" => 226,
			'VAR' => 227
		},
		GOTOS => {
			'variable' => 228,
			'str' => 93,
			'literal' => 222,
			'varOrName' => 225,
			'single' => 230,
			'expr' => 266,
			'internalName' => 231,
			'qname' => 66,
			'url' => 224
		}
	},
	{#State 246
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			"-" => 220,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"~" => 221,
			"%" => 90,
			'DtSTR' => 95,
			"!" => 223,
			"(" => 226,
			'VAR' => 227
		},
		GOTOS => {
			'variable' => 228,
			'str' => 93,
			'literal' => 222,
			'varOrName' => 225,
			'single' => 230,
			'expr' => 267,
			'internalName' => 231,
			'qname' => 66,
			'url' => 224
		}
	},
	{#State 247
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			"-" => 220,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"~" => 221,
			"%" => 90,
			'DtSTR' => 95,
			"!" => 223,
			"(" => 226,
			'VAR' => 227
		},
		GOTOS => {
			'variable' => 228,
			'str' => 93,
			'literal' => 222,
			'varOrName' => 225,
			'single' => 230,
			'expr' => 268,
			'internalName' => 231,
			'qname' => 66,
			'url' => 224
		}
	},
	{#State 248
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			"-" => 220,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"~" => 221,
			"%" => 90,
			'DtSTR' => 95,
			"!" => 223,
			"(" => 226,
			'VAR' => 227
		},
		GOTOS => {
			'variable' => 228,
			'str' => 93,
			'literal' => 222,
			'varOrName' => 225,
			'single' => 230,
			'expr' => 269,
			'internalName' => 231,
			'qname' => 66,
			'url' => 224
		}
	},
	{#State 249
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			"-" => 220,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"~" => 221,
			"%" => 90,
			'DtSTR' => 95,
			"!" => 223,
			"(" => 226,
			'VAR' => 227
		},
		GOTOS => {
			'variable' => 228,
			'str' => 93,
			'literal' => 222,
			'varOrName' => 225,
			'single' => 230,
			'expr' => 270,
			'internalName' => 231,
			'qname' => 66,
			'url' => 224
		}
	},
	{#State 250
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			"-" => 220,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"~" => 221,
			"%" => 90,
			'DtSTR' => 95,
			"!" => 223,
			"(" => 226,
			'VAR' => 227
		},
		GOTOS => {
			'variable' => 228,
			'str' => 93,
			'literal' => 222,
			'varOrName' => 225,
			'single' => 230,
			'expr' => 271,
			'internalName' => 231,
			'qname' => 66,
			'url' => 224
		}
	},
	{#State 251
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			"-" => 220,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"~" => 221,
			"%" => 90,
			'DtSTR' => 95,
			"!" => 223,
			"(" => 226,
			'VAR' => 227
		},
		GOTOS => {
			'variable' => 228,
			'str' => 93,
			'literal' => 222,
			'varOrName' => 225,
			'single' => 230,
			'expr' => 272,
			'internalName' => 231,
			'qname' => 66,
			'url' => 224
		}
	},
	{#State 252
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			"-" => 220,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"~" => 221,
			"%" => 90,
			'DtSTR' => 95,
			"!" => 223,
			"(" => 226,
			'VAR' => 227
		},
		GOTOS => {
			'variable' => 228,
			'str' => 93,
			'literal' => 222,
			'varOrName' => 225,
			'single' => 230,
			'expr' => 273,
			'internalName' => 231,
			'qname' => 66,
			'url' => 224
		}
	},
	{#State 253
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			"-" => 220,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"~" => 221,
			"%" => 90,
			'DtSTR' => 95,
			"!" => 223,
			"(" => 226,
			'VAR' => 227
		},
		GOTOS => {
			'variable' => 228,
			'str' => 93,
			'literal' => 222,
			'varOrName' => 225,
			'single' => 230,
			'expr' => 274,
			'internalName' => 231,
			'qname' => 66,
			'url' => 224
		}
	},
	{#State 254
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			"-" => 220,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"~" => 221,
			"%" => 90,
			'DtSTR' => 95,
			"!" => 223,
			"(" => 226,
			'VAR' => 227
		},
		GOTOS => {
			'variable' => 228,
			'str' => 93,
			'literal' => 222,
			'varOrName' => 225,
			'single' => 230,
			'expr' => 275,
			'internalName' => 231,
			'qname' => 66,
			'url' => 224
		}
	},
	{#State 255
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			"-" => 220,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"~" => 221,
			"%" => 90,
			'DtSTR' => 95,
			"!" => 223,
			"(" => 226,
			'VAR' => 227
		},
		GOTOS => {
			'variable' => 228,
			'str' => 93,
			'literal' => 222,
			'varOrName' => 225,
			'single' => 230,
			'expr' => 276,
			'internalName' => 231,
			'qname' => 66,
			'url' => 224
		}
	},
	{#State 256
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			"-" => 220,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"~" => 221,
			"%" => 90,
			'DtSTR' => 95,
			"!" => 223,
			"(" => 226,
			'VAR' => 227
		},
		GOTOS => {
			'variable' => 228,
			'str' => 93,
			'literal' => 222,
			'varOrName' => 225,
			'single' => 230,
			'expr' => 277,
			'internalName' => 231,
			'qname' => 66,
			'url' => 224
		}
	},
	{#State 257
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			"-" => 220,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"~" => 221,
			"%" => 90,
			'DtSTR' => 95,
			"!" => 223,
			"(" => 226,
			'VAR' => 227
		},
		GOTOS => {
			'variable' => 228,
			'str' => 93,
			'literal' => 222,
			'varOrName' => 225,
			'single' => 230,
			'expr' => 278,
			'internalName' => 231,
			'qname' => 66,
			'url' => 224
		}
	},
	{#State 258
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			"-" => 220,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"~" => 221,
			"%" => 90,
			'DtSTR' => 95,
			"!" => 223,
			"(" => 226,
			'VAR' => 227
		},
		GOTOS => {
			'variable' => 228,
			'str' => 93,
			'literal' => 222,
			'varOrName' => 225,
			'single' => 230,
			'expr' => 279,
			'internalName' => 231,
			'qname' => 66,
			'url' => 224
		}
	},
	{#State 259
		DEFAULT => -112
	},
	{#State 260
		ACTIONS => {
			"-" => 242,
			"<" => 244,
			"+" => 253,
			"%" => 245,
			"==" => 246,
			">=" => 247,
			"^" => 254,
			"*" => 248,
			"!=" => 255,
			"||" => 249,
			"&&" => 256,
			"&" => 257,
			"/" => 258,
			"|" => 250,
			"<=" => 251,
			">" => 252
		},
		DEFAULT => -111
	},
	{#State 261
		DEFAULT => -116
	},
	{#State 262
		ACTIONS => {
			")" => 280
		}
	},
	{#State 263
		ACTIONS => {
			"-" => 242,
			"<" => 244,
			"+" => 253,
			"%" => 245,
			"==" => 246,
			">=" => 247,
			"^" => 254,
			"*" => 248,
			"!=" => 255,
			"||" => 249,
			"&&" => 256,
			"&" => 257,
			"/" => 258,
			"|" => 250,
			"<=" => 251,
			">" => 252
		},
		DEFAULT => -133,
		GOTOS => {
			'exprStar' => 281
		}
	},
	{#State 264
		ACTIONS => {
			"%" => 245,
			"*" => 248,
			"/" => 258
		},
		DEFAULT => -98
	},
	{#State 265
		ACTIONS => {
			"-" => 242,
			"+" => 253,
			"%" => 245,
			"*" => 248,
			"/" => 258
		},
		DEFAULT => -99
	},
	{#State 266
		DEFAULT => -96
	},
	{#State 267
		ACTIONS => {
			"-" => 242,
			"<" => 244,
			"+" => 253,
			"%" => 245,
			">=" => 247,
			"*" => 248,
			"/" => 258,
			"<=" => 251,
			">" => 252
		},
		DEFAULT => -103
	},
	{#State 268
		ACTIONS => {
			"-" => 242,
			"+" => 253,
			"%" => 245,
			"*" => 248,
			"/" => 258
		},
		DEFAULT => -102
	},
	{#State 269
		DEFAULT => -94
	},
	{#State 270
		ACTIONS => {
			"-" => 242,
			"<" => 244,
			"+" => 253,
			"%" => 245,
			"==" => 246,
			">=" => 247,
			"^" => 254,
			"*" => 248,
			"!=" => 255,
			"||" => 249,
			"&&" => 256,
			"&" => 257,
			"/" => 258,
			"|" => 250,
			"<=" => 251,
			">" => 252
		},
		DEFAULT => -109
	},
	{#State 271
		ACTIONS => {
			"-" => 242,
			"<" => 244,
			"+" => 253,
			"%" => 245,
			"==" => 246,
			">=" => 247,
			"*" => 248,
			"!=" => 255,
			"&" => 257,
			"/" => 258,
			"<=" => 251,
			">" => 252
		},
		DEFAULT => -107
	},
	{#State 272
		ACTIONS => {
			"-" => 242,
			"+" => 253,
			"%" => 245,
			"*" => 248,
			"/" => 258
		},
		DEFAULT => -101
	},
	{#State 273
		ACTIONS => {
			"-" => 242,
			"+" => 253,
			"%" => 245,
			"*" => 248,
			"/" => 258
		},
		DEFAULT => -100
	},
	{#State 274
		ACTIONS => {
			"%" => 245,
			"*" => 248,
			"/" => 258
		},
		DEFAULT => -97
	},
	{#State 275
		ACTIONS => {
			"-" => 242,
			"<" => 244,
			"+" => 253,
			"%" => 245,
			"==" => 246,
			">=" => 247,
			"*" => 248,
			"!=" => 255,
			"&" => 257,
			"/" => 258,
			"<=" => 251,
			">" => 252
		},
		DEFAULT => -106
	},
	{#State 276
		ACTIONS => {
			"-" => 242,
			"<" => 244,
			"+" => 253,
			"%" => 245,
			">=" => 247,
			"*" => 248,
			"/" => 258,
			"<=" => 251,
			">" => 252
		},
		DEFAULT => -104
	},
	{#State 277
		ACTIONS => {
			"-" => 242,
			"<" => 244,
			"+" => 253,
			"%" => 245,
			"==" => 246,
			">=" => 247,
			"^" => 254,
			"*" => 248,
			"!=" => 255,
			"&&" => 256,
			"&" => 257,
			"/" => 258,
			"|" => 250,
			"<=" => 251,
			">" => 252
		},
		DEFAULT => -108
	},
	{#State 278
		ACTIONS => {
			"-" => 242,
			"<" => 244,
			"+" => 253,
			"%" => 245,
			"==" => 246,
			">=" => 247,
			"*" => 248,
			"!=" => 255,
			"/" => 258,
			"<=" => 251,
			">" => 252
		},
		DEFAULT => -105
	},
	{#State 279
		DEFAULT => -95
	},
	{#State 280
		DEFAULT => -121
	},
	{#State 281
		ACTIONS => {
			"," => 282
		},
		DEFAULT => -132
	},
	{#State 282
		ACTIONS => {
			'STR' => 96,
			'URL' => 62,
			"-" => 220,
			'DOUBLE' => 97,
			"?" => 65,
			'INT' => 98,
			"~" => 221,
			"%" => 90,
			'DtSTR' => 95,
			"!" => 223,
			"(" => 226,
			'VAR' => 227
		},
		GOTOS => {
			'variable' => 228,
			'str' => 93,
			'literal' => 222,
			'varOrName' => 225,
			'single' => 230,
			'expr' => 283,
			'internalName' => 231,
			'qname' => 66,
			'url' => 224
		}
	},
	{#State 283
		ACTIONS => {
			"-" => 242,
			"<" => 244,
			"+" => 253,
			"%" => 245,
			"==" => 246,
			">=" => 247,
			"^" => 254,
			"*" => 248,
			"!=" => 255,
			"||" => 249,
			"&&" => 256,
			"&" => 257,
			"/" => 258,
			"|" => 250,
			"<=" => 251,
			">" => 252
		},
		DEFAULT => -134
	}
],
                                  yyrules  =>
[
	[#Rule 0
		 '$start', 2, undef
	],
	[#Rule 1
		 'input', 1, undef
	],
	[#Rule 2
		 '@1-0', 0,
sub
#line 72 "AlgaeParser.yp"
{$_[0]->YYData->{my_DONE}=0}
	],
	[#Rule 3
		 'cmnds', 2,
sub
#line 73 "AlgaeParser.yp"
{$_[0]->YYData->{my_DONE}=1; $_[2]}
	],
	[#Rule 4
		 'actionStar', 0, undef
	],
	[#Rule 5
		 'actionStar', 2,
sub
#line 76 "AlgaeParser.yp"
{push (@{$_[1]}, $_[2]); $_[1]}
	],
	[#Rule 6
		 '@2-2', 0,
sub
#line 77 "AlgaeParser.yp"
{&FILE}
	],
	[#Rule 7
		 '@3-4', 0,
sub
#line 77 "AlgaeParser.yp"
{&TOK}
	],
	[#Rule 8
		 'actionStar', 5,
sub
#line 77 "AlgaeParser.yp"
{push (@{$_[1]}, $_[0]->YYData->{ALGAE2}->include($_[4])); $_[1]}
	],
	[#Rule 9
		 'actionStr', 1, undef
	],
	[#Rule 10
		 'actionStr', 1, undef
	],
	[#Rule 11
		 'actionStr', 1, undef
	],
	[#Rule 12
		 'actionStr', 1, undef
	],
	[#Rule 13
		 'actionStr', 1, undef
	],
	[#Rule 14
		 'actionStr', 1, undef
	],
	[#Rule 15
		 'actionStr', 1, undef
	],
	[#Rule 16
		 'actionStr', 1, undef
	],
	[#Rule 17
		 'actionStr', 1, undef
	],
	[#Rule 18
		 'actionStr', 1, undef
	],
	[#Rule 19
		 'actionStr', 1, undef
	],
	[#Rule 20
		 'actionStr', 1, undef
	],
	[#Rule 21
		 'actionStr', 1, undef
	],
	[#Rule 22
		 'actionStr', 1, undef
	],
	[#Rule 23
		 '@4-1', 0,
sub
#line 97 "AlgaeParser.yp"
{&VAR}
	],
	[#Rule 24
		 '@5-7', 0,
sub
#line 97 "AlgaeParser.yp"
{&TOK}
	],
	[#Rule 25
		 'askStr', 8,
sub
#line 98 "AlgaeParser.yp"
{$_[0]->YYData->{ALGAE2}->ask($_[5], $_[3])}
	],
	[#Rule 26
		 '@6-1', 0,
sub
#line 100 "AlgaeParser.yp"
{&VAR}
	],
	[#Rule 27
		 '@7-6', 0,
sub
#line 100 "AlgaeParser.yp"
{&TOK}
	],
	[#Rule 28
		 'assertStr', 7,
sub
#line 101 "AlgaeParser.yp"
{$_[0]->YYData->{ALGAE2}->assert($_[5], $_[3])}
	],
	[#Rule 29
		 '@8-1', 0,
sub
#line 103 "AlgaeParser.yp"
{&VAR}
	],
	[#Rule 30
		 '@9-7', 0,
sub
#line 103 "AlgaeParser.yp"
{&TOK}
	],
	[#Rule 31
		 'attachStr', 8,
sub
#line 104 "AlgaeParser.yp"
{$_[0]->YYData->{ALGAE2}->attach($_[3], $_[4], $_[6])}
	],
	[#Rule 32
		 'baseStr', 2,
sub
#line 107 "AlgaeParser.yp"
{$_[0]->YYData->{ALGAE2}->base($BASE_FILE)}
	],
	[#Rule 33
		 'baseStr', 2,
sub
#line 109 "AlgaeParser.yp"
{$_[0]->YYData->{ALGAE2}->base($BASE_HTTP)}
	],
	[#Rule 34
		 '@10-2', 0,
sub
#line 110 "AlgaeParser.yp"
{&VAR}
	],
	[#Rule 35
		 '@11-4', 0,
sub
#line 110 "AlgaeParser.yp"
{&TOK}
	],
	[#Rule 36
		 'baseStr', 5,
sub
#line 111 "AlgaeParser.yp"
{$_[0]->YYData->{ALGAE2}->base($_[4])}
	],
	[#Rule 37
		 'clear', 1,
sub
#line 114 "AlgaeParser.yp"
{$_[0]->YYData->{ALGAE2}->clear()}
	],
	[#Rule 38
		 '@12-2', 0,
sub
#line 116 "AlgaeParser.yp"
{&VAR}
	],
	[#Rule 39
		 '@13-5', 0,
sub
#line 116 "AlgaeParser.yp"
{&TOK}
	],
	[#Rule 40
		 'collectStr', 6,
sub
#line 117 "AlgaeParser.yp"
{$_[0]->YYData->{ALGAE2}->collect($_[4])}
	],
	[#Rule 41
		 '@14-2', 0,
sub
#line 118 "AlgaeParser.yp"
{&VAR}
	],
	[#Rule 42
		 '@15-5', 0,
sub
#line 118 "AlgaeParser.yp"
{&TOK}
	],
	[#Rule 43
		 'collectStr', 6,
sub
#line 119 "AlgaeParser.yp"
{$_[0]->YYData->{ALGAE2}->collect($_[4])}
	],
	[#Rule 44
		 '@16-1', 0,
sub
#line 121 "AlgaeParser.yp"
{&VAR}
	],
	[#Rule 45
		 '@17-4', 0,
sub
#line 121 "AlgaeParser.yp"
{&VAR}
	],
	[#Rule 46
		 '@18-7', 0,
sub
#line 121 "AlgaeParser.yp"
{&TOK}
	],
	[#Rule 47
		 'hostStr', 8,
sub
#line 122 "AlgaeParser.yp"
{$_[0]->YYData->{ALGAE2}->host($_[6], $_[3])}
	],
	[#Rule 48
		 '@19-3', 0,
sub
#line 124 "AlgaeParser.yp"
{&VAR}
	],
	[#Rule 49
		 '@20-6', 0,
sub
#line 124 "AlgaeParser.yp"
{&TOK}
	],
	[#Rule 50
		 'flagsStr', 7,
sub
#line 125 "AlgaeParser.yp"
{$_[0]->YYData->{ALGAE2}->flags($_[5], $_[2])}
	],
	[#Rule 51
		 'fwRuleStr', 3,
sub
#line 128 "AlgaeParser.yp"
{$_[0]->YYData->{ALGAE2}->fwrule($_[2], $_[3])}
	],
	[#Rule 52
		 '@21-1', 0,
sub
#line 132 "AlgaeParser.yp"
{&VAR}
	],
	[#Rule 53
		 'namespaceStr', 3,
sub
#line 133 "AlgaeParser.yp"
{&TOK;
	 $_[0]->addNamespace(@{$_[3]});
	 $_[0]->YYData->{ALGAE2}->namespace(@{$_[3]})}
	],
	[#Rule 54
		 '@22-1', 0,
sub
#line 136 "AlgaeParser.yp"
{&VAR}
	],
	[#Rule 55
		 'namespaceStr', 3,
sub
#line 137 "AlgaeParser.yp"
{&TOK;
	 $_[0]->addNamespace(@{$_[3]});
	 $_[0]->YYData->{ALGAE2}->namespace(@{$_[3]})}
	],
	[#Rule 56
		 '@23-1', 0,
sub
#line 141 "AlgaeParser.yp"
{&FILE}
	],
	[#Rule 57
		 '@24-3', 0,
sub
#line 141 "AlgaeParser.yp"
{&VAR}
	],
	[#Rule 58
		 '@25-8', 0,
sub
#line 141 "AlgaeParser.yp"
{&TOK}
	],
	[#Rule 59
		 'slurpStr', 9,
sub
#line 141 "AlgaeParser.yp"
{

    $_[0]->YYData->{ALGAE2}->slurp($_[3], $_[7], $_[5])}
	],
	[#Rule 60
		 '@26-1', 0,
sub
#line 144 "AlgaeParser.yp"
{&FILE}
	],
	[#Rule 61
		 '@27-3', 0,
sub
#line 144 "AlgaeParser.yp"
{&VAR}
	],
	[#Rule 62
		 '@28-8', 0,
sub
#line 144 "AlgaeParser.yp"
{&TOK}
	],
	[#Rule 63
		 'slurpStr', 9,
sub
#line 144 "AlgaeParser.yp"
{
    $_[0]->YYData->{ALGAE2}->slurp($_[3], $_[7], $_[5])}
	],
	[#Rule 64
		 '@29-1', 0,
sub
#line 147 "AlgaeParser.yp"
{&VAR}
	],
	[#Rule 65
		 'requireStr', 3,
sub
#line 148 "AlgaeParser.yp"
{&TOK; $_[0]->YYData->{ALGAE2}->require($_[3])}
	],
	[#Rule 66
		 'quit', 1,
sub
#line 150 "AlgaeParser.yp"
{exit}
	],
	[#Rule 67
		 '@30-1', 0,
sub
#line 155 "AlgaeParser.yp"
{&VAR}
	],
	[#Rule 68
		 '@31-6', 0,
sub
#line 155 "AlgaeParser.yp"
{&TOK}
	],
	[#Rule 69
		 'profileQueryStr', 7,
sub
#line 156 "AlgaeParser.yp"
{$_[0]->YYData->{ALGAE2}->profileQuery($_[4], $_[5])}
	],
	[#Rule 70
		 'declList', 1,
sub
#line 162 "AlgaeParser.yp"
{$_[0]->newDecl($_[1])}
	],
	[#Rule 71
		 'declList', 2,
sub
#line 163 "AlgaeParser.yp"
{$_[1]}
	],
	[#Rule 72
		 'declList', 3,
sub
#line 164 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::Conjunction($_[1], $_[0]->newDecl($_[3]), $_[0])}
	],
	[#Rule 73
		 'decl', 2,
sub
#line 166 "AlgaeParser.yp"
{[[$_[1], $_[2]]]}
	],
	[#Rule 74
		 'propValueList', 2,
sub
#line 168 "AlgaeParser.yp"
{[[$_[1], $_[2]]]}
	],
	[#Rule 75
		 'propValueList', 4,
sub
#line 169 "AlgaeParser.yp"
{push (@{$_[1]}, [$_[3], $_[4]]); $_[1]}
	],
	[#Rule 76
		 'valueList', 2,
sub
#line 171 "AlgaeParser.yp"
{[[$_[1], $_[2]]]}
	],
	[#Rule 77
		 'valueList', 4,
sub
#line 172 "AlgaeParser.yp"
{push (@{$_[1]}, [$_[3], $_[4]]); $_[1]}
	],
	[#Rule 78
		 'graphPattern', 1, undef
	],
	[#Rule 79
		 'graphPattern', 3,
sub
#line 179 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::Conjunction($_[1], $_[3], $_[0])}
	],
	[#Rule 80
		 'graphPattern', 3,
sub
#line 181 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::ShortcutDisjunction($_[1], $_[3], $_[0])}
	],
	[#Rule 81
		 'graphPattern', 3,
sub
#line 183 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::UnionDisjunction($_[1], $_[3], $_[0])}
	],
	[#Rule 82
		 'graphPattern', 3,
sub
#line 185 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::UnionDisjunctionMerge($_[1], $_[3], $_[0])}
	],
	[#Rule 83
		 'graphPattern', 4,
sub
#line 187 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::ShortcutDisjunction($_[1], $_[4], $_[0])}
	],
	[#Rule 84
		 'graphPattern', 4,
sub
#line 189 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::UnionDisjunction($_[1], $_[4], $_[0])}
	],
	[#Rule 85
		 'graphPattern', 4,
sub
#line 191 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::UnionDisjunctionMerge($_[1], $_[4], $_[0])}
	],
	[#Rule 86
		 'QTerm', 1,
sub
#line 194 "AlgaeParser.yp"
{$_[0]->newDecl($_[1])}
	],
	[#Rule 87
		 'QTerm', 4,
sub
#line 196 "AlgaeParser.yp"
{$_[2]}
	],
	[#Rule 88
		 'QTerm', 2,
sub
#line 198 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::Option($_[2], $_[0])}
	],
	[#Rule 89
		 'QTerm', 2,
sub
#line 200 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::Negation($_[0]->newDecl($_[2]), $_[0])}
	],
	[#Rule 90
		 'dotOpt', 0, undef
	],
	[#Rule 91
		 'dotOpt', 1, undef
	],
	[#Rule 92
		 'constraintStar', 0, undef
	],
	[#Rule 93
		 'constraintStar', 4,
sub
#line 209 "AlgaeParser.yp"
{push (@{$_[1]}, new W3C::Rdf::AlgaeCompileTree::Constraint($_[3], $_[0])); $_[1]}
	],
	[#Rule 94
		 'expr', 3,
sub
#line 211 "AlgaeParser.yp"
{$_[1] * $_[3];}
	],
	[#Rule 95
		 'expr', 3,
sub
#line 212 "AlgaeParser.yp"
{($_[3] != 0) ? $_[1] / $_[3] : 0;}
	],
	[#Rule 96
		 'expr', 3,
sub
#line 213 "AlgaeParser.yp"
{($_[3] != 0) ? $_[1] % $_[3] : 0;}
	],
	[#Rule 97
		 'expr', 3,
sub
#line 214 "AlgaeParser.yp"
{$_[1] + $_[3];}
	],
	[#Rule 98
		 'expr', 3,
sub
#line 215 "AlgaeParser.yp"
{$_[1] - $_[3];}
	],
	[#Rule 99
		 'expr', 3,
sub
#line 218 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::Lt($_[1], $_[3], $_[0])}
	],
	[#Rule 100
		 'expr', 3,
sub
#line 219 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::Gt($_[1], $_[3], $_[0])}
	],
	[#Rule 101
		 'expr', 3,
sub
#line 220 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::Le($_[1], $_[3], $_[0])}
	],
	[#Rule 102
		 'expr', 3,
sub
#line 221 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::Ge($_[1], $_[3], $_[0])}
	],
	[#Rule 103
		 'expr', 3,
sub
#line 222 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::Eq($_[1], $_[3], $_[0])}
	],
	[#Rule 104
		 'expr', 3,
sub
#line 224 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::Ne($_[1], $_[3], $_[0])}
	],
	[#Rule 105
		 'expr', 3,
sub
#line 226 "AlgaeParser.yp"
{$_[1] & $_[3];}
	],
	[#Rule 106
		 'expr', 3,
sub
#line 227 "AlgaeParser.yp"
{$_[1] ^ $_[3];}
	],
	[#Rule 107
		 'expr', 3,
sub
#line 228 "AlgaeParser.yp"
{$_[1] | $_[3];}
	],
	[#Rule 108
		 'expr', 3,
sub
#line 229 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::And($_[1], $_[3], $_[0])}
	],
	[#Rule 109
		 'expr', 3,
sub
#line 230 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::Or($_[1], $_[3], $_[0])}
	],
	[#Rule 110
		 'expr', 1,
sub
#line 233 "AlgaeParser.yp"
{$_[1];}
	],
	[#Rule 111
		 'expr', 3,
sub
#line 235 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::Assign($_[1], $_[3], $_[0])}
	],
	[#Rule 112
		 'expr', 3,
sub
#line 236 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::Glob($_[1], $_[3], $_[0])}
	],
	[#Rule 113
		 'single', 2,
sub
#line 239 "AlgaeParser.yp"
{-$_[2];}
	],
	[#Rule 114
		 'single', 2,
sub
#line 240 "AlgaeParser.yp"
{!$_[2];}
	],
	[#Rule 115
		 'single', 2,
sub
#line 241 "AlgaeParser.yp"
{~$_[2];}
	],
	[#Rule 116
		 'single', 3,
sub
#line 242 "AlgaeParser.yp"
{$_[2];}
	],
	[#Rule 117
		 'single', 1,
sub
#line 243 "AlgaeParser.yp"
{$_[1];}
	],
	[#Rule 118
		 'single', 1,
sub
#line 244 "AlgaeParser.yp"
{$_[1];}
	],
	[#Rule 119
		 'single', 1,
sub
#line 245 "AlgaeParser.yp"
{$_[1];}
	],
	[#Rule 120
		 'single', 1,
sub
#line 246 "AlgaeParser.yp"
{$_[1];}
	],
	[#Rule 121
		 'single', 4,
sub
#line 247 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::FuncCall($_[1], $_[3], $_[0])}
	],
	[#Rule 122
		 'bindingStar', 0, undef
	],
	[#Rule 123
		 'bindingStar', 2,
sub
#line 253 "AlgaeParser.yp"
{push (@{$_[1]}, $_[2]); $_[1]}
	],
	[#Rule 124
		 'knownVars', 1,
sub
#line 255 "AlgaeParser.yp"
{[$_[1]]}
	],
	[#Rule 125
		 'knownVars', 2,
sub
#line 256 "AlgaeParser.yp"
{push (@{$_[1]}, $_[2]); $_[1]}
	],
	[#Rule 126
		 'namespaceDecl', 3,
sub
#line 258 "AlgaeParser.yp"
{[$_[1], $_[3]]}
	],
	[#Rule 127
		 'namespaceDecl', 1,
sub
#line 259 "AlgaeParser.yp"
{['', $_[1]]}
	],
	[#Rule 128
		 'setOp', 0, undef
	],
	[#Rule 129
		 'setOp', 1, undef
	],
	[#Rule 130
		 'setOp', 1, undef
	],
	[#Rule 131
		 'exprList', 0, undef
	],
	[#Rule 132
		 'exprList', 2,
sub
#line 266 "AlgaeParser.yp"
{[$_[1], @{$_[2]}]}
	],
	[#Rule 133
		 'exprStar', 0,
sub
#line 268 "AlgaeParser.yp"
{[]}
	],
	[#Rule 134
		 'exprStar', 3,
sub
#line 269 "AlgaeParser.yp"
{push (@{$_[1]}, $_[2]); $_[1]}
	],
	[#Rule 135
		 'sourceStr', 1, undef
	],
	[#Rule 136
		 'sourceStr', 1, undef
	],
	[#Rule 137
		 'subject', 1, undef
	],
	[#Rule 138
		 'subject', 3, undef
	],
	[#Rule 139
		 'property', 1, undef
	],
	[#Rule 140
		 'value', 1, undef
	],
	[#Rule 141
		 'value', 3,
sub
#line 283 "AlgaeParser.yp"
{
		    my $node = new W3C::Rdf::AlgaeCompileTree::BNode($_[0]);
		    [$node, $_[0]->newDecl([[$node, $_[2]]])];
		}
	],
	[#Rule 142
		 'nulPropValList', 0, undef
	],
	[#Rule 143
		 'nulPropValList', 1, undef
	],
	[#Rule 144
		 'nulPropValList', 2, undef
	],
	[#Rule 145
		 'nulPropValList', 3, undef
	],
	[#Rule 146
		 'varOrName', 1, undef
	],
	[#Rule 147
		 'varOrName', 1, undef
	],
	[#Rule 148
		 'internalName', 2,
sub
#line 296 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::KeyName($_[2], 1, $_[0])}
	],
	[#Rule 149
		 'urlvar', 1, undef
	],
	[#Rule 150
		 'urlvar', 1, undef
	],
	[#Rule 151
		 'urlvarlit', 1, undef
	],
	[#Rule 152
		 'urlvarlit', 1, undef
	],
	[#Rule 153
		 'urlvarlit', 1, undef
	],
	[#Rule 154
		 'variable', 2,
sub
#line 305 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::Var($_[2], 1, $_[0])}
	],
	[#Rule 155
		 'knownVar', 2,
sub
#line 307 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::Var($_[2], 0, $_[0])}
	],
	[#Rule 156
		 'variableName', 1, undef
	],
	[#Rule 157
		 'literal', 1, undef
	],
	[#Rule 158
		 'literal', 1,
sub
#line 312 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::Int($_[1], $_[0])}
	],
	[#Rule 159
		 'literal', 1,
sub
#line 313 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::Double($_[1], $_[0])}
	],
	[#Rule 160
		 'literal', 2,
sub
#line 314 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::Literal($_[1], $_[2], undef, $_[0])}
	],
	[#Rule 161
		 'str', 1,
sub
#line 316 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::Literal($_[1], undef, undef, $_[0])}
	],
	[#Rule 162
		 'binding', 3,
sub
#line 318 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::Binding($_[1], $_[3], $_[0])}
	],
	[#Rule 163
		 'binding', 3,
sub
#line 319 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::Binding($_[1], $_[3], $_[0])}
	],
	[#Rule 164
		 'name', 1, undef
	],
	[#Rule 165
		 'optDbSpec', 0, undef
	],
	[#Rule 166
		 'optDbSpec', 1,
sub
#line 324 "AlgaeParser.yp"
{$_[0]->YYData->{ALGAE2}->getSourceByName($_[1]->getUrl)}
	],
	[#Rule 167
		 'dbSpec', 1, undef
	],
	[#Rule 168
		 'dbSpec', 1, undef
	],
	[#Rule 169
		 'filename', 1,
sub
#line 329 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::Url($_[1], undef, $_[0])}
	],
	[#Rule 170
		 'url', 1,
sub
#line 331 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::Url($_[1], undef, $_[0])}
	],
	[#Rule 171
		 'url', 1, undef
	],
	[#Rule 172
		 'qname', 3,
sub
#line 334 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::QName($_[1], $_[3], $_[0])}
	],
	[#Rule 173
		 'qname', 1,
sub
#line 335 "AlgaeParser.yp"
{new W3C::Rdf::AlgaeCompileTree::QName('',    $_[1], $_[0])}
	]
],
                                  @_);
    bless($self,$class);
}

#line 339 "AlgaeParser.yp"


#BEGIN {unshift@INC,('../..');}
use W3C::Util::Exception qw(&throw &catch);

use vars qw($PUNCT $TOKEN $VAR $FILE $URL $DBSPEC);
($PUNCT, $TOKEN, $VAR, $FILE, $URL, $DBSPEC) = (0, \ "TOKEN", \ "VAR", \ "PREFIX", \ "URL", 5);

sub TOK {$_[0]->YYData->{NEXT} = $TOKEN}
sub VAR {$_[0]->YYData->{NEXT} = $VAR}
sub FILE {$_[0]->YYData->{NEXT} = $FILE}

sub _Error {
    my ($self) = @_;
    if (exists $self->YYData->{EXCEPTION}) {
	&throw($self->YYData->{EXCEPTION});
    }
    if (exists $self->YYData->{ERRMSG}) {
	&throw(new W3C::Util::YappDriver::GrammarException(-message => $self->YYData->{ERRMSG}, 
							   -location => $self->YYData->{LOCATION}));
        delete $self->YYData->{ERRMSG};
        return;
    }
    &throw(new W3C::Util::YappDriver::MesgYappContextException($self, -location => $self->YYData->{LOCATION}));
    my $trimmed = $self->YYData->{INPUT};
    $trimmed =~ s/[\r\n]*\Z//m;

    my ($token, $value, $expect, $data) = ($self->YYCurtok(), $self->YYCurval(), $self->YYExpect(), $self->YYData);
    my $tokenStr = defined $token && $token ne $value ? "$token " : '';
    my $valueStr = defined $value ? "'$value'" : 'EOF';
    my $dataStr = ref $data eq 'HASH' ? join ("\n", map {"$_: $data->{$_}"} keys %$data) : $data;
    $dataStr = substr($trimmed, $self->YYData->{my_LASTPOS}, 20);
    print "expected '$expect', got $tokenStr$valueStr at \"$dataStr\"\n";

    my $before = substr($trimmed, 0, $self->YYData->{my_LASTPOS}+1);
    $before =~ m/([^\r\n]*)\Z/m;
    my $column = length ($1) - 1;
    my $after = substr($trimmed, $self->YYData->{my_LASTPOS}+1);

    $after =~ m/([^\r\n]*)[\r\n]?(.*)/s;
    my ($line, $last) = ($1, $2);
    print "$before$line\n";
    print '=' x $column, "^\n";
    print "$last\n" if ($last);
    foreach my $entry (@{$self->{STACK}}) {
	print join (' | ', @$entry),"\n";
    }
}

sub _Lexer {
    my($self)=shift;

    if (defined $self->YYData->{INPUT} && pos $self->YYData->{INPUT} < length ($self->YYData->{INPUT})) {
    } else {
	if ($self->YYData->{my_DONE}) {
	    return ('', undef);
	}
	if (0) {
	if (!($self->YYData->{INPUT} = $self->nextChunk())) {
	    undef $self->YYData->{INPUT};
	    return ('', undef);
	}
	} else {
	my $pos = pos $self->YYData->{INPUT};
	my $chunk = $self->nextChunk();
	#print "\nchunk: $chunk\n";
	if (!$chunk) {
	    undef $self->YYData->{INPUT};
	    return ('', undef);
	}
	$self->YYData->{INPUT} .= $chunk;
	pos $self->YYData->{INPUT} = $pos;
	}
	#my $txt = $self->YYData->{INPUT};
	#print "\ntxt: $txt\n";
    }

    my ($token, $value) = ('', undef);
    while ($self->YYData->{INPUT} =~ m/\G\s*\#[^\n]*\n/gc) {}
    $self->YYData->{INPUT} =~ m/\G\s*/gc;
    $self->YYData->{my_LASTPOS} = pos $self->YYData->{INPUT};
    my $expect = $self->YYData->{NEXT};
    if (($expect == $VAR || $expect == $FILE) && $self->YYData->{INPUT} =~ m/\G\<\s*([^\s\>]+)\s*\>/gc) {
	($token, $value) = ('URL',$1);
    } elsif ($expect == $VAR && ($self->YYData->{INPUT} =~ m/\G\"([^\"]+)\"/gc || 
				 $self->YYData->{INPUT} =~ m/\G\'([^\']+)\'/gc)) {
	$value = $1;
	if ($self->YYData->{INPUT} =~ m/\G\s*\^\^/gc) {
	    $token = 'DtSTR';
	} else {
	    $token = 'STR';
	}
    } elsif ($self->YYData->{INPUT} =~ m/\G((?:[0-9]+)?\.[0-9]+)/gc) {
	($token, $value) = ('DOUBLE',$1);
    } elsif ($self->YYData->{INPUT} =~ m/\G([0-9]+)/gc) {
	($token, $value) = ('INT',$1);
    } elsif ($self->YYData->{INPUT} =~ m/\G([A-Za-z][A-Za-z0-9_-]*)/gc) {
	($token, $value) = ($expect == $TOKEN ? $1 : $$expect ,$1);
    # very pathetic attempt at a file regexp
    } elsif ($expect == $FILE && $self->YYData->{INPUT} =~ m/\G([\.\;\~\|\&\w\/\+\-]+)/gc) {
	($token, $value) = ('FILE',$1);
    } elsif ($self->YYData->{INPUT} =~ m/\G(==|\!=|<=|>=|\|\||\|\&|\|\-|\&\&)/gc) {
	($token, $value) = ($1,$1);
    } elsif ($self->YYData->{INPUT} =~ m/\G(.)/gc) {
	($token, $value) = ($1,$1);
    }
    my $pos = pos $self->YYData->{INPUT};
    #print "\n$pos,$token,$value\n";
    return ($token, $value);
}

sub addNamespace {
    my ($self, $prefix, $namespace) = @_;
    $self->YYData->{-namespaceHandler}->addNamespace($prefix, $namespace->getUrl());
}

sub mapNamespace {
    my ($self, $qnameStr) = @_;
    return $self->YYData->{-namespaceHandler}->mapNamespace($qnameStr);
}

sub parse {
    my ($self, @args) = @_;
    $self->YYData->{NEXT} = $TOKEN;
    return $self->SUPER::parse(@args);
}

# Provide (one) chunk of text to parse.
sub nextChunk {
    my ($self) = @_;
    #return shift (@{$self->YYData->{my_CHUNKS}});
    #return shift (@ARGV);
    return <STDIN>;
}

# Handy debugging wrapper for calling semantics actions.
sub _wrap {
    my ($self, $obj, $method, @args) = @_;
    my @ret;
    eval {
	@ret = $obj->$method(@args);
    }; if ($@) {if (my $ex = &catch('W3C::Util::CachedContextException')) {
	&throw($ex);;
    } elsif ($ex = &catch('W3C::Util::Exception')) {
	my $newEx = new W3C::Util::CachedContextException(-str => $self->YYData->{INPUT}, 
							  -pos => $self->YYData->{my_LASTPOS}+1, 
							  -errorMessage => $ex->toString);
	$newEx->assumeStackTrace($ex);
	&throw($newEx);
    } else {
	my $newEx = new W3C::Util::CachedContextException(-str => $self->YYData->{INPUT}, 
							  -pos => $self->YYData->{my_LASTPOS}+1, 
							  -errorMessage => "$obj->$method: $@");
	&throw($newEx);
    }}
    return wantarray ? @ret : $ret[-1];
}

sub printArgs {
    return;
    print ':';
    foreach my $arg (@_) {
	print " $arg";
    }
    print ' Curtok:',$_[0]->YYCurtok;
    print ' Curval:',$_[0]->YYCurval;
    print ' Expect:',$_[0]->YYExpect;
    print ' Lexer:',$_[0]->YYLexer;
    print ' Data:',$_[0]->YYData;
    print "\n";
}

# Used by -M invocation:
#   perl -MW3C::Rdf::AlgaeParser -e '(new W3C::Rdf::RLAlgaeParser())->Run' '...'
sub main {
    my ($self) = @_;
    $self->Run();
}

# <parser state support>
sub newDecl {
    my ($self, $parm) = @_;
    my $ret;
    foreach my $decl (@$parm) {
	my ($subject, $propValList) = @$decl;
	foreach my $propVal (@$propValList) {
	    my ($property, $valueList) = @$propVal;
	    foreach my $valuePair (@$valueList) {
		my ($value, $constraints) = @$valuePair;
		# print $subject->toString.' '.$property->toString.' '.$value->toString."\n";
		my $toAdd = [];
		if (ref $value eq 'ARRAY') {
		    # we've got an object and a bunch of Decls about that object.
		    $toAdd = [$value->[1]];
		    $value = $value->[0];
		}
		my $newTerm = new W3C::Rdf::AlgaeCompileTree::Decl([$property, $subject, $value], 
								 $constraints, $self);
		foreach my $term ($newTerm, @$toAdd) {
		    if ($ret) {
			$ret = new W3C::Rdf::AlgaeCompileTree::Conjunction($ret, $term, $self);
		    } else {
			$ret = $term;
		    }
		}
	    }
	}
    }
    return $ret;
}

# </parser state support>

package W3C::Rdf::AlgaeParser;
@W3C::Rdf::AlgaeParser::ISA = qw(W3C::Rdf::_AlgaeParser);
sub new {
    my ($proto, $algaeString, $algae2, $location, @yappParms) = @_;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new(@yappParms);
    $self->YYData->{ALGAE_STRING} = $algaeString;
    $self->YYData->{LOCATION} = $location;
 
    $self->YYData->{ALGAE2} = $algae2;
    return $self;
}

sub nextChunk {
    my ($self) = @_;
    my $ret = $self->YYData->{ALGAE_STRING};
    $self->YYData->{ALGAE_STRING} = undef;
    return $ret;
}

# Interactive ReadLine parser -- under development
package W3C::Rdf::RLAlgaeParser;
use W3C::Util::Exception;
@W3C::Rdf::RLAlgaeParser::ISA = qw(W3C::Rdf::AlgaeParser);
sub new {
    my ($proto, @parms) = @_;
    my $class = ref($proto) || $proto;

    # Change the parser driver to the readline driver.
    @W3C::Rdf::_AlgaeParser::ISA = qw (W3C::Util::rlDriver);

    my $self = $class->SUPER::new(@parms);
    $self->YYData->{ACTIONS} = [];
    return $self;
}

sub nextChunk {
    my ($self) = @_;
    my $ret = undef;
    if ($self->{rl_COMPLETE_MODE}) {
	if ($self->{rl_SO_FAR}) {
	    $ret = $self->{rl_SO_FAR};
	    $self->{rl_SO_FAR} = undef;
	    #print "nextChunk: $ret\n";
	}
    } else {
	if (@{$self->YYData->{my_CHUNKS}}) {
	    $ret = shift (@{$self->YYData->{my_CHUNKS}});
	} else {
	    #return shift (@ARGV);
	    $ret = $self->readline('')."\n";
	    #print "ret: $ret";
	}
    }
    return $ret;
}

# perl -MW3C::Rdf::AlgaeParser -e '(new W3C::Rdf::RLAlgaeParser())->Run' 'asdf'
# b /usr/share/perl5/Parse/Yapp/Driver.pm:343

##!/usr/bin/perl
#BEGIN {unshift@INC,('../..');}
#use W3C::Rdf::AlgaeParser;
#$p = new W3C::Rdf::RLAlgaeParser();
#$p->main;

#./AlgaeParser "(ask '(<ab:cd> (?asdf ?s ?o)) assert '(ef:gh (?a ?b ?c)))"

1;

__END__

=head1 NAME

W3C::Rdf::AlgaeParser - parse the algae2 language

=head1 SYNOPSIS

  use W3C::Rdf::AlgaeParser;
  my $p = new W3C::Rdf::AlgaeParser($algaeString, $algae2, "algae.txt");
  my $actions = $p->parse($debug);
  foreach my $action (@$actions) {
    $action->delayedEvaluate($self->{RESULT_SET});
  }
  return $self->getReport();

=head1 DESCRIPTION

The AlgaeParser module binds a yapp grammar to semantic actions that build an
AlgaeCompileTree. In general, client applicatiosn have no direct interaction
with AlgaeParser. Devlopers wishing to extend the Algae2 query language
  http://www.w3.org/2003/11/Algae2/

will need the perl yapp modules. The Makefile included with the W3C::Rdf CPAN
module has a target to re-compile the AlgaeParser grammar. Invoke this with
  make AlgaeParser.pm
It is likely that someone extending the AlgaeParser grammar will also want to
extend AlgaeCompileTree.

This module is part of the W3C::Rdf CPAN module.

=head1 AUTHOR

Eric Prud\'hommeaux <eric@w3.org>

=head1 SEE ALSO

W3C::Rdf::Algae2(3) W3C::Rdf::AlgaeCompileTree(3) perl(1).

=cut

1;
