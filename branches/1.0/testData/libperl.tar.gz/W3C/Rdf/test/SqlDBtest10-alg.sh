#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# SqlDBtest10 - 
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: SqlDBtest10-alg.sh,v 1.5 2004/06/23 12:32:18 eric Exp $
###############################################################################

algae $* \
"(
 namespace '(testDB http://localhost/SqlDBtest#
             acl http://www.w3.org/2001/02/acls/ns#
             rdf http://www.w3.org/1999/02/22-rdf-syntax-ns#) 
 attach '(\"W3C::Rdf::SqlDB\" (\"properties:SqlDBtest.prop\" \"name:testDB::test1\"))
 ask '(testDB::test1
       (testDB::A.p4	?a	?d)
       (testDB::B.p5	?b	?c)
       (|| !(testDB::B.p6	?b	?c)
           (testDB::A.p1	?a	?b))
      )
 collect '(?d ?a ?b ?c) 
)" \

# Under-constraint example. Only one path through the OR constrains B_0 to A_0.
#        (testDB::A.p1	?a	?b)
# Path one [!(testDB::B.p6	?b	?c)] constains B_0 to A_0 yielding:
# +----------+------------------------------------------+---------------------------------------+---------------------------------------+
# |         d|                                         a|                                      b|                                      c|
# |----------|------------------------------------------|---------------------------------------|---------------------------------------|
# |"B1,C1,C2"|<http://localhost/SqlDBtest#A.u0=0&u1=101>|<http://localhost/SqlDBtest#B.key0=201>|<http://localhost/SqlDBtest#C.key1=301>|
# |"B2,C2,C1"|<http://localhost/SqlDBtest#A.u0=0&u1=102>|<http://localhost/SqlDBtest#B.key0=202>|<http://localhost/SqlDBtest#C.key1=302>|
# |"B3,C3,C3"|<http://localhost/SqlDBtest#A.u0=103&u1=0>|<http://localhost/SqlDBtest#B.key0=203>|<http://localhost/SqlDBtest#C.key1=303>|
# +----------+------------------------------------------+---------------------------------------+---------------------------------------+
# Path two [(testDB::A.p1	?a	?b)] does not constrain B_0:
# +----------+------------------------------------------+---------------------------------------+---------------------------------------+
# |         d|                                         a|                                      b|                                      c|
# |----------|------------------------------------------|---------------------------------------|---------------------------------------|
# |"B1,C1,C2"|<http://localhost/SqlDBtest#A.u0=0&u1=101>|<http://localhost/SqlDBtest#B.key0=201>|<http://localhost/SqlDBtest#C.key1=301>|
# |"B2,C2,C1"|<http://localhost/SqlDBtest#A.u0=0&u1=102>|<http://localhost/SqlDBtest#B.key0=201>|<http://localhost/SqlDBtest#C.key1=301>|
# |"B3,C3,C3"|<http://localhost/SqlDBtest#A.u0=103&u1=0>|<http://localhost/SqlDBtest#B.key0=201>|<http://localhost/SqlDBtest#C.key1=301>|
# |"B1,C1,C2"|<http://localhost/SqlDBtest#A.u0=0&u1=101>|<http://localhost/SqlDBtest#B.key0=202>|<http://localhost/SqlDBtest#C.key1=302>|
# |"B2,C2,C1"|<http://localhost/SqlDBtest#A.u0=0&u1=102>|<http://localhost/SqlDBtest#B.key0=202>|<http://localhost/SqlDBtest#C.key1=302>|
# |"B3,C3,C3"|<http://localhost/SqlDBtest#A.u0=103&u1=0>|<http://localhost/SqlDBtest#B.key0=202>|<http://localhost/SqlDBtest#C.key1=302>|
# +----------+------------------------------------------+---------------------------------------+---------------------------------------+
# The full disjunction would yield the SQL query
# SELECT A_0.u0 AS a_u0, A_0.u1 AS a_u1,
#        A_0.p4 AS d_p4,
# B_0.key0 AS b_key0,
#        C_0.key1 AS c_key1,
#        (NOT (B_0.p6=C_0.key1)),A_0.p1=B_0.key0
# FROM A AS A_0, B AS B_0, C AS C_0
# WHERE B_0.p5=C_0.key1
#   AND ((NOT (B_0.p6=C_0.key1))
#    OR A_0.p1=B_0.key0)
# and the solutions
# +----------+------------------------------------------+---------------------------------------+---------------------------------------+
# |         d|                                         a|                                      b|                                      c|
# |----------|------------------------------------------|---------------------------------------|---------------------------------------|
# |"B1,C1,C2"|<http://localhost/SqlDBtest#A.u0=0&u1=101>|<http://localhost/SqlDBtest#B.key0=201>|<http://localhost/SqlDBtest#C.key1=301>|
# |"B2,C2,C1"|<http://localhost/SqlDBtest#A.u0=0&u1=102>|<http://localhost/SqlDBtest#B.key0=201>|<http://localhost/SqlDBtest#C.key1=301>|
# |"B3,C3,C3"|<http://localhost/SqlDBtest#A.u0=103&u1=0>|<http://localhost/SqlDBtest#B.key0=201>|<http://localhost/SqlDBtest#C.key1=301>|
# |"B1,C1,C2"|<http://localhost/SqlDBtest#A.u0=0&u1=101>|<http://localhost/SqlDBtest#B.key0=202>|<http://localhost/SqlDBtest#C.key1=302>|
# |"B2,C2,C1"|<http://localhost/SqlDBtest#A.u0=0&u1=102>|<http://localhost/SqlDBtest#B.key0=202>|<http://localhost/SqlDBtest#C.key1=302>|
# |"B3,C3,C3"|<http://localhost/SqlDBtest#A.u0=103&u1=0>|<http://localhost/SqlDBtest#B.key0=202>|<http://localhost/SqlDBtest#C.key1=302>|
# |"B3,C3,C3"|<http://localhost/SqlDBtest#A.u0=103&u1=0>|<http://localhost/SqlDBtest#B.key0=203>|<http://localhost/SqlDBtest#C.key1=303>|
# +----------+------------------------------------------+---------------------------------------+---------------------------------------+

# Generates exception:
# %underconstraints exception:
# %  A_0 not constrained against B_0
# %    constrained by ' (testDB::A.p1 ?a ?b) object' in ' (|| !  (testDB::B.p6 ?b ?c)  (testDB::A.p1 ?a ?b)) object'
# %    constrained by ' (testDB::A.p1 ?a ?b) object' in ' (|| !  (testDB::B.p6 ?b ?c)  (testDB::A.p1 ?a ?b)) object'
# %  A_0 not constrained against C_0
