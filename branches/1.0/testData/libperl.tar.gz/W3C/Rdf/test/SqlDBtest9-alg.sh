#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# SqlDBtest9 - 
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: SqlDBtest9-alg.sh,v 1.4 2004/06/23 12:32:18 eric Exp $
###############################################################################

algae $* \
"(
 namespace '(testDB http://localhost/SqlDBtest#
             acl http://www.w3.org/2001/02/acls/ns#
             rdf http://www.w3.org/1999/02/22-rdf-syntax-ns#) 
 attach '(\"W3C::Rdf::SqlDB\" (\"properties:SqlDBtest.prop\" \"name:testDB::test1\"))
 ask '(testDB::test1
       (testDB::A.p4	?a	?d)
       (testDB::B.p5	?b	?c)
       !(testDB::B.p6	?b	?c)
      )
 collect '(?d ?a ?b ?c) 
)" \

# Under-constraint example. Introducing
#        (testDB::A.p1	?a	?b)
# yields
# +----------+------------------------------------------+---------------------------------------+---------------------------------------+
# |         d|                                         a|                                      b|                                      c|
# |----------|------------------------------------------|---------------------------------------|---------------------------------------|
# |"B1,C1,C2"|<http://localhost/SqlDBtest#A.u0=0&u1=101>|<http://localhost/SqlDBtest#B.key0=201>|<http://localhost/SqlDBtest#C.key1=301>|
# |"B2,C2,C1"|<http://localhost/SqlDBtest#A.u0=0&u1=102>|<http://localhost/SqlDBtest#B.key0=202>|<http://localhost/SqlDBtest#C.key1=302>|
# +----------+------------------------------------------+---------------------------------------+---------------------------------------+
# but eliminating it crosses
# mysql> SELECT * FROM A;      
# +-----+-----+-----+-----+-----+----------+
# | u0  | u1  | p1  | p2  | p3  | p4       |
# +-----+-----+-----+-----+-----+----------+
# |   0 | 101 | 201 | 301 | 302 | B1,C1,C2 |
# |   0 | 102 | 202 | 302 | 301 | B2,C2,C1 |
# | 103 |   0 | 203 | 303 | 303 | B3,C3,C3 |
# +-----+-----+-----+-----+-----+----------+
# 3 rows in set (0.00 sec)

# with
# mysql> SELECT * FROM B WHERE p5!=p6;
# +------+-----+-----+
# | key0 | p5  | p6  |
# +------+-----+-----+
# |  201 | 301 | 302 |
# |  202 | 302 | 301 |
# +------+-----+-----+
# 2 rows in set (0.00 sec)

# yielding
# +----------+------------------------------------------+---------------------------------------+---------------------------------------+
# |         d|                                         a|                                      b|                                      c|
# |----------|------------------------------------------|---------------------------------------|---------------------------------------|
# |"B1,C1,C2"|<http://localhost/SqlDBtest#A.u0=0&u1=101>|<http://localhost/SqlDBtest#B.key0=201>|<http://localhost/SqlDBtest#C.key1=301>|
# |"B2,C2,C1"|<http://localhost/SqlDBtest#A.u0=0&u1=102>|<http://localhost/SqlDBtest#B.key0=201>|<http://localhost/SqlDBtest#C.key1=301>|
# |"B3,C3,C3"|<http://localhost/SqlDBtest#A.u0=103&u1=0>|<http://localhost/SqlDBtest#B.key0=201>|<http://localhost/SqlDBtest#C.key1=301>|
# |"B1,C1,C2"|<http://localhost/SqlDBtest#A.u0=0&u1=101>|<http://localhost/SqlDBtest#B.key0=202>|<http://localhost/SqlDBtest#C.key1=302>|
# |"B2,C2,C1"|<http://localhost/SqlDBtest#A.u0=0&u1=102>|<http://localhost/SqlDBtest#B.key0=202>|<http://localhost/SqlDBtest#C.key1=302>|
# |"B3,C3,C3"|<http://localhost/SqlDBtest#A.u0=103&u1=0>|<http://localhost/SqlDBtest#B.key0=202>|<http://localhost/SqlDBtest#C.key1=302>|
# +----------+------------------------------------------+---------------------------------------+---------------------------------------+

# Generates exception:
# %underconstraints exception:
# %  A_0 not constrained against B_0
# %  A_0 not constrained against C_0
