#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# OrderTracking0 - 
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: OrderTracking0-alg.sh,v 1.12 2005/08/03 19:47:53 eric Exp $
###############################################################################

algae $* \
--lang Algae \
"
ns ot=<http://localhost/OrderTracking#>
attach <http://www.w3.org/2003/01/21-RDF-RDB-access/ns#SqlDB> ot:db (
                    properties=\"../test/OrderTracking.prop\")
ask ot:db (
	?p	ot:Products_description	?productDesc
)
collect (?productDesc) 
ns ot=<http://localhost/OrderTracking#>
ask ot:db (
	?c	ot:Customers_familyName	?last .
	?c	ot:Customers_givenName	?first
)
collect (?first ?last) 
" \

# Table Results:
# +-----------------------+--------+----------+
# |            productDesc|   first|      last|
# |-----------------------|--------|----------|
# |          "white house"|  "Biff"|"Thompson"|
# |          "white house"|  "Chip"|"Thompson"|
# |          "white house"|"Eustis"|  "Walker"|
# |          "white house"|  "Elie"|   "Tweak"|
# |         "picket fence"|  "Biff"|"Thompson"|
# |         "picket fence"|  "Chip"|"Thompson"|
# |         "picket fence"|"Eustis"|  "Walker"|
# |         "picket fence"|  "Elie"|   "Tweak"|
# |"sport utility vehicle"|  "Biff"|"Thompson"|
# |"sport utility vehicle"|  "Chip"|"Thompson"|
# |"sport utility vehicle"|"Eustis"|  "Walker"|
# |"sport utility vehicle"|  "Elie"|   "Tweak"|
# |                 "pool"|  "Biff"|"Thompson"|
# |                 "pool"|  "Chip"|"Thompson"|
# |                 "pool"|"Eustis"|  "Walker"|
# |                 "pool"|  "Elie"|   "Tweak"|
# |                "grill"|  "Biff"|"Thompson"|
# |                "grill"|  "Chip"|"Thompson"|
# |                "grill"|"Eustis"|  "Walker"|
# |                "grill"|  "Elie"|   "Tweak"|
# |           "skateboard"|  "Biff"|"Thompson"|
# |           "skateboard"|  "Chip"|"Thompson"|
# |           "skateboard"|"Eustis"|  "Walker"|
# |           "skateboard"|  "Elie"|   "Tweak"|
# |      "rebelious music"|  "Biff"|"Thompson"|
# |      "rebelious music"|  "Chip"|"Thompson"|
# |      "rebelious music"|"Eustis"|  "Walker"|
# |      "rebelious music"|  "Elie"|   "Tweak"|
# |              "earring"|  "Biff"|"Thompson"|
# |              "earring"|  "Chip"|"Thompson"|
# |              "earring"|"Eustis"|  "Walker"|
# |              "earring"|  "Elie"|   "Tweak"|
# |            "nose ring"|  "Biff"|"Thompson"|
# |            "nose ring"|  "Chip"|"Thompson"|
# |            "nose ring"|"Eustis"|  "Walker"|
# |            "nose ring"|  "Elie"|   "Tweak"|
# |           "other ring"|  "Biff"|"Thompson"|
# |           "other ring"|  "Chip"|"Thompson"|
# |           "other ring"|"Eustis"|  "Walker"|
# |           "other ring"|  "Elie"|   "Tweak"|
# +-----------------------+--------+----------+

