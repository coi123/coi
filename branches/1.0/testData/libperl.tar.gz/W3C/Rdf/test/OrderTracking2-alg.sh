#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# OrderTracking2 - avoid looking at some orders
# Tests:
#   - negation
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: OrderTracking2-alg.sh,v 1.8 2004/10/06 15:18:44 eric Exp $
###############################################################################

algae $* \
"
ns ot=<http://localhost/OrderTracking#>
attach <http://www.w3.org/2003/01/21-RDF-RDB-access/ns#SqlDB> ot:db (
                    properties=\"../test/OrderTracking.prop\")
ask ot:db (
       ?o	ot:Orders_customer	?c .
       ?o	ot:Orders_product	?p .
       ?o	ot:Orders_orderDate	?d .
       ?p	ot:Products_description	?prodDesc .
       ?c	ot:Customers_givenName	?first .
       ?c	ot:Customers_familyName	?last .
       ?c	ot:Customers_billingAddress	?billAddr .
       ?billAddr ot:Addresses_street	?billStreet .
       ?billAddr ot:Addresses_city	?billCity .
       ?billAddr ot:Addresses_state	?billState .
       ?o	ot:Orders_shippingAddress	?billAddr .
       !?p	ot:Products_description	\"other ring\" 
      )
collect (?first ?last ?prodDesc ?billStreet ?billCity ?billState ?billAddr) 
" \

# Generates exception:
# %overconstraints exception:
# %  Customers_0 over-constrained against Addresses_0 (ot:Customers_billingAddress ?c ?billAddr)

