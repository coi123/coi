#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# globTest1 - use reduced-expressivity form of wildcards
# Tests:
#   - URI glob matching
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: globTest1-alg.sh,v 1.5 2005/08/03 19:47:53 eric Exp $
###############################################################################

algae $* \
--lang Algae \
"
ns t=<http://t.t/>
slurp ../test/algaeTest.rdf ()
ask ( 
      ?s1 ?p ?o1 {?p @ \"http://t.*/p1*\"} .
      ?o1 t:p2 ?o2 .
      ?o2 ?o3 ?o3 .
      ?s1 t:p4 ?o2
      ) 
collect (?s1 ?o3 ?o2) 
" \

# Table Results:
# +----------------+----------------+----------------+
# |              s1|              o3|              o2|
# |----------------|----------------|----------------|
# |<http://t.t/s1a>|<http://t.t/o3a>|<http://t.t/o2a>|
# |<http://t.t/s1a>|<http://t.t/o3b>|<http://t.t/o2a>|
# |<http://t.t/s1b>|<http://t.t/o3a>|<http://t.t/o2a>|
# |<http://t.t/s1b>|<http://t.t/o3b>|<http://t.t/o2a>|
# |<http://t.t/s1a>|<http://t.t/o3a>|<http://t.t/o2a>|
# |<http://t.t/s1a>|<http://t.t/o3b>|<http://t.t/o2a>|
# +----------------+----------------+----------------+

