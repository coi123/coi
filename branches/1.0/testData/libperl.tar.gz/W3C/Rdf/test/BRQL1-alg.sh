#!/bin/sh

###############################################################################
# Copyright 2004 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# BRQL1 - info about discovered nodes.
# Tests:
#   - DESCRIBE
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: BRQL1-alg.sh,v 1.4 2004/08/09 19:03:20 eric Exp $
###############################################################################

algae $* \
--lang BRQL \
--reportClass n3 \
"
DESCRIBE ?s
  FROM <../test/Annotation1052587433.529382.rdf>
 WHERE { SOURCE ?src ?s rdf:type a:Annotation . }
 USING rdf FOR <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
       a FOR <http://www.w3.org/2000/10/annotation-ns#>
" \

## Extra Arguments:
# --forceHost example.com
# --forcePath /instpath/workingdir

# N3 Results:
# @prefix d1: <http://purl.org/dc/elements/1.1/>
# @prefix annotationType: <http://www.w3.org/2000/10/annotationType#>
# @prefix annotate: <mailto:eric+annotate@>
# @prefix d0: <http://purl.org/dc/elements/1.0/>
# @prefix a: <http://www.w3.org/2000/10/annotation-ns#>
# @prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
# <http://iggy.w3.org/annotations/annotation/1052587433.529382> rdf:type a:Annotation ;
#                                                               d0:creator "eric" ;
#                                                               d0:creator [
#    a:Email annotate:w3.org ;
#    a:Family "Prud'hommeaux" ;
#    a:Given "É®íç" .
# ] ;
#                                                               d0:date "2003-05-10T13:23:38-05:00" ;
#                                                               d0:title "Old Annotation of Eric's Homepage" ;
#                                                               rdf:type annotationType:Comment ;
#                                                               a:Attribution <http://iggy.w3.org/annotations/attribution/1052587433.529382> ;
#                                                               a:annotates <http://www.w3.org/People/Eric/> ;
#                                                               a:body <http://iggy.w3.org/annotations/body/1052587433.529382> ;
#                                                               a:context "http://www.w3.org/People/Eric/#xpointer(/html[1])" ;
#                                                               a:created "2003-05-10T13:22:50-05:00" .
# <http://iggy.w3.org/annotations/annotation/1054553215.108988> rdf:type a:Annotation ;
#                                                               d1:creator "eric" ;
#                                                               d1:creator [
#    a:Email annotate:w3.org ;
#    a:Family "Prud'hommeaux" ;
#    a:Given "É®íç" .
# ] ;
#                                                               d1:date "2003-06-06T14:32:54" ;
#                                                               d1:title "New Annotation of Eric's Homepage" ;
#                                                               rdf:type annotationType:Comment ;
#                                                               a:Attribution <http://iggy.w3.org/annotations/attribution/1054553215.108988> ;
#                                                               a:annotates <http://www.w3.org/People/Eric/> ;
#                                                               a:body <http://iggy.w3.org/annotations/body/1054553215.108988> ;
#                                                               a:context "http://www.w3.org/People/Eric/#xpointer(/html[1]/body[1]/p[2]/a[9])" ;
#                                                               a:created "2003-06-02T07:26:30-05:00" .

