#!/bin/sh

###############################################################################
# Copyright 2004 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# SPARQL-DT-0c - SPARQL Datatype tester.
# Tests:
#   - whether different datatypes restricted from decimal are different nodes.
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: SPARQL-DT-0c-alg.sh,v 1.1 2005/04/08 09:41:50 eric Exp $
###############################################################################

algae $* \
--lang n3 \
"
<foo> <shoeSize> \"42\"^^<http://www.w3.org/2001/XMLSchema#int> ;
      <age>      \"42\"^^<http://www.w3.org/2001/XMLSchema#float> .
" \
--lang SPARQL \
"
SELECT ?s ?size
 WHERE { ?s <shoeSize> ?size ; <age> ?age .
FILTER !sameAs(?size, ?age) }
" \

# Table Results:
# +----------+----+
# |         s|size|
# |----------|----|
# |<data:foo>|  42|
# +----------+----+

