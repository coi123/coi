#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# aclQuery2 - Demonstrate SqlDB:
# Needs two additional entries in the chacl.prop:
#   structure: W3C::Rnodes::AclSqlObjects
#   baseUri: http://localhost/SqlDB#
# May need to create AclSqlObjects with W3C/Rnodes/bin/makeAclSqlObjects.sh
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: aclQuery3-alg.sh,v 1.2 2004/06/23 12:32:18 eric Exp $
###############################################################################

./algae $* \
"(
 namespace '(sqlDB http://localhost/SqlDB#
             acl http://www.w3.org/2001/02/acls/ns#
             rdf http://www.w3.org/1999/02/22-rdf-syntax-ns#) 
 attach '(\"W3C::Rdf::SqlDB\" (\"properties:../test/aclQuery.prop\" \"name:sqlDB::W3Cacls\"))
 interface (sqlDB::W3Cacls
            API  '((acl::accessTo                ?a       ?uri)) 
            impl '((sqlDB::uris.uri             #?urisRow ?uri) 
                   (sqlDB::uris.acl              ?urisRow #?aacl) 
                   (sqlDB::acls.acl              ?a       ?aacl) )) 
 interface (sqlDB::W3Cacls
            API  '((acl::access                  ?a       ?access)) 
            impl '((sqlDB::acls.access           ?a       ?access))) 
 interface (sqlDB::W3Cacls
            API  '((acl::login                   ?u       ?name)) 
            impl '((sqlDB::ids.value             ?u       ?name))) 
 interface (sqlDB::W3Cacls
            API  '((acl::memberOf                ?sub     ?super)) 
            impl '((sqlDB::idInclusions.id      #?g1      ?sub) 
                   (sqlDB::idInclusions.groupId  ?g1      ?super))) 
 interface (sqlDB::W3Cacls
            API  '((acl::accessor                ?a       ?principal)) 
            impl '((sqlDB::acls.id               ?a       ?principal))) 
 ask '(sqlDB::W3Cacls
       (acl::accessTo   ?acl       http://www.w3.org/Member/Overview.html) 
       (acl::access     ?acl       ?access) 
       (acl::accessor   ?acl       ?accessor) 
       (acl::memberOf   ?u1        ?accessor) 
       (acl::login      ?u1        \"eric\")) 
 collect '(?acl) 
 update '(sqlDB::W3Cacls '(?acl = http://localhost/SqlDB#acls.acl=7&id=1&access=3122)) 
)" \

# SELECT uris_0.id AS urisRow_id,
#        uris_0.acl AS aacl_acl,
# acls_0.acl AS acl_acl, acls_0.id AS acl_id, acls_0.access AS acl_access,
#        ids_0.id AS u1_id,
#        idInclusions_0.id AS g1_id, idInclusions_0.groupId AS g1_groupId
# FROM uris AS uris_0, acls AS acls_0, ids AS ids_0, idInclusions AS idInclusions_0
# WHERE uris_0.uri="http://www.w3.org/Member/Overview.html"
#   AND acls_0.acl=uris_0.acl
#   AND ids_0.value="eric"
#   AND idInclusions_0.id=ids_0.id
#   AND acls_0.id=idInclusions_0.groupId

# +------------------------------------------------------+
# |                                                   acl|
# |------------------------------------------------------|
# |<http://localhost/SqlDB#acls.acl=6&id=100&access=3122>|
# |<http://localhost/SqlDB#acls.acl=6&id=102&access=3955>|
# +------------------------------------------------------+
