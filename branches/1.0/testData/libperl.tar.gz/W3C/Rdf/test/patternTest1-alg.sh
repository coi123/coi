#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# patternTest1 - test filtering of triplesMatching results for patterns like
#                (dc::title dc::title "title")
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: patternTest1-alg.sh,v 1.3 2004/06/23 12:32:18 eric Exp $
###############################################################################

../bin/algae $* \
"
ns t=<http://example.org/t#>
assert (t:ps t:ps t:o.
        t:po t:s t:po.
        t:p t:so t:so.
        t:p t:s t:o.
       )
ask (?ps ?ps ?o)
collect (?ps ?o)
" \
"
ns t=<http://example.org/t#>
assert (t:ps t:ps t:o.
        t:po t:s t:po.
        t:p t:so t:so.
        t:p t:s t:o.
       )
ask (?p ?so ?so)
collect (?p ?so)
" \
"
ns t=<http://example.org/t#>
assert (t:ps t:ps t:o.
        t:po t:s t:po.
        t:p t:so t:so.
        t:p t:s t:o.
       )
ask (?po ?s ?po)
collect (?po ?s)
" \

# +-------------------------+------------------------+
# |                       ps|                       o|
# |-------------------------|------------------------|
# |<http://example.org/t#ps>|<http://example.org/t#o>|
# +-------------------------+------------------------+
# +------------------------+-------------------------+
# |                       p|                       so|
# |------------------------|-------------------------|
# |<http://example.org/t#p>|<http://example.org/t#so>|
# +------------------------+-------------------------+
# +-------------------------+------------------------+
# |                       po|                       s|
# |-------------------------|------------------------|
# |<http://example.org/t#po>|<http://example.org/t#s>|
# +-------------------------+------------------------+

