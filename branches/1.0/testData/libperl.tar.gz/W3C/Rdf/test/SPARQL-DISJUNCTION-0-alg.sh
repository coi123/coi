#!/bin/sh

###############################################################################
# Copyright 2004 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# SPARQL-DISJUNCTION-0 - DISJUNCTION.
# Tests:
#   - simple UNION DISJUNCTION
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: SPARQL-DISJUNCTION-0-alg.sh,v 1.2 2004/12/14 09:01:42 eric Exp $
###############################################################################

algae $* \
--lang n3 \
"
@prefix p: <http://example.org/n#> .
p:A0 p:p1 p:B .
#p:A0 p:p2 p:C .
#p:A0 p:p3 p:D .

#p:A1 p:p1 p:B .
p:A1 p:p2 p:C .
#p:A1 p:p3 p:D .

#p:A2 p:p1 p:B .
#p:A2 p:p2 p:C .
p:A2 p:p3 p:D .

#p:A3 p:p1 p:B .
p:A3 p:p2 p:C .
p:A3 p:p3 p:D .

p:A4 p:p4 p:E .
" \
--lang SPARQL \
"
PREFIX p: <http://example.org/n#>
SELECT ?n
WHERE  (?n p:p2 p:C)
       OR (?n p:p3 p:D)
" \

# Table Results:
# +-------------------------+
# |                        n|
# |-------------------------|
# |<http://example.org/n#A1>|
# |<http://example.org/n#A2>|
# |<http://example.org/n#A3>|
# +-------------------------+

# ResultSet Results:
# @prefix rdf:    <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
# @prefix rs:     <http://jena.hpl.hp.com/2003/03/result-set#> .
# 
# [] rdf:type rs:ResultSet ;
#     rs:resultVariable "n" ;
#     rs:size "4" ;
#     rs:solution
#         [ rdf:type rs:ResultSolution ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "n" ; rs:value <http://example.org/n#A1> ] 
#         ] ;
#     rs:solution
#         [ rdf:type rs:ResultSolution ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "n" ; rs:value <http://example.org/n#A2> ] 
#         ] ;
#     rs:solution
#         [ rdf:type rs:ResultSolution ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "n" ; rs:value <http://example.org/n#A3> ] 
#         ] .

