#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# fwruleTest1 - 
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: fwruleTest1-alg.sh,v 1.9 2005/08/03 19:47:53 eric Exp $
###############################################################################

algae $* \
--lang Algae \
"
ns tax=<http://example.com/taxonomy/>
ns r=<http://example.com/resource/>
ns bm=<http://www.w3.org/2002/01/bookmark#>

require <http://www.w3.org/2004/06/20-rules/#assert>

@../test/bookmarkRules.alg
@../test/rdfs.alg
slurp ../test/subCategoryExample.rdf ()
ask (
    ?sub bm:subCategoryOf ?super .
    ?bmark bm:hasCategory ?super .
    !?bmark bm:foo ?super
)
collect (?bmark ?sub ?super)
" \

# Table Results:
# +---------------------------------+------------------------------------------------+-------------------------------------------+
# |                            bmark|                                             sub|                                      super|
# |---------------------------------|------------------------------------------------|-------------------------------------------|
# |<http://example.com/resource/one>|       <http://example.com/taxonomy/blue-whales>|<http://example.com/taxonomy/opaque-whales>|
# |<http://example.com/resource/one>|<http://example.com/taxonomy/bright-blue-whales>|<http://example.com/taxonomy/opaque-whales>|
# +---------------------------------+------------------------------------------------+-------------------------------------------+

