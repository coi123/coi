#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# OrderTracking5 - Database misc query
# Tests:
#   - join against __Holds__
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: OrderTracking9-alg.sh,v 1.3 2004/10/06 15:18:44 eric Exp $
###############################################################################

algae $* \
"
ns ot=<http://localhost/OrderTracking#>
ns billing=<http://example.com/billing#>
ns alg=<http://www.w3.org/1999/02/26-modules/algae#>
attach <http://www.w3.org/2003/01/21-RDF-RDB-access/ns#SqlDB> ot:test1 (
                    properties=\"../test/OrderTracking.prop\")
flags (dumpQueryMode=alg:DOT
       dumpQueryURL=<file:OrderTracking8-query.dot>
       dumpQueryGraphMode=alg:DOT
       dumpQueryGraphURL=<file:OrderTracking8-queryGraph.dot>
       dumpCompiledMode=alg:DOT
       dumpCompiledURL=<file:OrderTracking8-compiled.dot>
       dumpCompiledGraphMode=alg:DOT
       dumpCompiledGraphURL=<file:OrderTracking8-compiledGraph.dot>)
ask ot:test1 (
       ?o	ot:Orders_customer		?c .
#       ~?o	billing:dontTell		?who .
#       ?o	billing:dontTell		?who .
       (?o	billing:dontask			?who ||
        ?o	billing:dontTell		?who ||
        ?o	billing:dontKnow		?dunno .
        ?dunno	billing:name			?who).
       ?o	ot:Orders_product		?p .
       ?p	ot:Products_name		\"other ring\" .
       ?c	ot:Customers_givenName		\"Chip\" .
       ?c	ot:Customers_familyName		?last 
#       ?c       <http://example.com/sales#marketingProfile> ?profile
)
collect (?last) # ?profile)
" \

#       ?o	ot:Orders_customer	?c .
#       ~?o	<http://example.com/sales#marketingProfile>	?profile .
#       ?o	ot:Orders_product	?p .
#      )
#collect (?profile ?o ?c ?p) 


# Test with optional references from optional property ?shipAddr

# SELECT Orders_0.id AS o_id,
#        Customers_0.id AS c_id,
#        __Holds___0.id AS H_who_id,
#        __Nodes___1.type AS N_who_type,
#        __Nodes___1.str AS N_who_str,
#        __Nodes___1.big AS N_who_big,
#        __Nodes___1.attribOrDT AS N_who_attribOrDT,
#        Products_0.id AS p_id,
#        Orders_0.orderDate AS d_orderDate,
# Products_0.name AS productName_name,
# Customers_0.givenName AS first_givenName,
# Customers_0.familyName AS last_familyName,
# Addresses_0.id AS billAddr_id,
#        Addresses_0.street AS billStreet_street,
# Addresses_0.city AS billCity_city,
# Addresses_0.state AS billState_state,
# Addresses_1.id AS shipAddr_id,
#        Addresses_1.street AS shipStreet_street,
# Addresses_1.city AS shipCity_city,
# Addresses_1.state AS shipState_state
# FROM Orders AS Orders_0
#      INNER JOIN Customers AS Customers_0 ON Orders_0.customer=Customers_0.id
#      LEFT OUTER JOIN __Nodes__ AS __Nodes___0 ON __Nodes___0.str=concat("Orders,id=\"",Orders_0.id,"\"")
#      LEFT OUTER JOIN __Holds__ AS __Holds___0 ON __Nodes___0.node=__Holds___0.s AND __Nodes___0.nodec=__Holds___0.sc
#      LEFT OUTER JOIN __Nodes__ AS __Nodes___1 ON __Holds___0.o=__Nodes___1.node AND __Holds___0.oc=__Nodes___1.nodec
#      INNER JOIN Products AS Products_0 ON Orders_0.product=Products_0.id
#      INNER JOIN Addresses AS Addresses_0 ON Customers_0.billingAddress=Addresses_0.id
#      LEFT OUTER JOIN Addresses AS Addresses_1 ON (Orders_0.shippingAddress=Addresses_1.id)

# +------+------+----------+------------+------------------+-----------+------------------+------+----------------+------------------+-----------------+-----------------+-------------+-------------------+---------------+-----------------+-------------+-------------------+---------------+-----------------+
# | o_id | c_id | H_who_id | N_who_type | N_who_str        | N_who_big | N_who_attribOrDT | p_id | d_orderDate    | productName_name | first_givenName | last_familyName | billAddr_id | billStreet_street | billCity_city | billState_state | shipAddr_id | shipStreet_street | shipCity_city | shipState_state |
# +------+------+----------+------------+------------------+-----------+------------------+------+----------------+------------------+-----------------+-----------------+-------------+-------------------+---------------+-----------------+-------------+-------------------+---------------+-----------------+
# | 2185 |    1 |     NULL | NULL       | NULL             |      NULL |             NULL | 1004 | 20020907000000 | pool             | Biff            | Thompson        |           1 | 123 Elm Street    | EdgeCity      | AV              |        NULL | NULL              | NULL          | NULL            |
# | 2186 |    2 |     NULL | NULL       | NULL             |      NULL |             NULL | 2001 | 20020908000000 | skateboard       | Chip            | Thompson        |           1 | 123 Elm Street    | EdgeCity      | AV              |        NULL | NULL              | NULL          | NULL            |
# | 2187 |    2 |     NULL | NULL       | NULL             |      NULL |             NULL | 2004 | 20020907000000 | nose ring        | Chip            | Thompson        |           1 | 123 Elm Street    | EdgeCity      | AV              |        NULL | NULL              | NULL          | NULL            |
# | 3183 |    2 |      290 | table      | Customers,id="1" |      NULL |                0 | 2005 | 20020907000000 | other ring       | Chip            | Thompson        |           1 | 123 Elm Street    | EdgeCity      | AV              |           2 | 245 King Street   | EdgeCity      | AV              |
# +------+------+----------+------------+------------------+-----------+------------------+------+----------------+------------------+-----------------+-----------------+-------------+-------------------+---------------+-----------------+-------------+-------------------+---------------+-----------------+

# +------+----------+------------+------+----------+--------+--------+
# | first|      last| productName|bFirst|     bLast|  sFirst|   sLast|
# |------|----------|------------|------|----------|--------|--------|
# |"Biff"|"Thompson"|      "pool"|"Biff"|"Thompson"|    NULL|    NULL|
# |"Chip"|"Thompson"|"skateboard"|"Biff"|"Thompson"|    NULL|    NULL|
# |"Chip"|"Thompson"| "nose ring"|"Biff"|"Thompson"|    NULL|    NULL|
# |"Chip"|"Thompson"|"other ring"|"Biff"|"Thompson"|"Eustis"|"Walker"|
# +------+----------+------------+------+----------+--------+--------+

