#!/bin/sh

###############################################################################
# Copyright 2004 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# SPARQL-DT-3 - SPARQL Datatype tester.
# Tests:
#   - whether uncastables yield an error (tested by passing through not).
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: SPARQL-COL-0-alg.sh,v 1.2 2005/06/23 09:50:04 eric Exp $
###############################################################################

algae $* \
--lang n3 \
"
@prefix rdf:    <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
@prefix rdfs:	<http://www.w3.org/2000/01/rdf-schema#> .
@prefix dawgt:   <http://www.w3.org/2001/sw/DataAccess/tests/test-dawg#> .
@prefix mf:     <http://www.w3.org/2001/sw/DataAccess/tests/test-manifest#> .
@prefix qt:     <http://www.w3.org/2001/sw/DataAccess/tests/test-query#> .

<>  rdf:type mf:Manifest ;
    rdfs:comment \"SPARQL examples from query WD\" ;
    mf:entries
    ([  mf:name    \"sparql-query-example-a\" ;
        rdfs:comment
            \"Example from section 2.1\" ;
        mf:action
            [ qt:query  <ex2-1a.rq> ;
              qt:data   <ex2-1a.n3> ] ;
        mf:result  <ex2-1a-result.n3> ;
        dawgt:approval dawgt:Approved
      ]

     [  mf:name    \"sparql-query-example-b\" ;
        rdfs:comment
            \"Example from section 2.3\" ;
        mf:action
            [ qt:query  <ex2-2a.rq> ;
              qt:data   <ex2-2a.n3> ] ;
        mf:result  <ex2-2a-result.n3> ;
        dawgt:approval dawgt:Approved
      ]

     [  mf:name    \"sparql-query-example-c\" ;
        rdfs:comment
            \"Example from section 2.4\" ;
        mf:action
            [ qt:query  <ex2-3a.rq> ;
              qt:data   <ex2-3a.n3> ] ;
        mf:result  <ex2-3a-result.n3> ;
        dawgt:approval dawgt:Approved
      ]

     [  mf:name    \"sparql-query-example-d\" ;
        rdfs:comment
            \"Example from section 2.5\" ;
        mf:action
            [ qt:query  <ex2-4a.rq> ;
              qt:data   <ex2-4a.n3> ] ;
        mf:result  <ex2-4a-result.n3> ;
        dawgt:approval dawgt:Approved
      ]

     [  mf:name    \"sparql-query-example-e\" ;
        rdfs:comment
            \"Example from section 3\" ;
        mf:action
            [ qt:query  <ex3.rq> ;
              qt:data   <ex3.n3> ] ;
        mf:result  <ex3-result.n3>
      ]

    # End of tests
   ).
" \
--lang SPARQL \
"
SELECT  ?l ?mem ?result
 WHERE {
  ?man mf:entries list(?l),members(?mem) .
  ?mem mf:result ?result }
" \

# Table Results:
# +-------------------------------+-----+-----------------------------------------------------------------------------------------+
# |                              l|  mem|                                                                                   result|
# |-------------------------------|-----|-----------------------------------------------------------------------------------------|
# |(_:g2, _:g4, _:g6, _:g8, _:g10)| _:g2|<file://unagi.w3.org/home/eric/sources/public/perl/modules/W3C/Rdf/test/ex2-1a-result.n3>|
# |(_:g2, _:g4, _:g6, _:g8, _:g10)| _:g4|<file://unagi.w3.org/home/eric/sources/public/perl/modules/W3C/Rdf/test/ex2-2a-result.n3>|
# |(_:g2, _:g4, _:g6, _:g8, _:g10)| _:g6|<file://unagi.w3.org/home/eric/sources/public/perl/modules/W3C/Rdf/test/ex2-3a-result.n3>|
# |(_:g2, _:g4, _:g6, _:g8, _:g10)| _:g8|<file://unagi.w3.org/home/eric/sources/public/perl/modules/W3C/Rdf/test/ex2-4a-result.n3>|
# |(_:g2, _:g4, _:g6, _:g8, _:g10)|_:g10|   <file://unagi.w3.org/home/eric/sources/public/perl/modules/W3C/Rdf/test/ex3-result.n3>|
# +-------------------------------+-----+-----------------------------------------------------------------------------------------+

