#!/usr/bin/perl

$REVISION = '$Id: testRdfParser.pl,v 1.40 2004/06/08 06:51:01 eric Exp $ ';

use strict;

#BEGIN {unshift@INC,('../../..');}
package testRdfParser;
@testRdfParser::ISA = qw(W3C::Rdf::RdfApp);

use W3C::Rdf::RdfApp;
use W3C::Util::Exception;

eval {
    my $tester = new testRdfParser;
    $tester->execute(\@ARGV);
}; if ($@) {if ($@) {if (my $ex = &catch('W3C::Util::Exception')) {
    die $ex->toString;
#    die $@.' at line '.$tester->{XML_PARSER}->getLineNumber.' column '.$tester->{XML_PARSER}->getColumnNumber;
} else {die $@;}}}

sub render {
    my ($self) = @_;
    my @attribs = $self->{RDF_PARSER}->getRootAttribution;
    my $sysID = $self->{RDF_PARSER}->getSystemId;
    my ($query, @lookFors);

    # give $self->{RDF_PARSER} as a W3C::XML::OldNamespaceHandler to unmap names.
    print join ("\n", $self->{RDF_DB}->expandStatements(undef, ':', $self->{NAMESPACE_HANDLER}, 
							{-attributions => \@attribs, -sourceOnly => $self->{ARGS}{-sourceOnly}}));
    print "\n--------end of triples--------\n";

    # exercise some query functions in the W3C::Rdf::RdfDB
    @lookFors = ('http://www.w3.org/schema/certHTMLv1/access', 
		 'http://www.w3.org/schema/certHTMLv1/accessor', 
		 'http://www.w3.org/schema/certHTMLv1/hasAccessTo') if (!@lookFors);
    my @copy = map {$self->{-atomDictionary}->getUriLink($_, $sysID)} @lookFors;
    my $type = $self->{-atomDictionary}->getUriLink('http://www.w3.org/schema/certHTMLv1/resourceAccessRule', $sysID);
    my @nodes = $self->{RDF_DB}->nodesWithType(undef, $type, {-attributions => \@attribs});
    my @nodes1 = $self->{RDF_DB}->allPredicates(undef, \@copy);
#    $query = "(ask '((http://www.w3.org/schema/certHTMLv1/access ?x \"acc1\") 
#    $query = "(ask '((http://www.w3.org/schema/certHTMLv1/access ?x ?z) 
#(?y ?x \"http://user1\"))
#:collect ?x)" if (!$query);
#    $query = "(ask '((http://www.w3.org/schema/certHTMLv1/hasAccessTo ?s ?t) (http://www.w3.org/schema/certHTMLv1/accessor ?s ?r) (http://www.w3.org/schema/certHTMLv1/access ?s ?a)) :collect '(?s ?t ?r ?a))";
#    $query = "(ask '((http://t.t/p1 ?s1 ?o1) (http://t.t/p2 ?o1 ?o2) (?o3 ?o2 ?o3) (http://t.t/p4 ?s1 ?o2)) :collect '(?s1 ?o3))";
    foreach my $query (@{$self->{ARGS}{-algae}}) {
	my $queryHandler = $self->{RDF_DB}->getAlgaeInterface;
	my ($nodes2, $selects, $messages) = $queryHandler->algae($query, $sysID);

	print join ("\n", @$messages)."\n";
	print 'algae "'.$query."\" -> \n".join ("\n", map {'('.join (' ', map {$_->toString} @$_).')'} @$nodes2)."\n";
	print 'algae "'.$query."\" -> \n".complicatedRenderer($nodes2);
    }

    # find all defined recombinations of the objects of the nodes
    my @join = $self->{RDF_DB}->join(undef, \@nodes, \@copy);

    # show the onces we got
    foreach my $element (@join) {
	for (my $i = $0; $i <= $#lookFors; $i++) {
	    eval {print $lookFors[$i].': '.$element->[$i]->toString.'  ';};
	}
	print "\n";
    }

    # demonstrate the anySubjects function
#    my @supplied = $self->{RDF_DB}->supplied;
#    my @theirStatements = $self->{RDF_DB}->anySubjects(\@supplied, [$inputSource->getPublicId]);
#    foreach my $triple (@theirStatements) {
#	print $triple->toString."\n";
#    }

    # test the anyContainerNodes function to make sure the acl stuff keeps working
    foreach my $node (@nodes) {
	my $lookForPredicate = $self->{-atomDictionary}->getUriLink('http://www.w3.org/schema/certHTMLv1/hasAccessTo', $sysID);
	my @resourceList = $self->{RDF_DB}->triplesMatching(undef, [[$lookForPredicate, $node, undef]]);
	my @resources = map {$_->getObject} @resourceList;
	my @t = $self->{RDF_DB}->anyContainerNodes(undef, [$node]);
	map {print "\$aclDB->addResourceAttribute(['".join('\',\'', map {$_->toString} @resources)."'], {'aclBinBag', ".$_->getSubject->toString."})\n"} @t;
    }

    return;
}

sub main::break {
    print 'break: '.join (' ', @_)."\n";
    return;
}

sub complicatedRenderer {
    my ($rows) = @_;
    my $ret;
    foreach my $row (@$rows) {
	$ret .= '(';
	foreach my $column (@$row) {
	    if ($column->isa('W3C::Rdf::Uri')) {
		$ret .= '<'.$column->getUri.'>';
	    } elsif ($column->isa('W3C::Rdf::String')) {
		$ret .= '"'.$column->getString.'"';
	    } elsif ($column->isa('W3C::Rdf::BNode')) {
		$ret .= '"'.$column->getId.'"';
	    } else {
		&throw(new W3C::Util::Exception(-message => "don't know how to serialize \"$column\""));
	    }
	    $ret .= ' ';
	}
	$ret .= ")\n";
    }
    return $ret;
}

