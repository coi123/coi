#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# OrderTracking1 - Billing department view
# Tests:
#   - join of Orders, Products, Customers, Addresses
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: OrderTracking1-alg.sh,v 1.12 2007/06/24 22:09:22 eric Exp $
###############################################################################

algae $* \
--lang Algae \
"
ns ot=<http://localhost/OrderTracking#>
attach <http://www.w3.org/2003/01/21-RDF-RDB-access/ns#SqlDB> ot:db (
                    properties=\"../test/OrderTracking.prop\")
ask ot:db (
       ?o	ot:Orders_id		?orderId .
       ?o	ot:Orders_customer		?c .
       ?o	ot:Orders_orderDate		\"2002-09-06 18:00:00\" .
       ?o	ot:Orders_product		?p .
       ?p	ot:Products_description		?productDesc .
       ?c	ot:Customers_givenName	?first .
       ?c	ot:Customers_familyName	?last .
       ?c	ot:Customers_billingAddress	?billAddr .
       ?billAddr ot:Addresses_street	?billStreet .
       ?billAddr ot:Addresses_city		?billCity .
       ?billAddr ot:Addresses_state		?billState
      )
collect (?orderId ?productDesc ?first ?last ?billStreet ?billCity ?billState) 
" \

# Table Results:
# +-------+-----------+------+----------+----------------+----------+---------+
# |orderId|productDesc| first|      last|      billStreet|  billCity|billState|
# |-------|-----------|------|----------|----------------|----------|---------|
# | "2185"|     "pool"|"Biff"|"Thompson"|"123 Elm Street"|"EdgeCity"|     "AV"|
# | "2187"|"nose ring"|"Chip"|"Thompson"|"123 Elm Street"|"EdgeCity"|     "AV"|
# +-------+-----------+------+----------+----------------+----------+---------+

# SQL Query:
# SELECT Orders_0.id AS o_id,
#        Customers_0.id AS c_id,
#        Products_0.id AS p_id,
#        Products_0.description AS productDesc_description,
# Customers_0.givenName AS first_givenName,
# Customers_0.familyName AS last_familyName,
# Addresses_0.id AS billAddr_id,
#        Addresses_0.street AS billStreet_street,
# Addresses_0.city AS billCity_city,
# Addresses_0.state AS billState_state
# FROM Orders AS Orders_0
#      INNER JOIN Customers AS Customers_0 ON Orders_0.customer=Customers_0.id
#      INNER JOIN Products AS Products_0 ON Orders_0.product=Products_0.id
#      INNER JOIN Addresses AS Addresses_0 ON Customers_0.billingAddress=Addresses_0.id
# WHERE Orders_0.orderDate="20020907"
# GROUP BY o_id,c_id,p_id,productDesc_description,first_givenName,last_familyName,billAddr_id,billStreet_street,billCity_city,billState_state

