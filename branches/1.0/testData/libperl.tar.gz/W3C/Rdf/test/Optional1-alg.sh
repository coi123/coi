#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# Optional1 - Optionally disjoint arcs
# Tests:
#   - optional arcs
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: Optional1-alg.sh,v 1.5 2005/08/03 19:47:53 eric Exp $
###############################################################################

algae $* \
--lang Algae \
"
ns <http://example.org/n#>
require <http://www.w3.org/2004/06/20-rules/#assert>
assert (
 A p1 B .
 A p2 C .
 A p3 D .

 D p4 E .
 E p5 F .

 D2 p4 E2 .
 E2 p5 F2 )

ask (
 ?n p1 B .
 ?n p2 C .
 ?n2 p4 ?n3 .
 ?n3 p5 ?n4 .
 ~?n ?po ?n2 )

collect (?n ?n2 ?po)
" \


# Table Results:
# +------------------------+-------------------------+-------------------------+
# |                       n|                       n2|                       po|
# |------------------------|-------------------------|-------------------------|
# |<http://example.org/n#A>| <http://example.org/n#D>|<http://example.org/n#p3>|
# |<http://example.org/n#A>|<http://example.org/n#D2>|                     NULL|
# +------------------------+-------------------------+-------------------------+

# ResultSet Results:
# @prefix rdf:    <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
# @prefix rs:     <http://jena.hpl.hp.com/2003/03/result-set#> .
# 
# [] rdf:type rs:ResultSet ;
#     rs:resultVariable "n" ;
#     rs:resultVariable "n2" ;
#     rs:resultVariable "po" ;
#     rs:size "2" ;
#     rs:solution
#         [ rdf:type rs:ResultSolution ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "n" ; rs:value <http://example.org/n#A> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "n2" ; rs:value <http://example.org/n#D> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "po" ; rs:value <http://example.org/n#p3> ] 
#         ] ;
#     rs:solution
#         [ rdf:type rs:ResultSolution ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "n" ; rs:value <http://example.org/n#A> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "n2" ; rs:value <http://example.org/n#D2> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "po" ; rs:nonValue "NULL" ] 
#         ] .

 