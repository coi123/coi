#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# aclQuery1 - 
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: aclQuery1-alg.sh,v 1.6 2004/06/23 12:32:18 eric Exp $
###############################################################################

./algae $* \
"(
 namespace '(sqlDB http://localhost/SqlDB#
             acl http://www.w3.org/2001/02/acls/ns#
             rdf http://www.w3.org/1999/02/22-rdf-syntax-ns#) 
 attach '(\"W3C::Rdf::SqlDB\" (\"properties:../test/aclQuery.prop\" \"name:sqlDB::W3Cacls\"))
 ask '(sqlDB::W3Cacls
       (sqlDB::uris.uri             ?urisRow http://www.w3.org/Member/Overview.html)
       (sqlDB::acls.access          ?acl     ?access)
       (sqlDB::acls.acl             ?acl     ?aacl)
       (sqlDB::acls.id              ?acl     ?accessor)
       (sqlDB::idInclusions.groupId ?g1      ?accessor)
       (sqlDB::idInclusions.id      ?g1      ?u1)
       (sqlDB::ids.value            ?u1      \"eric\")
       (sqlDB::uris.acl             ?urisRow ?aacl)
      )
 collect '(?acl) 
)" \

# To try this test of the W3C ACLs schema, you will need to
# create a ../../../Conf/chacl.prop file with:
#   user: <username here>
#   password: <password here>
#   database: w3c
#   baseUri:  http://localhost/SqlDB#
#   structure: W3C::Rnodes::AclSqlObjects
# create the table description:
#   ../../../W3C/Rnodes/bin/makeAclSqlObjects.sh
# execute the ACLs tests:
#   make test-acls

# SELECT uris_0.id AS urisRow_id,
#        acls_0.acl AS acl_acl, acls_0.id AS acl_id, acls_0.access AS acl_access,
#        idInclusions_0.id AS g1_id, idInclusions_0.groupId AS g1_groupId,
#        ids_0.id AS u1_id
# FROM uris AS uris_0, acls AS acls_0, idInclusions AS idInclusions_0, ids AS ids_0
# WHERE uris_0.uri="http://www.w3.org/Member/Overview.html"
#   AND idInclusions_0.groupId=acls_0.id
#   AND idInclusions_0.id=ids_0.id
#   AND ids_0.value="eric"
#   AND uris_0.acl=acls_0.acl

# +------------------------------------------------------+
# |                                                   acl|
# |------------------------------------------------------|
# |<http://localhost/SqlDB#acls.acl=6&id=100&access=3122>|
# |<http://localhost/SqlDB#acls.acl=6&id=102&access=3955>|
# +------------------------------------------------------+

