#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# FileSystem0 - directory of /tmp
# Tests:
#   - simple file access
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: FileSystem0-alg.sh,v 1.4 2004/10/17 14:33:05 eric Exp $
###############################################################################

algae $* \
"
ns fs=<http://www.w3.org/2004/10/16-RDF-FileSystem/ns#>
attach fs:FSDB ?fs ()
ask ?fs (<file://localhost/tmp/> fs:dirEnt ?dirEnt.
         ?dirEnt fs:resource ?resource.
         ?dirEnt fs:filename ?filename)
collect (?filename ?resource)
"
# XTable Results:
# +----------------+-------------------------------------+
# |        filename|                             resource|
# |----------------|-------------------------------------|
# |  "gsrvdir12817"|  <file://localhost/tmp/gsrvdir12817>|
# |  "esrv12817-na"|  <file://localhost/tmp/esrv12817-na>|
# |    "orbit-eric"|    <file://localhost/tmp/orbit-eric>|
# |   "gconfd-eric"|   <file://localhost/tmp/gconfd-eric>|
# |            ".."|                  <file://localhost/>|
# |     ".ki2-unix"|     <file://localhost/tmp/.ki2-unix>|
# |"ssh-llWoxS2370"|<file://localhost/tmp/ssh-llWoxS2370>|
# |     "algae.log"|     <file://localhost/tmp/algae.log>|
# |     ".ICE-unix"|     <file://localhost/tmp/.ICE-unix>|
# |      ".X0-lock"|      <file://localhost/tmp/.X0-lock>|
# |    "fshd-12817"|    <file://localhost/tmp/fshd-12817>|
# |      "blootbot"|      <file://localhost/tmp/blootbot>|
# |"ssh-uXczpO2130"|<file://localhost/tmp/ssh-uXczpO2130>|
# |     ".X11-unix"|     <file://localhost/tmp/.X11-unix>|
# |   ".iroha_unix"|   <file://localhost/tmp/.iroha_unix>|
# |    ".font-unix"|    <file://localhost/tmp/.font-unix>|
# |             "."|              <file://localhost/tmp/>|
# +----------------+-------------------------------------+

