../../Database/bin/object_maker $* \
-p SqlDBtest.prop SqlDBtest \
-n W3C::Rdf::test::SqlDBtestObjects \
-h SqlDBtestObjects.html \
-m "{A.p1=>B.key0, 
     A.p2=>C.key1, 
     A.p3=>C.key1, 
     B.p5=>C.key1, 
     B.p6=>C.key1
    }" \
A B C \
> SqlDBtestObjects.pm
