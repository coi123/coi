#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# assertTest1 - 
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: assertTest1-alg.sh,v 1.4 2004/06/23 12:32:18 eric Exp $
###############################################################################

algae $* \
"
 ns t=<http://t.t/>
 slurp ../test/algaeTest.rdf ()
 ask (?s1 ?p ?o1 {?p @ \"http://t.*/p1*\"}.
      ?o1 t:p2 ?o2.
      ?o2 ?o3 ?o3.
      ?s1 t:p4 ?o2)
 assert (?o1 t:p5 #?g1. ?g1 t:p6 ?o2)
 collect (?s1 ?o3 ?o2 ?g1) 
" \

# +----------------+----------------+----------------+-----+
# |              s1|              o3|              o2|   g1|
# |----------------|----------------|----------------|-----|
# |<http://t.t/s1a>|<http://t.t/o3a>|<http://t.t/o2a>|_:g33|
# |<http://t.t/s1a>|<http://t.t/o3b>|<http://t.t/o2a>|_:g34|
# |<http://t.t/s1a>|<http://t.t/o3a>|<http://t.t/o2a>|_:g35|
# |<http://t.t/s1a>|<http://t.t/o3b>|<http://t.t/o2a>|_:g36|
# |<http://t.t/s1b>|<http://t.t/o3a>|<http://t.t/o2a>|_:g37|
# |<http://t.t/s1b>|<http://t.t/o3b>|<http://t.t/o2a>|_:g38|
# +----------------+----------------+----------------+-----+

