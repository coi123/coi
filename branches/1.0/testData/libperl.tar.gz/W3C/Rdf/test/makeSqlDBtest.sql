CREATE TABLE A (u0 INT UNSIGNED NOT NULL, 
                u1 INT UNSIGNED NOT NULL, 
                p1 INT UNSIGNED NOT NULL, 
                p2 INT UNSIGNED NOT NULL, 
                p3 INT UNSIGNED NOT NULL, 
                p4 VARCHAR(40), 
                UNIQUE u_u0_u1 (u0, u1));
CREATE TABLE B (key0 INT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT, 
                p5 INT UNSIGNED NOT NULL, 
                p6 INT UNSIGNED NOT NULL);
CREATE TABLE C (key1 INT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT, 
                str1 VARCHAR(40) NOT NULL, 
                str2 VARCHAR(40) NOT NULL, 
                UNIQUE u_str1_str2(str1, str2));

INSERT INTO C (key1, str1, str2) VALUES (301, "Crow30", "1");
INSERT INTO C (key1, str1, str2) VALUES (302, "Crow30", "2");
INSERT INTO C (key1, str1, str2) VALUES (303, "Crow30", "3");

INSERT INTO B (key0, p5, p6) VALUES (201, 301, 302);
INSERT INTO B (key0, p5, p6) VALUES (202, 302, 301);
INSERT INTO B (key0, p5, p6) VALUES (203, 303, 303);

INSERT INTO A (u0, u1, p1, p2, p3, p4) VALUES (0, 101, 201, 301, 302, "B1,C1,C2");
INSERT INTO A (u0, u1, p1, p2, p3, p4) VALUES (0, 102, 202, 302, 301, "B2,C2,C1");
INSERT INTO A (u0, u1, p1, p2, p3, p4) VALUES (103, 0, 203, 303, 303, "B3,C3,C3");

SELECT A_0.u0,A_0.u1,B_0.key0,C_0.key1,A_0.p4,C_1.key1
  FROM A AS A_0,B AS B_0,C AS C_0,C AS C_1
 WHERE A_0.p1=B_0.key0
   AND A_0.p2=C_0.key1
   AND A_0.p3=C_0.key1
   AND B_0.p5=C_0.key1
   AND B_0.p6=C_1.key1;
