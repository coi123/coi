#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# Finger0 - find out who's logged on
# Tests:
#   - FingerDB
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: Finger0-alg.sh,v 1.5 2004/10/17 14:34:41 eric Exp $
###############################################################################

algae $* \
"
ns lh=<finger://localhost/W/>
ns f=<http://dev.w3.org/cvsweb/perl/modules/W3C/Rdf/FingerDB.pm#>
attach <http://www.w3.org/1999/02/26-modules/algae#dynamic> ?fdb (
                    class=\"W3C::Rdf::FingerDB\")
ask ?fdb (
       lh:eric f:Login ?login
      )
select (?login)
"
# XTable Results:
# +------+
# | login|
# |------|
# |"eric"|
# +------+

