#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# Annotation3 - Ambitious Annotea query.
# Tests:
#   - variable predicates
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: Annotation4-alg.sh,v 1.4 2004/06/23 12:32:17 eric Exp $
###############################################################################

algae $* \
"
ns rdf=<http://www.w3.org/1999/02/22-rdf-syntax-ns#>
ns a=<http://www.w3.org/2000/10/annotation-ns#>
attach <http://www.w3.org/1999/02/26-modules/algae#sql> ?db (
                    properties=\"../test/genericTripleStore.prop\")
#slurp <../test/Annotation1052587433.529382.rdf> ?db ()
ns alg=<http://www.w3.org/1999/02/26-modules/algae#>
ask ?db (
       ?annotation rdf:type a:Annotation {%ATTRIB == <../test/Annotation1052587433.529382.rdf>}.
       ?annotation ?p ?o
      )
select (?annotation ?p ?o)
" \

# Table Results:
# +-------------------------------------------------------------+-----------------------------------------------------+---------------------------------------------------------------------+
# |                                                   annotation|                                                    p|                                                                    o|
# |-------------------------------------------------------------|-----------------------------------------------------|---------------------------------------------------------------------|
# |<http://iggy.w3.org/annotations/annotation/1052587433.529382>|    <http://www.w3.org/1999/02/22-rdf-syntax-ns#type>|                 <http://www.w3.org/2000/10/annotation-ns#Annotation>|
# |<http://iggy.w3.org/annotations/annotation/1052587433.529382>|    <http://www.w3.org/1999/02/22-rdf-syntax-ns#type>|                   <http://www.w3.org/2000/10/annotationType#Comment>|
# |<http://iggy.w3.org/annotations/annotation/1052587433.529382>|            <http://purl.org/dc/elements/1.0/creator>|                                                               "eric"|
# |<http://iggy.w3.org/annotations/annotation/1052587433.529382>|            <http://purl.org/dc/elements/1.0/creator>|                                                                _:g_1|
# |<http://iggy.w3.org/annotations/annotation/1052587433.529382>|              <http://purl.org/dc/elements/1.0/title>|                                  "Old Annotation of Eric's Homepage"|
# |<http://iggy.w3.org/annotations/annotation/1052587433.529382>|    <http://www.w3.org/2000/10/annotation-ns#context>|                  "http://www.w3.org/People/Eric/#xpointer(/html[1])"|
# |<http://iggy.w3.org/annotations/annotation/1052587433.529382>|               <http://purl.org/dc/elements/1.0/date>|                                          "2003-05-10T13:23:38-05:00"|
# |<http://iggy.w3.org/annotations/annotation/1052587433.529382>|    <http://www.w3.org/2000/10/annotation-ns#created>|                                          "2003-05-10T13:22:50-05:00"|
# |<http://iggy.w3.org/annotations/annotation/1052587433.529382>|       <http://www.w3.org/2000/10/annotation-ns#body>|              <http://iggy.w3.org/annotations/body/1052587433.529382>|
# |<http://iggy.w3.org/annotations/annotation/1052587433.529382>|  <http://www.w3.org/2000/10/annotation-ns#annotates>|                                     <http://www.w3.org/People/Eric/>|
# |<http://iggy.w3.org/annotations/annotation/1052587433.529382>|<http://www.w3.org/2000/10/annotation-ns#Attribution>|       <http://iggy.w3.org/annotations/attribution/1052587433.529382>|
# |<http://iggy.w3.org/annotations/annotation/1054553215.108988>|    <http://www.w3.org/1999/02/22-rdf-syntax-ns#type>|                 <http://www.w3.org/2000/10/annotation-ns#Annotation>|
# |<http://iggy.w3.org/annotations/annotation/1054553215.108988>|    <http://www.w3.org/1999/02/22-rdf-syntax-ns#type>|                   <http://www.w3.org/2000/10/annotationType#Comment>|
# |<http://iggy.w3.org/annotations/annotation/1054553215.108988>|    <http://www.w3.org/2000/10/annotation-ns#context>|"http://www.w3.org/People/Eric/#xpointer(/html[1]/body[1]/p[2]/a[9])"|
# |<http://iggy.w3.org/annotations/annotation/1054553215.108988>|    <http://www.w3.org/2000/10/annotation-ns#created>|                                          "2003-06-02T07:26:30-05:00"|
# |<http://iggy.w3.org/annotations/annotation/1054553215.108988>|       <http://www.w3.org/2000/10/annotation-ns#body>|              <http://iggy.w3.org/annotations/body/1054553215.108988>|
# |<http://iggy.w3.org/annotations/annotation/1054553215.108988>|  <http://www.w3.org/2000/10/annotation-ns#annotates>|                                     <http://www.w3.org/People/Eric/>|
# |<http://iggy.w3.org/annotations/annotation/1054553215.108988>|<http://www.w3.org/2000/10/annotation-ns#Attribution>|       <http://iggy.w3.org/annotations/attribution/1054553215.108988>|
# |<http://iggy.w3.org/annotations/annotation/1054553215.108988>|              <http://purl.org/dc/elements/1.1/title>|                                  "New Annotation of Eric's Homepage"|
# |<http://iggy.w3.org/annotations/annotation/1054553215.108988>|            <http://purl.org/dc/elements/1.1/creator>|                                                               "eric"|
# |<http://iggy.w3.org/annotations/annotation/1054553215.108988>|            <http://purl.org/dc/elements/1.1/creator>|                                                                _:g_2|
# |<http://iggy.w3.org/annotations/annotation/1054553215.108988>|               <http://purl.org/dc/elements/1.1/date>|                                                "2003-06-06T14:32:54"|
# +-------------------------------------------------------------+-----------------------------------------------------+---------------------------------------------------------------------+

# # SQL Query:
# SELECT STRAIGHT_JOIN
#        __Holds___0.a AS __Holds___0_a,
#        __Holds___0.id AS __Holds___0_id,
#        __Nodes___1.id AS __Nodes___1_annotation_id,
#        __Holds___1.a AS __Holds___1_a,
#        __Holds___1.id AS __Holds___1_id,
#        __Nodes___4.id AS __Nodes___4_p_id,
#        __Nodes___5.id AS __Nodes___5_o_id
#        
# FROM __Holds__ AS __Holds___0
#      INNER JOIN __Nodes__ AS __Nodes___0 ON __Holds___0.p=__Nodes___0.id
#      INNER JOIN __Nodes__ AS __Nodes___1 ON __Holds___0.s=__Nodes___1.id
#      INNER JOIN __Nodes__ AS __Nodes___2 ON __Holds___0.o=__Nodes___2.id
#      INNER JOIN __AttrLists__ AS __AttrLists___0 ON __Holds___0.a=__AttrLists___0.listId
#      INNER JOIN __Attributions__ AS __Attributions___0 ON __AttrLists___0.a=__Attributions___0.id
#      INNER JOIN __Nodes__ AS __Nodes___3 ON __Attributions___0.doc=__Nodes___3.id
#      LEFT OUTER JOIN __Holds__ AS __Holds___1 ON __Holds___1.s=__Nodes___1.id
#      LEFT OUTER JOIN __Nodes__ AS __Nodes___4 ON __Holds___1.p=__Nodes___4.id
#      LEFT OUTER JOIN __Nodes__ AS __Nodes___5 ON __Holds___1.o=__Nodes___5.id
# WHERE __Nodes___0.hash="c74e2b735dd8dc85ad0ee3510c33925f" 
#   AND  __Nodes___2.hash="acef97e962dd06905694368feda0317f" 
#   AND  __Nodes___3.hash="6d5559927da324180e59554c9453f18f"
# GROUP BY __Nodes___1_annotation_id,__Nodes___4_p_id,__Nodes___5_o_id
# 		    157 Query       SELECT listId,a FROM __AttrLists__ WHERE listId IN (3)
# 		    157 Query       SELECT SoughtAttrib.id, SoughtAttrib.type, SoughtAttrib.modified, SoughtAttrib.created, 
# 
#        Doc.id,Doc.type,Doc.str,Doc.big,
#        DocAttrib.type,DocAttrib.auth,DocAttrib.modified,DocAttrib.created,
#        DocDT.id,DocDT.str,
#        DocDoc.str, 
# 
#        Auth.id,Auth.type,Auth.str,Auth.big,
#        AuthAttrib.type,AuthAttrib.auth,AuthAttrib.modified,AuthAttrib.created,
#        AuthDT.id,AuthDT.str,
#        AuthAuth.str
#   FROM __Attributions__ AS SoughtAttrib  
# 
#        INNER JOIN __Nodes__ AS Doc ON SoughtAttrib.doc=Doc.id 
#        LEFT OUTER JOIN __Attributions__ AS DocAttrib ON Doc.attribOrDt=DocAttrib.id
#        LEFT OUTER JOIN __Nodes__ AS DocDT ON Doc.attribOrDt=DocDT.id
#        LEFT OUTER JOIN __Nodes__ AS DocDoc ON DocAttrib.doc=DocDoc.id
# 
#        LEFT OUTER JOIN __Nodes__ AS Auth ON SoughtAttrib.auth=Auth.id 
#        LEFT OUTER JOIN __Attributions__ AS AuthAttrib ON Auth.attribOrDt=AuthAttrib.id
#        LEFT OUTER JOIN __Nodes__ AS AuthDT ON Auth.attribOrDt=AuthDT.id
#        LEFT OUTER JOIN __Nodes__ AS AuthAuth ON AuthAttrib.doc=AuthAuth.id
# 
#  WHERE SoughtAttrib.id IN (1)
# 		    157 Query       SELECT __Nodes__.id,__Nodes__.type,__Nodes__.str,__Nodes__.big,
#        __Attributions__.type,__Attributions__.auth,__Attributions__.modified,__Attributions__.created,
#        DT.id,DT.str,
#        doc.str
#   FROM __Nodes__ 
#        LEFT OUTER JOIN __Attributions__ ON __Nodes__.attribOrDt=__Attributions__.id
#        LEFT OUTER JOIN __Nodes__ AS DT ON __Nodes__.attribOrDt=DT.id
#        LEFT OUTER JOIN __Nodes__ AS doc ON __Attributions__.doc=doc.id
#  WHERE __Nodes__.id IN (2,1,3,23,5,6,60,7,8,9,10,11,12,13,14,15,16,24,25,26,27,35,38,40,44,43,36,37,39,61,41,42)

