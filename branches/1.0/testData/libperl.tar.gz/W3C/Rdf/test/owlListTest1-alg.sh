#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# owlListTest1 - 
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: owlListTest1-alg.sh,v 1.11 2004/06/26 01:39:55 eric Exp $
###############################################################################

algae $* \
--reportClassdot \
--reportParm-createNamespaces=1 \
--reportParm-copyListEls=1 \
"
slurp ../test/list.owl ()
ns flg=<http://example.org/>
ask (
    ?s ?p ?o)
 collect (?p) # http://yup)
" \

# +-------------+
# | <http://yup>|
# |-------------|
# |<http://yup/>|
# +-------------+

