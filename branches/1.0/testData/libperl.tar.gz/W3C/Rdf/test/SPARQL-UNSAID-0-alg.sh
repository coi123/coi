#!/bin/sh

###############################################################################
# Copyright 2004 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# SPARQL-UNSAID-0 - UNSAID.
# Tests:
#   - 1st UNSAID example in SPARQL 1/149
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: SPARQL-UNSAID-0-alg.sh,v 1.1 2004/12/11 00:02:03 eric Exp $
###############################################################################

algae $* \
--lang n3 \
"
@prefix foaf:       <http://xmlns.com/foaf/0.1/> .
@prefix rdf:        <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
@prefix rdfs:       <http://www.w3.org/2000/01/rdf-schema#> .

_:a  foaf:name       \"Alice\" .
_:a  foaf:mbox       <mailto:alice@work.example> .

_:b  foaf:name       \"Bob\" .
" \
--lang SPARQL \
"
PREFIX foaf: <http://xmlns.com/foaf/0.1/>
SELECT ?name
WHERE  ( ?x foaf:name  ?name )
       UNSAID ( ?x  foaf:mbox  ?mbox )
" \

# Table Results:
# +-----+
# | name|
# |-----|
# |"Bob"|
# +-----+

# ResultSet Results:
# @prefix rdf:    <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
# @prefix rs:     <http://jena.hpl.hp.com/2003/03/result-set#> .
# 
# [] rdf:type rs:ResultSet ;
#     rs:resultVariable "name" ;
#     rs:size "1" ;
#     rs:solution
#         [ rdf:type rs:ResultSolution ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "name" ; rs:value "Bob" ] 
#         ] .

