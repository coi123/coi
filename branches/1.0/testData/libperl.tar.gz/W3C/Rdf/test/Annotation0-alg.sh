#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# Annotation0 - Simple input validation query on Annotation file
# Tests:
#   - viability for Annotea data
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: Annotation0-alg.sh,v 1.9 2005/08/03 19:47:52 eric Exp $
###############################################################################

algae $* \
--lang Algae
"
ns db=<http://localhost/OrderTracking#>
ns rdf=<http://www.w3.org/1999/02/22-rdf-syntax-ns#>
ns a=<http://www.w3.org/2000/10/annotation-ns#>
ns http=<http://www.w3.org/1999/xx/http#>
attach <http://www.w3.org/1999/02/26-modules/algae#ephemeral> db:test1 ()
slurp <../test/Annotation1052587433.529382.rdf> db:test1 ()
slurp <../test/Annotation1052587433.529382b.rdf> db:test1 ()
ask db:test1 (
       ?annotation rdf:type a:Annotation {%ATTRIB == <../test/Annotation1052587433.529382.rdf>}.
       ?annotation a:annotates ?annotates.
       ?annotation a:context ?context.
       ?annotation a:body ?body {%ATTRIB == <../test/Annotation1052587433.529382.rdf>}.
       ?body http:Body ?text
      )
# host db:test1 (?annotation ?body)
select (?annotation)
" \

# Table Results:
# +-------------------------------------------------------------+
# |                                                   annotation|
# |-------------------------------------------------------------|
# |<http://iggy.w3.org/annotations/annotation/1054553215.108988>|
# |<http://iggy.w3.org/annotations/annotation/1052587433.529382>|
# +-------------------------------------------------------------+

