./algae $* \
--set -failAttrNStoEltNs=1 \
--reportClassdot \
--reportParm-createNamespaces=1 \
--reportParm-rankdir=TB \
--reportParm-barebones=1
--reportParm-typeShapes=1 \
--reportParm-typeLabels=1 \
--reportParm-typeLegend=1 \
# -o DOTtest1-alg.sh
"(
 namespace '(wsdl http://schemas.xmlsoap.org/wsdl/ \
             http http://schemas.xmlsoap.org/wsdl/http/ \
             rdf http://www.w3.org/1999/02/22-rdf-syntax-ns# \
             scl http://schemas.xmlsoap.org/disco/scl/ \
             db http://www.w3.org/2001/11/13-RDF-Query-Rules/) \
 slurp '((default.disco)) \
 ask '((scl::contractDoc ?cr ?doc)) \
 collect '(?cr) \
)" \
