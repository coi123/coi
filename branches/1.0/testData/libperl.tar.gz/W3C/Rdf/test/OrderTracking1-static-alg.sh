#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# OrderTracking1 - 
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: OrderTracking1-static-alg.sh,v 1.1 2003/02/03 05:27:06 eric Exp $
###############################################################################

algae $* \
-a"(
 namespace '(testDB http://localhost/OrderTracking#
             acl http://www.w3.org/2001/02/acls/ns#
             rdf http://www.w3.org/1999/02/22-rdf-syntax-ns#) 
 slurp '((../test/OrderTracking-static.n3 -inputLang \"n3\")) 
 ask '((testDB::OrdersDOTcustomer	?o	?c)
       (testDB::OrdersDOTproduct	?o	?p)
       (testDB::ProductsDOTname	?p	?productName)
       (testDB::CustomersDOTgivenName	?c	?first)
       (testDB::CustomersDOTfamilyName	?c	?last)
       (testDB::CustomersDOTbillingAddress	?c	?billAddr)
       (testDB::AddressesDOTstreet	?billAddr ?billStreet)
       (testDB::AddressesDOTcity	?billAddr ?billCity)
       (testDB::AddressesDOTstate	?billAddr ?billState)
      )
 collect '(?first ?last ?productName ?billStreet ?billCity ?billState) 
)" \

# +------+----------+------------+----------------+----------+---------+
# | first|      last| productName|      billStreet|  billCity|billState|
# |------|----------|------------|----------------|----------|---------|
# |"Biff"|"Thompson"|      "pool"|"123 Elm Street"|"EdgeCity"|     "XX"|
# |"Chip"|"Thompson"|"skateboard"|"123 Elm Street"|"EdgeCity"|     "XX"|
# |"Chip"|"Thompson"| "nose ring"|"123 Elm Street"|"EdgeCity"|     "XX"|
# |"Chip"|"Thompson"|"other ring"|"123 Elm Street"|"EdgeCity"|     "XX"|
# +------+----------+------------+----------------+----------+---------+

