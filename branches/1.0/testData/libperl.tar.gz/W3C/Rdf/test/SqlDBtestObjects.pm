@W3C::Rdf::test::SqlDBtestObjects::A::ISA = ( 'W3C::Database::ObjectBase' );
%W3C::Rdf::test::SqlDBtestObjects::A::_TableDesc = ( '-table' => 'A',
                                                     '-index' => { 'u_u0_u1' => { '-unique' => '1',
                                                                                  '-sequence' => [ 'u0',
                                                                                                   'u1' ],
                                                                                  '-fields' => { 'u1' => '1',
                                                                                                 'u0' => '0' } } },
                                                     '-class' => 'W3C::Rdf::test::SqlDBtestObjects::A',
                                                     '-fieldOrder' => [ 'u0',
                                                                        'u1',
                                                                        'p1',
                                                                        'p2',
                                                                        'p3',
                                                                        'p4' ],
                                                     '-fields' => { 'p3' => { '-target' => [ 'C',
                                                                                             'key1' ],
                                                                              '-size' => '10',
                                                                              '-type' => 0,
                                                                              '-default' => '0' },
                                                                    'u1' => { '-size' => '10',
                                                                              '-type' => 0,
                                                                              '-default' => '0' },
                                                                    'p4' => { '-size' => '40',
                                                                              '-type' => 4,
                                                                              '-null' => 1 },
                                                                    'p1' => { '-target' => [ 'B',
                                                                                             'key0' ],
                                                                              '-size' => '10',
                                                                              '-type' => 0,
                                                                              '-default' => '0' },
                                                                    'p2' => { '-target' => [ 'C',
                                                                                             'key1' ],
                                                                              '-size' => '10',
                                                                              '-type' => 0,
                                                                              '-default' => '0' },
                                                                    'u0' => { '-size' => '10',
                                                                              '-type' => 0,
                                                                              '-default' => '0' } },
                                                     '-primaryKey' => [ 'u0',
                                                                        'u1' ] );
$W3C::Rdf::test::SqlDBtestObjects::_AllTables{'A'} = \%W3C::Rdf::test::SqlDBtestObjects::A::_TableDesc;
sub W3C::Rdf::test::SqlDBtestObjects::A::getTableDesc {return \%W3C::Rdf::test::SqlDBtestObjects::A::_TableDesc;}
sub W3C::Rdf::test::SqlDBtestObjects::A::getPrimaryKey {return $_[0]->{DB_ID};}
sub W3C::Rdf::test::SqlDBtestObjects::A::_getU0 {return $_[0]->{FIELD_VALUES}{'u0'};}
sub W3C::Rdf::test::SqlDBtestObjects::A::_checkU0 {return ${($_[0]->check(['u0']))[0]}[0];}
sub W3C::Rdf::test::SqlDBtestObjects::A::_setU0 {$_[0]->{FIELD_VALUES}{'u0'} = $_[1];}
sub W3C::Rdf::test::SqlDBtestObjects::A::_updateU0 {$_[0]->update({'u0' => $_[1]});}
sub W3C::Rdf::test::SqlDBtestObjects::A::getPrimaryKey {return $_[0]->{DB_ID};}
sub W3C::Rdf::test::SqlDBtestObjects::A::_getU1 {return $_[0]->{FIELD_VALUES}{'u1'};}
sub W3C::Rdf::test::SqlDBtestObjects::A::_checkU1 {return ${($_[0]->check(['u1']))[0]}[0];}
sub W3C::Rdf::test::SqlDBtestObjects::A::_setU1 {$_[0]->{FIELD_VALUES}{'u1'} = $_[1];}
sub W3C::Rdf::test::SqlDBtestObjects::A::_updateU1 {$_[0]->update({'u1' => $_[1]});}
sub W3C::Rdf::test::SqlDBtestObjects::A::_getP1 {return $_[0]->{FIELD_VALUES}{'p1'};}
sub W3C::Rdf::test::SqlDBtestObjects::A::_checkP1 {return ${($_[0]->check(['p1']))[0]}[0];}
sub W3C::Rdf::test::SqlDBtestObjects::A::_setP1 {$_[0]->{FIELD_VALUES}{'p1'} = $_[1];}
sub W3C::Rdf::test::SqlDBtestObjects::A::_updateP1 {$_[0]->update({'p1' => $_[1]});}
sub W3C::Rdf::test::SqlDBtestObjects::A::_getP2 {return $_[0]->{FIELD_VALUES}{'p2'};}
sub W3C::Rdf::test::SqlDBtestObjects::A::_checkP2 {return ${($_[0]->check(['p2']))[0]}[0];}
sub W3C::Rdf::test::SqlDBtestObjects::A::_setP2 {$_[0]->{FIELD_VALUES}{'p2'} = $_[1];}
sub W3C::Rdf::test::SqlDBtestObjects::A::_updateP2 {$_[0]->update({'p2' => $_[1]});}
sub W3C::Rdf::test::SqlDBtestObjects::A::_getP3 {return $_[0]->{FIELD_VALUES}{'p3'};}
sub W3C::Rdf::test::SqlDBtestObjects::A::_checkP3 {return ${($_[0]->check(['p3']))[0]}[0];}
sub W3C::Rdf::test::SqlDBtestObjects::A::_setP3 {$_[0]->{FIELD_VALUES}{'p3'} = $_[1];}
sub W3C::Rdf::test::SqlDBtestObjects::A::_updateP3 {$_[0]->update({'p3' => $_[1]});}
sub W3C::Rdf::test::SqlDBtestObjects::A::_getP4 {return $_[0]->{FIELD_VALUES}{'p4'};}
sub W3C::Rdf::test::SqlDBtestObjects::A::_checkP4 {return ${($_[0]->check(['p4']))[0]}[0];}
sub W3C::Rdf::test::SqlDBtestObjects::A::_setP4 {$_[0]->{FIELD_VALUES}{'p4'} = $_[1];}
sub W3C::Rdf::test::SqlDBtestObjects::A::_updateP4 {$_[0]->update({'p4' => $_[1]});}

@W3C::Rdf::test::SqlDBtestObjects::B::ISA = ( 'W3C::Database::ObjectBase' );
%W3C::Rdf::test::SqlDBtestObjects::B::_TableDesc = ( '-table' => 'B',
                                                     '-class' => 'W3C::Rdf::test::SqlDBtestObjects::B',
                                                     '-fieldOrder' => [ 'key0',
                                                                        'p5',
                                                                        'p6' ],
                                                     '-fields' => { 'key0' => { '-size' => '10',
                                                                                '-type' => 0 },
                                                                    'p5' => { '-target' => [ 'C',
                                                                                             'key1' ],
                                                                              '-size' => '10',
                                                                              '-type' => 0,
                                                                              '-default' => '0' },
                                                                    'p6' => { '-target' => [ 'C',
                                                                                             'key1' ],
                                                                              '-size' => '10',
                                                                              '-type' => 0,
                                                                              '-default' => '0' } },
                                                     '-primaryKey' => 'key0' );
$W3C::Rdf::test::SqlDBtestObjects::_AllTables{'B'} = \%W3C::Rdf::test::SqlDBtestObjects::B::_TableDesc;
sub W3C::Rdf::test::SqlDBtestObjects::B::getTableDesc {return \%W3C::Rdf::test::SqlDBtestObjects::B::_TableDesc;}
sub W3C::Rdf::test::SqlDBtestObjects::B::getPrimaryKey {return $_[0]->{DB_ID};}
sub W3C::Rdf::test::SqlDBtestObjects::B::_getKey0 {return $_[0]->{FIELD_VALUES}{'key0'};}
sub W3C::Rdf::test::SqlDBtestObjects::B::_checkKey0 {return ${($_[0]->check(['key0']))[0]}[0];}
sub W3C::Rdf::test::SqlDBtestObjects::B::_setKey0 {$_[0]->{FIELD_VALUES}{'key0'} = $_[1];}
sub W3C::Rdf::test::SqlDBtestObjects::B::_updateKey0 {$_[0]->update({'key0' => $_[1]});}
sub W3C::Rdf::test::SqlDBtestObjects::B::_getP5 {return $_[0]->{FIELD_VALUES}{'p5'};}
sub W3C::Rdf::test::SqlDBtestObjects::B::_checkP5 {return ${($_[0]->check(['p5']))[0]}[0];}
sub W3C::Rdf::test::SqlDBtestObjects::B::_setP5 {$_[0]->{FIELD_VALUES}{'p5'} = $_[1];}
sub W3C::Rdf::test::SqlDBtestObjects::B::_updateP5 {$_[0]->update({'p5' => $_[1]});}
sub W3C::Rdf::test::SqlDBtestObjects::B::_getP6 {return $_[0]->{FIELD_VALUES}{'p6'};}
sub W3C::Rdf::test::SqlDBtestObjects::B::_checkP6 {return ${($_[0]->check(['p6']))[0]}[0];}
sub W3C::Rdf::test::SqlDBtestObjects::B::_setP6 {$_[0]->{FIELD_VALUES}{'p6'} = $_[1];}
sub W3C::Rdf::test::SqlDBtestObjects::B::_updateP6 {$_[0]->update({'p6' => $_[1]});}

@W3C::Rdf::test::SqlDBtestObjects::C::ISA = ( 'W3C::Database::ObjectBase' );
%W3C::Rdf::test::SqlDBtestObjects::C::_TableDesc = ( '-table' => 'C',
                                                     '-index' => { 'u_str1_str2' => { '-unique' => '1',
                                                                                      '-sequence' => [ 'str1',
                                                                                                       'str2' ],
                                                                                      '-fields' => { 'str1' => '0',
                                                                                                     'str2' => '1' } } },
                                                     '-class' => 'W3C::Rdf::test::SqlDBtestObjects::C',
                                                     '-fieldOrder' => [ 'key1',
                                                                        'str1',
                                                                        'str2' ],
                                                     '-fields' => { 'str1' => { '-size' => '40',
                                                                                '-type' => 4,
                                                                                '-default' => '' },
                                                                    'key1' => { '-size' => '10',
                                                                                '-type' => 0 },
                                                                    'str2' => { '-size' => '40',
                                                                                '-type' => 4,
                                                                                '-default' => '' } },
                                                     '-primaryKey' => 'key1' );
$W3C::Rdf::test::SqlDBtestObjects::_AllTables{'C'} = \%W3C::Rdf::test::SqlDBtestObjects::C::_TableDesc;
sub W3C::Rdf::test::SqlDBtestObjects::C::getTableDesc {return \%W3C::Rdf::test::SqlDBtestObjects::C::_TableDesc;}
sub W3C::Rdf::test::SqlDBtestObjects::C::getPrimaryKey {return $_[0]->{DB_ID};}
sub W3C::Rdf::test::SqlDBtestObjects::C::_getKey1 {return $_[0]->{FIELD_VALUES}{'key1'};}
sub W3C::Rdf::test::SqlDBtestObjects::C::_checkKey1 {return ${($_[0]->check(['key1']))[0]}[0];}
sub W3C::Rdf::test::SqlDBtestObjects::C::_setKey1 {$_[0]->{FIELD_VALUES}{'key1'} = $_[1];}
sub W3C::Rdf::test::SqlDBtestObjects::C::_updateKey1 {$_[0]->update({'key1' => $_[1]});}
sub W3C::Rdf::test::SqlDBtestObjects::C::_getStr1 {return $_[0]->{FIELD_VALUES}{'str1'};}
sub W3C::Rdf::test::SqlDBtestObjects::C::_checkStr1 {return ${($_[0]->check(['str1']))[0]}[0];}
sub W3C::Rdf::test::SqlDBtestObjects::C::_setStr1 {$_[0]->{FIELD_VALUES}{'str1'} = $_[1];}
sub W3C::Rdf::test::SqlDBtestObjects::C::_updateStr1 {$_[0]->update({'str1' => $_[1]});}
sub W3C::Rdf::test::SqlDBtestObjects::C::_getStr2 {return $_[0]->{FIELD_VALUES}{'str2'};}
sub W3C::Rdf::test::SqlDBtestObjects::C::_checkStr2 {return ${($_[0]->check(['str2']))[0]}[0];}
sub W3C::Rdf::test::SqlDBtestObjects::C::_setStr2 {$_[0]->{FIELD_VALUES}{'str2'} = $_[1];}
sub W3C::Rdf::test::SqlDBtestObjects::C::_updateStr2 {$_[0]->update({'str2' => $_[1]});}

@W3C::Rdf::test::SqlDBtestObjects::_TableOrder = ( 'A',
                                                   'B',
                                                   'C' );
