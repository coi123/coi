#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# Disjunction2 - Single optional arc
# Tests:
#   - union disjunction without merge
#   - proofs
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: Disjunction2-alg.sh,v 1.5 2007/06/24 22:08:15 eric Exp $
###############################################################################

algae $* \
--lang Algae \
--sParm -proofs=1 \
"
ns <http://example.org/n#>
require <http://www.w3.org/2004/06/20-rules/#assert>
assert (
 A0 p1 B .
# A0 p2 C .
# A0 p3 D .

# A1 p1 B .
 A1 p2 C .
# A1 p3 D .

# A2 p1 B .
# A2 p2 C .
 A2 p3 D .

# A3 p1 B .
 A3 p2 C .
 A3 p3 D )

ask (
 ( ?n p2 C |& ?n p3 D ))

collect (?n)
" \

# Extra Arguments:
# --forceHost example.com
# --forcePath /instpath/workingdir

# Table Results:
# +-------------------------+----------------------------------------------------+
# |                        n|                                                    |
# |-------------------------|----------------------------------------------------|
# |<http://example.org/n#A1>|                                                    |
# [<http://example.org/n#A1> <http://example.org/n#p2> <http://example.org/n#C> .]
# [   -->{<file://example.com/instpath/test/Disjunction2-alg.sh>}                ]
# |------------------------------------------------------------------------------|
# |<http://example.org/n#A2>|                                                    |
# [<http://example.org/n#A2> <http://example.org/n#p3> <http://example.org/n#D> .]
# [   -->{<file://example.com/instpath/test/Disjunction2-alg.sh>}                ]
# |------------------------------------------------------------------------------|
# |<http://example.org/n#A3>|                                                    |
# [<http://example.org/n#A3> <http://example.org/n#p2> <http://example.org/n#C> .]
# [   -->{<file://example.com/instpath/test/Disjunction2-alg.sh>}                ]
# |------------------------------------------------------------------------------|
# |<http://example.org/n#A3>|                                                    |
# [<http://example.org/n#A3> <http://example.org/n#p3> <http://example.org/n#D> .]
# [   -->{<file://example.com/instpath/test/Disjunction2-alg.sh>}                ]
# +-------------------------+----------------------------------------------------+

