#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# aclQuery0 - 
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: aclQuery0-alg.sh,v 1.1 2005/02/23 01:09:55 eric Exp $
###############################################################################

./algae $* \
"
ns acl = <http://www.w3.org/2001/02/acls/ns#>
ns rdf = <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
slurp ../test/acl.rdf ()
ask ( ?rule rdf:type        acl:resourceAccessRule .
      ?rule acl:hasAccessTo <http://www.w3.org/Member/Overview.html> .
      ?rule acl:accessor    ?accessor .
      ?rule acl:access      ?access )
 collect (?rule ?accessor ?access) 
" \

# Table Results:
# +-----+-------------------------------------------------------+-------------------------------------------+
# | rule|                                               accessor|                                     access|
# |-----|-------------------------------------------------------|-------------------------------------------|
# |_:g13|<http://www.w3.org/Systems/db/webId?group=w3cteamgroup>|  <http://www.w3.org/2001/02/acls/ns#chacl>|
# |_:g13|<http://www.w3.org/Systems/db/webId?group=w3cteamgroup>|   <http://www.w3.org/2001/02/acls/ns#head>|
# |_:g13|<http://www.w3.org/Systems/db/webId?group=w3cteamgroup>|    <http://www.w3.org/2001/02/acls/ns#get>|
# |_:g13|<http://www.w3.org/Systems/db/webId?group=w3cteamgroup>|    <http://www.w3.org/2001/02/acls/ns#put>|
# |_:g13|<http://www.w3.org/Systems/db/webId?group=w3cteamgroup>|<http://www.w3.org/2001/02/acls/ns#connect>|
# |_:g13|<http://www.w3.org/Systems/db/webId?group=w3cteamgroup>|   <http://www.w3.org/2001/02/acls/ns#racl>|
# |_:g13|<http://www.w3.org/Systems/db/webId?group=w3cteamgroup>| <http://www.w3.org/2001/02/acls/ns#delete>|
# |_:g13|<http://www.w3.org/Systems/db/webId?group=w3cteamgroup>|<http://www.w3.org/2001/02/acls/ns#options>|
# |_:g13|<http://www.w3.org/Systems/db/webId?group=w3cteamgroup>|  <http://www.w3.org/2001/02/acls/ns#trace>|
# | _:g1|           <http://www.w3.org/Systems/db/webId?user=ot>|<http://www.w3.org/2001/02/acls/ns#options>|
# | _:g1|           <http://www.w3.org/Systems/db/webId?user=ot>|    <http://www.w3.org/2001/02/acls/ns#put>|
# | _:g1|           <http://www.w3.org/Systems/db/webId?user=ot>|<http://www.w3.org/2001/02/acls/ns#connect>|
# | _:g1|           <http://www.w3.org/Systems/db/webId?user=ot>|  <http://www.w3.org/2001/02/acls/ns#chacl>|
# | _:g1|           <http://www.w3.org/Systems/db/webId?user=ot>| <http://www.w3.org/2001/02/acls/ns#delete>|
# | _:g1|           <http://www.w3.org/Systems/db/webId?user=ot>|   <http://www.w3.org/2001/02/acls/ns#head>|
# | _:g1|           <http://www.w3.org/Systems/db/webId?user=ot>|    <http://www.w3.org/2001/02/acls/ns#get>|
# | _:g1|           <http://www.w3.org/Systems/db/webId?user=ot>|   <http://www.w3.org/2001/02/acls/ns#racl>|
# | _:g1|           <http://www.w3.org/Systems/db/webId?user=ot>|  <http://www.w3.org/2001/02/acls/ns#trace>|
# +-----+-------------------------------------------------------+-------------------------------------------+

