#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# datatype0 - xsd:datatypes
# Tests:
#   - xsd:datatype int
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: datatype0-alg.sh,v 1.3 2005/08/03 19:47:53 eric Exp $
###############################################################################

algae $* \
--lang Algae \
"
ns ex=<http://example.org/ex>
require <http://www.w3.org/2004/06/20-rules/#assert>
assert (ex:s ex:p \"123\"^^<http://www.w3.org/2001/XMLSchema#int>)
ask (?s ?p \"123\"^^<http://www.w3.org/2001/XMLSchema#int>)
collect (?s)
" \

# Table Results:
# +------------------------+
# |                       s|
# |------------------------|
# |<http://example.org/exs>|
# +------------------------+

