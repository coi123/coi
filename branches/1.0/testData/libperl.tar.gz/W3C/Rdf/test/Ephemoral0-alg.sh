#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# Ephemoral0 - Logic test on ephemoral DB
# Tests:
#   - flags
#   - attach
#   - keywords (%ATTRIB, %DATATYPE)
#   - bNodes
#   - datatypes
#   - sequential asks
#   - value constraints
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: Ephemoral0-alg.sh,v 1.9 2005/08/03 19:47:53 eric Exp $
###############################################################################

algae $* \
--lang Algae \
"
ns t=<http://example.org/t#>
ns <http://example.org/d#>
ns xsd=<http://www.w3.org/2001/XMLSchema#>
ns alg=<http://www.w3.org/1999/02/26-modules/algae#>

require <http://www.w3.org/2004/06/20-rules/#assert>

flags (dumpQueryMode=alg:DOT
       dumpQueryURL=<Ephemoral0-query.dot>
       dumpQueryGraphMode=alg:DOT
       dumpQueryGraphURL=<Ephemoral0-queryGraph.dot>)
flags +(minimumRowSolution=0 %ATTRIB=t:attrib)
attach <http://www.w3.org/1999/02/26-modules/algae#ephemeral> foo ()
#slurp ../test/Ephemoral0-inp.n3 foo (inputLang=\"n3\")
assert foo
       ( t:ps t:ps  o   {%ATTRIB = t:attrib1}.
         a p1 [ p2 b; p3 \"a string\"^^xsd:string].
         t:s  t:po <http://example.org/t#po>.
         t:so t:p  t:so.
         t:s  t:p   o;
              t:l1  3   {?old = (%DATATYPE || <http://example.com/dt>)}{%DATATYPE = xsd:int}.
         old  is   ?old {?old}.
       )
ask foo (?x ?y ?z{%DATATYPE == xsd:int}{?z < 4}
# || 
#         ?x ?y ?z{%DATATYPE == xsd:string}
)
collect (?z)
ask foo
    ( ?ps ?ps ?o {?ps != t:zzz}{%ATTRIB == t:attrib1}.
      ?s  ?p  ?o .
      (?s ?ps ?o || ?s ?p ?o {?s != ?p}).
      ~ ?s t:l1 ?zzz {?zzz < 4}.
      ~ ?s t:l2 ?zzz
    )
select (?ps ?z ?o ?s ?p ?zzz)
" \

# Table Results:
# +-+-------------------------+-+------------------------+-------------------------+-------------------------+----+
# |z|                       ps|z|                       o|                        s|                        p| zzz|
# |-|-------------------------|-|------------------------|-------------------------|-------------------------|----|
# |3|<http://example.org/t#ps>|3|<http://example.org/d#o>| <http://example.org/t#s>| <http://example.org/t#p>|   3|
# |3|<http://example.org/t#ps>|3|<http://example.org/d#o>|<http://example.org/t#ps>|<http://example.org/t#ps>|NULL|
# +-+-------------------------+-+------------------------+-------------------------+-------------------------+----+

# ResultSet Results:
# @prefix rdf:    <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
# @prefix rs:     <http://jena.hpl.hp.com/2003/03/result-set#> .
# 
# [] rdf:type rs:ResultSet ;
#     rs:resultVariable "z" ;
#     rs:resultVariable "ps" ;
#     rs:resultVariable "z" ;
#     rs:resultVariable "o" ;
#     rs:resultVariable "s" ;
#     rs:resultVariable "p" ;
#     rs:resultVariable "zzz" ;
#     rs:size "2" ;
#     rs:solution
#         [ rdf:type rs:ResultSolution ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "z" ; rs:value "3" ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "ps" ; rs:value <http://example.org/t#ps> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "z" ; rs:value "3" ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "o" ; rs:value <http://example.org/d#o> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "s" ; rs:value <http://example.org/t#s> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "p" ; rs:value <http://example.org/t#p> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "zzz" ; rs:value "3" ] 
#         ] ;
#     rs:solution
#         [ rdf:type rs:ResultSolution ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "z" ; rs:value "3" ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "ps" ; rs:value <http://example.org/t#ps> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "z" ; rs:value "3" ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "o" ; rs:value <http://example.org/d#o> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "s" ; rs:value <http://example.org/t#ps> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "p" ; rs:value <http://example.org/t#ps> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "zzz" ; rs:nonValue "NULL" ] 
#         ] .

