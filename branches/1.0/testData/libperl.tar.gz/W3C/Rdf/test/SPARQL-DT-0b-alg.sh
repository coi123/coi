#!/bin/sh

###############################################################################
# Copyright 2004 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# SPARQL-DT-0b - SPARQL Datatype tester.
# Tests:
#   - different datatypes restricted from decimal have a different value.
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: SPARQL-DT-0b-alg.sh,v 1.1 2005/04/08 09:41:50 eric Exp $
###############################################################################

algae $* \
--lang n3 \
"
<foo> <shoeSize> \"42\"^^<http://www.w3.org/2001/XMLSchema#int> ;
      <age>      \"42\"^^<http://www.w3.org/2001/XMLSchema#float> .
" \
--lang SPARQL \
"
SELECT ?s ?size
 WHERE { ?s <shoeSize> ?size ; <age> ?age .
FILTER ?size != ?age }
" \

# Table Results:
# +-+----+
# |s|size|
# |-|----|
# +-+----+

