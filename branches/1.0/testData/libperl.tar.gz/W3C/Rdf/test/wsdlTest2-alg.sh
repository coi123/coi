#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# wsdlTest2 - 
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: wsdlTest2-alg.sh,v 1.10 2004/06/26 01:39:55 eric Exp $
###############################################################################

algae $* \
#--reportClassn3 -reportParm-createNamespaces=1
"
slurp ../test/Calc.wsdl ()
ns wsdl=<http://schemas.xmlsoap.org/wsdl/>
ns http=<http://schemas.xmlsoap.org/wsdl/http/>
ns rdf=<http://www.w3.org/1999/02/22-rdf-syntax-ns#>
ns soap=<http://schemas.xmlsoap.org/wsdl/soap/>

ask (
?desc wsdl:port ?port.
  ?port wsdl:binding ?binding.
    ?binding wsdl:portType ?portType.
       ?portType wsdl:abstractOperation ?abOp.
    ?binding wsdl:boundOperation ?boundOp.
       ?boundOp wsdl:abstraction ?abOp.
          ?binding http:binding ?httpBinding.
            ?httpBinding http:method ?method.
               ?abOp rdf:type wsdl:AbstractOperation. 
               ?abOp wsdl:abstractInput ?abInput. 
                  ?abInput wsdl:part ?inputPart. 
#                     ?inputPart wsdl:partName ?partName. 
                     ?inputPart wsdl:schemaRef ?xsdDef_Req. 
~                        ?xsdDef_Req wsdl:schemaDef ?inputSchemaDef. 
               ?abOp wsdl:abstractOutput ?abOutput. 
                  ?abOutput wsdl:part ?outputPart. 
                     ?outputPart wsdl:schemaRef ?xsdDef_Response. 
                        ?xsdDef_Response wsdl:schemaDef ?outputSchemaDef. 
#                     ?outputPart wsdl:partName ?partName. 
#               ?abOp wsdl:abstractFault ?abFault. 
#                  ?abFault wsdl:part ?faultPart. 
#                     ?faultPart wsdl:schemaRef ?xsdDef_Fault. 
#                        ?xsdDef_Fault wsdl:schemaDef ?faultSchemaDef. 
#                     ?faultPart wsdl:partName ?partName. 
#            ?boundOp wsdl:boundFault ?boundFault. 
            ?boundOp wsdl:boundInput ?boundInput. 
#            ?boundOp soap:address ?address. 
            ?boundOp wsdl:boundOutput ?boundOutput. 
         ?binding wsdl:portType ?portType. 
            ?portType wsdl:abstractOperation ?abOp 
#         ?binding soap:binding ?transportBinding. 
#            ?transportBinding soap:stype ?style. 
#            ?transportBinding soap:transport ?transport
)
collect (?inputPart ?xsdDef_Req ?inputSchemaDef ?method)
" \
