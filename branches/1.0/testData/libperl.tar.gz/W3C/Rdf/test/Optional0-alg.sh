#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# Optional0 - Single optional arc
# Tests:
#   - optional arcs
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: Optional0-alg.sh,v 1.6 2005/08/03 19:47:53 eric Exp $
###############################################################################

algae $* \
--lang Algae \
"
ns <http://example.org/n#>
require <http://www.w3.org/2004/06/20-rules/#assert>
assert (
 A p1 B .
 A p2 C .
 A p3 D .

 B p1 B .
 B p2 C )

ask (
 ?n p1 B .
 ?n p2 C .
 ~?n p3 ?n2 )

collect (?n ?n2)
" \


# Table Results:
# +------------------------+------------------------+
# |                       n|                      n2|
# |------------------------|------------------------|
# |<http://example.org/n#B>|                    NULL|
# |<http://example.org/n#A>|<http://example.org/n#D>|
# +------------------------+------------------------+

# ResultSet Results:
# @prefix rdf:    <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
# @prefix rs:     <http://jena.hpl.hp.com/2003/03/result-set#> .
# 
# [] rdf:type rs:ResultSet ;
#     rs:resultVariable "n" ;
#     rs:resultVariable "n2" ;
#     rs:size "2" ;
#     rs:solution
#         [ rdf:type rs:ResultSolution ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "n" ; rs:value <http://example.org/n#A> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "n2" ; rs:value <http://example.org/n#D> ] 
#         ] ;
#     rs:solution
#         [ rdf:type rs:ResultSolution ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "n" ; rs:value <http://example.org/n#B> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "n2" ; rs:nonValue "NULL" ] 
#         ] .

 