#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# patternText0 - 
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: patternTest0-alg.sh,v 1.3 2004/06/23 12:32:18 eric Exp $
###############################################################################

../bin/algae $* \
"
slurp ../test/algaeTest.rdf ()
ask (<http://t.t/p1> ?s1 ?o1.
     <http://t.t/p2> ?o1 ?o2.
     ?o3 ?o2 ?o3.
     <http://t.t/p4> ?s1 ?o2)
assert (<http://a.a/p1> ?o1 *?g1.
        <http://a.a/p2> ?g1 ?o2)
collect (?s1 ?o3 ?g1 ?o2)
" \

# +----------------+----------------+------+----------------+
# |              s1|              o3|    g1|              o2|
# |----------------|----------------|------|----------------|
# |<http://t.t/s1a>|<http://t.t/o3b>|_:g_33|<http://t.t/o2a>|
# |<http://t.t/s1a>|<http://t.t/o3a>|_:g_34|<http://t.t/o2a>|
# |<http://t.t/s1a>|<http://t.t/o3b>|_:g_35|<http://t.t/o2a>|
# |<http://t.t/s1a>|<http://t.t/o3a>|_:g_36|<http://t.t/o2a>|
# |<http://t.t/s1b>|<http://t.t/o3b>|_:g_37|<http://t.t/o2a>|
# |<http://t.t/s1b>|<http://t.t/o3a>|_:g_38|<http://t.t/o2a>|
# +----------------+----------------+------+----------------+

