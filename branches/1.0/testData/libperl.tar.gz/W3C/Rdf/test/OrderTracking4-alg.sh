#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# OrderTracking4 - Shipping department view, ship address for orders for a day
# Tests:
#   - multiple join on Customers and Addresses
#   - optional properties ?sFirst ?sLast ?shipStreet ?shipCity ?shipState
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: OrderTracking4-alg.sh,v 1.11 2005/08/03 19:47:53 eric Exp $
###############################################################################

algae $* \
--lang Algae \
"
ns ot=<http://localhost/OrderTracking#>
attach <http://www.w3.org/2003/01/21-RDF-RDB-access/ns#SqlDB> ?db (
                    properties=\"../test/OrderTracking.prop\")
ns alg=<http://www.w3.org/1999/02/26-modules/algae#>
flags (dumpQueryMode=alg:DOT
       dumpQueryURL=<OrderTracking4-query.dot>
       dumpQueryGraphMode=alg:DOT
       dumpQueryGraphURL=<OrderTracking4-queryGraph.dot>
       dumpCompiledMode=alg:DOT
       dumpCompiledURL=<OrderTracking4-compiled.dot>
       dumpCompiledGraphMode=alg:DOT
       dumpCompiledGraphURL=<OrderTracking4-compiledGraph.dot>)
ask ?db (
       ?o	ot:Orders_id			?orderId .
       ?o	ot:Orders_customer		?c .
       ?o	ot:Orders_orderDate		?d {?d >= 20020908000000 && ?d < 20020909000000} .
       ?c	ot:Customers_givenName		?first .
       ?c	ot:Customers_familyName		?last .
       ?c	ot:Customers_billingAddress	?billAddr .
       ?billAddr ot:Addresses_street		?billStreet .
       ?billAddr ot:Addresses_city		?billCity .
       ?billAddr ot:Addresses_state		?billState .
       ~?o	ot:Orders_shippingAddress	?shipAddr .
       ~?shipAddr ot:Addresses_street		?shipStreet .
       ~?shipAddr ot:Addresses_city		?shipCity .
       ~?shipAddr ot:Addresses_state		?shipState .
       ~?shipAddr ot:Addresses_contact		?signer .
       ~?signer	ot:Customers_givenName		?sFirst .
       ~?signer	ot:Customers_familyName		?sLast 
      )
collect (?orderId ?first ?last ?billStreet ?billCity ?billState ?sFirst ?sLast ?shipStreet ?shipCity ?shipState) 
" \

# Table Results:
# +-------+------+----------+----------------+----------+---------+--------+--------+-----------------+----------+---------+
# |orderId| first|      last|      billStreet|  billCity|billState|  sFirst|   sLast|       shipStreet|  shipCity|shipState|
# |-------|------|----------|----------------|----------|---------|--------|--------|-----------------|----------|---------|
# | "2186"|"Chip"|"Thompson"|"123 Elm Street"|"EdgeCity"|     "AV"|    NULL|    NULL|             NULL|      NULL|     NULL|
# | "3183"|"Chip"|"Thompson"|"123 Elm Street"|"EdgeCity"|     "AV"|"Eustis"|"Walker"|"245 King Street"|"EdgeCity"|     "AV"|
# +-------+------+----------+----------------+----------+---------+--------+--------+-----------------+----------+---------+

# SQL Query:
# SELECT Orders_0.id AS o_id,
#        Customers_0.id AS c_id,
#        Customers_0.givenName AS first_givenName,
# Customers_0.familyName AS last_familyName,
# Addresses_0.id AS billAddr_id,
#        Addresses_0.street AS billStreet_street,
# Addresses_0.city AS billCity_city,
# Addresses_0.state AS billState_state,
# Addresses_1.id AS shipAddr_id,
#        Addresses_1.street AS shipStreet_street,
# Addresses_1.city AS shipCity_city,
# Addresses_1.state AS shipState_state,
# Customers_1.id AS signer_id,
#        Customers_1.givenName AS sFirst_givenName,
# Customers_1.familyName AS sLast_familyName
# FROM Orders AS Orders_0
#      INNER JOIN Customers AS Customers_0 ON Orders_0.customer=Customers_0.id
#      INNER JOIN Addresses AS Addresses_0 ON Customers_0.billingAddress=Addresses_0.id
#      LEFT OUTER JOIN Addresses AS Addresses_1 ON (Orders_0.shippingAddress=Addresses_1.id)
#      LEFT OUTER JOIN Customers AS Customers_1 ON (Addresses_1.contact=Customers_1.id)
# WHERE Orders_0.orderDate="20020907"

