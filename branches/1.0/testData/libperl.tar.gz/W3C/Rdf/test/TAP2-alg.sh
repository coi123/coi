#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# TAP2 - 
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: TAP2-alg.sh,v 1.3 2004/06/23 12:32:18 eric Exp $
###############################################################################

algae $* \
"
ns db=<http://example.com/>
ns foaf=<http://xmlns.com/foaf/0.1/>
ns dc=<http://purl.org/dc/elements/1.1/>
ns pim=<http://www.w3.org/2000/10/swap/pim/contact#>

ns rdf=<http://www.w3.org/1999/02/22-rdf-syntax-ns#>
ns rdfs=<http://www.w3.org/1999/02/22-rdf-syntax-ns#>
ns person=<http://tap.stanford.edu/data/W3CPerson>
attach <http://www.w3.org/1999/02/26-modules/algae#dynamic> ?tapdb (
	class=\"W3C::Rdf::TAPDB\" server=<http://localhost:8888/data/>)
ask ?tapdb (
       <mailto:emiller@w3.org> pim:homePageAddress ?page .
       <mailto:emiller@w3.org> rdfs:label ?label .
       <mailto:emiller@w3.org> rdf:type ?type .
       <mailto:emiller@w3.org> foaf:image ?img
#       ?p rdfs:label \"Eric Miller\".
#?p <http://www.w3.org/2000/10/swap/pim/contact#homePageAddress> <http://www.w3.org/People/EM/>
#      ~?p rdf:type foaf:Person .
#      ~?p foaf:title ?title .
#      ~?p foaf:image ?img .
#      ~?doc dc:creator ?p
	   )
collect (?type ?label ?img ?page)
" \

