#!/bin/sh
./testRdfParser.pl short.rdf >short.aaa && diff short.tst short.aaa
./testRdfParser.pl nest.rdf >nest.aaa && diff nest.tst nest.aaa
./testRdfParser.pl acl.rdf >acl.aaa && diff acl.tst acl.aaa
