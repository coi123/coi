#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# fwruleTest0 - 
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: fwruleTest0-alg.sh,v 1.6 2005/08/03 19:47:53 eric Exp $
###############################################################################

algae $* \
--lang Algae \
"
ns tax=<http://example.com/taxonomy/>
ns r=<http://example.com/resource/>
ns bm=<http://www.w3.org/2002/01/bookmark#>
ns owl=<http://www.w3.org/2002/07/owl#>
ns rdf=<http://www.w3.org/1999/02/22-rdf-syntax-ns#>

require <http://www.w3.org/2004/06/20-rules/#assert>

# owl TransitiveProperty
fwrule ask (?p rdf:type owl:TransitiveProperty . ?x ?p ?y . ?y ?p ?z)
       assert (?x ?p ?z)

assert (
    bm:subCategoryOf rdf:type owl:TransitiveProperty .
    tax:blue-whales bm:subCategoryOf tax:opaque-whales .
    tax:bright-blue-whales bm:subCategoryOf tax:blue-whales .
)
ask (
    ?s ?p ?o
)
collect (?p ?s ?o)
" \

# Table Results:
# +--------------------------------------------------+--------------------------------------------------+--------------------------------------------------+
# |                                                 p|                                                 s|                                                 o|
# |--------------------------------------------------|--------------------------------------------------|--------------------------------------------------|
# |<http://www.w3.org/2002/01/bookmark#subCategoryOf>|  <http://example.com/taxonomy/bright-blue-whales>|       <http://example.com/taxonomy/opaque-whales>|
# |<http://www.w3.org/2002/01/bookmark#subCategoryOf>|  <http://example.com/taxonomy/bright-blue-whales>|         <http://example.com/taxonomy/blue-whales>|
# |<http://www.w3.org/2002/01/bookmark#subCategoryOf>|         <http://example.com/taxonomy/blue-whales>|       <http://example.com/taxonomy/opaque-whales>|
# | <http://www.w3.org/1999/02/22-rdf-syntax-ns#type>|<http://www.w3.org/2002/01/bookmark#subCategoryOf>|<http://www.w3.org/2002/07/owl#TransitiveProperty>|
# +--------------------------------------------------+--------------------------------------------------+--------------------------------------------------+

