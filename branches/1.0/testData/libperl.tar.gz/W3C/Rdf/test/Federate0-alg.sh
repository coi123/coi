#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# Federate0 - Product Review
# Tests:
#   - query federation
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: Federate0-alg.sh,v 1.6 2005/08/03 19:47:53 eric Exp $
###############################################################################

algae $* \
--lang Algae \
"
# First query the SQL products database.
ns ot=<http://localhost/OrderTracking#>
attach <http://www.w3.org/2003/01/21-RDF-RDB-access/ns#SqlDB> ot:db (
                    properties=\"../test/OrderTracking.prop\")
ask ot:db (
       ?p	ot:Products_partNo		?partNo .
       ?p	ot:Products_price		?price {?price >= 15.00 && 
							?price <= 50.00} .
       ?p	ot:Products_description		?description )

# Next query the prices from another source.
slurp <../test/Federate0-jwlry.rdf> (inputLang=\"rdf\") 
ask ( ~?j	ot:Products_partNo		?partNo .
      ~?j	ot:Products_price		?jprice )

# And get the ratings from a third source.
slurp <../test/Federate0-reviews.rdf> (inputLang=\"rdf\") 
ns rvw=<http://localhost/Reviews#>
ask ( ~?p	rvw:rating			?rating .
      ~?p	rvw:distribution		?dist )

# Return the prices for comparison.
collect (?description ?price ?jprice ?rating ?dist) 
" \

# Table Results:
# +------------+-------+-------+------+-----+
# | description|  price| jprice|rating| dist|
# |------------|-------|-------|------|-----|
# |     "grill"|"39.95"|   NULL|  NULL| NULL|
# |"skateboard"|   "46"|   NULL|   "6"|"0.8"|
# |   "earring"|"19.99"|"37.99"|   "5"|"3.3"|
# | "nose ring"|"39.99"|"23.99"|   "8"|"0.3"|
# +------------+-------+-------+------+-----+

# SQL Query:
# SELECT STRAIGHT_JOIN
#        Products_0.id AS p_id,
#        Products_0.partNo AS partNo_partNo,
# Products_0.price AS price_price,
# Products_0.description AS description_description
# 
# FROM Products AS Products_0
# WHERE Products_0.price>="15.00" 
#   AND  Products_0.price<="50.00"
# GROUP BY p_id,partNo_partNo,price_price,description_description

