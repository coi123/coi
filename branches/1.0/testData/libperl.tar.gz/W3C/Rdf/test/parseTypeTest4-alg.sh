#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# parseTypeTest1 - 
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: parseTypeTest4-alg.sh,v 1.3 2004/06/26 01:39:55 eric Exp $
###############################################################################

algae $* \
--reportClassRDFXML \
"(
 slurp '((../test/parseType4.rdf)) 
 ask '((?p ?s ?o)) 
 collect '(?p))" \

