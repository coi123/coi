#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# OrderTracking3 - special orders with shipping addresses
# Tests:
#   - multiple join on Addresses
#   - load dynamic database class
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: OrderTracking3-alg.sh,v 1.11 2007/06/24 22:09:22 eric Exp $
###############################################################################

algae $* \
--lang Algae \
"
ns ot=<http://localhost/OrderTracking#>
attach <http://www.w3.org/1999/02/26-modules/algae#dynamic> ot:db (
                    class=\"W3C::Rdf::SqlDB\"
                    properties=\"../test/OrderTracking.prop\")
ask ot:db (
       ?o	ot:Orders_customer	?c .
       ?o	ot:Orders_product	?p .
       ?o	ot:Orders_orderDate	\"2002-09-07 18:00:00\" .
       ?p	ot:Products_description	?prodDesc .
       ?c	ot:Customers_givenName	?first .
       ?c	ot:Customers_familyName	?last .
       ?c	ot:Customers_billingAddress	?billAddr .
       ?billAddr ot:Addresses_street	?billStreet .
       ?billAddr ot:Addresses_city	?billCity .
       ?billAddr ot:Addresses_state	?billState .
       ?shipAddr ot:Addresses_street	?shipStreet .
       ?shipAddr ot:Addresses_city	?shipCity .
       ?shipAddr ot:Addresses_state	?shipState .
       ?o	ot:Orders_shippingAddress	?shipAddr
      )
collect (?first ?last ?prodDesc ?billStreet ?billCity ?billState ?shipStreet ?shipCity ?shipState) 
" \

# Table Results:
# +------+----------+------------+----------------+----------+---------+-----------------+----------+---------+
# | first|      last|    prodDesc|      billStreet|  billCity|billState|       shipStreet|  shipCity|shipState|
# |------|----------|------------|----------------|----------|---------|-----------------|----------|---------|
# |"Chip"|"Thompson"|"other ring"|"123 Elm Street"|"EdgeCity"|     "AV"|"245 King Street"|"EdgeCity"|     "AV"|
# +------+----------+------------+----------------+----------+---------+-----------------+----------+---------+

# SELECT Orders_0.id AS o_id,
#        Customers_0.id AS c_id,
#        Products_0.id AS p_id,
#        Orders_0.orderDate AS d_orderDate,
#        Products_0.description AS prodDesc_description,
#        Customers_0.givenName AS first_givenName,
#        Customers_0.familyName AS last_familyName,
#        Addresses_0.id AS billAddr_id,
#        Addresses_0.street AS billStreet_street,
#        Addresses_0.city AS billCity_city,
#        Addresses_0.state AS billState_state,
#        Addresses_1.id AS shipAddr_id,
#        Addresses_1.street AS shipStreet_street,
#        Addresses_1.city AS shipCity_city,
#        Addresses_1.state AS shipState_state
# FROM Orders AS Orders_0
#      INNER JOIN Customers AS Customers_0 ON Orders_0.customer=Customers_0.id
#      INNER JOIN Products AS Products_0 ON Orders_0.product=Products_0.id
#      INNER JOIN Addresses AS Addresses_0 ON Customers_0.billingAddress=Addresses_0.id
#      INNER JOIN Addresses AS Addresses_1 ON Orders_0.shippingAddress=Addresses_1.id
# WHERE Orders_0.orderDate="20020907"
# GROUP BY prodDesc_description,first_givenName,last_familyName,billStreet_street,billCity_city,billState_state,shipStreet_street,shipCity_city,shipState_state

