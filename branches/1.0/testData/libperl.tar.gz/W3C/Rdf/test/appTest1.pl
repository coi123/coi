#!/usr/bin/perl

$REVISION = '$Id: appTest1.pl,v 1.7 2004/06/08 06:51:01 eric Exp $ ';

use strict;

#BEGIN {unshift@INC,('../../..');}

use W3C::Rdf::RdfApp;
use W3C::Rdf::Atoms qw(&registerDB &getTie);

# Prepare and use parser.
my $atomDict = new W3C::Rdf::Atoms();
my $tester = new W3C::Rdf::RdfApp({-atomDictionary => $atomDict});
$tester->prepareParser();
$tester->parseOne(new W3C::XML::FileInputSource('../test/algaeTest.rdf'));

print "Initial statements:\n";
foreach my $statement ($tester->{RDF_DB}->getTriples) {
    print $statement->toString,"\n";
}

# Get atoms from dictionary.
&registerDB($tester->{RDF_DB});
my $toArc = $atomDict->getUri('http://t.t/p2', undef);

# Query via object interface.
my $startNode = $atomDict->getUri('http://t.t/o1a', undef);
my @a = $startNode->arcsFrom(undef, $toArc);
print "Objects of http://t.t/o1a --http://t.t/p2->:\n";
print join (' . ', map {$_->getObject->toString(-brief => 1)} @a),"\n";

# Query via tie interface.
my $node = &getTie('<http://t.t/o1a>');
my $a = $node->{'<http://t.t/p2>'};
print join (' | ', map {$_->{-toString}} @$a),"\n";

my ($p, $os);
foreach (($p, $os) = each %$node) {
    if (!ref $os) {
	$os = [$os];
    }
    foreach my $o (@$os) {
	print $node->{-toString},' --', $p->{-toString}, '-> ' , $o->{-toString}, "\n";
    }
}

# Test various accessors.
print join (' | ', map {join ('_', @{$node->{$_}})} keys %$node),"\n";

# Follow an arc to an object.
print &getTie('<http://t.t/o2c>')->{'-<http://t.t/p2>'}->{-toString}, "\n";

# Delete a property.
print 'before delete: ', exists $node->{$toArc}, "\n";
delete $node->{$toArc};
print 'after delete: ', exists $node->{$toArc}, "\n";

