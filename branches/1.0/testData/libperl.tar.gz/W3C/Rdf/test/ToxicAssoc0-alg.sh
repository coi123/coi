#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# ToxicAssoc0 - Pharma test for indications and contra-indications.
# Tests:
#   - federation across multiple databases
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: ToxicAssoc0-alg.sh,v 1.4 2005/08/03 19:47:53 eric Exp $
###############################################################################

algae $* \
--lang Algae \
#--set-failAttrNStoEltNs=1 \
#--reportClass dot \
#--reportParm createNamespaces=1 \
#--reportParm rankdir=TB \
#--reportParm barebones=1 \
#--reportParm typeShapes=1 \
#--reportParm typeLabels=1 \
#--reportParm typeLegend=1 \
"
@../test/ToxicAssoc0.alg
" \

# Table Results:
# +------+--------------+-----------+----------+-----+-------+-----+
# |  name|      chemical|      motif|    saProt| kd50|   like|   ld|
# |------|--------------|-----------|----------|-----|-------|-----|
# |"rq23"|"lhrh-agonist"|"@@motif@@"|"?saProt2"|"0.8"|"like2"|"0.3"|
# |"rq23"|"lhrh-agonist"|"@@motif@@"|"?saProt3"|"0.1"|"like2"|"0.3"|
# +------+--------------+-----------+----------+-----+-------+-----+

