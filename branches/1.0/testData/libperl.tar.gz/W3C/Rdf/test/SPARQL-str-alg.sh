#!/bin/sh

###############################################################################
# Copyright 2004 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
#  - 
# Tests:
#   - 
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: SPARQL-str-alg.sh,v 1.1 2005/05/03 22:16:25 eric Exp $
###############################################################################

algae $* \
--lang n3 \
"
@prefix foaf:       <http://xmlns.com/foaf/0.1/> .
  <file://localhost/query1/#ellen> foaf:name
    <http://localhost/arbitraryPath#a>, \"h_Ellen\".
"
--lang SPARQL \
"
PREFIX foaf:       <http://xmlns.com/foaf/0.1/>
SELECT ?x ?n
 WHERE { ?x foaf:name ?n .
         FILTER regex(str(?n), \"^h\")
       }
" \

