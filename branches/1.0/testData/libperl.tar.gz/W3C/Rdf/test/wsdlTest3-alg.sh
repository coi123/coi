#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# wsdlTest2 - 
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: wsdlTest3-alg.sh,v 1.2 2004/06/23 12:32:18 eric Exp $
###############################################################################

algae $* \
"(
namespace '(myagnt http://airline.wsdl/ticketagent/
            wsdl http://schemas.xmlsoap.org/wsdl/ 
            soap http://schemas.xmlsoap.org/wsdl/soap/ 
            rdf http://www.w3.org/1999/02/22-rdf-syntax-ns# ) 
flags '(minimumRowSolution 1) 
slurp '((../test/wsdl12ticketAgent.wsdl)) 
ask '( 
(?p ?s ?o)) collect '(?p ?s ?o)
ask '(
(wsdl::service ?def ?service) 
   (wsdl::port ?service ?port) 
      (soap::address ?port ?address) 
      (wsdl::binding ?port ?binding) 
         (wsdl::boundOperation ?binding ?boundOp) 
            (wsdl::abstraction ?boundOp ?abOp) 
               (rdf::type ?abOp wsdl::AbstractOperation) 
               (wsdl::abstractInput ?abOp ?abInput) 
                  (wsdl::part ?abInput ?inputPart) 
                     (wsdl::partName ?inputPart ?partName) 
                     (wsdl::schemaRef ?inputPart ?xsdDef_Req) 
                        (wsdl::schemaDef ?xsdDef_Req ?inputSchemaDef) 
               (wsdl::abstractOutput ?abOp ?abOutput) 
                  (wsdl::part ?abOutput ?outputPart) 
                     (wsdl::schemaRef ?outputPart ?xsdDef_Response) 
                        (wsdl::schemaDef ?xsdDef_Response ?outputSchemaDef) 
                     (wsdl::partName ?outputPart ?partName) 
               (wsdl::abstractFault ?abOp ?abFault) 
                  (wsdl::part ?abFault ?faultPart) 
                     (wsdl::schemaRef ?faultPart ?xsdDef_Fault) 
                        (wsdl::schemaDef ?xsdDef_Fault ?faultSchemaDef) 
                     (wsdl::partName ?faultPart ?partName) 
            (wsdl::boundFault ?boundOp ?boundFault) 
            (wsdl::boundInput ?boundOp ?boundInput) 
            (soap::address ?boundOp ?address) 
            (wsdl::boundOutput ?boundOp ?boundOutput) 
         (wsdl::portType ?binding ?portType) 
            (wsdl::abstractOperation ?portType ?abOp) 
         (soap::binding ?binding ?transportBinding) 
            (soap::stype ?transportBinding ?style) 
            (soap::transport ?transportBinding ?transport) 
) collect '(?abOp))" \

#             (rdf::type ?boundOp wsdl::BoundOperation) 

# +------------------------------------------------------------------------------------------------------+
# |                                                                                                  abOp|
# |------------------------------------------------------------------------------------------------------|
# |<http://namespaces.snowboard-info.com/servicesabstract_GetEndorsingBoarderPortTypeGetEndorsingBoarder>|
# +------------------------------------------------------------------------------------------------------+

