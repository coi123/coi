#!/bin/sh

###############################################################################
# Copyright 2004 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# SPARQL0 - SPARQL tester.
# Tests:
#   - SPARQL parser and it's use of Algae2 query structures
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: SPARQL0-alg.sh,v 1.20 2005/08/02 16:40:26 eric Exp $
###############################################################################

algae $* \
--lang n3 \
"
@prefix dc1: <http://purl.org/dc/elements/1.1/> .
@prefix dc0: <http://purl.org/dc/elements/1.0/> .
@prefix a: <http://www.w3.org/2000/10/annotation-ns#> .
@prefix r: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
@prefix xs: <http://www.w3.org/2001/XMLSchema#> .
@prefix tst: <http://dev.w3.org/cvsweb/perl/modules/W3C/Rdf/test/SPARQL0-alg.sh> .
<http://iggy.w3.org/annotations/annotation/1052587433.529382> r:type a:Annotation ;
                    dc0:creator \"eric\" ;
                    dc0:creator [
   a:Given \"É®íç\" 
] ;
                    dc0:date \"2003-05-10T13:23:38-05:00\"^^xs:dateTime ;
                    tst:shoeSize \"42\"^^xs:int.
"
--lang SPARQL \
"
  BASE <http://iggy.w3.org/annotations/annotation/redHerring>
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
PREFIX a: <http://www.w3.org/2000/10/annotation-ns#>
PREFIX dc0: <http://purl.org/dc/elements/1.0/>
PREFIX dc1: <http://purl.org/dc/elements/1.1/>
PREFIX xs: <http://www.w3.org/2001/XMLSchema#>
PREFIX tst: <http://dev.w3.org/cvsweb/perl/modules/W3C/Rdf/test/SPARQL0-alg.sh> 
SELECT DISTINCT ?s ?o0 ?o1
 WHERE { ?s rdf:type a:Annotation; dc0:date ?d .
       OPTIONAL { ?s dc0:creator ?o0; tst:shoeSize ?size . 
		OPTIONAL { ?o0 a:Given ?given} } .
       OPTIONAL { ?s dc1:noMatch ?o1 } .
FILTER (true || 
# Boolean tests.
	true
	&&
	!false
	&&
# Bound tests.
	!bound(?o1)
	&&
	bound(?o1) = false
	&&
# Arithmetic
	rdfs:Literal(?size) = \"42\"
	&&
	?size/2 = 3*7
	&& 
	(
 # Blank node test.
	 isBlank(?o0)
	 &&
	 ?given = \"É®íç\"
	 ||
 # Literal tests.
	 isLiteral(?o0)
	 &&
	 rdfs:Literal(?o0) = \"eric\"
	 &&
	 regex(?o0, \"^E. .c\$\", \"ix\"))
	&&
	isURI(?s)
	&&
# Node to node test.
	?s != ?o0
	&&
	# IRI arithmetic.
	?s = <1052587433.529382>
	&&
# Strings and Resources.
	rdfs:Resource(str(?s)) = <1052587433.529382>
	&&
	regex(str(?s), \"^http://.*.529382$\")
	&&
# Datatype testx.
	?size = \"42\"^^xs:int
	&&
	?size = xs:float(\"42\")
	&&
	datatype(?d) = xs:dateTime)}
ORDER BY ?s ASC(?o0)
LIMIT 2
OFFSET 0
" \

# SOURCE ?src 
## Extra Arguments:
# --forceHost example.com
# --forcePath /instpath/workingdir

# Table Results:
# +-------------------------------------------------------------+------+----+
# |                                                            s|    o0|  o1|
# |-------------------------------------------------------------|------|----|
# |<http://iggy.w3.org/annotations/annotation/1052587433.529382>|  _:g1|NULL|
# |<http://iggy.w3.org/annotations/annotation/1052587433.529382>|"eric"|NULL|
# +-------------------------------------------------------------+------+----+

# excluded by FILTER:
# |<http://iggy.w3.org/annotations/annotation/1054553215.108988>|  NULL| _:g30|
# |<http://iggy.w3.org/annotations/annotation/1054553215.108988>|  NULL|"eric"|

# ResultSet Results:
# @prefix rdf:    <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
# @prefix rs:     <http://jena.hpl.hp.com/2003/03/result-set#> .
# 
# [] rdf:type rs:ResultSet ;
#     rs:resultVariable "s" ;
#     rs:resultVariable "o0" ;
#     rs:resultVariable "o1" ;
#     rs:size "2" ;
#     rs:solution
#         [ rdf:type rs:ResultSolution ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "s" ; rs:value <http://iggy.w3.org/annotations/annotation/1052587433.529382> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "o0" ; rs:value _:1 ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "o1" ; rs:nonValue "NULL" ] 
#         ] ;
#     rs:solution
#         [ rdf:type rs:ResultSolution ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "s" ; rs:value <http://iggy.w3.org/annotations/annotation/1052587433.529382> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "o0" ; rs:value "eric" ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "o1" ; rs:nonValue "NULL" ] 
#         ] .

 