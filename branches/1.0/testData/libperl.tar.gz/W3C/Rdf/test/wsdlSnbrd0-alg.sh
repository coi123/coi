#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# wsdlSnbrd0 - parse adaptation of Uche's snowboard example
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: wsdlSnbrd0-alg.sh,v 1.3 2004/06/26 01:39:55 eric Exp $
###############################################################################

algae $* \
--set -failAttrNStoEltNs=1 \
#--reportClassn3 \
#--reportParm-createNamespaces=1 \
"
ns mysnwbrd=<http://namespaces.snowboard-info.com/services#>
ns wsdl=<http://schemas.xmlsoap.org/wsdl/>
ns soap=<http://schemas.xmlsoap.org/wsdl/soap/>
ns rdf=<http://www.w3.org/1999/02/22-rdf-syntax-ns#>
ns esxsd=<http://schemas.snowboard-info.com/EndorsementSearch.xsd#>
attach <http://www.w3.org/1999/02/26-modules/algae#ephemeral> ?db ()

flags (minimumRowSolution=1) 
slurp ../test/snowboard.wsdl ?db ()
ask ?db ( 
?def wsdl:service ?service. 
   ?service wsdl:port ?port. 
      ?port soap:address ?address. 
      ?port wsdl:binding ?binding. 
         ?binding wsdl:boundOperation ?boundOp. 
            ?boundOp wsdl:abstraction ?abOp. 
               ?abOp rdf:type wsdl:AbstractOperation. 
               ?abOp wsdl:abstractInput ?abInput. 
                  ?abInput wsdl:part ?inputPart)
collect (?abOp)
" \

#             ?boundOp rdf:type wsdl::BoundOperation. 

# +------------------------------------------------------------------------------------------------------+
# |                                                                                                  abOp|
# |------------------------------------------------------------------------------------------------------|
# |<http://namespaces.snowboard-info.com/servicesabstract_GetEndorsingBoarderPortTypeGetEndorsingBoarder>|
# +------------------------------------------------------------------------------------------------------+

# TODO -- get these props to match. they did before some code changes. bitrot.
# . 
#                ?abOp rdf:type wsdl:AbstractOperation. 
#                ?abOp wsdl:abstractInput ?abInput. 
#                   ?abInput wsdl:part ?inputPart. 
#                      ?inputPart wsdl:partName ?partName. 
#                      ?inputPart wsdl:schemaRef ?xsdDef_Req. 
#                         ?xsdDef_Req wsdl:schemaDef ?inputSchemaDef. 
#                ?abOp wsdl:abstractOutput ?abOutput. 
#                   ?abOutput wsdl:part ?outputPart. 
#                      ?outputPart wsdl:schemaRef ?xsdDef_Response. 
#                         ?xsdDef_Response wsdl:schemaDef ?outputSchemaDef. 
#                      ?outputPart wsdl:partName ?partName. 
#                ?abOp wsdl:abstractFault ?abFault. 
#                   ?abFault wsdl:part ?faultPart. 
#                      ?faultPart wsdl:schemaRef ?xsdDef_Fault. 
#                         ?xsdDef_Fault wsdl:schemaDef ?faultSchemaDef. 
#                      ?faultPart wsdl:partName ?partName. 
#             ?boundOp wsdl:boundFault ?boundFault. 
#             ?boundOp wsdl:boundInput ?boundInput. 
#             ?boundOp soap:address ?address. 
#             ?boundOp wsdl:boundOutput ?boundOutput. 
#          ?binding wsdl:portType ?portType. 
#             ?portType wsdl:abstractOperation ?abOp. 
#          ?binding soap:binding ?transportBinding. 
#             ?transportBinding soap:stype ?style. 
#             ?transportBinding soap:transport ?transport
