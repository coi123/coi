#!/bin/sh

###############################################################################
# Copyright 2004 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# SPARQL-DT-1 - SPARQL Datatype tester.
# Tests:
#   - whether equivilent casts become the same RDF node
# 
# !!! investigate burden on normalized relational stores
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: SPARQL-DT-1-alg.sh,v 1.2 2005/04/08 09:39:15 eric Exp $
###############################################################################

algae $* \
--lang n3 \
"
<foo> <shoeSize> \"42\"^^<http://www.w3.org/2001/XMLSchema#int> ;
      <age>      \"42\"^^<http://www.w3.org/2001/XMLSchema#float> .
" \
--lang SPARQL \
"
PREFIX xs: <http://www.w3.org/2001/XMLSchema#>
SELECT ?s ?size
 WHERE { ?s <shoeSize> ?size ; <age> ?age .
FILTER sameAs(?size, xs:int(?age)) }
" \

# Table Results:
# +----------+----+
# |         s|size|
# |----------|----|
# |<data:foo>|  42|
# +----------+----+

