#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# FileSystem0 - directory of current directory
# Tests:
#   - ability to set base URI
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: FileSystem1-alg.sh,v 1.1 2004/10/18 06:48:58 eric Exp $
###############################################################################

algae $* \
"
ns fs=<http://www.w3.org/2004/10/16-RDF-FileSystem/ns#>
attach fs:FSDB ?fs ()
base file
ask ?fs (<.> fs:dirEnt ?dirEnt.
         ?dirEnt fs:resource ?resource.
         ?dirEnt fs:filename ?filename)
collect (?filename ?resource)
"
# XTable Results:
# +--------------------------+------------------------------------------------------------------------------------------+
# |                  filename|                                                                                  resource|
# |--------------------------|------------------------------------------------------------------------------------------|
# |                    "blib"|                    <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/blib>|
# |        "RXQueryParser.pm"|        <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/RXQueryParser.pm>|
# |       "BrqlParser.output"|       <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/BrqlParser.output>|
# |                  "DbMeta"|                  <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/DbMeta>|
# |      "RdalCompileTree.pm"|      <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/RdalCompileTree.pm>|
# |     "SparqlParser.output"|     <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/SparqlParser.output>|
# |          "AlgaeParser.yp"|          <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/AlgaeParser.yp>|
# |            "ResultSet.pm"|            <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/ResultSet.pm>|
# |                     "IRC"|                     <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/IRC>|
# |             "FingerDB.pm"|             <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/FingerDB.pm>|
# |       "Attributions.html"|       <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/Attributions.html>|
# |      ".#Makefile.PL.1.50"|    <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/.%23Makefile.PL.1.50>|
# |  ".#SparqlParser.yp.1.16"|<file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/.%23SparqlParser.yp.1.16>|
# |               "CGIApp.pm"|               <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/CGIApp.pm>|
# |        "RXQueryParser.yp"|        <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/RXQueryParser.yp>|
# |                    "test"|                    <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/test>|
# |  "FileSystemDB.pm.simple"|  <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/FileSystemDB.pm.simple>|
# |                  "README"|                  <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/README>|
# |      "AlgaeParser.output"|      <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/AlgaeParser.output>|
# |              ".cvsignore"|              <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/.cvsignore>|
# |"FileSystemDB.pm.matching"|<file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/FileSystemDB.pm.matching>|
# |           "TrigParser.yp"|           <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/TrigParser.yp>|
# |           "TrigParser.pm"|           <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/TrigParser.pm>|
# |                   "notes"|                   <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/notes>|
# |       "RdqlParser.output"|       <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/RdqlParser.output>|
# |                "SqlDB.pm"|                <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/SqlDB.pm>|
# |         "N3Parser.output"|         <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/N3Parser.output>|
# |       "Tk::Columns.patch"|   <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/Tk%3A%3AColumns.patch>|
# | "OrderTrackingObjects.pm"| <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/OrderTrackingObjects.pm>|
# |         "SparqlParser.yp"|         <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/SparqlParser.yp>|
# |               "RdfApp.pm"|               <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/RdfApp.pm>|
# |               "RdfDB.dbg"|               <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/RdfDB.dbg>|
# |         "TkVisualizer.pm"|         <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/TkVisualizer.pm>|
# |              "short.xfig"|              <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/short.xfig>|
# |     "EmitterInterface.pm"|     <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/EmitterInterface.pm>|
# | "StatementsSerializer.pm"| <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/StatementsSerializer.pm>|
# |             "Makefile.PL"|             <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/Makefile.PL>|
# |              "pm_to_blib"|              <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/pm_to_blib>|
# |                 "test.pl"|                 <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/test.pl>|
# |          "AlgaeParser.pm"|          <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/AlgaeParser.pm>|
# |                "Makefile"|                <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/Makefile>|
# |                "MANIFEST"|                <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/MANIFEST>|
# |                 "brql.jj"|                 <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/brql.jj>|
# |          "SeRQLParser.pm"|          <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/SeRQLParser.pm>|
# |             "N3Parser.yp"|             <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/N3Parser.yp>|
# |        "XmlSerializer.pm"|        <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/XmlSerializer.pm>|
# |                       "."|                        <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/>|
# |                "RdfDB.pm"|                <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/RdfDB.pm>|
# |           "RdqlParser.yp"|           <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/RdqlParser.yp>|
# |    "RXQueryParser.output"|    <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/RXQueryParser.output>|
# |               "Algae2.pm"|               <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/Algae2.pm>|
# |            "cattest.xfig"|            <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/cattest.xfig>|
# |               "brql.html"|               <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/brql.html>|
# |            "SqlDB.pm.EGP"|            <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/SqlDB.pm.EGP>|
# |   "NTriplesSerializer.pm"|   <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/NTriplesSerializer.pm>|
# |        ".#.cvsignore.1.7"|      <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/.%23.cvsignore.1.7>|
# |       ".cvsignore.~1.8.~"|   <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/.cvsignore.%7E1.8.%7E>|
# |            "Swordfish.pl"|            <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/Swordfish.pl>|
# |           "BrqlParser.yp"|           <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/BrqlParser.yp>|
# |           "RdqlParser.pm"|           <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/RdqlParser.pm>|
# |               "nest.xfig"|               <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/nest.xfig>|
# |           "RdalParser.yp"|           <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/RdalParser.yp>|
# |            "TkVisualizer"|            <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/TkVisualizer>|
# |                "acl.xfig"|                <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/acl.xfig>|
# |           "BrqlParser.pm"|           <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/BrqlParser.pm>|
# |     "AlgaeCompileTree.pm"|     <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/AlgaeCompileTree.pm>|
# |         "rdfxml-rdal.rnc"|         <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/rdfxml-rdal.rnc>|
# |      "AlgaeParser.yp.EGP"|      <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/AlgaeParser.yp.EGP>|
# |          "SeRQLParser.yp"|          <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/SeRQLParser.yp>|
# |         "N3Serializer.pm"|         <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/N3Serializer.pm>|
# |        "DotSerializer.pm"|        <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/DotSerializer.pm>|
# |                      ".."|                            <file://localhost//home/eric/sources/public/perl/modules/W3C/>|
# |       "RDF-ImpNotes.html"|       <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/RDF-ImpNotes.html>|
# |              "README.cvs"|              <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/README.cvs>|
# |                     "bin"|                     <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/bin>|
# |           "RdalParser.pm"|           <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/RdalParser.pm>|
# |       "TrigParser.output"|       <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/TrigParser.output>|
# |                "Atoms.pm"|                <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/Atoms.pm>|
# |            "Makefile.old"|            <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/Makefile.old>|
# |                  "Aux.pm"|                  <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/Aux.pm>|
# |                  "cgibin"|                  <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/cgibin>|
# |         "SparqlParser.pm"|         <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/SparqlParser.pm>|
# |                "YesDB.pm"|                <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/YesDB.pm>|
# |       "RdalParser.output"|       <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/RdalParser.output>|
# |                "TAPDB.pm"|                <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/TAPDB.pm>|
# |      "SeRQLParser.output"|      <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/SeRQLParser.output>|
# |                 "test.pm"|                 <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/test.pm>|
# |                "META.yml"|                <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/META.yml>|
# |                     "CVS"|                     <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/CVS>|
# |            "XmlParser.pm"|            <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/XmlParser.pm>|
# |             "N3Parser.pm"|             <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/N3Parser.pm>|
# |         "FileSystemDB.pm"|         <file://localhost//home/eric/sources/public/perl/modules/W3C/Rdf/FileSystemDB.pm>|
# +--------------------------+------------------------------------------------------------------------------------------+


