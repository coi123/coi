#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# Annotation0 - Insert annotation into database and simple input query
# Tests:
#   - viability for Annotea data
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: Annotation1-alg.sh,v 1.10 2005/08/03 19:47:53 eric Exp $
###############################################################################

algae $* \
--lang Algae \
"
ns rdf=<http://www.w3.org/1999/02/22-rdf-syntax-ns#>
ns a=<http://www.w3.org/2000/10/annotation-ns#>
ns http=<http://www.w3.org/1999/xx/http#>
attach <http://www.w3.org/1999/02/26-modules/algae#dynamic> ?db (
                    class=\"W3C::Rdf::SqlDB\"
                    properties=\"../test/genericTripleStore.prop\")
slurp <../test/Annotation1052587433.529382.rdf> ?db ()
slurp <../test/Annotation1052587433.529382b.rdf> ?db ()
ask ?db (
       ?annotation rdf:type a:Annotation {%ATTRIB == <../test/Annotation1052587433.529382.rdf>}.
       ?annotation a:annotates ?annotates.
       ?annotation a:context ?context.
       ?annotation a:body ?body {%ATTRIB == <../test/Annotation1052587433.529382.rdf>}.
       ?body http:Body ?text
      )
#host ?db (?annotation ?body)
select (?annotation ?body)
" \

# Table Results:
# +-------------------------------------------------------------+-------------------------------------------------------+
# |                                                   annotation|                                                   body|
# |-------------------------------------------------------------|-------------------------------------------------------|
# |<http://iggy.w3.org/annotations/annotation/1052587433.529382>|<http://iggy.w3.org/annotations/body/1052587433.529382>|
# |<http://iggy.w3.org/annotations/annotation/1054553215.108988>|<http://iggy.w3.org/annotations/body/1054553215.108988>|
# +-------------------------------------------------------------+-------------------------------------------------------+

# With Hosting, something like: (difficult to test)
# +--------------------------------------------------------------------------+--------------------------------------------------------------------------+
# |                                                                annotation|                                                                      body|
# |--------------------------------------------------------------------------|--------------------------------------------------------------------------|
# |<file://na/home/eric/sources/public/perl/modules/W3C/Rdf/bin/algae#host_0>|<file://na/home/eric/sources/public/perl/modules/W3C/Rdf/bin/algae#host_1>|
# |<file://na/home/eric/sources/public/perl/modules/W3C/Rdf/bin/algae#host_2>|<file://na/home/eric/sources/public/perl/modules/W3C/Rdf/bin/algae#host_3>|
# +--------------------------------------------------------------------------+--------------------------------------------------------------------------+

# SQL Query:
# SELECT STRAIGHT_JOIN
#        __Holds___0.a AS __Holds___0_a,
#        __Holds___0.id AS __Holds___0_id,
#        __Nodes___1.id AS __Nodes___1_annotation_id,
#        __Holds___1.a AS __Holds___1_a,
#        __Holds___1.id AS __Holds___1_id,
#        __Nodes___5.id AS __Nodes___5_annotates_id,
#        __Holds___2.a AS __Holds___2_a,
#        __Holds___2.id AS __Holds___2_id,
#        __Nodes___7.id AS __Nodes___7_context_id,
#        __Holds___3.a AS __Holds___3_a,
#        __Holds___3.id AS __Holds___3_id,
#        __Nodes___9.id AS __Nodes___9_body_id,
#        __Holds___4.a AS __Holds___4_a,
#        __Holds___4.id AS __Holds___4_id,
#        __Nodes___12.id AS __Nodes___12_text_id
#        
# FROM __Holds__ AS __Holds___0
#      INNER JOIN __Nodes__ AS __Nodes___0 ON __Holds___0.p=__Nodes___0.id
#      INNER JOIN __Nodes__ AS __Nodes___1 ON __Holds___0.s=__Nodes___1.id
#      INNER JOIN __Nodes__ AS __Nodes___2 ON __Holds___0.o=__Nodes___2.id
#      INNER JOIN __AttrLists__ AS __AttrLists___0 ON __Holds___0.a=__AttrLists___0.listId
#      INNER JOIN __Attributions__ AS __Attributions___0 ON __AttrLists___0.a=__Attributions___0.id
#      INNER JOIN __Nodes__ AS __Nodes___3 ON __Attributions___0.doc=__Nodes___3.id
#      INNER JOIN __Holds__ AS __Holds___1 ON __Holds___1.s=__Nodes___1.id
#      INNER JOIN __Nodes__ AS __Nodes___4 ON __Holds___1.p=__Nodes___4.id
#      INNER JOIN __Nodes__ AS __Nodes___5 ON __Holds___1.o=__Nodes___5.id
#      INNER JOIN __Holds__ AS __Holds___2 ON __Holds___2.s=__Nodes___1.id
#      INNER JOIN __Nodes__ AS __Nodes___6 ON __Holds___2.p=__Nodes___6.id
#      INNER JOIN __Nodes__ AS __Nodes___7 ON __Holds___2.o=__Nodes___7.id
#      INNER JOIN __Holds__ AS __Holds___3 ON __Holds___3.s=__Nodes___1.id
#      INNER JOIN __Nodes__ AS __Nodes___8 ON __Holds___3.p=__Nodes___8.id
#      INNER JOIN __Nodes__ AS __Nodes___9 ON __Holds___3.o=__Nodes___9.id
#      INNER JOIN __AttrLists__ AS __AttrLists___1 ON __Holds___3.a=__AttrLists___1.listId
#      INNER JOIN __Attributions__ AS __Attributions___1 ON __AttrLists___1.a=__Attributions___1.id
#      INNER JOIN __Nodes__ AS __Nodes___10 ON __Attributions___1.doc=__Nodes___10.id
#      INNER JOIN __Holds__ AS __Holds___4 ON __Holds___4.s=__Nodes___9.id
#      INNER JOIN __Nodes__ AS __Nodes___11 ON __Holds___4.p=__Nodes___11.id
#      INNER JOIN __Nodes__ AS __Nodes___12 ON __Holds___4.o=__Nodes___12.id
# WHERE __Nodes___0.hash="c74e2b735dd8dc85ad0ee3510c33925f" 
#   AND  __Nodes___2.hash="acef97e962dd06905694368feda0317f" 
#   AND  __Nodes___3.hash="36c932af5ef5ec3b348f01e6fd79817a" 
#   AND  __Nodes___4.hash="5a57811b2e27c10052c3916f8c1d7415" 
#   AND  __Nodes___6.hash="ddb55f1d54598bb5120e03548d3b1dfa" 
#   AND  __Nodes___8.hash="93911c4322d01104748a861871acb21c" 
#   AND  __Nodes___10.hash="36c932af5ef5ec3b348f01e6fd79817a" 
#   AND  __Nodes___11.hash="c8b099193cc043d0f51b47d65c24300b"
# GROUP BY __Nodes___1_annotation_id,__Nodes___5_annotates_id,__Nodes___7_context_id,__Nodes___9_body_id,__Nodes___12_text_id

