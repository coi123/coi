#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# Annotations1 - Flexible Annotea query
# Tests:
#   - disjunction
#   - operator precedence (generating SQL query)
#   - utf-8
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: Annotation2-alg.sh,v 1.8 2004/09/10 16:31:25 eric Exp $
###############################################################################

algae $* \
"
ns rdf=<http://www.w3.org/1999/02/22-rdf-syntax-ns#>
ns a=<http://www.w3.org/2000/10/annotation-ns#>
ns http=<http://www.w3.org/1999/xx/http#>
ns d0=<http://purl.org/dc/elements/1.0/>
ns d1=<http://purl.org/dc/elements/1.1/>
attach <http://www.w3.org/1999/02/26-modules/algae#dynamic> ?db (
                    class=\"W3C::Rdf::SqlDB\"
                    properties=\"../test/genericTripleStore.prop\")
slurp <../test/Annotation1052587433.529382.rdf> ?db ()
ns alg=<http://www.w3.org/1999/02/26-modules/algae#>
ask ?db (
       ?annotation rdf:type a:Annotation {%ATTRIB == <../test/Annotation1052587433.529382.rdf>}.
       (?annotation d0:title ?title ||
        ?annotation d1:title ?title).
       (?annotation d0:creator ?creat ||
        ?annotation d1:creator ?creat).
       ?creat      a:Given ?given.
       ?annotation a:annotates ?annotates.
       ?annotation a:context ?context.
       ?annotation a:body ?body {%ATTRIB == <../test/Annotation1052587433.529382.rdf>}.
       ?body http:Body ?text
      )
select (?annotation ?body ?title ?given)
" \

# Table Results:
# +-------------------------------------------------------------+-------------------------------------------------------+-----------------------------------+----------+
# |                                                   annotation|                                                   body|                              title|     given|
# |-------------------------------------------------------------|-------------------------------------------------------|-----------------------------------|----------|
# |<http://iggy.w3.org/annotations/annotation/1052587433.529382>|<http://iggy.w3.org/annotations/body/1052587433.529382>|"Old Annotation of Eric's Homepage"|"É®íç"|
# |<http://iggy.w3.org/annotations/annotation/1054553215.108988>|<http://iggy.w3.org/annotations/body/1054553215.108988>|"New Annotation of Eric's Homepage"|"É®íç"|
# +-------------------------------------------------------------+-------------------------------------------------------+-----------------------------------+----------+

# SQL Query:

# SELECT STRAIGHT_JOIN
#        __Holds___0.a AS __Holds___0_a,
#        __Holds___0.id AS __Holds___0_id,
#        __Nodes___1.id AS __Nodes___1_annotation_id,
#        __Holds___1.a AS __Holds___1_a,
#        __Holds___1.id AS __Holds___1_id,
#        __Nodes___5.id AS __Nodes___5_title_id,
#        __Nodes___4.hash="3b4aaedf762b1aec25eccbfe129baa0a" AS "?annotation <http://purl.org/dc/elements/1.0/title> ?title ",
#        __Nodes___4.hash="10a2b68e090fc22a4421947526be1e64" AS "?annotation <http://purl.org/dc/elements/1.1/title> ?title ",
#        __Holds___2.a AS __Holds___2_a,
#        __Holds___2.id AS __Holds___2_id,
#        __Nodes___7.id AS __Nodes___7_creat_id,
#        __Nodes___6.hash="8056ba84c24b8f6a3098f50b3c17b34f" AS "?annotation <http://purl.org/dc/elements/1.0/creator> ?creat ",
#        __Nodes___6.hash="d8448f7de5238dcdf58a6a729dd44487" AS "?annotation <http://purl.org/dc/elements/1.1/creator> ?creat ",
#        __Holds___3.a AS __Holds___3_a,
#        __Holds___3.id AS __Holds___3_id,
#        __Nodes___9.id AS __Nodes___9_given_id,
#        __Holds___4.a AS __Holds___4_a,
#        __Holds___4.id AS __Holds___4_id,
#        __Nodes___11.id AS __Nodes___11_annotates_id,
#        __Holds___5.a AS __Holds___5_a,
#        __Holds___5.id AS __Holds___5_id,
#        __Nodes___13.id AS __Nodes___13_context_id,
#        __Holds___6.a AS __Holds___6_a,
#        __Holds___6.id AS __Holds___6_id,
#        __Nodes___15.id AS __Nodes___15_body_id,
#        __Holds___7.a AS __Holds___7_a,
#        __Holds___7.id AS __Holds___7_id,
#        __Nodes___18.id AS __Nodes___18_text_id
#        
# FROM __Holds__ AS __Holds___0
#      INNER JOIN __Nodes__ AS __Nodes___0 ON __Holds___0.p=__Nodes___0.id
#      INNER JOIN __Nodes__ AS __Nodes___1 ON __Holds___0.s=__Nodes___1.id
#      INNER JOIN __Nodes__ AS __Nodes___2 ON __Holds___0.o=__Nodes___2.id
#      INNER JOIN __AttrLists__ AS __AttrLists___0 ON __Holds___0.a=__AttrLists___0.listId
#      INNER JOIN __Attributions__ AS __Attributions___0 ON __AttrLists___0.a=__Attributions___0.id
#      INNER JOIN __Nodes__ AS __Nodes___3 ON __Attributions___0.doc=__Nodes___3.id
#      INNER JOIN __Holds__ AS __Holds___1 ON __Holds___1.s=__Nodes___1.id
#      INNER JOIN __Nodes__ AS __Nodes___4 ON __Holds___1.p=__Nodes___4.id
#      INNER JOIN __Nodes__ AS __Nodes___5 ON __Holds___1.o=__Nodes___5.id
#      INNER JOIN __Holds__ AS __Holds___2 ON __Holds___2.s=__Nodes___1.id
#      INNER JOIN __Nodes__ AS __Nodes___6 ON __Holds___2.p=__Nodes___6.id
#      INNER JOIN __Nodes__ AS __Nodes___7 ON __Holds___2.o=__Nodes___7.id
#      INNER JOIN __Holds__ AS __Holds___3 ON __Holds___3.s=__Nodes___7.id
#      INNER JOIN __Nodes__ AS __Nodes___8 ON __Holds___3.p=__Nodes___8.id
#      INNER JOIN __Nodes__ AS __Nodes___9 ON __Holds___3.o=__Nodes___9.id
#      INNER JOIN __Holds__ AS __Holds___4 ON __Holds___4.s=__Nodes___1.id
#      INNER JOIN __Nodes__ AS __Nodes___10 ON __Holds___4.p=__Nodes___10.id
#      INNER JOIN __Nodes__ AS __Nodes___11 ON __Holds___4.o=__Nodes___11.id
#      INNER JOIN __Holds__ AS __Holds___5 ON __Holds___5.s=__Nodes___1.id
#      INNER JOIN __Nodes__ AS __Nodes___12 ON __Holds___5.p=__Nodes___12.id
#      INNER JOIN __Nodes__ AS __Nodes___13 ON __Holds___5.o=__Nodes___13.id
#      INNER JOIN __Holds__ AS __Holds___6 ON __Holds___6.s=__Nodes___1.id
#      INNER JOIN __Nodes__ AS __Nodes___14 ON __Holds___6.p=__Nodes___14.id
#      INNER JOIN __Nodes__ AS __Nodes___15 ON __Holds___6.o=__Nodes___15.id
#      INNER JOIN __AttrLists__ AS __AttrLists___1 ON __Holds___6.a=__AttrLists___1.listId
#      INNER JOIN __Attributions__ AS __Attributions___1 ON __AttrLists___1.a=__Attributions___1.id
#      INNER JOIN __Nodes__ AS __Nodes___16 ON __Attributions___1.doc=__Nodes___16.id
#      INNER JOIN __Holds__ AS __Holds___7 ON __Holds___7.s=__Nodes___15.id
#      INNER JOIN __Nodes__ AS __Nodes___17 ON __Holds___7.p=__Nodes___17.id
#      INNER JOIN __Nodes__ AS __Nodes___18 ON __Holds___7.o=__Nodes___18.id
# WHERE __Nodes___0.hash="c74e2b735dd8dc85ad0ee3510c33925f" 
#   AND  __Nodes___2.hash="acef97e962dd06905694368feda0317f" 
#   AND  __Nodes___3.hash="8ec725967569b750531555ff6cd49f50" 
#   AND  (__Nodes___4.hash="3b4aaedf762b1aec25eccbfe129baa0a" 
#    OR  __Nodes___4.hash="10a2b68e090fc22a4421947526be1e64") 
#   AND  (__Nodes___6.hash="8056ba84c24b8f6a3098f50b3c17b34f" 
#    OR  __Nodes___6.hash="d8448f7de5238dcdf58a6a729dd44487") 
#   AND  __Nodes___8.hash="999488e9874569d317a88fe71e065609" 
#   AND  __Nodes___10.hash="5a57811b2e27c10052c3916f8c1d7415" 
#   AND  __Nodes___12.hash="ddb55f1d54598bb5120e03548d3b1dfa" 
#   AND  __Nodes___14.hash="93911c4322d01104748a861871acb21c" 
#   AND  __Nodes___16.hash="8ec725967569b750531555ff6cd49f50" 
#   AND  __Nodes___17.hash="c8b099193cc043d0f51b47d65c24300b"
# GROUP BY __Nodes___1_annotation_id,__Nodes___5_title_id,__Nodes___7_creat_id,__Nodes___9_given_id,__Nodes___11_annotates_id,__Nodes___13_context_id,__Nodes___15_body_id,__Nodes___18_text_id

