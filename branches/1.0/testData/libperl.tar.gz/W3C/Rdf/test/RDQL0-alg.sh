#!/bin/sh

###############################################################################
# Copyright 2004 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# RDQL0 - RDQL tester.
# Tests:
#   - RDQL parser and it's use of Algae2 query structures
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: RDQL0-alg.sh,v 1.7 2004/07/07 01:22:20 eric Exp $
###############################################################################

algae $* \
--lang RDQL \
"
SELECT *
  FROM <../test/Annotation1052587433.529382.rdf>
 WHERE (?s rdf:type a:Annotation)
       (?s ?p ?o)
   AND ?o == 5 * 3 + 10/5 || ?o == \"eric\" || ?o == \"joe\"
 USING rdf FOR <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
       a FOR <http://www.w3.org/2000/10/annotation-ns#>
" \

# Table Results:
# +-------------------------------------------------------------+-----------------------------------------+------+
# |                                                            s|                                        p|     o|
# |-------------------------------------------------------------|-----------------------------------------|------|
# |<http://iggy.w3.org/annotations/annotation/1054553215.108988>|<http://purl.org/dc/elements/1.1/creator>|"eric"|
# |<http://iggy.w3.org/annotations/annotation/1052587433.529382>|<http://purl.org/dc/elements/1.0/creator>|"eric"|
# +-------------------------------------------------------------+-----------------------------------------+------+

