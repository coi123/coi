#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# n3parseTest1 - 
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: n3parseTest1-alg.sh,v 1.3 2004/06/23 12:32:18 eric Exp $
###############################################################################

algae $* \
"(
    slurp '((../test/infos.n3 -inputLang \"n3\")) 
     ask '((?p ?s ?o ?r ?b ?a)) collect '(?p ?s ?o ?r ?b ?a))" \

# +---------------------------------------------------+----------------------------------------------------------------------------+---------------------------------------------+----+----+----------------------------------------------------------------------------+
# |                                                  p|                                                                           s|                                            o|   r|   b|                                                                           a|
# |---------------------------------------------------|----------------------------------------------------------------------------|---------------------------------------------|----|----|----------------------------------------------------------------------------|
# |          <http://dev.w3.org/Presentation/HTML#alt>|                                                                        _:g3|                                        "W3C"|NULL|NULL|[file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3]|
# |          <http://dev.w3.org/Presentation#baselang>|<file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3>|                                      "en-US"|NULL|NULL|[file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3]|
# |           <http://dev.w3.org/Presentation#logoAlt>|<file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3>|                                        "W3C"|NULL|NULL|[file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3]|
# |  <http://www.w3.org/1999/02/22-rdf-syntax-ns#type>|<file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3>|<http://dev.w3.org/Presentation#Presentation>|NULL|NULL|[file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3]|
# |               <http://dev.w3.org/Presentation#css>|                                                                        _:g8|                                  "local.css"|NULL|NULL|[file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3]|
# |            <http://dev.w3.org/Presentation/HTML#a>|                                                                        _:g5|                                         _:g4|NULL|NULL|[file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3]|
# |<http://dev.w3.org/Presentation#renderingDimension>|<file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3>|                                         _:g9|NULL|NULL|[file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3]|
# |         <http://dev.w3.org/Presentation#rendering>|                                                                        _:g9|                                         _:g8|NULL|NULL|[file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3]|
# |         <http://dev.w3.org/Presentation#rendering>|                                                                        _:g9|                                         _:g7|NULL|NULL|[file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3]|
# |         <http://dev.w3.org/Presentation/HTML#href>|                                                                        _:g1|                         <mailto:eric@w3.org>|NULL|NULL|[file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3]|
# |          <http://dev.w3.org/Presentation/HTML#img>|                                                                        _:g4|                                         _:g3|NULL|NULL|[file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3]|
# |               <http://dev.w3.org/Presentation#css>|                                                                        _:g6|                     "../Tools/slide-640.css"|NULL|NULL|[file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3]|
# |         <http://dev.w3.org/Presentation#addAuthor>|<file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3>|                                         _:g2|NULL|NULL|[file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3]|
# |           <http://dev.w3.org/Presentation#setLogo>|<file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3>|                                         _:g5|NULL|NULL|[file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3]|
# |            <http://dev.w3.org/Presentation/HTML#a>|                                                                        _:g2|                                         _:g1|NULL|NULL|[file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3]|
# |         <http://dev.w3.org/Presentation/HTML#href>|                                                                        _:g4|                      "../Icons/w3c_home.gif"|NULL|NULL|[file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3]|
# |        <http://dev.w3.org/Presentation/HTML#CDATA>|                                                                        _:g1|                    "Eric 'N3' Prud'hommeaux"|NULL|NULL|[file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3]|
# |          <http://dev.w3.org/Presentation/HTML#src>|                                                                        _:g3| <http://www.w3.org/Talks/Icons/w3c_home.gif>|NULL|NULL|[file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3]|
# |               <http://dev.w3.org/Presentation#css>|                                                                        _:g6|                                  "local.css"|NULL|NULL|[file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3]|
# |         <http://dev.w3.org/Presentation#rendering>|                                                                        _:g9|                                         _:g6|NULL|NULL|[file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3]|
# |               <http://dev.w3.org/Presentation#css>|                                                                        _:g8|                    "../Tools/slide-1024.css"|NULL|NULL|[file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3]|
# |           <http://dev.w3.org/Presentation#charset>|<file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3>|                                 "ISO-8859-1"|NULL|NULL|[file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3]|
# |             <http://dev.w3.org/Presentation#index>|<file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3>|                                   "Overview"|NULL|NULL|[file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3]|
# |         <http://dev.w3.org/Presentation#talkTitle>|<file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3>|                   "W3C Open Source Activity"|NULL|NULL|[file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3]|
# |               <http://dev.w3.org/Presentation#css>|                                                                        _:g7|                                  "local.css"|NULL|NULL|[file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3]|
# |           <http://dev.w3.org/Presentation#doctype>|<file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3>|                                  "XHTML+SVG"|NULL|NULL|[file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3]|
# |               <http://dev.w3.org/Presentation#css>|                                                                        _:g7|                     "../Tools/slide-800.css"|NULL|NULL|[file://mr-pink/home/eric/sources/public/perl/modules/W3C/Rdf/test/infos.n3]|
# +---------------------------------------------------+----------------------------------------------------------------------------+---------------------------------------------+----+----+----------------------------------------------------------------------------+
