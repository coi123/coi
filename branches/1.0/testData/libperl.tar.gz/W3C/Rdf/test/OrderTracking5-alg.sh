#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# OrderTracking5 - Shipping department view for one order
# Tests:
#   - Subject entity identified by resource
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: OrderTracking5-alg.sh,v 1.10 2007/06/24 22:09:22 eric Exp $
###############################################################################

algae $* \
--lang Algae \
"
ns ot=<http://localhost/OrderTracking#>
attach <http://www.w3.org/2003/01/21-RDF-RDB-access/ns#SqlDB> ot:db (
                    properties=\"../test/OrderTracking.prop\")
ask ot:db (
       ot:Orders_id_3183 ot:Orders_id			?orderId .
       ot:Orders_id_3183 ot:Orders_customer		?c .
       ot:Orders_id_3183 ot:Orders_orderDate		\"2002-09-07 18:00:00\" .
       ?c		ot:Customers_givenName		?first .
       ?c		ot:Customers_familyName		?last .
       ?c		ot:Customers_billingAddress	?billAddr .
       ?billAddr	ot:Addresses_street		?billStreet .
       ?billAddr	ot:Addresses_city		?billCity .
       ?billAddr	ot:Addresses_state		?billState .
       ~ot:Orders_id_3183 ot:Orders_shippingAddress	?shipAddr .
       ~?shipAddr	ot:Addresses_street		?shipStreet .
       ~?shipAddr	ot:Addresses_city		?shipCity .
       ~?shipAddr	ot:Addresses_state		?shipState .
       ~?shipAddr	ot:Addresses_contact		?signer .
       ~?signer		ot:Customers_givenName		?sFirst .
       ~?signer		ot:Customers_familyName		?sLast
      )
collect (?orderId ?first ?last ?billStreet ?billCity ?billState ?sFirst ?sLast ?shipStreet ?shipCity ?shipState) 
" \

# Table Results:
# +-------+------+----------+----------------+----------+---------+--------+--------+-----------------+----------+---------+
# |orderId| first|      last|      billStreet|  billCity|billState|  sFirst|   sLast|       shipStreet|  shipCity|shipState|
# |-------|------|----------|----------------|----------|---------|--------|--------|-----------------|----------|---------|
# | "3183"|"Chip"|"Thompson"|"123 Elm Street"|"EdgeCity"|     "AV"|"Eustis"|"Walker"|"245 King Street"|"EdgeCity"|     "AV"|
# +-------+------+----------+----------------+----------+---------+--------+--------+-----------------+----------+---------+

# SQL Query:
# SELECT Orders_0.id AS orderId_id,
# Customers_0.id AS c_id,
#        Customers_0.givenName AS first_givenName,
# Customers_0.familyName AS last_familyName,
# Addresses_0.id AS billAddr_id,
#        Addresses_0.street AS billStreet_street,
# Addresses_0.city AS billCity_city,
# Addresses_0.state AS billState_state,
# Addresses_1.id AS shipAddr_id,
#        Addresses_1.street AS shipStreet_street,
# Addresses_1.city AS shipCity_city,
# Addresses_1.state AS shipState_state,
# Customers_1.id AS signer_id,
#        Customers_1.givenName AS sFirst_givenName,
# Customers_1.familyName AS sLast_familyName
# FROM Orders AS Orders_0
#      INNER JOIN Customers AS Customers_0 ON Orders_0.customer=Customers_0.id
#      INNER JOIN Addresses AS Addresses_0 ON Customers_0.billingAddress=Addresses_0.id
#      LEFT OUTER JOIN Addresses AS Addresses_1 ON (Orders_0.shippingAddress=Addresses_1.id)
#      LEFT OUTER JOIN Customers AS Customers_1 ON (Addresses_1.contact=Customers_1.id)
# WHERE Orders_0.id="3183"
#   AND Orders_0.orderDate="20020907"

