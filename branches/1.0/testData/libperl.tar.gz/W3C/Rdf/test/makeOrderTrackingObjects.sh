../../Database/bin/object_maker $* \
-p OrderTracking.prop OrderTracking \
-n W3C::Rdf::test::OrderTrackingObjects \
-h OrderTrackingObjects.html \
-m "{Customers.billingAddress=>Addresses.id, 
     Orders.customer=>Customers.id, 
     Orders.product=>Products.id, 
     Orders.shippingAddress=>Addresses.id, 
     Addresses.contact=>Customers.id

     __AttrLists__.listId=>undef, 
     __AttrLists__.a=>__Attributions__.id, 
     __Attributions__.doc=>__Nodes__.id, 
     __Attributions__.auth=>__Nodes__.id, 
     __Holds__.p=>__Nodes__.id, 
     __Holds__.s=>__Nodes__.id, 
     __Holds__.o=>__Nodes__.id, 
     __Holds__.r=>__Nodes__.id, 
     __Holds__.a=>__AttrLists__.listId, 
     __Nodes__.big=>__Big__.id, 
     __Nodes__.attribOrDT=>__Attributions__.id
    }" \
> OrderTrackingObjects.pm
