#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# SqlDBtest4 - 
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: SqlDBtest4-alg.sh,v 1.6 2004/06/23 12:32:18 eric Exp $
###############################################################################

algae $* \
"(
 namespace '(testDB http://localhost/SqlDBtest#
             acl http://www.w3.org/2001/02/acls/ns#
             rdf http://www.w3.org/1999/02/22-rdf-syntax-ns#) 
 attach '(\"W3C::Rdf::SqlDB\" (\"properties:SqlDBtest.prop\" \"name:testDB::test1\"))
 ask '(testDB::test1
       (testDB::A.u1	?a	?u)
       (testDB::A.p1	?a	?b)
       (testDB::A.p2	?a	?c)
       (|| (testDB::A.u1	?a	\"101\")
           (testDB::A.p3	?a	?c))
       (testDB::A.p4	?a	?d)
       (testDB::B.p5	?b	?c)
       (testDB::B.p6	?b	?e)
      )
 collect '(?d ?a ?b ?c) 
)" \

# SELECT A_0.u0 AS a_u0, A_0.u1 AS a_u1,
#        B_0.key0 AS b_key0,
#        C_0.key1 AS c_key1,A_0.u1="101",A_0.p3=C_0.key1,A_0.p4 AS d_p4,
# C_1.key1 AS e_key1
# FROM A AS A_0, B AS B_0, C AS C_0, C AS C_1
# WHERE A_0.p1=B_0.key0
#   AND A_0.p2=C_0.key1
#   AND (A_0.u1="101"
#    OR A_0.p3=C_0.key1)
#   AND B_0.p5=C_0.key1
#   AND B_0.p6=C_1.key1

# +----------+------------------------------------------+---------------------------------------+---------------------------------------+
# |         d|                                         a|                                      b|                                      c|
# |----------|------------------------------------------|---------------------------------------|---------------------------------------|
# |"B1,C1,C2"|<http://localhost/SqlDBtest#A.u0=0&u1=101>|<http://localhost/SqlDBtest#B.key0=201>|<http://localhost/SqlDBtest#C.key1=301>|
# |"B3,C3,C3"|<http://localhost/SqlDBtest#A.u0=103&u1=0>|<http://localhost/SqlDBtest#B.key0=203>|<http://localhost/SqlDBtest#C.key1=303>|
# +----------+------------------------------------------+---------------------------------------+---------------------------------------+

