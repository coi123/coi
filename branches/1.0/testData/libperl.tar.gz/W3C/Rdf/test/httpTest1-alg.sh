#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# httpTest1 - 
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: httpTest1-alg.sh,v 1.2 2002/12/09 19:35:39 eric Exp $
###############################################################################

algae $* \
-a"(
 namespace '(ns http://namespaces.snowboard-info.com/services#
             rdf http://www.w3.org/1999/02/22-rdf-syntax-ns#
             a http://www.w3.org/2000/10/annotation-ns#) 
 slurp '((http://annotest.w3.org/annotations/attribution/984686194.875809
          -user \"eric+annotate@w3.org\" 
          -password -)) 
 ask '((rdf::type ?annotation a::Annotation)) 
 collect '(?annotation)
)" \

# +----------------------------------------------------------------+
# |                                                      annotation|
# |----------------------------------------------------------------|
# |<http://annotest.w3.org/annotations/annotation/984686194.875809>|
# +----------------------------------------------------------------+

