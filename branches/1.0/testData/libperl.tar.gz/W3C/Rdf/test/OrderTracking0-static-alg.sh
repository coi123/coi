#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# OrderTracking0 - 
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: OrderTracking0-static-alg.sh,v 1.1 2003/02/03 05:27:06 eric Exp $
###############################################################################

algae $* \
-a"(
 namespace '(testDB http://localhost/OrderTracking#)
 slurp '((../test/OrderTracking-static.n3 -inputLang \"n3\")) 
 ask '((testDB::ProductsDOTname	?p	?productName)
      )
 collect '(?productName) 
)" \
-a"(
 namespace '(testDB http://localhost/OrderTracking#)
 ask '((testDB::CustomersDOTfamilyName	?c	?last)
       (testDB::CustomersDOTgivenName	?c	?first)
      )
 collect '(?first ?last) 
)" \

# +-----------------------+
# |            productName|
# |-----------------------|
# |          "white house"|
# |         "picket fence"|
# |"sport utility vehicle"|
# |                 "pool"|
# |                "grill"|
# |           "skateboard"|
# |      "rebelious music"|
# |              "earring"|
# |            "nose ring"|
# |           "other ring"|
# +-----------------------+
# +--------+----------+
# |   first|      last|
# |--------|----------|
# |  "Biff"|"Thompson"|
# |  "Chip"|"Thompson"|
# |"Eustis"|  "Walker"|
# |  "Elie"|   "Tweak"|
# +--------+----------+

