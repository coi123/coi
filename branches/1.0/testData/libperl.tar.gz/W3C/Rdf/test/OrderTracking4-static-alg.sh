#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# OrderTracking4 - 
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: OrderTracking4-static-alg.sh,v 1.4 2003/02/03 09:23:08 eric Exp $
###############################################################################

algae $* \
-a"(
 namespace '(testDB http://localhost/OrderTracking#
             acl http://www.w3.org/2001/02/acls/ns#
             rdf http://www.w3.org/1999/02/22-rdf-syntax-ns#) 
 slurp '((../test/OrderTracking-static.n3 -inputLang \"n3\")) 
 ask '((testDB::OrdersDOTcustomer	?o	?c)
       (testDB::OrdersDOTproduct	?o	?p)
       (testDB::OrdersDOTorderDate	?o	?d)
       (testDB::ProductsDOTname	?p	?productName)
       (testDB::CustomersDOTgivenName	?c	?first)
       (testDB::CustomersDOTfamilyName	?c	?last)
       (testDB::CustomersDOTbillingAddress	?c	?billAddr)
       (testDB::AddressesDOTstreet	?billAddr ?billStreet)
       (testDB::AddressesDOTcity	?billAddr ?billCity)
       (testDB::AddressesDOTstate	?billAddr ?billState)
       ~(testDB::OrdersDOTshippingAddress	?o	?shipAddr)
       ~(testDB::AddressesDOTstreet	?shipAddr ?shipStreet)
       ~(testDB::AddressesDOTcity	?shipAddr ?shipCity)
       ~(testDB::AddressesDOTstate	?shipAddr ?shipState)
      )
 collect '(?first ?last ?productName ?billStreet ?billCity ?billState ?shipStreet ?shipCity ?shipState) 
)" \

# Test with optional properties ?shipStreet ?shipCity ?shipState

# +------+----------+------------+----------------+----------+---------+-----------------+----------+---------+
# | first|      last| productName|      billStreet|  billCity|billState|       shipStreet|  shipCity|shipState|
# |------|----------|------------|----------------|----------|---------|-----------------|----------|---------|
# |"Biff"|"Thompson"|      "pool"|"123 Elm Street"|"EdgeCity"|     "XX"|             NULL|      NULL|     NULL|
# |"Chip"|"Thompson"|"skateboard"|"123 Elm Street"|"EdgeCity"|     "XX"|             NULL|      NULL|     NULL|
# |"Chip"|"Thompson"| "nose ring"|"123 Elm Street"|"EdgeCity"|     "XX"|             NULL|      NULL|     NULL|
# |"Chip"|"Thompson"|"other ring"|"123 Elm Street"|"EdgeCity"|     "XX"|"245 King Street"|"EdgeCity"|     "XX"|
# +------+----------+------------+----------------+----------+---------+-----------------+----------+---------+

