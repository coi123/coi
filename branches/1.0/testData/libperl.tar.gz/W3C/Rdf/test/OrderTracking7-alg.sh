#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# OrderTracking7 - Database misc update
# Tests:
#   - insert into __Statements__
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: OrderTracking7-alg.sh,v 1.4 2004/06/23 12:32:18 eric Exp $
###############################################################################

algae $* \
"
ns db=<http://localhost/OrderTracking#>
ns billing=<http://example.com/billing#>
ns sales=<http://example.com/sales#>
attach <http://www.w3.org/1999/02/26-modules/algae#dynamic> ?ot (
                    class=\"W3C::Rdf::SqlDB\"
                    properties=\"../test/OrderTracking.prop\")
assert ?ot (
       db:Orders_id_3183	billing:dontTell	db:Customers_id_1 .
       db:Customers_id_2	sales:marketingProfile	[
		sales:id	sales:suburbanDad;
		sales:age	40 {%DATATYPE = <http://www.w3.org/2001/XMLSchema#int>};
		sales:desc	\"suburban dad\";
		sales:markup	\"<em>super</em> dad\" {%ENCODING = \"XML\"}{%LANG = \"en-US\"};
		sales:markup	\"papa <em>superbe</em>\" {%ENCODING = \"XML\"}{%LANG = \"fr\"};
		sales:markup	\"<em>upersay</em> addsay\" {%ENCODING = \"XML\"}{%LANG = \"x-pig-latin\"};
		sales:longDesc	\"<?xml version='1.0' encoding='iso-8859-1'?>
<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.1//EN' 'http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd'>
<html>
  <head>
    <title>Marketing Profile for Biff Thompson</title>
  </head>
  <body>
    <p>Biff Thompson has it all, a white house with a picket fence, we
    really should try to sell him a pool.</p>
  </body>
</html>\" {%ENCODING = \"XML\"}.
	]
      )
" \

# Table Results:
# +
# +

# SQL Query:
# SELECT __Nodes__.id,__Nodes__.node,__Nodes__.nodec
#   FROM __Nodes__
#  WHERE __Nodes__.type="uri"
#    AND __Nodes__.hash="a993295912763ca6dbfc96b31f1be4c9";
# INSERT INTO __Nodes__ SET node=521921737, nodec=0, type="uri", hash="a993295912763ca6dbfc96b31f1be4c9", str='http://example.com/billing#dontTell';
# SELECT __Nodes__.id,__Nodes__.node,__Nodes__.nodec
#   FROM __Nodes__,Orders
#  WHERE __Nodes__.type="table"
#    AND __Nodes__.str='Orders,id=\"3183\"'
#    AND Orders.id="3183";
# INSERT INTO Orders SET id="3183";
# INSERT INTO __Nodes__ SET node=1413137867, nodec=0, type="table", hash="d1d275556d424415c9aa7b29543ac5cb", str='Orders,id=\"3183\"';
# SELECT __Nodes__.id,__Nodes__.node,__Nodes__.nodec
#   FROM __Nodes__,Customers
#  WHERE __Nodes__.type="table"
#    AND __Nodes__.str='Customers,id=\"1\"'
#    AND Customers.id="1";
# INSERT INTO Customers SET id="1";
# INSERT INTO __Nodes__ SET node=945509795, nodec=0, type="table", hash="6b18f150658a259bc8ff9f0d385b55a3", str='Customers,id=\"1\"';
# SELECT __Nodes__.id,__Nodes__.node,__Nodes__.nodec
#   FROM __Nodes__
#  WHERE __Nodes__.type="uri"
#    AND __Nodes__.hash="c53e2787d7abb196ca542817f0949d2f";
# INSERT INTO __Nodes__ SET node=4036271407, nodec=0, type="uri", hash="c53e2787d7abb196ca542817f0949d2f", str='fake:/W3C::Rdf::SqlDB=HASH(0x88d8068)';
# SELECT __Attributions__.id
#   FROM __Attributions__
#  WHERE __Attributions__.doc=268;
# INSERT INTO __Attributions__ SET type="source", doc=268, created=now();
# INSERT INTO __Holds__ SET p=521921737, pc=0, s=1413137867, sc=0, o=945509795, oc=0, a=2;
# SELECT __Nodes__.id,__Nodes__.node,__Nodes__.nodec
#   FROM __Nodes__
#  WHERE __Nodes__.type="uri"
#    AND __Nodes__.hash="529f266cde57dc96c80808b656ed443d";
# INSERT INTO __Nodes__ SET node=1458390077, nodec=0, type="uri", hash="529f266cde57dc96c80808b656ed443d", str='http://example.com/sales#marketingProfile';
# SELECT __Nodes__.id,__Nodes__.node,__Nodes__.nodec
#   FROM __Nodes__,Customers
#  WHERE __Nodes__.type="table"
#    AND __Nodes__.str='Customers,id=\"2\"'
#    AND Customers.id="2";
# INSERT INTO Customers SET id="2";
# INSERT INTO __Nodes__ SET node=2934389102, nodec=0, type="table", hash="f3674552ee175a08ad4db6c8aee7396e", str='Customers,id=\"2\"';
# SELECT __Nodes__.id,__Nodes__.node,__Nodes__.nodec
#   FROM __Nodes__
#  WHERE __Nodes__.type="bnode"
#    AND __Nodes__.hash="424b0f19dc87e38fb5c267dc36daae42";
# INSERT INTO __Nodes__ SET node=920301122, nodec=0, type="bnode", hash="424b0f19dc87e38fb5c267dc36daae42", str='_1:fake:/W3C::Rdf::SqlDB=HASH(0x88d8068)', attribOrDT="2";
# INSERT INTO __Holds__ SET p=1458390077, pc=0, s=2934389102, sc=0, o=920301122, oc=0, a=2;
# SELECT __Nodes__.id,__Nodes__.node,__Nodes__.nodec
#   FROM __Nodes__
#  WHERE __Nodes__.type="uri"
#    AND __Nodes__.hash="5e6674c7ae1dd319c7306c77c77fd1e7";
# INSERT INTO __Nodes__ SET node=3347042791, nodec=0, type="uri", hash="5e6674c7ae1dd319c7306c77c77fd1e7", str='http://example.com/sales#id';
# SELECT __Nodes__.id,__Nodes__.node,__Nodes__.nodec
#   FROM __Nodes__
#  WHERE __Nodes__.type="uri"
#    AND __Nodes__.hash="c3436bcb1a7f0283e3d80cd5b5e558a8";
# INSERT INTO __Nodes__ SET node=3051706536, nodec=0, type="uri", hash="c3436bcb1a7f0283e3d80cd5b5e558a8", str='http://example.com/sales#suburbanDad';
# INSERT INTO __Holds__ SET p=3347042791, pc=0, s=920301122, sc=0, o=3051706536, oc=0, a=2;
# SELECT __Nodes__.id,__Nodes__.node,__Nodes__.nodec
#   FROM __Nodes__
#  WHERE __Nodes__.type="uri"
#    AND __Nodes__.hash="d75052e90e75e096a1e2aecfa3aa2e4f";
# INSERT INTO __Nodes__ SET node=2745839183, nodec=0, type="uri", hash="d75052e90e75e096a1e2aecfa3aa2e4f", str='http://example.com/sales#age';
# SELECT __Nodes__.id,__Nodes__.node,__Nodes__.nodec
#   FROM __Nodes__
#  WHERE __Nodes__.type="uri"
#    AND __Nodes__.hash="0ebe96c7396884ec39ea3d0cc92e67dd";
# INSERT INTO __Nodes__ SET node=3375261661, nodec=0, type="uri", hash="0ebe96c7396884ec39ea3d0cc92e67dd", str='http://www.w3.org/2001/XMLSchema#int';
# SELECT __Nodes__.id,__Nodes__.node,__Nodes__.nodec
#   FROM __Nodes__
#  WHERE __Nodes__.type="literal"
#    AND __Nodes__.hash="6152bbd954a78ea1254f9aff41b04555";
# INSERT INTO __Nodes__ SET node=1102071125, nodec=0, type="literal", hash="6152bbd954a78ea1254f9aff41b04555", str='275P:40', attribOrDT="275";
# INSERT INTO __Holds__ SET p=2745839183, pc=0, s=920301122, sc=0, o=1102071125, oc=0, a=2;
# SELECT __Nodes__.id,__Nodes__.node,__Nodes__.nodec
#   FROM __Nodes__
#  WHERE __Nodes__.type="uri"
#    AND __Nodes__.hash="76435210e60ff218f11cb8d3429e5f65";
# INSERT INTO __Nodes__ SET node=1117675365, nodec=0, type="uri", hash="76435210e60ff218f11cb8d3429e5f65", str='http://example.com/sales#desc';
# SELECT __Nodes__.id,__Nodes__.node,__Nodes__.nodec
#   FROM __Nodes__
#  WHERE __Nodes__.type="literal"
#    AND __Nodes__.hash="083b45594be0135d32365b3d1090983a";
# INSERT INTO __Nodes__ SET node=277911610, nodec=0, type="literal", hash="083b45594be0135d32365b3d1090983a", str='P:suburban dad';
# INSERT INTO __Holds__ SET p=1117675365, pc=0, s=920301122, sc=0, o=277911610, oc=0, a=2;
# SELECT __Nodes__.id,__Nodes__.node,__Nodes__.nodec
#   FROM __Nodes__
#  WHERE __Nodes__.type="uri"
#    AND __Nodes__.hash="3c7dedb10bf52f57e36c44ceab33ccab";
# INSERT INTO __Nodes__ SET node=2872298667, nodec=0, type="uri", hash="3c7dedb10bf52f57e36c44ceab33ccab", str='http://example.com/sales#markup';
# SELECT __Nodes__.id,__Nodes__.node,__Nodes__.nodec
#   FROM __Nodes__
#  WHERE __Nodes__.type="literal"
#    AND __Nodes__.hash="623ffd40a7616593704f8fa027a6a78c";
# INSERT INTO __Nodes__ SET node=665233292, nodec=0, type="literal", hash="623ffd40a7616593704f8fa027a6a78c", str='Xen-US:<em>super</em> dad';
# INSERT INTO __Holds__ SET p=2872298667, pc=0, s=920301122, sc=0, o=665233292, oc=0, a=2;
# SELECT __Nodes__.id,__Nodes__.node,__Nodes__.nodec
#   FROM __Nodes__
#  WHERE __Nodes__.type="literal"
#    AND __Nodes__.hash="f82fe6dce04ef5b0272d84ccbbf45575";
# INSERT INTO __Nodes__ SET node=3153352053, nodec=0, type="literal", hash="f82fe6dce04ef5b0272d84ccbbf45575", str='Xfr:papa <em>superbe</em>';
# INSERT INTO __Holds__ SET p=2872298667, pc=0, s=920301122, sc=0, o=3153352053, oc=0, a=2;
# SELECT __Nodes__.id,__Nodes__.node,__Nodes__.nodec
#   FROM __Nodes__
#  WHERE __Nodes__.type="literal"
#    AND __Nodes__.hash="9b472426fd135b5178339fff7326cf2f";
# INSERT INTO __Nodes__ SET node=1931923247, nodec=0, type="literal", hash="9b472426fd135b5178339fff7326cf2f", str='Xx-pig-latin:<em>upersay</em> addsay';
# INSERT INTO __Holds__ SET p=2872298667, pc=0, s=920301122, sc=0, o=1931923247, oc=0, a=2;
# SELECT __Nodes__.id,__Nodes__.node,__Nodes__.nodec
#   FROM __Nodes__
#  WHERE __Nodes__.type="uri"
#    AND __Nodes__.hash="0498adc71af3ac1762520a75fb28a6a3";
# INSERT INTO __Nodes__ SET node=4213745315, nodec=0, type="uri", hash="0498adc71af3ac1762520a75fb28a6a3", str='http://example.com/sales#longDesc';
# SELECT __Nodes__.id,__Nodes__.node,__Nodes__.nodec
#   FROM __Nodes__
#  WHERE __Nodes__.type="literal"
#    AND __Nodes__.hash="6817a77b75c731516c94326229a80c37";
# INSERT INTO __Big__ SET hash="6817a77b75c731516c94326229a80c37", str='X:<?xml version=\'1.0\' encoding=\'iso-8859-1\'?>\n<!DOCTYPE html PUBLIC \'-//W3C//DTD XHTML 1.1//EN\' \'http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd\'>\n<html>\n  <head>\n    <title>Marketing Profile for Biff Thompson</title>\n  </head>\n  <body>\n    <p>Biff Thompson has it all, a white house with a picket fence, we\n    really should try to sell him a pool.</p>\n  </body>\n</html>';
# INSERT INTO __Nodes__ SET node=698879031, nodec=0, type="literal", hash="6817a77b75c731516c94326229a80c37", str="SELECT str FROM __Big__ WHERE id=19", big=19;
# INSERT INTO __Holds__ SET p=4213745315, pc=0, s=920301122, sc=0, o=698879031, oc=0, a=2;

