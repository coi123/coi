#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# ProfileQuery0 - test profile reflection
#   - profiles
#   - profile reflection
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: ProfileQuery0-alg.sh,v 1.3 2005/08/03 19:47:53 eric Exp $
###############################################################################

algae $* \
--lang Algae \
"
ns pq=<http://lists.w3.org/Archives/Public/public-rdf-dawg/2004AprJun/0699.html#>
require pq:profileQuery
profileQuery(pq:profileList ?p)
collect (?p)
" \

# Table Results:
# +---------------------------------------------------------------------------------------+
# |                                                                                      p|
# |---------------------------------------------------------------------------------------|
# |                                             <http://www.w3.org/2004/05/06-Algae/#core>|
# |                                           <http://www.w3.org/2004/06/20-rules/#assert>|
# |<http://lists.w3.org/Archives/Public/public-rdf-dawg/2004AprJun/0699.html#profileQuery>|
# +---------------------------------------------------------------------------------------+

