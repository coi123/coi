#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# GenericStore0 - Dump triple store
# Tests:
#   - access to ObjectDB
#   - ObjectDB's interpretation of AlgaeStructure
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: GenericStore0-alg.sh,v 1.5 2004/06/23 12:32:18 eric Exp $
###############################################################################

algae $* \
"
ns <http://localhost/OrderTracking#>
attach <http://www.w3.org/1999/02/26-modules/algae#sql> ?test1 (
                    properties=\"../test/genericTripleStore.prop\")
ask ?test1 (
       ?s	?p	?o .
      )
collect (?p ?s ?o) 
" \

# Table Results:

# SQL Query:

