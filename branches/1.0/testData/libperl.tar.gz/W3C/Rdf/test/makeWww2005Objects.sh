../../Database/bin/object_maker $* \
-p www2005.prop www2005 \
-n W3C::Rdf::test::www2005Objects \
-h www2005Objects.html \
-m "{Event.track=>Track.id, 
     Role.event=>Event.id, 
     Role.person=>Person.id, 
     Person.organization=>Organization.id
    }" \
> www2005Objects.pm
