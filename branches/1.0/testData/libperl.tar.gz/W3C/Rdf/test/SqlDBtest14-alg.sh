#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# SqlDBtest14 - 
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: SqlDBtest14-alg.sh,v 1.3 2004/06/23 12:32:18 eric Exp $
###############################################################################

 algae $* \
"(
 namespace '(testDB http://localhost/SqlDBtest#
             acl http://www.w3.org/2001/02/acls/ns#
             rdf http://www.w3.org/1999/02/22-rdf-syntax-ns#) 
 attach '(\"W3C::Rdf::SqlDB\" (\"properties:SqlDBtest.prop\" \"name:testDB::test1\"))
 ask '(testDB::test1
       (testDB::A.u1	http://localhost/SqlDBtest#A.u0=0&u1=102	?u)
       (testDB::A.p1	http://localhost/SqlDBtest#A.u0=0&u1=102	?b)
       (testDB::A.p2	http://localhost/SqlDBtest#A.u0=0&u1=102	http://localhost/SqlDBtest#C.key1=302)
       (testDB::A.p3	http://localhost/SqlDBtest#A.u0=0&u1=102	?f)
       (testDB::A.p4	http://localhost/SqlDBtest#A.u0=0&u1=102	?d)
       (testDB::B.p5	?b	?g)
       (testDB::B.p6	?b	?e)
      )
 collect '(?d http://localhost/SqlDBtest#A.u0=0&u1=102 ?b http://localhost/SqlDBtest#C.key1=302) 
)" \

# SELECT A_0.u1 AS u_u1,
# B_0.key0 AS b_key0,
#        C_1.key1 AS f_key1,
#        A_0.p4 AS d_p4,
# C_2.key1 AS g_key1,
#        C_3.key1 AS e_key1
# FROM A AS A_0, B AS B_0, C AS C_0, C AS C_1, C AS C_2, C AS C_3
# WHERE A_0.u0="0"
#   AND A_0.u1="102"
#   AND A_0.p1=B_0.key0
#   AND C_0.key1="302"
#   AND A_0.p2=C_0.key1
#   AND A_0.p3=C_1.key1
#   AND B_0.p5=C_2.key1
#   AND B_0.p6=C_3.key1

# +----------+------------------------------------------+---------------------------------------+---------------------------------------+
# |         d|<http://localhost/SqlDBtest#A.u0=0&u1=102>|                                      b|<http://localhost/SqlDBtest#C.key1=302>|
# |----------|------------------------------------------|---------------------------------------|---------------------------------------|
# |"B2,C2,C1"|<http://localhost/SqlDBtest#A.u0=0&u1=102>|<http://localhost/SqlDBtest#B.key0=202>|<http://localhost/SqlDBtest#C.key1=302>|
# +----------+------------------------------------------+---------------------------------------+---------------------------------------+

