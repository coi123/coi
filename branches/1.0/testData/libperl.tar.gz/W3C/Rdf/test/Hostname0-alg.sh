#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# Hostname0 - test extensible value testing
#   - checks the hosthame of documents.
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: Hostname0-alg.sh,v 1.3 2005/08/03 19:47:53 eric Exp $
###############################################################################

algae $* 
--lang Algae \
"
ns <http://purl.org/rss/1.0/>
ns da=<http://www.w3.org/2001/sw/DataAccess/>
ns ex=<http://example.org/foo/bar/>

# Get some data to play with.
require <http://www.w3.org/2004/06/20-rules/#assert>
assert (
 da:UseCases title \"RDF Data Access Use Cases and Requirements\" ;
             link <http://www.w3.org/2001/sw/DataAccess/> ;
             description \"specifies use cases, requirements, ...\" .

 ex:someDoc title \"Title of Some Document\" ;
            link <http://example.org/foo/bar/> ;
            description \"A more verbose description of some document.\"
)

# Play with it.
ns prov=<http://example.org/provenanceStuff#>
require prov:profile
ask (?article title ?title ;
              link ?link {hostname(?link) == \"www.w3.org\"} ;
              description ?description)

collect (?title ?link ?description)
" \

# Table Results:
# +--------------------------------------------+---------------------------------------+----------------------------------------+
# |                                       title|                                   link|                             description|
# |--------------------------------------------|---------------------------------------|----------------------------------------|
# |"RDF Data Access Use Cases and Requirements"|<http://www.w3.org/2001/sw/DataAccess/>|"specifies use cases, requirements, ..."|
# +--------------------------------------------+---------------------------------------+----------------------------------------+

