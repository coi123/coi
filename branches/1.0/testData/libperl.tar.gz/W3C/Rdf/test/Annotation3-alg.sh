#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# Annotation2 - Inept Annotea query.
# Tests:
#   - optimization of compile-tree
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: Annotation3-alg.sh,v 1.9 2005/08/03 19:47:53 eric Exp $
###############################################################################

algae $* \
--lang Algae \
#--reportClass n3 \
#--reportParm -stream=1 \
"
ns rdf=<http://www.w3.org/1999/02/22-rdf-syntax-ns#>
ns a=<http://www.w3.org/2000/10/annotation-ns#>
ns http=<http://www.w3.org/1999/xx/http#>
ns d0=<http://purl.org/dc/elements/1.0/>
ns d1=<http://purl.org/dc/elements/1.1/>
attach <http://www.w3.org/1999/02/26-modules/algae#sql> ?db (
                    properties=\"../test/genericTripleStore.prop\")
slurp <../test/Annotation1052587433.529382.rdf> ?db ()
ns alg=<http://www.w3.org/1999/02/26-modules/algae#>
ask ?db (
       ?annotation rdf:type a:Annotation {%ATTRIB == <../test/Annotation1052587433.529382.rdf>}.
       (?annotation a:annotates ?annotates.?annotation d0:title ?title ||
        ?annotation a:annotates ?annotates.?annotation d1:title ?title).
       ?annotation a:annotates ?annotates.
       ?annotation a:context ?context.
       ?annotation a:body ?body {%ATTRIB == <../test/Annotation1052587433.529382.rdf>}
      )
select (?annotation ?body ?title)
" \

# Table Results:
# +-------------------------------------------------------------+-------------------------------------------------------+-----------------------------------+
# |                                                   annotation|                                                   body|                              title|
# |-------------------------------------------------------------|-------------------------------------------------------|-----------------------------------|
# |<http://iggy.w3.org/annotations/annotation/1052587433.529382>|<http://iggy.w3.org/annotations/body/1052587433.529382>|"Old Annotation of Eric's Homepage"|
# |<http://iggy.w3.org/annotations/annotation/1054553215.108988>|<http://iggy.w3.org/annotations/body/1054553215.108988>|"New Annotation of Eric's Homepage"|
# +-------------------------------------------------------------+-------------------------------------------------------+-----------------------------------+

# SQL Query:
