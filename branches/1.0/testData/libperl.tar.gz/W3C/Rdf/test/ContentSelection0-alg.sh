#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# ContentSelection0 - schema-defined aboutEachPrefix
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: ContentSelection0-alg.sh,v 1.2 2004/06/23 12:32:17 eric Exp $
###############################################################################

algae $* \
"
ns r=<http://www.w3.org/1999/02/22-rdf-syntax-ns#>
ns p=<http://www.w3.org/TR/WD-pics2.0#>
slurp ../../../../../../../WWW/2004/05/07-CS-RDF/ratingData.rdf ()
ask (?r p:aboutEachPrefix ?pre .
     ?r p:violentContent ?vc {?vc < 3})
collect (?pre ?vc)
" \

# +-----------------------------------+---+
# |                                pre| vc|
# |-----------------------------------|---|
# |"http://example.org/mayhem/flowers"|"0"|
# |   "http://example.org/familyStuff"|"0"|
# +-----------------------------------+---+

