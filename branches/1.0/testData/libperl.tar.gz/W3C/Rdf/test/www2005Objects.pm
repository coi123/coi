@W3C::Rdf::test::www2005Objects::Event::ISA = ( 'W3C::Database::ObjectBase' );
$W3C::Rdf::test::www2005Objects::Event::type_TALK = 0;
$W3C::Rdf::test::www2005Objects::Event::type_KEYNOTE = 1;
$W3C::Rdf::test::www2005Objects::Event::type_FOOD = 2;
%W3C::Rdf::test::www2005Objects::Event::type_to_string = ( '1' => 'keynote',
                                                           '0' => 'talk',
                                                           '2' => 'food' );
%W3C::Rdf::test::www2005Objects::Event::string_to_type = ( 'food' => 2,
                                                           'talk' => 0,
                                                           'keynote' => 1 );
%W3C::Rdf::test::www2005Objects::Event::_TableDesc = ( '-table' => 'Event',
                                                       '-class' => 'W3C::Rdf::test::www2005Objects::Event',
                                                       '-index' => { 'u_date_time_track' => { '-sequence' => [ 'date',
                                                                                                               'time',
                                                                                                               'track' ],
                                                                                              '-unique' => '1',
                                                                                              '-fields' => { 'track' => 2,
                                                                                                             'time' => 1,
                                                                                                             'date' => 0 } } },
                                                       '-primaryKey' => 'id',
                                                       '-fields' => { 'track' => { '-target' => [ 'Track',
                                                                                                  'id' ],
                                                                                   '-type' => 0,
                                                                                   '-default' => '0',
                                                                                   '-size' => '11' },
                                                                      'time' => { '-type' => 9,
                                                                                  '-null' => 1 },
                                                                      'date' => { '-type' => 8,
                                                                                  '-null' => 1 },
                                                                      'name' => { '-type' => 5,
                                                                                  '-size' => '255',
                                                                                  '-null' => 1 },
                                                                      'type' => { '-type' => 3,
                                                                                  '-stringsTo' => \%W3C::Rdf::test::www2005Objects::Event::string_to_type,
                                                                                  '-values' => [ 'talk',
                                                                                                 'keynote',
                                                                                                 'food' ],
                                                                                  '-null' => 1,
                                                                                  '-toStrings' => \%W3C::Rdf::test::www2005Objects::Event::type_to_string },
                                                                      'id' => { '-type' => 0,
                                                                                '-default' => '0',
                                                                                '-size' => '11' } },
                                                       '-fieldOrder' => [ 'id',
                                                                          'type',
                                                                          'date',
                                                                          'time',
                                                                          'track',
                                                                          'name' ] );
$W3C::Rdf::test::www2005Objects::_AllTables{'Event'} = \%W3C::Rdf::test::www2005Objects::Event::_TableDesc;
sub W3C::Rdf::test::www2005Objects::Event::getTableDesc {return \%W3C::Rdf::test::www2005Objects::Event::_TableDesc;}

@W3C::Rdf::test::www2005Objects::Organization::ISA = ( 'W3C::Database::ObjectBase' );
%W3C::Rdf::test::www2005Objects::Organization::_TableDesc = ( '-table' => 'Organization',
                                                              '-class' => 'W3C::Rdf::test::www2005Objects::Organization',
                                                              '-index' => { 'u_name_address' => { '-sequence' => [ 'name',
                                                                                                                   'address' ],
                                                                                                  '-unique' => '1',
                                                                                                  '-fields' => { 'name' => 0,
                                                                                                                 'address' => 1 } } },
                                                              '-primaryKey' => 'id',
                                                              '-fields' => { 'name' => { '-type' => 4,
                                                                                         '-size' => '64',
                                                                                         '-null' => 1 },
                                                                             'address' => { '-type' => 4,
                                                                                            '-size' => '191',
                                                                                            '-null' => 1 },
                                                                             'id' => { '-type' => 0,
                                                                                       '-default' => '0',
                                                                                       '-size' => '11' } },
                                                              '-fieldOrder' => [ 'id',
                                                                                 'name',
                                                                                 'address' ] );
$W3C::Rdf::test::www2005Objects::_AllTables{'Organization'} = \%W3C::Rdf::test::www2005Objects::Organization::_TableDesc;
sub W3C::Rdf::test::www2005Objects::Organization::getTableDesc {return \%W3C::Rdf::test::www2005Objects::Organization::_TableDesc;}

@W3C::Rdf::test::www2005Objects::Person::ISA = ( 'W3C::Database::ObjectBase' );
%W3C::Rdf::test::www2005Objects::Person::_TableDesc = ( '-table' => 'Person',
                                                        '-class' => 'W3C::Rdf::test::www2005Objects::Person',
                                                        '-index' => { 'u_givenName_familyName_organization' => { '-sequence' => [ 'givenName',
                                                                                                                                  'familyName',
                                                                                                                                  'organization' ],
                                                                                                                 '-unique' => '1',
                                                                                                                 '-fields' => { 'familyName' => 1,
                                                                                                                                'givenName' => 0,
                                                                                                                                'organization' => 2 } } },
                                                        '-primaryKey' => 'id',
                                                        '-fields' => { 'id' => { '-type' => 0,
                                                                                 '-default' => '0',
                                                                                 '-size' => '11' },
                                                                       'familyName' => { '-type' => 4,
                                                                                         '-size' => '80',
                                                                                         '-null' => 1 },
                                                                       'givenName' => { '-type' => 4,
                                                                                        '-size' => '80',
                                                                                        '-null' => 1 },
                                                                       'organization' => { '-target' => [ 'Organization',
                                                                                                          'id' ],
                                                                                           '-type' => 0,
                                                                                           '-default' => '0',
                                                                                           '-size' => '11' } },
                                                        '-fieldOrder' => [ 'id',
                                                                           'givenName',
                                                                           'familyName',
                                                                           'organization' ] );
$W3C::Rdf::test::www2005Objects::_AllTables{'Person'} = \%W3C::Rdf::test::www2005Objects::Person::_TableDesc;
sub W3C::Rdf::test::www2005Objects::Person::getTableDesc {return \%W3C::Rdf::test::www2005Objects::Person::_TableDesc;}

@W3C::Rdf::test::www2005Objects::Role::ISA = ( 'W3C::Database::ObjectBase' );
$W3C::Rdf::test::www2005Objects::Role::role_AUTHOR = 0;
$W3C::Rdf::test::www2005Objects::Role::role_PRESENTER = 1;
$W3C::Rdf::test::www2005Objects::Role::role_OBSERVER = 2;
%W3C::Rdf::test::www2005Objects::Role::role_to_string = ( '1' => 'presenter',
                                                          '0' => 'author',
                                                          '2' => 'observer' );
%W3C::Rdf::test::www2005Objects::Role::string_to_role = ( 'presenter' => 1,
                                                          'author' => 0,
                                                          'observer' => 2 );
%W3C::Rdf::test::www2005Objects::Role::_TableDesc = ( '-table' => 'Role',
                                                      '-class' => 'W3C::Rdf::test::www2005Objects::Role',
                                                      '-index' => { 'PRIMARY' => { '-sequence' => [ 'event',
                                                                                                    'person',
                                                                                                    'role' ],
                                                                                   '-unique' => '1',
                                                                                   '-fields' => { 'person' => 1,
                                                                                                  'role' => 2,
                                                                                                  'event' => 0 } } },
                                                      '-primaryKey' => [ 'event',
                                                                         'person',
                                                                         'role' ],
                                                      '-fields' => { 'person' => { '-target' => [ 'Person',
                                                                                                  'id' ],
                                                                                   '-type' => 0,
                                                                                   '-default' => '0',
                                                                                   '-size' => '11' },
                                                                     'role' => { '-type' => 3,
                                                                                 '-default' => 'author',
                                                                                 '-stringsTo' => \%W3C::Rdf::test::www2005Objects::Role::string_to_role,
                                                                                 '-values' => [ 'author',
                                                                                                'presenter',
                                                                                                'observer' ],
                                                                                 '-toStrings' => \%W3C::Rdf::test::www2005Objects::Role::role_to_string },
                                                                     'event' => { '-target' => [ 'Event',
                                                                                                 'id' ],
                                                                                  '-type' => 0,
                                                                                  '-default' => '0',
                                                                                  '-size' => '11' } },
                                                      '-fieldOrder' => [ 'event',
                                                                         'person',
                                                                         'role' ] );
$W3C::Rdf::test::www2005Objects::_AllTables{'Role'} = \%W3C::Rdf::test::www2005Objects::Role::_TableDesc;
sub W3C::Rdf::test::www2005Objects::Role::getTableDesc {return \%W3C::Rdf::test::www2005Objects::Role::_TableDesc;}

@W3C::Rdf::test::www2005Objects::Track::ISA = ( 'W3C::Database::ObjectBase' );
%W3C::Rdf::test::www2005Objects::Track::_TableDesc = ( '-table' => 'Track',
                                                       '-class' => 'W3C::Rdf::test::www2005Objects::Track',
                                                       '-index' => { 'u_name' => { '-sequence' => [ 'name' ],
                                                                                   '-unique' => '1',
                                                                                   '-fields' => { 'name' => 0 } } },
                                                       '-primaryKey' => 'id',
                                                       '-fields' => { 'name' => { '-type' => 4,
                                                                                  '-size' => '20',
                                                                                  '-null' => 1 },
                                                                      'id' => { '-type' => 0,
                                                                                '-default' => '0',
                                                                                '-size' => '11' } },
                                                       '-fieldOrder' => [ 'id',
                                                                          'name' ] );
$W3C::Rdf::test::www2005Objects::_AllTables{'Track'} = \%W3C::Rdf::test::www2005Objects::Track::_TableDesc;
sub W3C::Rdf::test::www2005Objects::Track::getTableDesc {return \%W3C::Rdf::test::www2005Objects::Track::_TableDesc;}

@W3C::Rdf::test::www2005Objects::_TableOrder = ( 'Event',
                                                 'Organization',
                                                 'Person',
                                                 'Role',
                                                 'Track' );
