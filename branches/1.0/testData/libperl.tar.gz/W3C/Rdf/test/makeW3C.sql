-- Set up w3c database for sample ACL queries
--
-- used in aclQuery1.alg and aclQuery2.alg
-- $Id: makeW3C.sql,v 1.2 2002/12/09 17:59:09 eric Exp $

-- MySQL dump 8.22
--
-- Host: localhost    Database: w3c
---------------------------------------------------------
-- Server version	3.23.53-log

--
-- Table structure for table 'ids'
--

CREATE TABLE ids (
  id int(10) unsigned NOT NULL auto_increment,
  stops int(10) unsigned default '0',
  type char(1) binary NOT NULL default '',
  value varchar(40) binary NOT NULL default '',
  pubKey text,
  expire date default NULL,
  info varchar(80) default NULL,
  last timestamp(14) NOT NULL,
  orgId int(10) unsigned NOT NULL default '0',
  sponsor varchar(32) default NULL,
  fmp int(1) default NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY value (type,value),
  KEY value_idx (type,value),
  UNIQUE KEY u_value (value)
) TYPE=ISAM PACK_KEYS=1;

INSERT INTO ids (id,stops,type,value) VALUES (100, 0, 'G', "cabal");
INSERT INTO ids (id,stops,type,value) VALUES (101, 0, 'G', "CERN-group");
INSERT INTO ids (id,stops,type,value) VALUES (102, 0, 'G', "w3cteamgroup");
INSERT INTO ids (id,stops,type,value) VALUES (1023, 0, 'G', "w3clagroup");
INSERT INTO ids (id,stops,type,value) VALUES (6050, 0, 'G', "WAIsteer");
INSERT INTO ids (id,stops,type,value) VALUES (2112, 0, 'U', "eric");

--
-- Table structure for table 'idInclusions'
--

CREATE TABLE idInclusions (
  id int(10) unsigned NOT NULL default '0',
  type char(1) binary NOT NULL default '',
  groupId int(10) unsigned NOT NULL default '0',
  g int(11) default NULL,
  PRIMARY KEY  (id,groupId)
) TYPE=ISAM PACK_KEYS=1;

INSERT INTO idInclusions (id,type,groupId,g) VALUES (2112, 'U', 100, 3);
INSERT INTO idInclusions (id,type,groupId,g) VALUES (2112, 'U', 102, 3);

INSERT INTO idInclusions (id,type,groupId,g) VALUES (2112, 'U', 103, 3);
INSERT INTO idInclusions (id,type,groupId,g) VALUES (2112, 'U', 104, 3);
INSERT INTO idInclusions (id,type,groupId,g) VALUES (2112, 'U', 105, 2);
INSERT INTO idInclusions (id,type,groupId,g) VALUES (2112, 'U', 106, 1);
INSERT INTO idInclusions (id,type,groupId,g) VALUES (2112, 'U', 115, 3);
INSERT INTO idInclusions (id,type,groupId,g) VALUES (2112, 'U', 117, 3);
INSERT INTO idInclusions (id,type,groupId,g) VALUES (2112, 'U', 120, 2);
INSERT INTO idInclusions (id,type,groupId,g) VALUES (2112, 'U', 2112, 0);
INSERT INTO idInclusions (id,type,groupId,g) VALUES (2112, 'U', 7756, 3);
INSERT INTO idInclusions (id,type,groupId,g) VALUES (2112, 'U', 9546, 3);
INSERT INTO idInclusions (id,type,groupId,g) VALUES (2112, 'U', 10892, 1);
INSERT INTO idInclusions (id,type,groupId,g) VALUES (2112, 'U', 21483, 3);
INSERT INTO idInclusions (id,type,groupId,g) VALUES (2112, 'U', 28030, 2);

--
-- Table structure for table 'acls'
--

CREATE TABLE acls (
  acl int(10) unsigned NOT NULL auto_increment,
  type char(1) binary NOT NULL default '',
  id int(10) unsigned NOT NULL default '0',
  access int(10) unsigned NOT NULL default '0',
  last timestamp(14) NOT NULL,
  PRIMARY KEY  (acl,id,access)
) TYPE=MyISAM;

INSERT INTO acls (acl, type, id, access) VALUES (6, 'G', 100, 3122);
INSERT INTO acls (acl, type, id, access) VALUES (6, 'G', 102, 3955);

INSERT INTO acls (acl, type, id, access) VALUES (7, 'A',   1, 3122);
INSERT INTO acls (acl, type, id, access) VALUES (7, 'G', 102, 3955);

INSERT INTO acls (acl, type, id, access) VALUES (121, 'G', 102, 3955);
INSERT INTO acls (acl, type, id, access) VALUES (121, 'G', 6050, 48);

INSERT INTO acls (acl, type, id, access) VALUES (26, 'G', 101, 3122);
INSERT INTO acls (acl, type, id, access) VALUES (26, 'G', 102, 3955);
INSERT INTO acls (acl, type, id, access) VALUES (26, 'G', 103, 3122);

--
-- Table structure for table 'uris'
--

CREATE TABLE uris (
  id int(10) unsigned NOT NULL auto_increment,
  uri varchar(255) binary NOT NULL default '',
  acl int(10) unsigned NOT NULL default '0',
  last timestamp(14) NOT NULL,
  idsId int(10) unsigned default NULL,
  valid char(1) NOT NULL default 'n',
  PRIMARY KEY  (id),
  UNIQUE KEY uri (uri),
  KEY uri_idx (uri(32)),
  KEY uris_valid (valid),
  KEY uris_acl (acl),
  KEY i_last (last)
) TYPE=ISAM PACK_KEYS=1;

INSERT INTO uris (id, uri, acl) VALUES (810, "http://www.w3.org/Member/Overview.html", 6);
INSERT INTO uris (id, uri, acl) VALUES (1991, "http://www.w3.org/Overview.html", 7);
INSERT INTO uris (id, uri, acl) VALUES (36297, "http://www.w3.org/robots.txt", 7);
INSERT INTO uris (id, uri, acl) VALUES (128543, "http://www.w3.org/WAI/Steer/", 121);
INSERT INTO uris (id, uri, acl) VALUES (47008, "http://www.w3.org/W3C-LA/Partner/Talks/", 26);

