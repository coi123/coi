#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# TAP1 - 
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: TAP1-alg.sh,v 1.3 2004/06/23 12:32:18 eric Exp $
###############################################################################

algae $* \
"
ns db=<http://example.com/>
ns tap=<http://tap.stanford.edu/data/>
ns person=<http://tap.stanford.edu/data/W3CPersonMiller,>
attach <http://www.w3.org/1999/02/26-modules/algae#dynamic> ?tapdb (
	class=\"W3C::Rdf::TAPDB\" server=<http://localhost:8888/data/>)
ask ?tapdb (
       <http://tap.stanford.edu/data/W3CPersonMiller,_Eric> tap:worksFor ?w .
       <http://tap.stanford.edu/data/W3CPersonMiller,_Eric> tap:imageURL ?img .
       ?doc tap:hasAuthor <http://tap.stanford.edu/data/W3CPersonMiller,_Eric> .
       ~?foo tap:hibbyHop <http://tap.stanford.edu/data/W3CPersonMiller,_Eric>)
 collect (?w ?img ?doc ?foo)
" \

