../../Database/bin/object_maker $* \
-p WWW2005.prop WWW2005 \
-n W3C::Rdf::test::WWW2005Objects \
-h WWW2005Objects.html \
-m "{Chair.track=>Track._id,
Chair.person=>Person._id,
ProgramCommittee.track=>Track._id,
ProgramCommittee.person=>Person._id,
Author.paper=>Paper._id,
Session.room=>Room._id,
SessionPaper.session=>Session._id,
SessionPaper.paper=>Paper._id,
Paper.session=>Session._id,
Program.date=>Date.date,
ProgramSession.program=>Program._id,
ProgramSession.session=>Session._id,
Program.session=>Session._id,
Partner.width=>undef,
Partner.height=>undef
    }" \
> WWW2005Objects.pm
