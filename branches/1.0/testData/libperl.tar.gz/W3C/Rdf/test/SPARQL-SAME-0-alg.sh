#!/bin/sh

###############################################################################
# Copyright 2004 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# SPARQL-DT-0 - SPARQL Datatype tester.
# Tests:
#   - whether different datatypes restricted from decimal have the same value.
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: SPARQL-SAME-0-alg.sh,v 1.1 2005/04/08 09:41:50 eric Exp $
###############################################################################

algae $* \
--lang n3 \
"
@prefix foaf: <foaf> .
<a> foaf:knows <a>.
<a> foaf:knows <b>.
"
--lang SPARQL \
"
PREFIX foaf: <foaf>
SELECT ?k1 ?k2
 WHERE { ?s1 foaf:knows ?k1 .
         ?s1 foaf:knows ?k2 .
FILTER !sameAs(?k1, ?k2) }
" \

# Table Results:
# +--------------------------------------------------------------------------+--------------------------------------------------------------------------+
# |                                                                        k1|                                                                        k2|
# |--------------------------------------------------------------------------|--------------------------------------------------------------------------|
# |<file://unagi.w3.org/home/eric/sources/public/perl/modules/W3C/Rdf/test/a>|<file://unagi.w3.org/home/eric/sources/public/perl/modules/W3C/Rdf/test/b>|
# |<file://unagi.w3.org/home/eric/sources/public/perl/modules/W3C/Rdf/test/b>|<file://unagi.w3.org/home/eric/sources/public/perl/modules/W3C/Rdf/test/a>|
# +--------------------------------------------------------------------------+--------------------------------------------------------------------------+

