#!/usr/bin/perl

$REVISION = '$Id: appTest3.pl,v 1.2 2004/06/08 06:51:01 eric Exp $ ';

use strict;

#BEGIN {unshift@INC,('../../..');}
use vars qw(@ISA);
@ISA = qw(W3C::Rdf::RdfApp);

use W3C::Rdf::SqlDB;
use W3C::Rdf::Atoms qw(&registerDB &getTie);
use W3C::Util::Exception;
eval {
# Prepare and use SQL database.
my $atomDict = new W3C::Rdf::Atoms();
my $rdfDB = new W3C::Rdf::SqlDB(-properties => 'OrderTracking.prop', -atomDictionary => $atomDict);
my $db = 'http://localhost/OrderTracking#';
&registerDB($rdfDB);

# Query via tie interface.
my $productName = &getTie('"nose ring"');
my $product = $productName->{"-<${db}Products.name>"};
my $order = $product->{"-<${db}Orders.product>"};
my $customer = $order->{"<${db}Orders.customer>"};
my $first = $customer->{"<${db}Customers.givenName>"}{-toString};
my $last = $customer->{"<${db}Customers.familyName>"}{-toString};
print "$last, $first\n";
}; if ($@) {if (my $ex = &catch('W3C::Util::Exception')) {
    die $ex->toString;
} else {
    die $@;
}}

