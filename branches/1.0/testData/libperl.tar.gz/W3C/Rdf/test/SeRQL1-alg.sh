#!/bin/sh

###############################################################################
# Copyright 2004 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# SeRQL1 - SeRQL tester.
# Tests:
#   - SeRQL CONSTRUCT clauses
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: SeRQL1-alg.sh,v 1.3 2004/06/26 01:39:55 eric Exp $
###############################################################################

algae $* \
-f ../test/Annotation1052587433.529382.rdf \
--lang SeRQL \
--reportClass n3 \
"
CONSTRUCT
   {s} p {<a:Bob>}
FROM
   {s} <rdf:type> {<a:Annotation>};
       p {o}
 WHERE label(o) = \"eric\" OR label(o) = \"joe\"
USING NAMESPACE
   rdf = <!http://www.w3.org/1999/02/22-rdf-syntax-ns#>,
     a = <!http://www.w3.org/2000/10/annotation-ns#>
" \


