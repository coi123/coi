#!/bin/sh

###############################################################################
# Copyright 2004 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# BRQL0 - BRQL tester.
# Tests:
#   - BRQL parser and it's use of Algae2 query structures
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: BRQL3-alg.sh,v 1.1 2004/09/13 14:30:27 eric Exp $
###############################################################################

algae $* \
--lang BRQL \
"
SELECT ?mbox ?name ?name2
FROM  <file:D.n3>
WHERE
  { ?x foaf:mbox ?mbox .
    ?x foaf:number ?n . ?n < 30 .
    OPTIONAL { ?x foaf:name ?name } .
    OPTIONAL { ?x foaf:knows ?y . OPTIONAL { ?y foaf:name ?name2 } }
  }
USING foaf FOR <http://xmlns.com/foaf/0.1/>
" \

