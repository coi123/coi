#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# OrderTracking8 - Heterogeneous database query for user-extended data.
# Tests:
#   - join against __Holds__
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: OrderTracking8-alg.sh,v 1.8 2004/10/06 15:18:44 eric Exp $
###############################################################################

algae $* \
"
ns ot=<http://localhost/OrderTracking#>
ns billing=<http://example.com/billing#>
ns alg=<http://www.w3.org/1999/02/26-modules/algae#>
attach <http://www.w3.org/2003/01/21-RDF-RDB-access/ns#SqlDB> ot:test1 (
                    properties=\"../test/OrderTracking.prop\")
flags (dumpQueryMode=alg:DOT
       dumpQueryURL=<file:OrderTracking8-query.dot>
       dumpQueryGraphMode=alg:DOT
       dumpQueryGraphURL=<file:OrderTracking8-queryGraph.dot>
       dumpCompiledMode=alg:DOT
       dumpCompiledURL=<file:OrderTracking8-compiled.dot>
       dumpCompiledGraphMode=alg:DOT
       dumpCompiledGraphURL=<file:OrderTracking8-compiledGraph.dot>)
ask ot:test1 (
       ?o	ot:Orders_customer		?c .
       ?o	billing:dontTell		?avoid .
       ?o	ot:Orders_product		?p .
       ?p	ot:Products_description		\"other ring\" .
       ?c	ot:Customers_givenName		\"Chip\" .
       ?c	ot:Customers_familyName		?last 
#       ?c       <http://example.com/sales#marketingProfile> ?profile
)
collect (?last ?avoid) # ?profile)
" \

#       ?o	ot:Orders_customer	?c .
#       ~?o	<http://example.com/sales#marketingProfile>	?profile .
#       ?o	ot:Orders_product	?p .
#      )
#collect (?profile ?o ?c ?p) 


# SELECT Orders_0.id AS o_id,
#        Customers_0.id AS c_id,
#        __Holds___0.a AS __Holds___0_a,
#        __Nodes___1.id AS __Nodes___1_o_id,
#        __Nodes___2.id AS __Nodes___2_avoid_id,
#        Products_0.id AS p_id,
#        Customers_0.familyName AS last_familyName
# FROM Orders AS Orders_0
#      INNER JOIN Customers AS Customers_0 ON Orders_0.customer=Customers_0.id
#      INNER JOIN __Holds__ AS __Holds___0 ON 1
#      INNER JOIN __Nodes__ AS __Nodes___0 ON __Holds___0.p=__Nodes___0.id
#      INNER JOIN __Nodes__ AS __Nodes___1 ON __Nodes___1.str=concat("Orders,id=\"",Orders_0.id,"\"") AND __Holds___0.s=__Nodes___1.id
#      INNER JOIN __Nodes__ AS __Nodes___2 ON __Holds___0.s=__Nodes___1.id AND __Holds___0.o=__Nodes___2.id
#      INNER JOIN Products AS Products_0 ON __Holds___0.o=__Nodes___2.id AND Orders_0.product=Products_0.id
# WHERE __Nodes___0.hash="a993295912763ca6dbfc96b31f1be4c9" 
#   AND  Orders_0.product=Products_0.id 
#   AND  Products_0.description="other ring" 
#   AND  Customers_0.givenName="Chip"
# GROUP BY o_id,c_id,__Nodes___1_o_id,__Nodes___2_avoid_id,p_id,last_familyName

# SQL Query:
# __Holds___0 not reached, going for cross product @@@ this comes from not ordering the JOINs
# +----------+-----------------------------------------------+
# |      last|                                          avoid|
# |----------|-----------------------------------------------|
# |"Thompson"|<http://localhost/OrderTracking#Customers_id_1>|
# +----------+-----------------------------------------------+

