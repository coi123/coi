#!/bin/sh

###############################################################################
# Copyright 2002 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# Optional1 - Nested optionals
# Tests:
#   - optional arcs
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: Optional2-alg.sh,v 1.6 2005/08/03 19:47:53 eric Exp $
###############################################################################

algae $* \
--lang Algae \
"
ns <http://example.org/n#>
require <http://www.w3.org/2004/06/20-rules/#assert>
assert (
 A p1 B . # truncates on optional 1 term 1
 A p2 C .
# A p3 D .

# D p4 E .
# D p5 F .
# D p6 F .

 A2 p1 B . # truncates on optional term 2
 A2 p2 C .
 A2 p3 D2 .

 D2 p4 E2 .
# D2 p5 F2 .
# D2 p6 F2 .

 A3 p1 B . # eliminates second optional
 A3 p2 C .
 A3 p3 D3 .

 D3 p4 E3 .
 D3 p5 F3 .
# D3 p6 F3 .

 A4 p1 B . # has all arcs
 A4 p2 C .
 A4 p3 D4 .

 D4 p4 E4 .
 D4 p5 F4 .
 D4 p6 F4 
)

ask (
 ?n p1 B .
 ?n p2 C .
 ~(?n ?p3 ?d .
   ?d p4 ?e .
   ?d p5 ?f .
   ~?d p6 ?g))

collect (?n ?d ?e ?f ?g)
" \


# Table Results:
# +-------------------------+-------------------------+-------------------------+-------------------------+-------------------------+
# |                        n|                        d|                        e|                        f|                        g|
# |-------------------------|-------------------------|-------------------------|-------------------------|-------------------------|
# | <http://example.org/n#A>|                     NULL|                     NULL|                     NULL|                     NULL|
# |<http://example.org/n#A2>|                     NULL|                     NULL|                     NULL|                     NULL|
# |<http://example.org/n#A3>|<http://example.org/n#D3>|<http://example.org/n#E3>|<http://example.org/n#F3>|                     NULL|
# |<http://example.org/n#A4>|<http://example.org/n#D4>|<http://example.org/n#E4>|<http://example.org/n#F4>|<http://example.org/n#F4>|
# +-------------------------+-------------------------+-------------------------+-------------------------+-------------------------+

# ResultSet Results:
# @prefix rdf:    <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
# @prefix rs:     <http://jena.hpl.hp.com/2003/03/result-set#> .
# 
# [] rdf:type rs:ResultSet ;
#     rs:resultVariable "n" ;
#     rs:resultVariable "d" ;
#     rs:resultVariable "e" ;
#     rs:resultVariable "f" ;
#     rs:resultVariable "g" ;
#     rs:size "4" ;
#     rs:solution
#         [ rdf:type rs:ResultSolution ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "n" ; rs:value <http://example.org/n#A> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "d" ; rs:nonValue "NULL" ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "e" ; rs:nonValue "NULL" ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "f" ; rs:nonValue "NULL" ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "g" ; rs:nonValue "NULL" ] 
#         ] ;
#     rs:solution
#         [ rdf:type rs:ResultSolution ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "n" ; rs:value <http://example.org/n#A2> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "d" ; rs:nonValue "NULL" ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "e" ; rs:nonValue "NULL" ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "f" ; rs:nonValue "NULL" ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "g" ; rs:nonValue "NULL" ] 
#         ] ;
#     rs:solution
#         [ rdf:type rs:ResultSolution ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "n" ; rs:value <http://example.org/n#A3> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "d" ; rs:value <http://example.org/n#D3> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "e" ; rs:value <http://example.org/n#E3> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "f" ; rs:value <http://example.org/n#F3> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "g" ; rs:nonValue "NULL" ] 
#         ] ;
#     rs:solution
#         [ rdf:type rs:ResultSolution ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "n" ; rs:value <http://example.org/n#A4> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "d" ; rs:value <http://example.org/n#D4> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "e" ; rs:value <http://example.org/n#E4> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "f" ; rs:value <http://example.org/n#F4> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "g" ; rs:value <http://example.org/n#F4> ] 
#         ] .

 