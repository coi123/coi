#!/bin/sh

###############################################################################
# Copyright 2004 W3C (MIT, INRIA, Keio), All Rights Reserved.
# W3C liability, trademark, document use and software licensing rules apply.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium
# 
# BRQL0 - BRQL tester.
# Tests:
#   - BRQL parser and it's use of Algae2 query structures
# 
# Part of W3C/Rdf/test perl library test suite.
# See http://www.w3.org/1999/02/26-modules/
# $Id: BRQL0-alg.sh,v 1.4 2004/08/09 19:03:20 eric Exp $
###############################################################################

algae $* \
--lang BRQL \
"
SELECT ?s ?p ?o
  FROM <../test/Annotation1052587433.529382.rdf>
 WHERE { SOURCE ?src ?s rdf:type a:Annotation .
       ?s ?p ?o .
       NOT {?s ?p 999 .}
       OPTIONAL {?s ?p 888. }}
   AND ?o == 5 * 3 + 10/5 || ?o == \"eric\" || ?o == \"joe\"
 USING rdf FOR <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
       a FOR <http://www.w3.org/2000/10/annotation-ns#>
" \

## Extra Arguments:
# --forceHost example.com
# --forcePath /instpath/workingdir

# Table Results:
# +-------------------------------------------------------------+-----------------------------------------+------+
# |                                                            s|                                        p|     o|
# |-------------------------------------------------------------|-----------------------------------------|------|
# |<http://iggy.w3.org/annotations/annotation/1054553215.108988>|<http://purl.org/dc/elements/1.1/creator>|"eric"|
# |<http://iggy.w3.org/annotations/annotation/1052587433.529382>|<http://purl.org/dc/elements/1.0/creator>|"eric"|
# +-------------------------------------------------------------+-----------------------------------------+------+

# ResultSet Results:
# @prefix rdf:    <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
# @prefix rs:     <http://jena.hpl.hp.com/2003/03/result-set#> .
# 
# [] rdf:type rs:ResultSet ;
#     rs:resultVariable "s" ;
#     rs:resultVariable "p" ;
#     rs:resultVariable "o" ;
#     rs:size "2" ;
#     rs:solution
#         [ rdf:type rs:ResultSolution ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "s" ; rs:value <http://iggy.w3.org/annotations/annotation/1052587433.529382> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "p" ; rs:value <http://purl.org/dc/elements/1.0/creator> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "o" ; rs:value "eric" ] 
#         ] ;
#     rs:solution
#         [ rdf:type rs:ResultSolution ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "s" ; rs:value <http://iggy.w3.org/annotations/annotation/1054553215.108988> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "p" ; rs:value <http://purl.org/dc/elements/1.1/creator> ] ;
#           rs:binding [ rdf:type rs:ResultBinding ;
#                        rs:variable "o" ; rs:value "eric" ] 
#         ] .

