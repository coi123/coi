../../Database/bin/object_maker $* \
-p ../../Rdf/test/Uniprot.prop \
-n W3C::Rdf::DbMeta::Uniprot \
-h Uniprot.html \
-o Uniprot.pm \
-m "{Uniprot.id=>undef}" \
Uniprot \

#-c "RdfIds=>{type=>{ID=>IDObject,Ref=>UriObject,String=>StringObject,Fake=>FakeObject,Gen=>GenIdObject}}" \
