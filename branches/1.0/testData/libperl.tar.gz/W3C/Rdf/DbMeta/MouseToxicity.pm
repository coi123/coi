@W3C::Rdf::DbMeta::MouseToxicity::MouseToxicity::ISA = ( 'W3C::Database::ObjectBase' );
%W3C::Rdf::DbMeta::MouseToxicity::MouseToxicity::_TableDesc = ( '-table' => 'MouseToxicity',
                                                                '-class' => 'W3C::Rdf::DbMeta::MouseToxicity::MouseToxicity',
                                                                '-index' => { 'u_chemical' => { '-sequence' => [ 'chemical' ],
                                                                                                '-unique' => '1',
                                                                                                '-fields' => { 'chemical' => 0 } } },
                                                                '-primaryKey' => 'id',
                                                                '-fields' => { 'toxicity' => { '-type' => 2,
                                                                                               '-size' => undef,
                                                                                               '-null' => 1 },
                                                                               'id' => { '-type' => 0,
                                                                                         '-default' => '0',
                                                                                         '-size' => '11' },
                                                                               'chemical' => { '-type' => 4,
                                                                                               '-size' => '80',
                                                                                               '-null' => 1 } },
                                                                '-fieldOrder' => [ 'id',
                                                                                   'chemical',
                                                                                   'toxicity' ] );
$W3C::Rdf::DbMeta::MouseToxicity::_AllTables{'MouseToxicity'} = \%W3C::Rdf::DbMeta::MouseToxicity::MouseToxicity::_TableDesc;
sub W3C::Rdf::DbMeta::MouseToxicity::MouseToxicity::getTableDesc {return \%W3C::Rdf::DbMeta::MouseToxicity::MouseToxicity::_TableDesc;}

@W3C::Rdf::DbMeta::MouseToxicity::_TableOrder = ( 'MouseToxicity' );
