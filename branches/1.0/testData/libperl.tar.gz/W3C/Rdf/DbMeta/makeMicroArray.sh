../../Database/bin/object_maker $* \
-p ../../Rdf/test/MicroArray.prop \
-n W3C::Rdf::DbMeta::MicroArray \
-h MicroArray.html \
-o MicroArray.pm \
-m "{MicroArray.experiment=>Kinase.id, 
     Kinase.against=>Chemicals.id, 
     Chemicals.id=>undef}" \
MicroArray \

#-c "RdfIds=>{type=>{ID=>IDObject,Ref=>UriObject,String=>StringObject,Fake=>FakeObject,Gen=>GenIdObject}}" \
