../../Database/bin/object_maker $* \
-p ../../Rdf/test/ScreeningAssay.prop \
-n W3C::Rdf::DbMeta::ScreeningAssay \
-h ScreeningAssay.html \
-o ScreeningAssay.pm \
-m "{ScreeningAssay.id=>undef}" \
ScreeningAssay \

#-c "RdfIds=>{type=>{ID=>IDObject,Ref=>UriObject,String=>StringObject,Fake=>FakeObject,Gen=>GenIdObject}}" \
