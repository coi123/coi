@W3C::Rdf::DbMeta::MicroArray::Chemicals::ISA = ( 'W3C::Database::ObjectBase' );
%W3C::Rdf::DbMeta::MicroArray::Chemicals::_TableDesc = ( '-table' => 'Chemicals',
                                                         '-class' => 'W3C::Rdf::DbMeta::MicroArray::Chemicals',
                                                         '-primaryKey' => 'id',
                                                         '-fields' => { 'id' => { '-type' => 0,
                                                                                  '-default' => '0',
                                                                                  '-size' => '11' },
                                                                        'chemical' => { '-type' => 4,
                                                                                        '-size' => '80',
                                                                                        '-null' => 1 } },
                                                         '-fieldOrder' => [ 'id',
                                                                            'chemical' ] );
$W3C::Rdf::DbMeta::MicroArray::_AllTables{'Chemicals'} = \%W3C::Rdf::DbMeta::MicroArray::Chemicals::_TableDesc;
sub W3C::Rdf::DbMeta::MicroArray::Chemicals::getTableDesc {return \%W3C::Rdf::DbMeta::MicroArray::Chemicals::_TableDesc;}

@W3C::Rdf::DbMeta::MicroArray::Kinase::ISA = ( 'W3C::Database::ObjectBase' );
%W3C::Rdf::DbMeta::MicroArray::Kinase::_TableDesc = ( '-table' => 'Kinase',
                                                      '-class' => 'W3C::Rdf::DbMeta::MicroArray::Kinase',
                                                      '-primaryKey' => 'id',
                                                      '-fields' => { 'against' => { '-target' => [ 'Chemicals',
                                                                                                   'id' ],
                                                                                    '-type' => 0,
                                                                                    '-default' => '0',
                                                                                    '-size' => '11' },
                                                                     'id' => { '-type' => 0,
                                                                               '-default' => '0',
                                                                               '-size' => '11' } },
                                                      '-fieldOrder' => [ 'id',
                                                                         'against' ] );
$W3C::Rdf::DbMeta::MicroArray::_AllTables{'Kinase'} = \%W3C::Rdf::DbMeta::MicroArray::Kinase::_TableDesc;
sub W3C::Rdf::DbMeta::MicroArray::Kinase::getTableDesc {return \%W3C::Rdf::DbMeta::MicroArray::Kinase::_TableDesc;}

@W3C::Rdf::DbMeta::MicroArray::MicroArray::ISA = ( 'W3C::Database::ObjectBase' );
$W3C::Rdf::DbMeta::MicroArray::MicroArray::expression_UP = 0;
$W3C::Rdf::DbMeta::MicroArray::MicroArray::expression_DOWN = 1;
%W3C::Rdf::DbMeta::MicroArray::MicroArray::expression_to_string = ( '1' => 'down',
                                                                    '0' => 'up' );
%W3C::Rdf::DbMeta::MicroArray::MicroArray::string_to_expression = ( 'down' => 1,
                                                                    'up' => 0 );
%W3C::Rdf::DbMeta::MicroArray::MicroArray::_TableDesc = ( '-table' => 'MicroArray',
                                                          '-class' => 'W3C::Rdf::DbMeta::MicroArray::MicroArray',
                                                          '-index' => { 'u_name' => { '-sequence' => [ 'name' ],
                                                                                      '-unique' => '1',
                                                                                      '-fields' => { 'name' => 0 } } },
                                                          '-primaryKey' => 'id',
                                                          '-fields' => { 'experiment' => { '-target' => [ 'Kinase',
                                                                                                          'id' ],
                                                                                           '-type' => 0,
                                                                                           '-default' => '0',
                                                                                           '-size' => '11' },
                                                                         'expression' => { '-type' => 3,
                                                                                           '-stringsTo' => \%W3C::Rdf::DbMeta::MicroArray::MicroArray::string_to_expression,
                                                                                           '-values' => [ 'up',
                                                                                                          'down' ],
                                                                                           '-null' => 1,
                                                                                           '-toStrings' => \%W3C::Rdf::DbMeta::MicroArray::MicroArray::expression_to_string },
                                                                         'name' => { '-type' => 4,
                                                                                     '-size' => '80',
                                                                                     '-null' => 1 },
                                                                         'id' => { '-type' => 0,
                                                                                   '-default' => '0',
                                                                                   '-size' => '11' } },
                                                          '-fieldOrder' => [ 'id',
                                                                             'name',
                                                                             'expression',
                                                                             'experiment' ] );
$W3C::Rdf::DbMeta::MicroArray::_AllTables{'MicroArray'} = \%W3C::Rdf::DbMeta::MicroArray::MicroArray::_TableDesc;
sub W3C::Rdf::DbMeta::MicroArray::MicroArray::getTableDesc {return \%W3C::Rdf::DbMeta::MicroArray::MicroArray::_TableDesc;}

@W3C::Rdf::DbMeta::MicroArray::_TableOrder = ( 'Chemicals',
                                               'Kinase',
                                               'MicroArray' );
