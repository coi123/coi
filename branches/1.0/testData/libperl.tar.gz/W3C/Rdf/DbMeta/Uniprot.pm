@W3C::Rdf::DbMeta::Uniprot::Uniprot::ISA = ( 'W3C::Database::ObjectBase' );
%W3C::Rdf::DbMeta::Uniprot::Uniprot::_TableDesc = ( '-table' => 'Uniprot',
                                                    '-class' => 'W3C::Rdf::DbMeta::Uniprot::Uniprot',
                                                    '-index' => { 'u_name_motif' => { '-sequence' => [ 'name',
                                                                                                       'motif' ],
                                                                                      '-unique' => '1',
                                                                                      '-fields' => { 'name' => 0,
                                                                                                     'motif' => 1 } } },
                                                    '-primaryKey' => 'id',
                                                    '-fields' => { 'name' => { '-type' => 4,
                                                                               '-size' => '80',
                                                                               '-null' => 1 },
                                                                   'id' => { '-type' => 0,
                                                                             '-default' => '0',
                                                                             '-size' => '11' },
                                                                   'pathway' => { '-type' => 4,
                                                                                  '-size' => '80',
                                                                                  '-null' => 1 },
                                                                   'motif' => { '-type' => 4,
                                                                                '-size' => '80',
                                                                                '-null' => 1 } },
                                                    '-fieldOrder' => [ 'id',
                                                                       'name',
                                                                       'motif',
                                                                       'pathway' ] );
$W3C::Rdf::DbMeta::Uniprot::_AllTables{'Uniprot'} = \%W3C::Rdf::DbMeta::Uniprot::Uniprot::_TableDesc;
sub W3C::Rdf::DbMeta::Uniprot::Uniprot::getTableDesc {return \%W3C::Rdf::DbMeta::Uniprot::Uniprot::_TableDesc;}

@W3C::Rdf::DbMeta::Uniprot::_TableOrder = ( 'Uniprot' );
