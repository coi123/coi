../../Database/bin/object_maker $* \
-p ../../Rdf/test/MouseToxicity.prop \
-n W3C::Rdf::DbMeta::MouseToxicity \
-h MouseToxicity.html \
-o MouseToxicity.pm \
-m "{MouseToxicity.id=>undef}" \
MouseToxicity \

#-c "RdfIds=>{type=>{ID=>IDObject,Ref=>UriObject,String=>StringObject,Fake=>FakeObject,Gen=>GenIdObject}}" \
