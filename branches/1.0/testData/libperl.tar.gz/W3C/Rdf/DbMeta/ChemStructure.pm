@W3C::Rdf::DbMeta::ChemStructure::ChemStructure::ISA = ( 'W3C::Database::ObjectBase' );
%W3C::Rdf::DbMeta::ChemStructure::ChemStructure::_TableDesc = ( '-table' => 'ChemStructure',
                                                                '-class' => 'W3C::Rdf::DbMeta::ChemStructure::ChemStructure',
                                                                '-index' => { 'u_chemical_sidechain' => { '-sequence' => [ 'chemical',
                                                                                                                           'sidechain' ],
                                                                                                          '-unique' => '1',
                                                                                                          '-fields' => { 'sidechain' => 1,
                                                                                                                         'chemical' => 0 } } },
                                                                '-primaryKey' => 'id',
                                                                '-fields' => { 'structure' => { '-type' => 4,
                                                                                                '-size' => '80',
                                                                                                '-null' => 1 },
                                                                               'id' => { '-type' => 0,
                                                                                         '-default' => '0',
                                                                                         '-size' => '11' },
                                                                               'sidechain' => { '-type' => 4,
                                                                                                '-size' => '20',
                                                                                                '-null' => 1 },
                                                                               'chemical' => { '-type' => 4,
                                                                                               '-size' => '80',
                                                                                               '-null' => 1 } },
                                                                '-fieldOrder' => [ 'id',
                                                                                   'chemical',
                                                                                   'structure',
                                                                                   'sidechain' ] );
$W3C::Rdf::DbMeta::ChemStructure::_AllTables{'ChemStructure'} = \%W3C::Rdf::DbMeta::ChemStructure::ChemStructure::_TableDesc;
sub W3C::Rdf::DbMeta::ChemStructure::ChemStructure::getTableDesc {return \%W3C::Rdf::DbMeta::ChemStructure::ChemStructure::_TableDesc;}

@W3C::Rdf::DbMeta::ChemStructure::_TableOrder = ( 'ChemStructure' );
