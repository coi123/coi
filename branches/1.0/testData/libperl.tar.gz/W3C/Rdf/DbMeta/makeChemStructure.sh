../../Database/bin/object_maker $* \
-p ../../Rdf/test/ChemStructure.prop \
-n W3C::Rdf::DbMeta::ChemStructure \
-h ChemStructure.html \
-o ChemStructure.pm \
-m "{ChemStructure.id=>undef}" \
ChemStructure \

#-c "RdfIds=>{type=>{ID=>IDObject,Ref=>UriObject,String=>StringObject,Fake=>FakeObject,Gen=>GenIdObject}}" \
