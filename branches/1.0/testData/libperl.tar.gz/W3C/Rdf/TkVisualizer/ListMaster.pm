#Copyright Massachusetts Institute of technology, 2000.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

package W3C::Rdf::TkVisualizer::ListMaster;

use strict;
use base  qw(Tk::Frame);
use Tk::widgets qw(Frame Label Entry);

use W3C::Rdf::TkVisualizer::WindowSetClient;
use W3C::Util::Exception;

use vars qw($VERSION $DSLI @ISA @EXPORT @EXPORT_OK @TODO);

@EXPORT = qw();
@EXPORT_OK = qw();
$VERSION = 0.01;
$DSLI = 'adpO';
@TODO = ('write');

Construct Tk::Widget 'ListMaster';

sub Populate
{
    require W3C::Rdf::TkVisualizer::WindowSetClient;
    my($cw, $args) = @_;
    $cw->SUPER::Populate($args);
#    my $child = delete $args->{-child};
#    &throw(new W3C::Util::Exception(-message => 'child not defined')) if (!defined $child);

    my $windowSetClient = $cw->WindowSetClient();
#    $cw->{ENTRY} = $child->makeEntry($cw->parent);
    $cw->{ENTRY} = $cw->makeEntry($cw->parent);
    $cw->{ENTRY}->bind("<Return>", sub {$cw->onReturn});
    $cw->{ENTRY}->bind("<Up>", sub {$cw->onArrow(-1)});
    $cw->{ENTRY}->bind("<Down>", sub {$cw->onArrow(1)});
#    $cw->{LEFT} = $parentWindow->Button(-text => "<-", -underline => 0, -state => 'disabled', 
#				-command => sub {$cw->nav(1)}, -background => 'grey')->pack(-side => 'left');
#    $cw->{RIGHT} = $parentWindow->Button(-text => "->",  -underline => 1, -state => 'disabled', 
#				 -command => sub {$cw->nav(1)}, -background => 'grey')->pack(-side => 'left');

    $cw->{INDEX} = -1;
    $cw->{STACK} = [];
    $cw->{BY_STRING} = {};

    $cw->Advertise('base' => $windowSetClient);
    $cw->ConfigSpecs('DEFAULT' => [$windowSetClient]);
    $cw->Delegates(DEFAULT => $windowSetClient);
}

sub setDragWidget {
    my ($self, $widget, $type) = @_;
    $self->{DRAG_WIDGET} = $widget;
    $widget->DragDrop(-event => '<B1-Motion>', 
		      -handlers => [[-type => 'text/plain', sub {return $self->{TEXT_VARIABLE}}],
				    [-type => 'FILE_NAME', sub {return $self->{TEXT_VARIABLE}}],
				    [-type => $type, sub {return $self->{TEXT_VARIABLE}}],
				    [sub {return $self->{TEXT_VARIABLE}}]]);
}

sub getDragWidget {
    my ($self) = @_;
    return $self->{DRAG_WIDGET};
}

sub makeEntry {die}

# control window event redirectees
sub add {
    my ($self, $view) = @_;
#    return if (grep {$_->getString eq $view->getString} @{$self->{VIEW}});
    $self->{TEXT_VARIABLE} = $view->getString;
    push (@{$self->{STACK}}, $view);
    $self->{INDEX} = scalar @{$self->{STACK}} - 1;
    $self->{BY_STRING}{$view->getString} = $view;
}

sub onArrow {
    my ($self, $direc) = @_;
    return if (@{$self->{STACK}} < 1);
    $self->{INDEX} += $direc;
    $self->{INDEX} += @{$self->{STACK}} if ($self->{INDEX} < 0);
    $self->{INDEX} -= @{$self->{STACK}} if ($self->{INDEX} >= @{$self->{STACK}});
    $self->{TEXT_VARIABLE} = $self->{STACK}[$self->{INDEX}]->getString;
    $self->{STACK}[$self->{INDEX}]->activate($self);
    $self->cget(-windowSet)->refreshList;
}

sub onReturn {die}

sub getByString {
    my ($self, $string) = @_;
    return $self->{BY_STRING}{$string};
}

sub getPrevious {
    my ($self) = @_;
    return $self->{INDEX} > 0                  ? $self->{STACK}[$self->{INDEX} - 1] : $self->{STACK}[$#{$self->{STACK}}];
}
sub getNext {
    my ($self) = @_;
    return $self->{INDEX} < $#{$self->{STACK}} ? $self->{STACK}[$self->{INDEX} + 1] : $self->{STACK}[0];
}

# point index to the element that claims to be active
sub setActive {
    my ($self, $newActive) = @_;
    $self->{INDEX} = (grep {return $_ == $newActive;} @{$self->{STACK}})[0];
    die if (!defined $self->{INDEX});
    $self->{TEXT_VARIABLE} = $newActive->getString;
}

sub passed {
    my ($self, $passed) = @_;
    $self->{TEXT_VARIABLE} = $passed;
    $self->onReturn;
}

1;
