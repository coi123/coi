#Copyright Massachusetts Institute of technology, 2000.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

use strict;
require Exporter;
#require AutoLoader;

$W3C::Rdf::TkVisualizer::StatementSet::REVISION = '$Id: StatementSet.pm,v 1.2 2000/07/09 00:53:07 eric Exp $ ';

package W3C::Rdf::TkVisualizer::StatementSet;
use vars qw($VERSION $DSLI @ISA @EXPORT @EXPORT_OK);
@ISA = qw(Exporter); # AutoLoader);
@EXPORT = qw();
@EXPORT_OK = qw();
$VERSION = 0.94;
$DSLI = 'adpO';

# use vars qw();

sub new {
    my ($proto, $uri) = @_;
    my $class = ref($proto) || $proto;
    my $self = {BY_TAG => {}, BY_STATEMENT => {}, BY_INDEX => []};
    bless ($self, $class);
    return $self;
}

sub clearRenderedStatements {
    my ($self) = @_;
    $self->{BY_TAG} = {};
    $self->{BY_STATEMENT} = {};
    $self->{BY_INDEX} = [];
}

sub addRenderedStatement {
    my ($self, $tag, $index, $statement) = @_;
    $self->{BY_TAG}{$tag} = [$index, $statement];
    $self->{BY_STATEMENT}{$statement} = [$index, $tag];
    $self->{BY_INDEX}[$index] = $statement;
}

sub getTripleBy999 {
    my ($self, $nineninenine) = @_;
    return $self->{BY_TAG}{$nineninenine};
}

sub getTripleByIndex {
    my ($self, $index) = @_;
    return $self->{BY_INDEX}[$index];
}

sub getStatementDetails {
    my ($self, $statement) = @_;
    return $self->{BY_STATEMENT}{$statement};
}

1;

