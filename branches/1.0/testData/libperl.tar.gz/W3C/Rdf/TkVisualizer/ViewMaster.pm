#Copyright Massachusetts Institute of technology, 2000.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

package W3C::Rdf::TkVisualizer::ViewMaster;

use strict;
use base  qw(W3C::Rdf::TkVisualizer::ListMaster);
use Tk::widgets qw(Frame Label Entry);

use W3C::Rdf::TkVisualizer::WindowSetClient;

use vars qw($VERSION $DSLI @ISA @EXPORT @EXPORT_OK @TODO);

@EXPORT = qw();
@EXPORT_OK = qw();
$VERSION = 0.01;
$DSLI = 'adpO';
@TODO = ('write');

Construct Tk::Widget 'ViewMaster';

#sub Populate
#{
#    require W3C::Rdf::TkVisualizer::WindowSetClient;
#    my($cw, $args) = @_;
#    $cw->SUPER::Populate($args);
#    $cw->Label(-text => 'Now playing: ')->pack(-side => 'left')->pack;

#    my $listMaster = $cw->ListMaster(-child => $cw);
#    $listMaster->pack;
#    $cw->Advertise('listMaster' => $listMaster);
#    $cw->ConfigSpecs('DEFAULT' => [$listMaster]);
#    $cw->Delegates(DEFAULT => $listMaster);
#}

# virtual functions
sub makeEntry { # ListMaster downcall
    my ($self, $parentWindow) = @_;
    my $label = $self->Label(-text => 'Now playing: ', -relief => 'ridge')->pack(-side => 'left')->pack(-side => 'left');
    $self->setDragWidget($label, 'VIEW');
    return $self->Scrolled('Entry', -scrollbars => 'os', -textvariable => \ $self->{TEXT_VARIABLE}, -width => 25)
	->pack(-side => 'left', -anchor => 'w');
}

sub string_handler
{
 my ($text,$offset,$max) = @_;
 return substr($text,$offset,$max);
}

sub stringHandler
{
 my ($self, $text, $offset, $max) = @_;
 return $self->{TEXT_VARIABLE};
}

sub onReturn {
    my ($self) = @_;
    my @sources = split (/\s/, $self->{TEXT_VARIABLE});
    my ($errors, $nextSources, $nextAttribs) = $self->cget(-windowSet)->getAttributionsForSources(\@sources);
    for (my $i = 0; $i < $errors; $i++) {$self->{ENTRY}->bell}
    if (@$nextAttribs) {
	$self->{TEXT_VARIABLE} = join (' ', @$nextSources);
	if (grep {$_->getString eq $self->{TEXT_VARIABLE}} @{$self->{STACK}}) {
	} else {
	    require W3C::Rdf::TkVisualizer::Views;
	    my $currentView = new W3C::Rdf::TkVisualizer::SourceView(VIEW_MASTER => $self->{VIEW_MASTER}, 
								     -windowSet => $self->cget(-windowSet), 
								     -string => $self->{TEXT_VARIABLE}, -statements => undef, 
								     -attribs => $nextAttribs);
	    $self->add($currentView);
	}
	$self->cget(-windowSet)->refreshList;
    }
}

sub getStatements { # for StatementList::refreshList
    my ($self) = @_;
    return $self->{INDEX} > -1 ? $self->{STACK}[$self->{INDEX}]->getStatements : ();
}

1;

