package W3C::Rdf::TkVisualizer::PromptHistory;
sub makeEntry {die}

sub new {
    my ($proto, $parms) = @_;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new($parms);
    bless ($self, $class);
    $self->{INDEX} = -1;
    $self->{STACK} = [];
    $self->{BY_STRING} = {};
    return $self;
}

sub makeWindow { # ClientWindow
    my ($self, $parentWindow) = @_;
    $self->{ENTRY} = $self->makeEntry($parentWindow);
    $self->{ENTRY}->bind("<Return>", sub {$self->onReturn});
    $self->{ENTRY}->bind("<Up>", sub {$self->onArrow(-1)});
    $self->{ENTRY}->bind("<Down>", sub {$self->onArrow(1)});
#    $self->{LEFT} = $parentWindow->Button(-text => "<-", -underline => 0, -state => 'disabled', 
#				-command => sub {$self->nav(1)}, -background => 'grey')->pack(-side => 'left');
#    $self->{RIGHT} = $parentWindow->Button(-text => "->",  -underline => 1, -state => 'disabled', 
#				 -command => sub {$self->nav(1)}, -background => 'grey')->pack(-side => 'left');
}

# control window event redirectees
sub add {
    my ($self, $view) = @_;
#    return if (grep {$_->getString eq $view->getString} @{$self->{VIEW}});
    $self->{TEXT_VARIABLE} = $view->getString;
    push (@{$self->{STACK}}, $view);
    $self->{INDEX} = scalar @{$self->{STACK}} - 1;
    $self->{BY_STRING}{$view->getString} = $view;
}

sub onArrow {
    my ($self, $direc) = @_;
    return if (@{$self->{STACK}} < 1);
    $self->{INDEX} += $direc;
    $self->{INDEX} += @{$self->{STACK}} if ($self->{INDEX} < 0);
    $self->{INDEX} -= @{$self->{STACK}} if ($self->{INDEX} >= @{$self->{STACK}});
    $self->{TEXT_VARIABLE} = $self->{STACK}[$self->{INDEX}]->getString;
    $self->{STACK}[$self->{INDEX}]->activate($self);
    $self->cget(-windowSet)->refreshList;
}

sub onReturn {die}

sub getByString {
    my ($self, $string) = @_;
    return $self->{BY_STRING}{$string};
}

sub getPrevious {
    my ($self) = @_;
    return $self->{INDEX} > 0                  ? $self->{STACK}[$self->{INDEX} - 1] : $self->{STACK}[$#{$self->{STACK}}];
}
sub getNext {
    my ($self) = @_;
    return $self->{INDEX} < $#{$self->{STACK}} ? $self->{STACK}[$self->{INDEX} + 1] : $self->{STACK}[0];
}

# point index to the element that claims to be active
sub setActive {
    my ($self, $newActive) = @_;
    $self->{INDEX} = (grep {return $_ == $newActive;} @{$self->{STACK}})[0];
    die if (!defined $self->{INDEX});
    $self->{TEXT_VARIABLE} = $newActive->getString;
}

sub passed {
    my ($self, $passed) = @_;
    $self->{TEXT_VARIABLE} = $passed;
    $self->onReturn;
}

1;

