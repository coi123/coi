#Copyright Massachusetts Institute of technology, 2000.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

package W3C::Rdf::TkVisualizer::MatrixRenderer;

use strict;
use base  qw(Tk::Frame);
use Tk::widgets qw(Frame Label Entry);

use W3C::Rdf::TkVisualizer::WindowSetClient;
use W3C::Util::Exception;
use vars qw($VERSION $DSLI @ISA @EXPORT @EXPORT_OK @TODO);

@EXPORT = qw();
@EXPORT_OK = qw();
$VERSION = 0.01;
$DSLI = 'adpO';
@TODO = ('write');

Construct Tk::Widget 'MatrixRenderer';

sub Populate
{
    require W3C::Rdf::TkVisualizer::WindowSetClient;
    my($cw, $args) = @_;
    $cw->SUPER::Populate($args);
#    &throw(new W3C::Util::Exception(-message => 'matrixWidget not defined')) if (!defined $args->{-matrixWidget});

    my $windowSetClient = $cw->WindowSetClient();
    $cw->Advertise('base' => $windowSetClient);
    $cw->ConfigSpecs(-matrixWidget => ['PASSIVE', undef, undef, undef],
		     -columns => ['PASSIVE', undef, undef, undef],
		     -data => ['PASSIVE', undef, undef, undef],
		     -command => ['PASSIVE', undef, undef, undef],
		     -widths => ['PASSIVE', undef, undef, undef],
		     -columnLabels => ['PASSIVE', undef, undef, undef],
		     'DEFAULT' => [$windowSetClient]);
#    $cw->Delegates(DEFAULT => $windowSetClient);
}

# virtual functions
sub makeWidget {die}
sub packNUKE {return shift->cget(-matrixWidget)->pack(@_);}
sub bind {return shift->cget(-matrixWidget)->bind(@_);}
sub size {return shift->cget(-matrixWidget)->size(@_);}
sub get {return shift->cget(-matrixWidget)->get(@_);}
sub curselection {return shift->cget(-matrixWidget)->curselection(@_);}
sub bell {return shift->cget(-matrixWidget)->bell(@_);}

sub highlight {
    my ($self, $index) = @_;
    $self->cget(-matrixWidget)->selection('clear', 0, 'end');
    return if (!defined $index); # filter out Graph::graphPick(undef) calls
    $self->cget(-matrixWidget)->selection('set', $index);
    $self->cget(-matrixWidget)->activate($index);
    $self->cget(-matrixWidget)->see($index);
}
sub startRows {
    my ($self) = @_;
    $self->configure(-data => []);
    $self->configure(-widths => []);
}
sub addRow {
    my ($self, $data) = @_;
    for (my $i = 0; $i < @$data; $i++) {
	my $width = length $data->[$i];
	$self->cget(-widths)->[$i] = $width if ($self->cget(-widths)->[$i] < $width);
    }
    push (@{$self->cget(-data)}, $data);
}
sub endRows {die}
sub destroy {
    my ($self) = @_;
    $self->cget(-matrixWidget)->destroy; # @@@ 4TF: why dan't I destroy this widget?
    # PORTNOTE: delete $self
}

1;

