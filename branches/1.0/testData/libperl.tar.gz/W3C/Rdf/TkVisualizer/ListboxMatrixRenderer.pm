#Copyright Massachusetts Institute of technology, 2000.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

package W3C::Rdf::TkVisualizer::ListboxMatrixRenderer;

use strict;
use base  qw(W3C::Rdf::TkVisualizer::MatrixRenderer);
use Tk::widgets qw(Frame Label Entry);
use Tk::Font;

use vars qw($VERSION $DSLI @ISA @EXPORT @EXPORT_OK @TODO);

@EXPORT = qw();
@EXPORT_OK = qw();
$VERSION = 0.01;
$DSLI = 'adpO';
@TODO = ('write');

Construct Tk::Widget 'ListboxMatrixRenderer';

sub Populate
{
    require W3C::Rdf::TkVisualizer::WindowSetClient;
    my($cw, $args) = @_;
    $cw->SUPER::Populate($args);

    my $self = $cw;
    my $matrixWidget;
    my $f = $self->Font(-family => 'Courier');
    $matrixWidget = $self->Scrolled('Listbox', -scrollbars => 'osoe', -selectmode => 'extended', -font => $f);
    $matrixWidget->pack(-fill => 'both', -expand => 1);

    $matrixWidget->bind("<Double-ButtonPress-1>", sub {$self->selectAction});
    $matrixWidget->bind("<Return>", sub {$self->selectAction});
#   $matrixWidget->bind("<Space>", [\&triplesPick, $self]);

    $cw->configure(-matrixWidget => $matrixWidget);
    $cw->Advertise('matrixRenderer' => $matrixWidget);
    $cw->ConfigSpecs('DEFAULT' => [$matrixWidget]);
    $cw->Delegates(DEFAULT => $matrixWidget);
}

sub makeWidget {die;}
sub selectAction {
    my ($self) = @_;
    &{$self->cget(-command)} ((($self->cget(-matrixWidget)->curselection)[0], 0));
}
sub startRows {
    my ($self) = @_;
    $self->SUPER::startRows;
    $self->cget(-matrixWidget)->delete(0, 'end');
}
sub endRows {
    my ($self) = @_;
    foreach my $row (@{$self->cget(-data)}) {
	my $text;
	for (my $j = 0; $j < @$row; $j++) {
	    my $column = $row->[$j];
	    $text .= $column;
	    $text .= ' ' x ($self->cget(-widths)->[$j] - length $column);
	    $text .= ' ' if ($j < @$row-1);
	}
	$self->cget(-matrixWidget)->insert('end', $text);
    }
    my $windowWidth = 0;
    for (my $i = 0; $i < @{$self->cget(-widths)}; $i++) {
	my $width = $self->cget(-widths)->[$i];
	$windowWidth += $width;
    }
    return $windowWidth;
}

1;

