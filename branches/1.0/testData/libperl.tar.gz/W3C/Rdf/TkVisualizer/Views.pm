use strict;

@W3C::Rdf::TkVisualizer::SourceView::ISA = qw(W3C::Rdf::TkVisualizer::View);
@W3C::Rdf::TkVisualizer::QueryView::ISA = qw(W3C::Rdf::TkVisualizer::View);
@W3C::Rdf::TkVisualizer::ProofView::ISA = qw(W3C::Rdf::TkVisualizer::View);
@W3C::Rdf::TkVisualizer::GraphView::ISA = qw(W3C::Rdf::TkVisualizer::View);
@W3C::Rdf::TkVisualizer::GraphStatementView::ISA = qw(W3C::Rdf::TkVisualizer::GraphView);
@W3C::Rdf::TkVisualizer::GraphNodeView::ISA = qw(W3C::Rdf::TkVisualizer::GraphView);

package W3C::Rdf::TkVisualizer::View;
# pure virtuals
sub getStatements {die}

sub new {
    my ($proto, @parms) = @_;
    my $class = ref($proto) || $proto;
    my $self = {@parms};
    bless ($self, $class);
    return $self;
}

sub getString {
    my ($self) = @_;
    return $self->{-string};
}

sub activate {
    my ($self, $caller) = @_;
}

package W3C::Rdf::TkVisualizer::SourceView;
sub getStatements {
    my ($self) = @_;
#    may want a parent view - need to work out interface to view selection
    return $self->{-windowSet}->triplesMatching(undef, [[undef,undef,undef]], 
						{$self->{-windowSet}->getQueryOptions, 
						 -attributions=>$self->{-attribs}});
}

package W3C::Rdf::TkVisualizer::QueryView;
sub getStatements {
    my ($self) = @_;
    my ($nodes, $selects, $messages, $proofs) = 
	$self->{-windowSet}->guessQuery($self->{-string}, $self->{-systemId});
    return $self->processAlgaeResults($nodes, $selects, $messages, $proofs);
}

sub activate {
    my ($self, $caller) = @_;
    if ($caller == $self->{-queryMaster}) {
	$self->{-viewMaster}->setActive($self);
    } elsif ($caller == $self->{-viewMaster}) {
	$self->{-queryMaster}->setActive($self);
    } else {
	die "$caller has no damn right to activate $self";
    }
}

sub processAlgaeResults {
    my ($self, $nodes, $selects, $messages, $proofs) = @_;
    my (%ret, @proofViews);
    for (my $i = 0; $i < @$nodes; $i++) {
	my $row = $nodes->[$i];
	my $rowProofs = $proofs->[$i];
	foreach my $rowProof (@$rowProofs) {
	    $ret{$rowProof} = $rowProof;
	}
	my $proofView = new W3C::Rdf::TkVisualizer::ProofView(VIEW_MASTER => $self->{VIEW_MASTER}, 
							      -windowSet => $self->{-windowSet}, 
							      -string => $self->{TEXT_VARIABLE}.'.'.$i, 
							      -statements => $rowProofs, -data => $row);
	push (@proofViews, $proofView);
    }
    $self->{-windowSet}->setProofViews($selects, \@proofViews);
    return values %ret;
}

package W3C::Rdf::TkVisualizer::ProofView;
sub getStatements { # proof statements are static (not re-queried) for simplicity
    my ($self) = @_;
    return @{$self->{-statements}};
}

sub renderData { # for QueryResults::refresh
    my ($self) = @_;
    my (@data);
    if ($self->{-data}) {
	for (my $i = 0; $i < @{$self->{-data}}; $i++) {
	    my $rendered = $self->{-windowSet}->renderNode($self->{-data}[$i], $self->{-statements}[0]->getAttribution, 
							   {-stringTrunc => 30, -truncFlag => '...'});
	    push (@data, $rendered);
	}
    }
    return @data;
}

package W3C::Rdf::TkVisualizer::GraphView;
sub renderData { # for QueryResults::refresh
    my ($self) = @_;
    my (@data);
    for (my $i = 0; $i < @{$self->{-data}}; $i++) {
	my $rendered = $self->{-windowSet}->renderNode($self->{-data}[$i], $self->{-statements}[0]->getAttribution, 
						       {-stringTrunc => 30, -truncFlag => '...'});
	push (@data, $rendered);
    }
    return @data;
}

sub activate {
    my ($self) = @_;
    $self->renderGraphView;
}

sub matchesNode {die}

package W3C::Rdf::TkVisualizer::GraphStatementView;
sub renderGraphView {
    my ($self) = @_;
    $self->{-graph}->clearCanvas;
    $self->{-graph}->graphTriples([$self->{-statement}], 1);
}

sub matchesNode {
    my ($self, $node) = @_;
    return 1 if ($self->{-statement}->getSubject == $node);
    return 1 if ($self->{-statement}->getObject == $node);
    return 0;
}

package W3C::Rdf::TkVisualizer::GraphNodeView;
sub renderGraphView {
    my ($self) = @_;
    $self->{-graph}->clearCanvas;

    my @triples;
    @triples = $self->{-windowSet}->triplesMatching(undef, [[undef, undef, $self->{-node}]], 
						    {$self->{-windowSet}->getQueryOptions});
    $self->{-graph}->graphTriples(\@triples, 0, 1);
    @triples = $self->{-windowSet}->triplesMatching(undef, [[undef, $self->{-node}, undef]], 
						    {$self->{-windowSet}->getQueryOptions});
    $self->{-graph}->graphTriples(\@triples, 0, 0);
}

sub matchesNode {
    my ($self, $node) = @_;
    return $self->{-node} == $node;
}

1;

