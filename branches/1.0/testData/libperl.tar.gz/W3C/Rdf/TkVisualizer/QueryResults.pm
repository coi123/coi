#Copyright Massachusetts Institute of technology, 2000.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

package W3C::Rdf::TkVisualizer::QueryResults;

use strict;
use base  qw(W3C::Rdf::TkVisualizer::HidableMainWindow);
use Tk::widgets qw(Frame Label Entry);

use W3C::Rdf::TkVisualizer::WindowSetClient;
use W3C::Rdf::TkVisualizer::HidableMainWindow;

use vars qw($VERSION $DSLI @ISA @EXPORT @EXPORT_OK @TODO);

@EXPORT = qw();
@EXPORT_OK = qw();
$VERSION = 0.01;
$DSLI = 'adpO';
@TODO = ('write');

Construct Tk::Widget 'QueryResults';

sub Populate
{
    require W3C::Rdf::TkVisualizer::WindowSetClient;
    my($cw, $args) = @_;
    $cw->SUPER::Populate($args);
    &throw(new W3C::Util::Exception(-message => 'widget factory not defined')) if (!defined $args->{-matrixWidget});

#    $cw->{WINDOW} = $cw;
    my $button = $cw->Button(-text => 'Hide', -command => sub {$cw->hideWindow})->pack;
    $cw->Advertise('Button' => $button);
    $cw->ConfigSpecs(-matrixWidget => ['PASSIVE', undef, undef, undef]);
}

# overloaded virtuals
sub getTitle {return 'Query Results';}

sub destroyWindow {
    my ($self) = @_;
    $self->SUPER::destroyWindow;
    $self->refresh;
}

sub setProofViews { # for QueryView::processAlgaeResults
    my ($self, $columnlabels, $proofViews) = @_;
    $self->{COLUMN_LABELS} = $columnlabels;
    $self->configure('title' => 'Query Results: '.join (' ', @{$self->{COLUMN_LABELS}}));
    $self->{PROOF_VIEWS} = $proofViews;
}

sub refresh { # for destroyWindow QueryMaster::on{Return,Arrow}
    my ($self) = @_;

#    $self->{WINDOW}->destroy($self->{COLUMNS}) if ($self->{COLUMNS});
#    $self->{COLUMNS}->destrow if ($self->{COLUMNS});
#    $self->{COLUMNS} = &{$self->cget(-matrixWidgetFactory)} (({-command => sub {$self->pick(@_);}, 
#							       -columnLabels => ['#', @{$self->{COLUMN_LABELS}}]}));
    my $matrixWidget = $self->cget(-matrixWidget);
    $self->{COLUMNS} = $self->$matrixWidget(-command => sub {$self->pick(@_);}, 
					    -columnLabels => ['#', @{$self->{COLUMN_LABELS}}]);
    $self->{COLUMNS}->startRows;
    for (my $i = 0; $i < @{$self->{PROOF_VIEWS}}; $i++) {
	$self->{COLUMNS}->addRow([$i, $self->{PROOF_VIEWS}[$i]->renderData]);
    }

    my $windowWidth = $self->{COLUMNS}->endRows;
    $self->configure('-width' => $windowWidth); # @@@ - no worky
    $self->{COLUMNS}->pack('-expand' => 1, '-fill' => 'both');
}

sub pick {
    my ($self, $row, $column) = @_;
    my $view = $self->{PROOF_VIEWS}[$row];
    $self->cget(-windowSet)->addView($view);
    if ($column > 0) {
	my $datum = $view->{-data}[$column-1];
	$self->cget(-windowSet)->graphNode($datum);
	$self->cget(-windowSet)->showGraphWindow;
    }
    $self->cget(-windowSet)->refreshList;
}

1;

