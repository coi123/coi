#Copyright Massachusetts Institute of technology, 2000.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

package W3C::Rdf::TkVisualizer::ColumnMatrixRenderer;

use strict;
use base  qw(W3C::Rdf::TkVisualizer::MatrixRenderer);
use Tk::widgets qw(Frame Label Entry);
use Tk::Columns;

use vars qw($VERSION $DSLI @ISA @EXPORT @EXPORT_OK @TODO);

@EXPORT = qw();
@EXPORT_OK = qw();
$VERSION = 0.01;
$DSLI = 'adpO';
@TODO = ('write');

Construct Tk::Widget 'ColumnMatrixRenderer';

sub Populate
{
    require W3C::Rdf::TkVisualizer::WindowSetClient;
    my($cw, $args) = @_;
    $cw->SUPER::Populate($args);

    my $f = $cw->Font(-family => 'Courier');
    my $matrixWidget = $cw->Columns(-columnlabels => $args->{-columnLabels}, # [qw(a b c 1 2 3)], 
				    -command => $args->{-command}, 
				    -listforeground => 'blue4', 
				    -listbackground => 'beige', 
				    -buttonbackground => 'brown', 
				    -buttonforeground => 'white', 
				    -selectmode => 'extended', 
				    -sort => 'false', 
				    -font => $f);
    $matrixWidget->pack(-fill => 'both', -expand => 1);

    $cw->configure(-matrixWidget => $matrixWidget);
    $cw->Advertise('matrixWidget' => $matrixWidget);
    $cw->ConfigSpecs('DEFAULT' => [$matrixWidget]);
    $cw->Delegates(DEFAULT => $matrixWidget);
}

sub get {
    my ($self) = (shift);
    my @array = $self->cget(-matrixWidget)->get(@_);
    my $tmp = $array[0];
    my $entry = join (' ', @$tmp);
    return $entry;
}
sub startRows {
    my ($self) = @_;
    $self->SUPER::startRows;
    $self->cget(-matrixWidget)->delete(0, 'end');
}
sub endRows {
    my ($self) = @_;
    foreach my $row (@{$self->cget(-data)}) {
	$self->cget(-matrixWidget)->insert('end', [@$row]);
    }
    my $windowWidth = 0;
    for (my $i = 0; $i < @{$self->cget(-widths)}; $i++) {
	my $width = $self->cget(-widths)->[$i];
	$self->cget(-matrixWidget)->indexedbutton($i)->configure('-width' => $width-1);
	$windowWidth += $width;
    }
    return $windowWidth;
}

sub destroy {
    my ($self) = @_;
#    $self->cget(-matrixWidget)->destroy; # @@@ 4TF: why can't I destroy this widget?
    # PORTNOTE: delete $self
}

1;

