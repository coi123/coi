#Copyright Massachusetts Institute of technology, 2000.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

package W3C::Rdf::TkVisualizer::HidableMainWindow;

use strict;
use base  qw(W3C::Rdf::TkVisualizer::WindowSetClient);
use Tk::widgets qw(Frame Label Entry);

use W3C::Rdf::TkVisualizer::PromptHistory;
use W3C::Rdf::TkVisualizer::WindowSetClient;
use W3C::Util::Exception;

use vars qw($VERSION $DSLI @ISA @EXPORT @EXPORT_OK @TODO);

@EXPORT = qw();
@EXPORT_OK = qw();
$VERSION = 0.01;
$DSLI = 'adpO';
@TODO = ('write');

Construct Tk::Widget 'HidableMainWindow';

sub Populate
{
    require W3C::Rdf::TkVisualizer::WindowSetClient;
    my($cw, $args) = @_;
    $cw->SUPER::Populate($args);

    my $windowSetClient = $cw->WindowSetClient();
    $cw->makeWindow;
    $cw->Advertise('windowSetClient' => $windowSetClient);
}

# pure virtuals
sub getTitle {die}

sub makeWindow {
    my ($cw) = @_;
    my $window = $cw->Toplevel;
#    $window->title($cw->getTitle);
    $window->protocol('WM_DELETE_WINDOW', sub {$cw->destroyWindow});
    $window->withdraw if (!$cw->{SHOW});
    $cw->{WINDOW} = $window;
    $cw->ConfigSpecs('DEFAULT' => [$window]);
    $cw->Delegates(DEFAULT => $window);
}
sub hideWindow {$_[0]->{SHOW} = 0; $_[0]->viewWindow;}
sub showWindow {$_[0]->{SHOW} = 1; $_[0]->viewWindow;}
sub viewWindow {
    my ($self) = @_;
    if ($self->{SHOW}) {
	$self->deiconify();
	$self->raise();
    } else {
	$self->withdraw;
    }
}
sub destroyWindow {
    my ($self) = @_;
    $self->{SHOW} = 0;
    $self->withdraw;
#    $self->makeWindow;
#    $self->{WINDOW}->destroy;
}
sub getShowVariable {return \ $_[0]->{SHOW};}

1;

