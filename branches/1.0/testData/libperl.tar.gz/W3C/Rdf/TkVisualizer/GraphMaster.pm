#Copyright Massachusetts Institute of technology, 2000.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

package W3C::Rdf::TkVisualizer::GraphMaster;

use strict;
use base  qw(W3C::Rdf::TkVisualizer::ListMaster);
use Tk::widgets qw(Frame Label Entry);

use W3C::Rdf::TkVisualizer::WindowSetClient;

use vars qw($VERSION $DSLI @ISA @EXPORT @EXPORT_OK @TODO);

@EXPORT = qw();
@EXPORT_OK = qw();
$VERSION = 0.01;
$DSLI = 'adpO';
@TODO = ('write');

Construct Tk::Widget 'GraphMaster';

sub Populate
{
    require W3C::Rdf::TkVisualizer::WindowSetClient;
    my($cw, $args) = @_;
    $cw->SUPER::Populate($args);

#    my $listMaster = $cw->ListMaster(-child => $cw);
#    $cw->Advertise('listMaster' => $listMaster);
#    $cw->ConfigSpecs('DEFAULT' => [$listMaster]);
#    $cw->Delegates(DEFAULT => $listMaster);
}

# virtual functions
sub makeEntry { # ListMaster downcall
    my ($self, $parentWindow) = @_;
    $parentWindow->Label(-text => 'Node: ')->pack(-side => 'left');
    return $parentWindow->Scrolled('Entry', -scrollbars => 'os', -textvariable => \ $self->{TEXT_VARIABLE})
	->pack(-side => 'left', -fill => 'x', -expand => 1, -padx => 10);
}

sub onReturn {
    my ($self) = @_;
    $self->{ENTRY}->bell;
}

1;

