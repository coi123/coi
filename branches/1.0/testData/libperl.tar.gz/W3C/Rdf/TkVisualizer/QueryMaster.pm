#Copyright Massachusetts Institute of technology, 2000.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

package W3C::Rdf::TkVisualizer::QueryMaster;

use strict;
use base  qw(W3C::Rdf::TkVisualizer::ListMaster);
use Tk::widgets qw(Frame Label Entry);

use W3C::Rdf::TkVisualizer::WindowSetClient;

use vars qw($VERSION $DSLI @ISA @EXPORT @EXPORT_OK @TODO);

@EXPORT = qw();
@EXPORT_OK = qw();
$VERSION = 0.01;
$DSLI = 'adpO';
@TODO = ('write');

Construct Tk::Widget 'QueryMaster';

#sub Populate
#{
#    require W3C::Rdf::TkVisualizer::WindowSetClient;
#    my($cw, $args) = @_;
#    $cw->SUPER::Populate($args);
#
#    my $listMaster = $cw->ListMaster(-child => $cw);
#    $cw->Advertise('listMaster' => $listMaster);
#    $cw->ConfigSpecs('DEFAULT' => [$listMaster]);
#    $cw->Delegates(DEFAULT => $listMaster);
#}

# virtual functions
sub makeEntry { # ListMaster downcall
    my ($self, $parentWindow) = @_;
    my $label = $self->Label(-text => 'Query: ', -relief => 'ridge')->pack(-side => 'left');
    $self->setDragWidget($label, 'QUERY');
    return $self->Scrolled('Entry', -scrollbars => 'os', -textvariable => \ $self->{TEXT_VARIABLE})
	->pack(-side => 'left', -fill => 'x', -expand => 1);
}

sub onReturn {
    my ($self) = @_;
    eval {
	if (grep {$_->getString eq $self->{TEXT_VARIABLE}} @{$self->{STACK}}) {
	} else {
	    my ($nodes, $selects, $messages, $proofs) = 
		$self->cget(-windowSet)->guessQuery($self->{TEXT_VARIABLE}, $self->cget(-systemId));
	    my $viewName = 'query-'.($self->{INDEX}+1);
	    require W3C::Rdf::TkVisualizer::Views;
	    my $currentView = new W3C::Rdf::TkVisualizer::QueryView(-viewMaster => $self->cget(-windowSet)->getViewMaster, 
								    -windowSet => $self->cget(-windowSet), 
								    -string => $self->{TEXT_VARIABLE}, 
								    -statements => undef, 
								    -query => $self->{TEXT_VARIABLE}, 
								    -viewTitle => $viewName, 
								    -queryMaster => $self);
	    $self->add($currentView);
	    $self->cget(-windowSet)->addView($currentView);
	}
	$self->cget(-windowSet)->refreshList;
	$self->cget(-windowSet)->refreshQueryResults;
	$self->cget(-windowSet)->showQueryResultsWindow;
    }; if ($@) {
	$self->{ENTRY}->bell;
    }
}

sub onArrow {
    my ($self, $direc) = @_;
    return if (@{$self->{STACK}} < 1);
    $self->SUPER::onArrow($direc);
    $self->cget(-windowSet)->refreshQueryResults;
}

1;

