#Copyright Massachusetts Institute of technology, 2000.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

package W3C::Rdf::TkVisualizer::WindowSetClient;

use strict;
use base  qw(Tk::Frame);
use Tk::widgets qw(Frame Label Entry);

use W3C::Rdf::TkVisualizer::PromptHistory;

use vars qw($VERSION $DSLI @ISA @EXPORT @EXPORT_OK @TODO);

@EXPORT = qw();
@EXPORT_OK = qw();
$VERSION = 0.01;
$DSLI = 'adpO';
@TODO = ('write');

Construct Tk::Widget 'WindowSetClient';

sub Populate
{
    require W3C::Rdf::TkVisualizer::WindowSetClient;
    my($cw, $args) = @_;
    $cw->SUPER::Populate($args);

    $cw->ConfigSpecs(-windowSet => ['PASSIVE', undef, undef, undef]);
}

1;
