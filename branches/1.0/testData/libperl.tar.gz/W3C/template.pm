#Copyright Massachusetts Institute of technology, 1998.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

use strict;
require Exporter;
require AutoLoader;

use W3C::blah::blah;

$W3C::XML::::REVISION = '$Id: template.pm,v 1.5 2004/03/29 06:45:49 eric Exp $ ';

package W3C::XML::foo;
use vars qw($VERSION $DSLI @ISA @EXPORT @EXPORT_OK @TODO);
@ISA = qw(Exporter AutoLoader);
@EXPORT = qw();
@EXPORT_OK = qw();
$VERSION = 0.91;
$DSLI = 'adpO';
@TODO = ('write the damn\'ed code',
	 'debug it', 
	 '...');

# put code here

# get versions
`find . -name \*.pm -print | xargs grep "VERSION ="|awk '{print $3}'|perl -pi -e "s/[\\'\\;]//g"|sort -n|uniq `
# change versions
`find . -name \*.pm -print | xargs perl -pi -e "s/VERSION = 0\\.(\\d\\d)/sprintf('VERSION = 0.%02d', \$1+1)/ge"`

1;

__END__

=head1 NAME

W3C::XML:: - 

=head1 SYNOPSIS

@@@

=head1 DESCRIPTION

This module is part of the W3C::XML CPAN module.

=head1 AUTHOR

Eric Prud\'hommeaux <eric@w3.org>

=head1 SEE ALSO

perl(1).

=cut
