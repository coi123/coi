use strict;

package W3C::JVM::Access;
use vars qw(@ISA @EXPORT);
use Exporter;
@ISA = qw(Exporter);
@EXPORT = qw($ACC_PUBLIC $ACC_PRIVATE $ACC_PROTECTED $ACC_STATIC
	     $ACC_FINAL $ACC_SUPER $ACC_SYNCHRONIZED $ACC_VOLATILE
	     $ACC_TRANSIENT $ACC_NATIVE $ACC_INTERFACE $ACC_ABSTRACT
	     $ACC_MAX
	     %ACC_2STR_class %ACC_2STR_interface 
	     %ACC_2STR_field %ACC_2STR_method
	     &RenderAccess);

# Access constants
use vars qw($ACC_PUBLIC $ACC_PRIVATE $ACC_PROTECTED $ACC_STATIC
	    $ACC_FINAL $ACC_SUPER $ACC_SYNCHRONIZED $ACC_VOLATILE
	    $ACC_TRANSIENT $ACC_NATIVE $ACC_INTERFACE $ACC_ABSTRACT
	    $ACC_MAX);

	    $ACC_PUBLIC		= 0x0001;
	    $ACC_PRIVATE	= 0x0002;
	    $ACC_PROTECTED	= 0x0004;
	    $ACC_STATIC		= 0x0008;
	    $ACC_FINAL		= 0x0010;
	    $ACC_SUPER		= 0x0020;
	    $ACC_SYNCHRONIZED	= 0x0020;
	    $ACC_VOLATILE	= 0x0040;
	    $ACC_TRANSIENT	= 0x0080;
	    $ACC_NATIVE		= 0x0100;
	    $ACC_INTERFACE	= 0x0200;
	    $ACC_ABSTRACT	= 0x0400;
	    $ACC_MAX		= 0x0400;

use vars qw(%ACC_2STR_class %ACC_2STR_interface 
	    %ACC_2STR_field %ACC_2STR_method);
%ACC_2STR_class = (0x0001 => 'ACC_PUBLIC', 
		   0x0010 => 'ACC_FINAL', 
		   0x0020 => 'ACC_SUPER', 
		   0x0400 => 'ACC_ABSTRACT');
%ACC_2STR_interface = (0x0001 => 'ACC_PUBLIC', 
		       0x0020 => 'ACC_SUPER', 
		       0x0200 => 'ACC_INTERFACE', 
		       0x0400 => 'ACC_ABSTRACT');
%ACC_2STR_field = (0x0001 => 'ACC_PUBLIC', 
		   0x0002 => 'ACC_PRIVATE', 
		   0x0004 => 'ACC_PROTECTED', 
		   0x0008 => 'ACC_STATIC', 
		   0x0010 => 'ACC_FINAL', 
		   0x0040 => 'ACC_VOLATILE', 
		   0x0080 => 'ACC_TRANSIENT');
%ACC_2STR_method = (0x0001 => 'ACC_PUBLIC', 
		    0x0002 => 'ACC_PRIVATE', 
		    0x0004 => 'ACC_PROTECTED', 
		    0x0008 => 'ACC_STATIC', 
		    0x0010 => 'ACC_FINAL', 
		    0x0020 => 'ACC_SYNCHRONIZED', 
		    0x0100 => 'ACC_NATIVE');

sub RenderAccess {
    my ($bits, $strs, $label) = @_;
    my @accessStrs;
    for (my $bit = 1; $bit <= $ACC_MAX; $bit <<= 1) {
	if ($bits & $bit) {
	    push (@accessStrs, $strs->{$bit});
	    $bits ^= $bit;
	}
    }
    if ($bits) {
	&throw(new W3C::Util::Exception(-message => "unknown bit fields in $label $bits"));
    }
    return "$label: ".join (' ', @accessStrs);
}

