use strict;

package W3C::JVM::Attribute;

sub new_unpack {
    my ($proto, $index, $pBits) = @_;
    my $class = ref($proto) || $proto;
    my $self = {};
    bless ($self, $class);
    my $length;
    ($self->{CONST_INDEX}, $length, $$pBits) = unpack('nNa*', $$pBits);
    ($self->{DATA}, $$pBits) = unpack("a${length}a*", $$pBits);
    return $self;
}

sub fixupRefs {
    my ($self, $pool, $classRef) = @_;
    $self->{CONST_REF} = $pool->getEntry($self->{CONST_INDEX});
    eval {
	my $data = $pool->getEntry(unpack ('n', $self->{DATA}));
	if ($data) {
	    $self->{DATA_REF} = $data;
	}
    }; # don't care if it fails
}

sub getName {
    my ($self) = @_;
    return $self->{CONST_INDEX};
}

sub getData {
    my ($self) = @_;
    return $self->{DATA};
}

sub toString {
    my ($self, $flags) = @_;
    $flags ||= {};
    my $const = $self->{CONST_REF}->toString(); # getConst();
    if (ref $self->{DATA_REF} && $self->{DATA_REF}->can('toString')) {
	my $data = $self->{DATA_REF}->toString();
	return "$const --> $data";
    } else {
	return "$const --> $self->{DATA}";
    }
}

1;

