use strict;

package W3C::JVM::Item;

sub new {
    my ($proto) = @_;
    my $class = ref($proto) || $proto;
    my $self = {};
    bless ($self, $class);
    return $self;
}

package W3C::JVM::StackFrame;
use W3C::Util::Exception;
use W3C::JVM::Attribute;

sub new {
    my ($proto) = @_;
    my $class = ref($proto) || $proto;
#    my $self = {OP_STACK => [new W3C::JVM::Item()], 
#		LOCALS => [new W3C::JVM::Item()]};
    my $self = {OP_STACK => [], 
		LOCALS => []};
    bless ($self, $class);
    return $self;
}

sub getOpStack {
    my ($self) = @_;
    return $self->{OP_STACK};
}

sub getLocals {
    my ($self) = @_;
    return $self->{LOCALS};
}

sub toString {
    my ($self, $flags) = @_;
    $flags ||= {};
    my @ret;
    my $ref = ref $self;
    $ref =~ s/W3C::JVM:://;
    push (@ret, $ref);
    return join ("\n", @ret);
}

1;

