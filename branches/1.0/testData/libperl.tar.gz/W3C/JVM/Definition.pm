use strict;

package W3C::JVM::Definition;
use W3C::Util::Exception;
use W3C::JVM::Attribute;

sub new_unpack {
    my ($proto, $index, $pBits, $constPool) = @_;
    my $class = ref($proto) || $proto;
    my $self = {INDEX => $index, CONST_POOL => $constPool};
    bless ($self, $class);
    my $attrs;
    ($self->{ACCESS}, $self->{NAME_INDEX}, $self->{TYPE_INDEX}, $attrs, $$pBits) = unpack('n4a*', $$pBits);
    for (my $i = 0; $i < $attrs; $i++) {
	push (@{$self->{ATTRIBUTES}}, new_unpack W3C::JVM::Attribute($i, $pBits));
    }
    return $self;
}

sub fixupRefs {
    my ($self, $pool, $classRef) = @_;
    $self->{NAME_REF} = $pool->getEntry($self->{NAME_INDEX});
    $self->{TYPE_REF} = $pool->getEntry($self->{TYPE_INDEX});
    foreach my $attribute (@{$self->{ATTRIBUTES}}) {
	$attribute->fixupRefs($pool);
    }
}

sub getName {
    my ($self) = @_;
    return $self->{NAME_REF};
}

sub toString {
    my ($self, $flags) = @_;
    $flags ||= {};
    my @ret;
    my $ref = ref $self;
    $ref =~ s/W3C::JVM:://;
    push (@ret, "$ref $self->{INDEX}: ");
    push (@ret, $self->_RenderAccess());
    my $tmp;
    $tmp = $self->{NAME_REF}->getConst();
    push (@ret, "name: $tmp");
    $tmp = $self->{TYPE_REF}->getConst();
    push (@ret, "type: $tmp");
    foreach my $attribute (@{$self->{ATTRIBUTES}}) {
	push (@ret, $attribute->toString());
    }
    return join ("\n", @ret);
}

sub _RenderAccess { # protected
    my ($self) = @_;
    &throw(new W3C::Util::NotImplementedException());
}

1;

