use strict;

package W3C::JVM::Interface;
use W3C::JVM::Definition;
use W3C::JVM::Access;

use vars qw(@ISA);
@ISA = qw(W3C::JVM::Definition);

sub new_unpack {
    my ($proto, $index, $pBits, $constPool) = @_;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new_unpack($index, $pBits, $constPool);
    return $self;
}

sub _RenderAccess { # protected
    my ($self) = @_;
    return &RenderAccess($self->{ACCESS}, \%ACC_2STR_interface, 'interface access')
}

1;

