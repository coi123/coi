#!/usr/bin/perl

package W3C::JVM::JavaClasses::java::lang::System;

use vars qw(@EXPORT_OK $System);
@EXPORT_OK = qw($System);

use W3C::JVM::JavaClasses::java::io::PrintStream;

sub new {
    my ($proto, $pBits, $jvm) = @_;
    my $class = ref($proto) || $proto;
    my $self = {};
    bless ($self, $class);
    $self->{'out'} = new W3C::JVM::JavaClasses::java::io::PrintStream();
    return $self;
}

BEGIN {
    $System = new W3C::JVM::JavaClasses::java::lang::System();
    $W3C::JVM::JavaClasses::java::lang::System = $System;
}

1;

