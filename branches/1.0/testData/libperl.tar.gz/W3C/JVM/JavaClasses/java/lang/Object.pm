#!/usr/bin/perl

package W3C::JVM::JavaClasses::java::lang::Object;

sub new {
    my ($proto, $pBits, $jvm) = @_;
    my $class = ref($proto) || $proto;
    my $self = {};
    bless ($self, $class);
    print "created $self\n";
    return $self;
}

1;

