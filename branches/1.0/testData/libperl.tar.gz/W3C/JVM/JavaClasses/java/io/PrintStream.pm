#!/usr/bin/perl

package W3C::JVM::JavaClasses::java::io::PrintStream;

sub new {
    my ($proto, $pBits, $jvm) = @_;
    my $class = ref($proto) || $proto;
    my $self = {};
    bless ($self, $class);
    return $self;
}

sub println_Ljava_ulang_uString {
    my ($self, $str) = @_;
    print "$str\n";
}

1;

