#Copyright Massachusetts Institute of technology, 2002.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

use strict;
require Exporter;
#require AutoLoader;


$W3C::JVM::JVM::REVISION = '$Id: BuiltIn.pm,v 1.5 2002/02/15 03:21:14 eric Exp $ ';

package W3C::JVM::BuiltIn;
use vars qw(@ISA @TODO @EXPORT_OK $VERSION $DSLI);
@ISA = qw(Exporter); # AutoLoader);
@TODO = qw();
@EXPORT_OK = qw($BuiltIn);
$VERSION = 0.0;
$DSLI = 'adpO';

# Contrary to my standard approach, W3C::JVM::BuiltIn objects are
# implemented as ARRAY refs for ease and brevity of initialization.
# These are the element offsets for the array members:
use vars qw($BuiltIn $ACCESS $CODE);
($ACCESS, $CODE) = (0 .. 1);

# Following is an array of W3C::JVM::BuiltIn objects, all of which
# will be initialized at the end of the initializer:
$BuiltIn = {
    'java/io/PrintStream' => {
	'println' => {
	    '(Ljava/lang/String;)V' => [0, 'print ${$args->[0]}," - ",$args->[1],"\n";'], 
	}
    }
};

# Take the above array of methods and turn them elements into
# W3C::JVM::BuiltIn objects so the following methods may
# be called upon them.
foreach my $classKey (keys %$BuiltIn) {
    my $class = $BuiltIn->{$classKey};
    foreach my $methodKey (keys %$class) {
	my $methodNames = $class->{$methodKey};
	foreach my $typeKey (keys %$methodNames) {
	    my $method = $methodNames->{$typeKey};
	    bless ($method, 'W3C::JVM::BuiltIn');
	}
    }
}

sub getCode {
    my ($self) = @_;
    return $self->[$CODE];
}

1;

