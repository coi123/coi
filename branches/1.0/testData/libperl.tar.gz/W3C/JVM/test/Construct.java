class Construct {
    private int int1;

    public Construct (int parm1) {
	int1 = parm1;	
    }

    public static void main(String[] args) {
        Construct construct = new Construct(127);
	System.out.println("int1:" + construct.int1);
    }
}

