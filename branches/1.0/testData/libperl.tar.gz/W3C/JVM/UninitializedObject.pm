use strict;

package W3C::JVM::UninitializedObject;
use W3C::Util::Exception;
use W3C::JVM::JVM qw(&javaClass2PerlPackage);

sub new {
    my ($proto, $className) = @_;
    my $class = ref($proto) || $proto;
    my $self = {NAME => $className, CLASS => &W3C::JVM::JVM::javaClass2PerlPackage($className)};
    bless ($self, $class);
    return $self;
}

sub getClassName {
    my ($self) = @_;
    return $self->{CLASS};
}

sub toString {
    my ($self, $flags) = @_;
    $flags ||= {};
    return "Unitialized $self->{CLASS}";
}

1;

