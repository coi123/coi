#Copyright Massachusetts Institute of technology, 1998.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

use strict;
require Exporter;
#require AutoLoader;

$W3C::Rnodes::RdfAclAgent::REVISION = '$Id: RdfAclAgent.pm,v 1.14 2004/04/16 05:56:37 eric Exp $ ';

package W3C::Rnodes::RdfAclAgent;
use W3C::Util::Object;
use W3C::Util::Exception;

use W3C::Rnodes::ACL qw();

use vars qw($VERSION $DSLI @ISA @EXPORT @EXPORT_OK);
@ISA = qw(W3C::Util::NamedParmObject Exporter); # AutoLoader);
@EXPORT = qw();
@EXPORT_OK = qw();
$VERSION = 0.10;
$DSLI = 'adpO';

sub new {
    my ($proto, @parms) = @_;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new(@parms);
    bless ($self, $class);
    my $xmlParser = new W3C::XML::PerlXmlParser;
    my $errorHandler = new W3C::Rdf::RdfDbErrorHandler(-documentLocator => $xmlParser);
    my $objectDBProps = new W3C::Util::Properties($self->{-properties}->getI('dbProps'));
    $self->{RDF_DB} = new W3C::Rdf::ObjectDB({-atomDictionary => $self->{-atomDictionary}, 
					      -properties => $objectDBProps, 
					      -errorHandler => $errorHandler, 
					      -lazyReification => 1});
    return $self;
}

############################## ACLAgentInterface ##############################

sub disconnect {
    my ($self) = @_;
}

sub getAclsFor {
    my ($self, $aclDB, $resourcesP, $wildcard, $recursive) = @_;

    # Copy resources as we will be playing around with them.
    my @resources = ref $resourcesP eq 'ARRAY' ? @$resourcesP : $resourcesP;
    return;
    &throw(new W3C::Util::NotImplementedException());
}

sub setAclFor {
    my ($self, $resources, $acl, $creations, $updates) = @_;
    &throw(new W3C::Util::NotImplementedException());
}

sub deleteAclFor {
    my ($self, $resources, $deletions) = @_;
    &throw(new W3C::Util::NotImplementedException());
}

sub setAuthResAttrs {
    my ($self, $aclDB, $requiredAccess, $user, $ip) = @_;
    &throw(new W3C::Util::NotImplementedException());
}

1;

__END__

=head1 NAME

W3C::Rnodes::RdfAclAgent - 

=head1 SYNOPSIS

  use W3C::Rnodes::RdfAclAgent;

=head1 DESCRIPTION

<description>

This module is part of the W3C::Rnodes CPAN module.

=head1 AUTHOR

Eric Prud\'hommeaux <eric@w3.org>

=head1 SEE ALSO

W3C::Rnodes::ACL(3) perl(1).

=cut
