#Copyright Massachusetts Institute of technology, 2000.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

# Overload of W3C::Rnodes::UnixPermAgent to handle ,v files.

use strict;
require Exporter;
#require AutoLoader;

package W3C::Rnodes::CvsPermAgent;
use W3C::Util::Exception;
use W3C::Rnodes::UnixPermAgent;

use vars qw($REVISION $VERSION $DSLI @ISA @EXPORT @EXPORT_OK);
$REVISION = '$Id: CvsPermAgent.pm,v 1.7 2003/02/28 21:42:14 eric Exp $ ';
@ISA = qw(W3C::Rnodes::UnixPermAgent Exporter); # AutoLoader);
@EXPORT = qw();
@EXPORT_OK = qw();
$VERSION = 0.10;
$DSLI = 'adpO';

#####
# getAclsFor - creates new entry for resource, acls set according to file permissions
#
# return (new id, redirection location)

sub _mapToLocalFile {
    my ($self, $singleResource, $isDir) = @_;
    if (!$isDir) {
	if (!($singleResource =~ s/\Z/\,v/)) {
	    &throw(new W3C::Util::Exception(-message => "Could not execute CVS ,v file to uri map \"s/\\Z/\\,v/\""));
	}
    }
    return CGI::unescape($singleResource);
}

sub _mapFromLocalFile {
    my ($self, $singleResource, $isDir) = @_;
    if (!$isDir) {
	if (!($singleResource =~ s/\%2Cv\Z//)) {
	    &throw(new W3C::Util::Exception(-message => "Could not execute CVS ,v file to uri map \"s/\\,v\\Z//\""));
	}
    }
    return $singleResource;
}

1;

__END__

=head1 NAME

W3C::Rnodes::CvsPermAgent - ACLImporter for W3C::Rnodes

=head1 SYNOPSIS

    use W3C::Rnodes::CvsPermAgent;
    my $cvsAgent = new W3C::Rnodes::CvsPermAgent(-properties => $self->{PROPERTIES}, 
						 -sourceID => $SOURCE_CVS, 
						 -getFilepathMaps => sub {
						     $self->_getCVSFilepathMaps(@_)}, 
						 -getFilesystemIdsAndTypes => sub {
						     $self->_getFilesystemIdsAndTypes(@_)});
    $self->{ACL_IMPORTERS} = [$cvsAgent];

=head1 DESCRIPTION

W3C::Rnodex::CvsPermAgent is an ACLImporter for reading ACLs from filesystem permissions in a CVS repository.

This module is part of the W3C::Rnodes CPAN module.

=head1 FUTURE PLANS

Maybe some day, if i've got nothing else to do, work on a pserver version.

=head1 AUTHOR

Eric Prud'hommeaux <eric@w3.org>

=head1 SEE ALSO

W3C::Rnodes::ACL(3) perl(1).

=cut
