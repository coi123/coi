#Copyright Massachusetts Institute of technology, 1998.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

# Help strings for ChACL applications to present to user.

use strict;
require Exporter;
#require AutoLoader;

package W3C::Rnodes::ChaclHelp;

use vars qw($VERSION $REVISION $DSLI @ISA @EXPORT @EXPORT_OK);
@ISA = qw(Exporter); # AutoLoader);
@EXPORT = qw();
@EXPORT_OK = qw(%INFO_FUNCS);
$VERSION = 0.10;
$REVISION = '$Id: ChaclHelp.pm,v 1.2 2001/05/31 15:25:08 eric Exp $ ';
$DSLI = 'adpO';

sub new {
    my ($proto) = @_;
    my $class = ref($proto) || $proto;
    my $self = {LayoutRowNUKE => "    </td></tr><tr><td>\n",
		Intro => <<EOF
<div class="annotation">
<h2>Introduction</h2>
Welcome to the W3C Access Control List (ACL) editor. This is a system to allow any person with sufficient priveleges to permit
or deny others a subset of those priveleges.

<dl>
<dt><b><a name=\"rule\">(ACL) rule</a></b><dd>a combination of a type of identity (user, group, ip, or member organization), 
    an identity (like \"bob\" or 1.2.3.4), and a set of access priveleges to extend to that identity.
    The access priveleges consist of:<ol>
	<li>read priveleges<ul>
	    <li>chacl - change (edit) these ACL rules</li>
	    <li>racl - read these ACL rules</li>
	    <li>get - HTTP <em>get</em> request (the normal command to get a document)</li>
	    <li>head - the HTTP <em>head</em> request is like the HTTP <em>get</em> request except it 
		returns only the headers for the document rather than the document itself </li>
	    <li>trace - an echo tool for debugging http problems. </li>
	    <li>options - a way to ask the http server what commands it excepts</li>
	</ul><li>write priveleges<ul>
	    <li>put - the opposite of <em>get</em>. This is how you upload files to the server.</li>
	    <li>delete - remove a document on the server.</li>
	</ul><li>execution priveleges<ul>
	    <li>post - execute a CGI script that has permanent side-effects</li>
	</ul><li>odd stuff<ul>
	    <li>connect - I really don\'t know. I found it in apache and stuck in the access options for completeness</li>
	</ul>
    </ol></dd>
<dt><a name=\"macro\"><b>macro</b></a><dd>a standard set of <a href=\"\#rule\"><em>rules</em></a> associated with these names<ul>
    <li><a name="user-access">user</a> - document is restricted to be viewed and edited by the current user</li>
    <li><a name="team-access">team</a> - document is restricted to be viewed and edited by the W3C team group</li>
    <li><a name="member-access">member</a> - W3C members may view the document, but only the W3C team group may edit it</li>
    <li><a name="world-access">world</a> - anyone may view the document, but only the W3C team group may edit it</li>
    <li><a name="user-script-access">user-script</a> - same as <em><a href="#user-access">user</a></em>+<em>post</em> privilege</li>
    <li><a name="team-script-access">team-script</a> - same as <em><a href="#team-access">team</a></em>+<em>post</em> privilege</li>
    <li><a name="member-script-access">member-script</a> - same as <em><a href="#member-access">member</a></em>+<em>post</em> privilege</li>
    <li><a name="world-script-access">world-script</a> - same as <em><a href="#world-access">world</a></em>+<em>post</em> privilege</li>
    </ul>The macros provide a way to group the commonly used <a href=\"\#rule\"><em>rule</em></a> sets and to give users some
guidance. The macros can serve as a template, or point of departure, for users who require more exotic rules.</dd>

<dt><a name=\"selectedResources\"><b>selected resources</b></a><dd>all operations are performed on a set of resources
coming from either:<ul>
    <li>the resource and wildcard referenced by the user when they started chacl&nbsp;&nbsp;or</li>
    <li>the resources listed in the ACL RDF</li>
</ul>This list of resources is further limited by the set of resources that the user selected with the checkboxes if the user
is manipulating more than one resource. This may cause some confusion, but I was anxious to avoid the </dd>
</dl>

The following icon indicates the current level of access to the listed resources.
(My Publish Page is just a random icon I picked to indicate a mixed bag of ACL <a href=\"\#rule\"><em>rules</em></a>. I would
appreciate any help in finding/creating small, effective icons.)
</div>
EOF
    ,

		Help => <<EOF
<div class="annotation">
Control whether these \"helpful\" annotations are displayed.
</div>
EOF
    ,
		HelpButtonNUKE => "      <input type=\"submit\" name=\"w3c_helpHide\" value=\"Hide Help\" />\n",

		RenderOptions => <<EOF
<div class="annotation">
Select a display mode from<ol>
  <li>diff - shows the resource name and the current level of access the closest <a href=\"\#macro\"><em>macro</em></a>
      and the list of <a href=\"\#rule\"><em>rules</em></a> that differ from that <a href=\"\#macro\"><em>macro</em></a>.</li>
  <li>list - just displays the list of ACL <a href=\"\#rule\"><em>rules</em></a> for a resource.
</ol>
<code>tabular form</code> is an alternate presentation in a table.<br />
<code>expert mode</code> allows the experience user to<ul>
  <li>customize ACL macros.</li>
  <li>copy ACLs from one resource to another.</li>
  <li>view and edit the ACL RDF.</li>
</ul>
</div>
EOF
    ,

		RenderAuthButton => <<EOF
<div class="annotation">
You do not have full access to all listed resources so you may press this button to ask your
browser for a username and password. Don\'t press this button if you don\'t have another
identity you would like to use.
</div>
EOF
    ,

		CurrentId => <<EOF
<div class="annotation">
This it the identity you are currently using to athenticate yourself to the server.
</div>
EOF
    ,

		RenderACLs => <<EOF
<div class="annotation">
Following is a list of all the resources you have selected and their corresponding access
<a href=\"\#rule\"><em>rules</em></a> displayed occording to the <em>render options</em> above.
</div>
EOF
    ,

		RescanOrigResources => <<EOF
<div class="annotation">
You started chacl with a wildcard. You may, at any point, press this button to return to editing
the ACLs for all resoruces covered by that wildcard.
</div>
EOF
    ,

		RenderMacros => <<EOF
<div class="annotation">
These are the <a href=\"\#macro\"><em>macro</em></a> options. They shortcut the Rdf editing process by directly
manipulating the ACL database by setting the ACL for each of the selected resources to the selected macro.
</div>
EOF
    ,

		RenderAclRdf => <<EOF
<div class="annotation">
All ACL <a href=\"\#rule\"><em>rules</em></a> may be expressed in RDF. RDF describing the ACLs you are currently editing is
displayed (and editable) here.
</div>
EOF
    ,

		RenderPicks => <<EOF
<div class="annotation">
Select what identities you wish to assign which access priveleges to which resource.
</div>
EOF
    ,

		RenderDetails => <<EOF
<div class="annotation">
This is an attempt to more fully describe a seleced identity.
</div>
EOF
    ,
		};
    bless ($self, $class);
    return $self;
}

package W3C::Rnodes::NoHelp;

use vars qw($VERSION $REVISION $DSLI @ISA @EXPORT @EXPORT_OK);
@ISA = qw(Exporter); # AutoLoader);
@EXPORT = qw();
@EXPORT_OK = qw(%INFO_FUNCS);
$VERSION = 0.10;
$DSLI = 'adpO';

sub new {
    my ($proto) = @_;
    my $class = ref($proto) || $proto;
    my $self = {LayoutRowNUKE => "    </td><td>\n",
		Intro => '',
		Help => '',
		HelpButtonNUKE => "      <input type=\"submit\" name=\"w3c_helpShow\" value=\"Show Help\" />\n",
		RenderOptions => '',
		RenderAuthButton => '',
		CurrentId => '',
		RenderACLs => '',
		RescanOrigResources => '',
		RenderMacros => '',
		RenderAclRdf => '',
		RenderPicks => '',
		RenderDetails => '',
		};
    bless ($self, $class);
    return $self;
}

sub getFoo {
    return "the nohelp foo";
}

package W3C::Rnodes::ChaclHelp;

1;

__END__

=head1 NAME

W3C::Rnodes::ChaclHelp - 

=head1 SYNOPSIS

  use W3C::Rnodes::ChaclHelp;

=head1 DESCRIPTION

<description>

This module is part of the W3C::Rnodes CPAN module.

=head1 AUTHOR

Eric Prud\'hommeaux <eric@w3.org>

=head1 SEE ALSO

W3C::Rnodes::ACL(3) perl(1).

=cut
