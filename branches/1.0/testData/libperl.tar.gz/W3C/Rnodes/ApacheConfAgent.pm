#Copyright W3C, 2003.
#Written by Dominique Hazael-Massieux for the World Wide Web Consortium

# Overload of UnixPermAgent to handle predefined configurations in Apache

use strict;
require Exporter;
#require AutoLoader;

package W3C::Rnodes::ApacheConfAgent; # implements W3C::Rnodes::ACLAgentInterface
use W3C::Util::Exception;
use W3C::Rnodes::UnixPermAgent;

use W3C::Rnodes::ACL qw(&buildDBRuleId
			&parseURI
			$TYPE_NONE);

use vars qw($REVISION $VERSION $DSLI @ISA @EXPORT @EXPORT_OK);
$REVISION = '$Id: ApacheConfAgent.pm,v 1.3 2005/03/17 05:56:53 eric Exp $ ';
@ISA = qw(W3C::Rnodes::UnixPermAgent Exporter); # AutoLoader);
@EXPORT = qw();
@EXPORT_OK = qw();
$VERSION = 0.10;
$DSLI = 'adpO';

sub _getFileSystemRulesFor {
    my ($self, $aclDB, $mapped, $resource, $isDir) = @_;
    my ($dev,$ino,$mode,$nlink,$uid,$gid,$rdev,$size,$atime,$mtime,$ctime,$blksize,$blocks) = stat($mapped);
    &throw(new W3C::Util::NoSuchFileException(-file => $mapped, -uri => $resource)) if (!defined $dev);
    my $count = 0;
    my ($protocol, $host, $portStr, $path) = &parseURI($resource);
    foreach my $rule (@{&{$self->{-getRules}}($path)}) {
	my @rules = @$rule ;
	$aclDB->addDBRule($resource, &buildDBRuleId($rules[0], $rules[1]), $rules[2], {'source'=> $self->{-sourceID}});
	$count++;
    }
    return $count;
}


1;

__END__

=head1 NAME

W3C::Rnodes::UnixPermAgent - 

=head1 SYNOPSIS

  use W3C::Rnodes::UnixPermAgent;

=head1 DESCRIPTION

<description>

This module is part of the W3C::Rnodes CPAN module.

=head1 AUTHOR

Eric Prud\'hommeaux <eric@w3.org>

=head1 SEE ALSO

W3C::Rnodes::ACL(3) perl(1).

=cut
