@W3C::Rnodes::AclSqlObjects::userDetails::ISA = ( 'W3C::Database::ObjectBase' );
%W3C::Rnodes::AclSqlObjects::userDetails::_TableDesc = ( '-table' => 'userDetails',
                                                         '-class' => 'W3C::Rnodes::AclSqlObjects::userDetails',
                                                         '-fieldOrder' => [ 'id',
                                                                            'family',
                                                                            'given',
                                                                            'prefix',
                                                                            'status',
                                                                            'passwd',
                                                                            'mailback',
                                                                            'email',
                                                                            'emailUrisId',
                                                                            'phone',
                                                                            'position',
                                                                            'ac',
                                                                            'acEric',
                                                                            'url',
                                                                            'last',
                                                                            'cleartxt',
                                                                            'notes',
                                                                            'phonesId' ],
                                                         '-fields' => { 'acEric' => { '-size' => '10',
                                                                                      '-type' => 0,
                                                                                      '-null' => 1 },
                                                                        'status' => { '-size' => '10',
                                                                                      '-type' => 0,
                                                                                      '-null' => 1,
                                                                                      '-default' => '0' },
                                                                        'ac' => { '-size' => '255',
                                                                                  '-type' => 4,
                                                                                  '-null' => 1 },
                                                                        'emailUrisId' => { '-target' => [ 'uris',
                                                                                                          'id' ],
                                                                                           '-size' => '10',
                                                                                           '-type' => 0,
                                                                                           '-default' => '0' },
                                                                        'notes' => { '-size' => undef,
                                                                                     '-type' => 5,
                                                                                     '-default' => '' },
                                                                        'phone' => { '-size' => '32',
                                                                                     '-type' => 4,
                                                                                     '-null' => 1 },
                                                                        'passwd' => { '-size' => '40',
                                                                                      '-type' => 4,
                                                                                      '-null' => 1 },
                                                                        'given' => { '-size' => '255',
                                                                                     '-type' => 4,
                                                                                     '-default' => '' },
                                                                        'cleartxt' => { '-size' => '40',
                                                                                        '-type' => 4,
                                                                                        '-null' => 1 },
                                                                        'phonesId' => { '-size' => '10',
                                                                                        '-type' => 0,
                                                                                        '-null' => 1 },
                                                                        'mailback' => { '-size' => '40',
                                                                                        '-type' => 4,
                                                                                        '-null' => 1 },
                                                                        'url' => { '-size' => '255',
                                                                                   '-type' => 4,
                                                                                   '-null' => 1 },
                                                                        'position' => { '-size' => '255',
                                                                                        '-type' => 4,
                                                                                        '-null' => 1 },
                                                                        'last' => { '-type' => 10,
                                                                                    '-null' => 1 },
                                                                        'id' => { '-size' => '10',
                                                                                  '-type' => 0,
                                                                                  '-default' => '0' },
                                                                        'family' => { '-size' => '255',
                                                                                      '-type' => 4,
                                                                                      '-default' => '' },
                                                                        'email' => { '-size' => '255',
                                                                                     '-type' => 4,
                                                                                     '-null' => 1 },
                                                                        'prefix' => { '-size' => '255',
                                                                                      '-type' => 4,
                                                                                      '-default' => '' } },
                                                         '-primaryKey' => 'id' );
$W3C::Rnodes::AclSqlObjects::_AllTables{'userDetails'} = \%W3C::Rnodes::AclSqlObjects::userDetails::_TableDesc;
sub W3C::Rnodes::AclSqlObjects::userDetails::getTableDesc {return \%W3C::Rnodes::AclSqlObjects::userDetails::_TableDesc;}
sub W3C::Rnodes::AclSqlObjects::userDetails::getPrimaryKey {return $_[0]->{DB_ID};}
sub W3C::Rnodes::AclSqlObjects::userDetails::_getId {return $_[0]->{FIELD_VALUES}{'id'};}
sub W3C::Rnodes::AclSqlObjects::userDetails::_checkId {return ${($_[0]->check(['id']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_setId {$_[0]->{FIELD_VALUES}{'id'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_updateId {$_[0]->update({'id' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::userDetails::_getFamily {return $_[0]->{FIELD_VALUES}{'family'};}
sub W3C::Rnodes::AclSqlObjects::userDetails::_checkFamily {return ${($_[0]->check(['family']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_setFamily {$_[0]->{FIELD_VALUES}{'family'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_updateFamily {$_[0]->update({'family' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::userDetails::_getGiven {return $_[0]->{FIELD_VALUES}{'given'};}
sub W3C::Rnodes::AclSqlObjects::userDetails::_checkGiven {return ${($_[0]->check(['given']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_setGiven {$_[0]->{FIELD_VALUES}{'given'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_updateGiven {$_[0]->update({'given' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::userDetails::_getPrefix {return $_[0]->{FIELD_VALUES}{'prefix'};}
sub W3C::Rnodes::AclSqlObjects::userDetails::_checkPrefix {return ${($_[0]->check(['prefix']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_setPrefix {$_[0]->{FIELD_VALUES}{'prefix'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_updatePrefix {$_[0]->update({'prefix' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::userDetails::_getStatus {return $_[0]->{FIELD_VALUES}{'status'};}
sub W3C::Rnodes::AclSqlObjects::userDetails::_checkStatus {return ${($_[0]->check(['status']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_setStatus {$_[0]->{FIELD_VALUES}{'status'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_updateStatus {$_[0]->update({'status' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::userDetails::_getPasswd {return $_[0]->{FIELD_VALUES}{'passwd'};}
sub W3C::Rnodes::AclSqlObjects::userDetails::_checkPasswd {return ${($_[0]->check(['passwd']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_setPasswd {$_[0]->{FIELD_VALUES}{'passwd'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_updatePasswd {$_[0]->update({'passwd' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::userDetails::_getMailback {return $_[0]->{FIELD_VALUES}{'mailback'};}
sub W3C::Rnodes::AclSqlObjects::userDetails::_checkMailback {return ${($_[0]->check(['mailback']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_setMailback {$_[0]->{FIELD_VALUES}{'mailback'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_updateMailback {$_[0]->update({'mailback' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::userDetails::_getEmail {return $_[0]->{FIELD_VALUES}{'email'};}
sub W3C::Rnodes::AclSqlObjects::userDetails::_checkEmail {return ${($_[0]->check(['email']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_setEmail {$_[0]->{FIELD_VALUES}{'email'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_updateEmail {$_[0]->update({'email' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::userDetails::_getEmailUrisId {return $_[0]->{FIELD_VALUES}{'emailUrisId'};}
sub W3C::Rnodes::AclSqlObjects::userDetails::_checkEmailUrisId {return ${($_[0]->check(['emailUrisId']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_setEmailUrisId {$_[0]->{FIELD_VALUES}{'emailUrisId'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_updateEmailUrisId {$_[0]->update({'emailUrisId' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::userDetails::_getPhone {return $_[0]->{FIELD_VALUES}{'phone'};}
sub W3C::Rnodes::AclSqlObjects::userDetails::_checkPhone {return ${($_[0]->check(['phone']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_setPhone {$_[0]->{FIELD_VALUES}{'phone'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_updatePhone {$_[0]->update({'phone' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::userDetails::_getPosition {return $_[0]->{FIELD_VALUES}{'position'};}
sub W3C::Rnodes::AclSqlObjects::userDetails::_checkPosition {return ${($_[0]->check(['position']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_setPosition {$_[0]->{FIELD_VALUES}{'position'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_updatePosition {$_[0]->update({'position' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::userDetails::_getAc {return $_[0]->{FIELD_VALUES}{'ac'};}
sub W3C::Rnodes::AclSqlObjects::userDetails::_checkAc {return ${($_[0]->check(['ac']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_setAc {$_[0]->{FIELD_VALUES}{'ac'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_updateAc {$_[0]->update({'ac' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::userDetails::_getAcEric {return $_[0]->{FIELD_VALUES}{'acEric'};}
sub W3C::Rnodes::AclSqlObjects::userDetails::_checkAcEric {return ${($_[0]->check(['acEric']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_setAcEric {$_[0]->{FIELD_VALUES}{'acEric'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_updateAcEric {$_[0]->update({'acEric' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::userDetails::_getUrl {return $_[0]->{FIELD_VALUES}{'url'};}
sub W3C::Rnodes::AclSqlObjects::userDetails::_checkUrl {return ${($_[0]->check(['url']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_setUrl {$_[0]->{FIELD_VALUES}{'url'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_updateUrl {$_[0]->update({'url' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::userDetails::_getLast {return $_[0]->{FIELD_VALUES}{'last'};}
sub W3C::Rnodes::AclSqlObjects::userDetails::_checkLast {return ${($_[0]->check(['last']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_setLast {$_[0]->{FIELD_VALUES}{'last'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_updateLast {$_[0]->update({'last' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::userDetails::_getCleartxt {return $_[0]->{FIELD_VALUES}{'cleartxt'};}
sub W3C::Rnodes::AclSqlObjects::userDetails::_checkCleartxt {return ${($_[0]->check(['cleartxt']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_setCleartxt {$_[0]->{FIELD_VALUES}{'cleartxt'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_updateCleartxt {$_[0]->update({'cleartxt' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::userDetails::_getNotes {return $_[0]->{FIELD_VALUES}{'notes'};}
sub W3C::Rnodes::AclSqlObjects::userDetails::_checkNotes {return ${($_[0]->check(['notes']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_setNotes {$_[0]->{FIELD_VALUES}{'notes'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_updateNotes {$_[0]->update({'notes' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::userDetails::_getPhonesId {return $_[0]->{FIELD_VALUES}{'phonesId'};}
sub W3C::Rnodes::AclSqlObjects::userDetails::_checkPhonesId {return ${($_[0]->check(['phonesId']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_setPhonesId {$_[0]->{FIELD_VALUES}{'phonesId'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::userDetails::_updatePhonesId {$_[0]->update({'phonesId' => $_[1]});}

@W3C::Rnodes::AclSqlObjects::groupDetails::ISA = ( 'W3C::Database::ObjectBase' );
%W3C::Rnodes::AclSqlObjects::groupDetails::_TableDesc = ( '-table' => 'groupDetails',
                                                          '-class' => 'W3C::Rnodes::AclSqlObjects::groupDetails',
                                                          '-fieldOrder' => [ 'id',
                                                                             'type',
                                                                             'acRep',
                                                                             'entityEncoded',
                                                                             'alphaname',
                                                                             'category',
                                                                             'name',
                                                                             'notes',
                                                                             'last' ],
                                                          '-fields' => { 'category' => { '-size' => '100',
                                                                                         '-type' => 4,
                                                                                         '-null' => 1 },
                                                                         'acRep' => { '-size' => '10',
                                                                                      '-type' => 0,
                                                                                      '-default' => '0' },
                                                                         'entityEncoded' => { '-size' => '255',
                                                                                              '-type' => 4,
                                                                                              '-default' => '' },
                                                                         'alphaname' => { '-size' => '255',
                                                                                          '-type' => 4,
                                                                                          '-default' => '' },
                                                                         'name' => { '-size' => '255',
                                                                                     '-type' => 4,
                                                                                     '-default' => '' },
                                                                         'last' => { '-type' => 10,
                                                                                     '-null' => 1 },
                                                                         'id' => { '-size' => '10',
                                                                                   '-type' => 0,
                                                                                   '-default' => '0' },
                                                                         'notes' => { '-size' => undef,
                                                                                      '-type' => 5,
                                                                                      '-default' => '' },
                                                                         'type' => { '-size' => '1',
                                                                                     '-type' => 3,
                                                                                     '-null' => 1 } },
                                                          '-primaryKey' => 'id' );
$W3C::Rnodes::AclSqlObjects::_AllTables{'groupDetails'} = \%W3C::Rnodes::AclSqlObjects::groupDetails::_TableDesc;
sub W3C::Rnodes::AclSqlObjects::groupDetails::getTableDesc {return \%W3C::Rnodes::AclSqlObjects::groupDetails::_TableDesc;}
sub W3C::Rnodes::AclSqlObjects::groupDetails::getPrimaryKey {return $_[0]->{DB_ID};}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_getId {return $_[0]->{FIELD_VALUES}{'id'};}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_checkId {return ${($_[0]->check(['id']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_setId {$_[0]->{FIELD_VALUES}{'id'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_updateId {$_[0]->update({'id' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_getType {return $_[0]->{FIELD_VALUES}{'type'};}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_checkType {return ${($_[0]->check(['type']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_setType {$_[0]->{FIELD_VALUES}{'type'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_updateType {$_[0]->update({'type' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_getAcRep {return $_[0]->{FIELD_VALUES}{'acRep'};}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_checkAcRep {return ${($_[0]->check(['acRep']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_setAcRep {$_[0]->{FIELD_VALUES}{'acRep'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_updateAcRep {$_[0]->update({'acRep' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_getEntityEncoded {return $_[0]->{FIELD_VALUES}{'entityEncoded'};}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_checkEntityEncoded {return ${($_[0]->check(['entityEncoded']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_setEntityEncoded {$_[0]->{FIELD_VALUES}{'entityEncoded'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_updateEntityEncoded {$_[0]->update({'entityEncoded' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_getAlphaname {return $_[0]->{FIELD_VALUES}{'alphaname'};}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_checkAlphaname {return ${($_[0]->check(['alphaname']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_setAlphaname {$_[0]->{FIELD_VALUES}{'alphaname'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_updateAlphaname {$_[0]->update({'alphaname' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_getCategory {return $_[0]->{FIELD_VALUES}{'category'};}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_checkCategory {return ${($_[0]->check(['category']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_setCategory {$_[0]->{FIELD_VALUES}{'category'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_updateCategory {$_[0]->update({'category' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_getName {return $_[0]->{FIELD_VALUES}{'name'};}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_checkName {return ${($_[0]->check(['name']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_setName {$_[0]->{FIELD_VALUES}{'name'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_updateName {$_[0]->update({'name' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_getNotes {return $_[0]->{FIELD_VALUES}{'notes'};}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_checkNotes {return ${($_[0]->check(['notes']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_setNotes {$_[0]->{FIELD_VALUES}{'notes'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_updateNotes {$_[0]->update({'notes' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_getLast {return $_[0]->{FIELD_VALUES}{'last'};}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_checkLast {return ${($_[0]->check(['last']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_setLast {$_[0]->{FIELD_VALUES}{'last'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::groupDetails::_updateLast {$_[0]->update({'last' => $_[1]});}

@W3C::Rnodes::AclSqlObjects::hierarchy::ISA = ( 'W3C::Database::ObjectBase' );
%W3C::Rnodes::AclSqlObjects::hierarchy::_TableDesc = ( '-table' => 'hierarchy',
                                                       '-index' => { 'PRIMARY' => { '-unique' => '1',
                                                                                    '-sequence' => [ 'super',
                                                                                                     'sub' ],
                                                                                    '-fields' => { 'super' => '0',
                                                                                                   'sub' => '1' } },
                                                                     'sub' => { '-unique' => '',
                                                                                '-sequence' => [ 'sub',
                                                                                                 'super' ],
                                                                                '-fields' => { 'super' => '1',
                                                                                               'sub' => '0' } } },
                                                       '-class' => 'W3C::Rnodes::AclSqlObjects::hierarchy',
                                                       '-fieldOrder' => [ 'super',
                                                                          'sub',
                                                                          'type',
                                                                          'sponsor',
                                                                          'stops',
                                                                          'why',
                                                                          'newType',
                                                                          'last' ],
                                                       '-fields' => { 'why' => { '-size' => '255',
                                                                                 '-type' => 4,
                                                                                 '-null' => 1 },
                                                                      'stops' => { '-size' => '10',
                                                                                   '-type' => 0,
                                                                                   '-default' => '0' },
                                                                      'super' => { '-size' => '10',
                                                                                   '-type' => 0,
                                                                                   '-default' => '0' },
                                                                      'sponsor' => { '-target' => [ 'ids',
                                                                                                    'id' ],
                                                                                     '-size' => '10',
                                                                                     '-type' => 0,
                                                                                     '-null' => 1 },
                                                                      'last' => { '-type' => 10,
                                                                                  '-null' => 1 },
                                                                      'newType' => { '-size' => '1',
                                                                                     '-type' => 3,
                                                                                     '-null' => 1 },
                                                                      'type' => { '-size' => '1',
                                                                                  '-type' => 3,
                                                                                  '-default' => '' },
                                                                      'sub' => { '-size' => '10',
                                                                                 '-type' => 0,
                                                                                 '-default' => '0' } },
                                                       '-primaryKey' => [ 'super',
                                                                          'sub' ] );
$W3C::Rnodes::AclSqlObjects::_AllTables{'hierarchy'} = \%W3C::Rnodes::AclSqlObjects::hierarchy::_TableDesc;
sub W3C::Rnodes::AclSqlObjects::hierarchy::getTableDesc {return \%W3C::Rnodes::AclSqlObjects::hierarchy::_TableDesc;}
sub W3C::Rnodes::AclSqlObjects::hierarchy::getPrimaryKey {return $_[0]->{DB_ID};}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_getSuper {return $_[0]->{FIELD_VALUES}{'super'};}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_checkSuper {return ${($_[0]->check(['super']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_setSuper {$_[0]->{FIELD_VALUES}{'super'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_updateSuper {$_[0]->update({'super' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_getType {return $_[0]->{FIELD_VALUES}{'type'};}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_checkType {return ${($_[0]->check(['type']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_setType {$_[0]->{FIELD_VALUES}{'type'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_updateType {$_[0]->update({'type' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::hierarchy::getPrimaryKey {return $_[0]->{DB_ID};}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_getSub {return $_[0]->{FIELD_VALUES}{'sub'};}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_checkSub {return ${($_[0]->check(['sub']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_setSub {$_[0]->{FIELD_VALUES}{'sub'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_updateSub {$_[0]->update({'sub' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_getSponsor {return $_[0]->{FIELD_VALUES}{'sponsor'};}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_checkSponsor {return ${($_[0]->check(['sponsor']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_setSponsor {$_[0]->{FIELD_VALUES}{'sponsor'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_updateSponsor {$_[0]->update({'sponsor' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_getStops {return $_[0]->{FIELD_VALUES}{'stops'};}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_checkStops {return ${($_[0]->check(['stops']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_setStops {$_[0]->{FIELD_VALUES}{'stops'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_updateStops {$_[0]->update({'stops' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_getWhy {return $_[0]->{FIELD_VALUES}{'why'};}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_checkWhy {return ${($_[0]->check(['why']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_setWhy {$_[0]->{FIELD_VALUES}{'why'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_updateWhy {$_[0]->update({'why' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_getNewType {return $_[0]->{FIELD_VALUES}{'newType'};}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_checkNewType {return ${($_[0]->check(['newType']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_setNewType {$_[0]->{FIELD_VALUES}{'newType'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_updateNewType {$_[0]->update({'newType' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_getLast {return $_[0]->{FIELD_VALUES}{'last'};}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_checkLast {return ${($_[0]->check(['last']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_setLast {$_[0]->{FIELD_VALUES}{'last'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::hierarchy::_updateLast {$_[0]->update({'last' => $_[1]});}

@W3C::Rnodes::AclSqlObjects::idInclusions::ISA = ( 'W3C::Database::ObjectBase' );
%W3C::Rnodes::AclSqlObjects::idInclusions::_TableDesc = ( '-table' => 'idInclusions',
                                                          '-index' => { 'PRIMARY' => { '-unique' => '1',
                                                                                       '-sequence' => [ 'id',
                                                                                                        'groupId' ],
                                                                                       '-fields' => { 'groupId' => '1',
                                                                                                      'id' => '0' } } },
                                                          '-class' => 'W3C::Rnodes::AclSqlObjects::idInclusions',
                                                          '-fieldOrder' => [ 'id',
                                                                             'groupId',
                                                                             'type',
                                                                             'g' ],
                                                          '-fields' => { 'groupId' => { '-size' => '10',
                                                                                        '-type' => 0,
                                                                                        '-default' => '0' },
                                                                         'g' => { '-size' => '11',
                                                                                  '-type' => 0,
                                                                                  '-null' => 1 },
                                                                         'id' => { '-target' => [ 'ids',
                                                                                                  'id' ],
                                                                                   '-size' => '10',
                                                                                   '-type' => 0,
                                                                                   '-default' => '0' },
                                                                         'type' => { '-size' => '1',
                                                                                     '-type' => 3,
                                                                                     '-default' => '' } },
                                                          '-primaryKey' => [ 'id',
                                                                             'groupId' ] );
$W3C::Rnodes::AclSqlObjects::_AllTables{'idInclusions'} = \%W3C::Rnodes::AclSqlObjects::idInclusions::_TableDesc;
sub W3C::Rnodes::AclSqlObjects::idInclusions::getTableDesc {return \%W3C::Rnodes::AclSqlObjects::idInclusions::_TableDesc;}
sub W3C::Rnodes::AclSqlObjects::idInclusions::getPrimaryKey {return $_[0]->{DB_ID};}
sub W3C::Rnodes::AclSqlObjects::idInclusions::_getId {return $_[0]->{FIELD_VALUES}{'id'};}
sub W3C::Rnodes::AclSqlObjects::idInclusions::_checkId {return ${($_[0]->check(['id']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::idInclusions::_setId {$_[0]->{FIELD_VALUES}{'id'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::idInclusions::_updateId {$_[0]->update({'id' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::idInclusions::_getType {return $_[0]->{FIELD_VALUES}{'type'};}
sub W3C::Rnodes::AclSqlObjects::idInclusions::_checkType {return ${($_[0]->check(['type']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::idInclusions::_setType {$_[0]->{FIELD_VALUES}{'type'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::idInclusions::_updateType {$_[0]->update({'type' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::idInclusions::getPrimaryKey {return $_[0]->{DB_ID};}
sub W3C::Rnodes::AclSqlObjects::idInclusions::_getGroupId {return $_[0]->{FIELD_VALUES}{'groupId'};}
sub W3C::Rnodes::AclSqlObjects::idInclusions::_checkGroupId {return ${($_[0]->check(['groupId']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::idInclusions::_setGroupId {$_[0]->{FIELD_VALUES}{'groupId'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::idInclusions::_updateGroupId {$_[0]->update({'groupId' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::idInclusions::_getG {return $_[0]->{FIELD_VALUES}{'g'};}
sub W3C::Rnodes::AclSqlObjects::idInclusions::_checkG {return ${($_[0]->check(['g']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::idInclusions::_setG {$_[0]->{FIELD_VALUES}{'g'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::idInclusions::_updateG {$_[0]->update({'g' => $_[1]});}

@W3C::Rnodes::AclSqlObjects::acls::ISA = ( 'W3C::Database::ObjectBase' );
%W3C::Rnodes::AclSqlObjects::acls::_TableDesc = ( '-table' => 'acls',
                                                  '-index' => { 'PRIMARY' => { '-unique' => '1',
                                                                               '-sequence' => [ 'acl',
                                                                                                'id',
                                                                                                'access' ],
                                                                               '-fields' => { 'access' => '2',
                                                                                              'id' => '1',
                                                                                              'acl' => '0' } } },
                                                  '-class' => 'W3C::Rnodes::AclSqlObjects::acls',
                                                  '-fieldOrder' => [ 'acl',
                                                                     'id',
                                                                     'access',
                                                                     'type',
                                                                     'last' ],
                                                  '-fields' => { 'last' => { '-type' => 10,
                                                                             '-null' => 1 },
                                                                 'access' => { '-size' => '10',
                                                                               '-type' => 0,
                                                                               '-default' => '0' },
                                                                 'id' => { '-size' => '10',
                                                                           '-type' => 0,
                                                                           '-default' => '0' },
                                                                 'type' => { '-size' => '1',
                                                                             '-type' => 3,
                                                                             '-default' => '' },
                                                                 'acl' => { '-size' => '10',
                                                                            '-type' => 0 } },
                                                  '-primaryKey' => [ 'acl',
                                                                     'id',
                                                                     'access' ] );
$W3C::Rnodes::AclSqlObjects::_AllTables{'acls'} = \%W3C::Rnodes::AclSqlObjects::acls::_TableDesc;
sub W3C::Rnodes::AclSqlObjects::acls::getTableDesc {return \%W3C::Rnodes::AclSqlObjects::acls::_TableDesc;}
sub W3C::Rnodes::AclSqlObjects::acls::getPrimaryKey {return $_[0]->{DB_ID};}
sub W3C::Rnodes::AclSqlObjects::acls::_getAcl {return $_[0]->{FIELD_VALUES}{'acl'};}
sub W3C::Rnodes::AclSqlObjects::acls::_checkAcl {return ${($_[0]->check(['acl']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::acls::_setAcl {$_[0]->{FIELD_VALUES}{'acl'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::acls::_updateAcl {$_[0]->update({'acl' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::acls::_getType {return $_[0]->{FIELD_VALUES}{'type'};}
sub W3C::Rnodes::AclSqlObjects::acls::_checkType {return ${($_[0]->check(['type']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::acls::_setType {$_[0]->{FIELD_VALUES}{'type'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::acls::_updateType {$_[0]->update({'type' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::acls::getPrimaryKey {return $_[0]->{DB_ID};}
sub W3C::Rnodes::AclSqlObjects::acls::_getId {return $_[0]->{FIELD_VALUES}{'id'};}
sub W3C::Rnodes::AclSqlObjects::acls::_checkId {return ${($_[0]->check(['id']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::acls::_setId {$_[0]->{FIELD_VALUES}{'id'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::acls::_updateId {$_[0]->update({'id' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::acls::getPrimaryKey {return $_[0]->{DB_ID};}
sub W3C::Rnodes::AclSqlObjects::acls::_getAccess {return $_[0]->{FIELD_VALUES}{'access'};}
sub W3C::Rnodes::AclSqlObjects::acls::_checkAccess {return ${($_[0]->check(['access']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::acls::_setAccess {$_[0]->{FIELD_VALUES}{'access'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::acls::_updateAccess {$_[0]->update({'access' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::acls::_getLast {return $_[0]->{FIELD_VALUES}{'last'};}
sub W3C::Rnodes::AclSqlObjects::acls::_checkLast {return ${($_[0]->check(['last']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::acls::_setLast {$_[0]->{FIELD_VALUES}{'last'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::acls::_updateLast {$_[0]->update({'last' => $_[1]});}

@W3C::Rnodes::AclSqlObjects::ids::ISA = ( 'W3C::Database::ObjectBase' );
%W3C::Rnodes::AclSqlObjects::ids::_TableDesc = ( '-table' => 'ids',
                                                 '-index' => { 'u_value' => { '-unique' => '1',
                                                                              '-sequence' => [ 'value' ],
                                                                              '-fields' => { 'value' => '0' } },
                                                               'value' => { '-unique' => '1',
                                                                            '-sequence' => [ 'type',
                                                                                             'value' ],
                                                                            '-fields' => { 'value' => '1',
                                                                                           'type' => '0' } },
                                                               'value_idx' => { '-unique' => '',
                                                                                '-sequence' => [ 'type',
                                                                                                 'value' ],
                                                                                '-fields' => { 'value' => '1',
                                                                                               'type' => '0' } } },
                                                 '-class' => 'W3C::Rnodes::AclSqlObjects::ids',
                                                 '-fieldOrder' => [ 'id',
                                                                    'stops',
                                                                    'type',
                                                                    'value',
                                                                    'pubKey',
                                                                    'expire',
                                                                    'info',
                                                                    'last',
                                                                    'orgId',
                                                                    'sponsor',
                                                                    'fmp' ],
                                                 '-fields' => { 'stops' => { '-size' => '10',
                                                                             '-type' => 0,
                                                                             '-null' => 1,
                                                                             '-default' => '0' },
                                                                'value' => { '-size' => '40',
                                                                             '-type' => 4,
                                                                             '-default' => '' },
                                                                'fmp' => { '-size' => '1',
                                                                           '-type' => 0,
                                                                           '-null' => 1 },
                                                                'info' => { '-size' => '80',
                                                                            '-type' => 4,
                                                                            '-null' => 1 },
                                                                'pubKey' => { '-size' => undef,
                                                                              '-type' => 5,
                                                                              '-null' => 1 },
                                                                'sponsor' => { '-size' => '32',
                                                                               '-type' => 4,
                                                                               '-null' => 1 },
                                                                'last' => { '-type' => 10,
                                                                            '-null' => 1 },
                                                                'id' => { '-size' => '10',
                                                                          '-type' => 0 },
                                                                'orgId' => { '-size' => '10',
                                                                             '-type' => 0,
                                                                             '-default' => '0' },
                                                                'type' => { '-size' => '1',
                                                                            '-type' => 3,
                                                                            '-default' => '' },
                                                                'expire' => { '-type' => 7,
                                                                              '-null' => 1 } },
                                                 '-primaryKey' => 'id' );
$W3C::Rnodes::AclSqlObjects::_AllTables{'ids'} = \%W3C::Rnodes::AclSqlObjects::ids::_TableDesc;
sub W3C::Rnodes::AclSqlObjects::ids::getTableDesc {return \%W3C::Rnodes::AclSqlObjects::ids::_TableDesc;}
sub W3C::Rnodes::AclSqlObjects::ids::getPrimaryKey {return $_[0]->{DB_ID};}
sub W3C::Rnodes::AclSqlObjects::ids::_getId {return $_[0]->{FIELD_VALUES}{'id'};}
sub W3C::Rnodes::AclSqlObjects::ids::_checkId {return ${($_[0]->check(['id']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::ids::_setId {$_[0]->{FIELD_VALUES}{'id'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::ids::_updateId {$_[0]->update({'id' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::ids::_getStops {return $_[0]->{FIELD_VALUES}{'stops'};}
sub W3C::Rnodes::AclSqlObjects::ids::_checkStops {return ${($_[0]->check(['stops']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::ids::_setStops {$_[0]->{FIELD_VALUES}{'stops'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::ids::_updateStops {$_[0]->update({'stops' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::ids::_getType {return $_[0]->{FIELD_VALUES}{'type'};}
sub W3C::Rnodes::AclSqlObjects::ids::_checkType {return ${($_[0]->check(['type']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::ids::_setType {$_[0]->{FIELD_VALUES}{'type'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::ids::_updateType {$_[0]->update({'type' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::ids::_getValue {return $_[0]->{FIELD_VALUES}{'value'};}
sub W3C::Rnodes::AclSqlObjects::ids::_checkValue {return ${($_[0]->check(['value']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::ids::_setValue {$_[0]->{FIELD_VALUES}{'value'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::ids::_updateValue {$_[0]->update({'value' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::ids::_getPubKey {return $_[0]->{FIELD_VALUES}{'pubKey'};}
sub W3C::Rnodes::AclSqlObjects::ids::_checkPubKey {return ${($_[0]->check(['pubKey']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::ids::_setPubKey {$_[0]->{FIELD_VALUES}{'pubKey'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::ids::_updatePubKey {$_[0]->update({'pubKey' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::ids::_getExpire {return $_[0]->{FIELD_VALUES}{'expire'};}
sub W3C::Rnodes::AclSqlObjects::ids::_checkExpire {return ${($_[0]->check(['expire']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::ids::_setExpire {$_[0]->{FIELD_VALUES}{'expire'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::ids::_updateExpire {$_[0]->update({'expire' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::ids::_getInfo {return $_[0]->{FIELD_VALUES}{'info'};}
sub W3C::Rnodes::AclSqlObjects::ids::_checkInfo {return ${($_[0]->check(['info']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::ids::_setInfo {$_[0]->{FIELD_VALUES}{'info'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::ids::_updateInfo {$_[0]->update({'info' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::ids::_getLast {return $_[0]->{FIELD_VALUES}{'last'};}
sub W3C::Rnodes::AclSqlObjects::ids::_checkLast {return ${($_[0]->check(['last']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::ids::_setLast {$_[0]->{FIELD_VALUES}{'last'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::ids::_updateLast {$_[0]->update({'last' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::ids::_getOrgId {return $_[0]->{FIELD_VALUES}{'orgId'};}
sub W3C::Rnodes::AclSqlObjects::ids::_checkOrgId {return ${($_[0]->check(['orgId']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::ids::_setOrgId {$_[0]->{FIELD_VALUES}{'orgId'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::ids::_updateOrgId {$_[0]->update({'orgId' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::ids::_getSponsor {return $_[0]->{FIELD_VALUES}{'sponsor'};}
sub W3C::Rnodes::AclSqlObjects::ids::_checkSponsor {return ${($_[0]->check(['sponsor']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::ids::_setSponsor {$_[0]->{FIELD_VALUES}{'sponsor'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::ids::_updateSponsor {$_[0]->update({'sponsor' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::ids::_getFmp {return $_[0]->{FIELD_VALUES}{'fmp'};}
sub W3C::Rnodes::AclSqlObjects::ids::_checkFmp {return ${($_[0]->check(['fmp']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::ids::_setFmp {$_[0]->{FIELD_VALUES}{'fmp'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::ids::_updateFmp {$_[0]->update({'fmp' => $_[1]});}

@W3C::Rnodes::AclSqlObjects::uris::ISA = ( 'W3C::Database::ObjectBase' );
%W3C::Rnodes::AclSqlObjects::uris::_TableDesc = ( '-table' => 'uris',
                                                  '-index' => { 'uris_valid' => { '-unique' => '',
                                                                                  '-sequence' => [ 'valid' ],
                                                                                  '-fields' => { 'valid' => '0' } },
                                                                'i_last' => { '-unique' => '',
                                                                              '-sequence' => [ 'last' ],
                                                                              '-fields' => { 'last' => '0' } },
                                                                'uri_idx' => { '-unique' => '',
                                                                               '-sequence' => [ 'uri' ],
                                                                               '-fields' => { 'uri' => '0' } },
                                                                'uris_acl' => { '-unique' => '',
                                                                                '-sequence' => [ 'acl' ],
                                                                                '-fields' => { 'acl' => '0' } },
                                                                'uri' => { '-unique' => '1',
                                                                           '-sequence' => [ 'uri' ],
                                                                           '-fields' => { 'uri' => '0' } } },
                                                  '-class' => 'W3C::Rnodes::AclSqlObjects::uris',
                                                  '-fieldOrder' => [ 'id',
                                                                     'uri',
                                                                     'acl',
                                                                     'last',
                                                                     'idsId',
                                                                     'valid' ],
                                                  '-fields' => { 'last' => { '-type' => 10,
                                                                             '-null' => 1 },
                                                                 'idsId' => { '-size' => '10',
                                                                              '-type' => 0,
                                                                              '-null' => 1 },
                                                                 'valid' => { '-size' => '1',
                                                                              '-type' => 3,
                                                                              '-default' => 'n' },
                                                                 'id' => { '-size' => '10',
                                                                           '-type' => 0 },
                                                                 'acl' => { '-size' => '10',
                                                                            '-type' => 0,
                                                                            '-default' => '0' },
                                                                 'uri' => { '-size' => '255',
                                                                            '-type' => 4,
                                                                            '-default' => '' } },
                                                  '-primaryKey' => 'id' );
$W3C::Rnodes::AclSqlObjects::_AllTables{'uris'} = \%W3C::Rnodes::AclSqlObjects::uris::_TableDesc;
sub W3C::Rnodes::AclSqlObjects::uris::getTableDesc {return \%W3C::Rnodes::AclSqlObjects::uris::_TableDesc;}
sub W3C::Rnodes::AclSqlObjects::uris::getPrimaryKey {return $_[0]->{DB_ID};}
sub W3C::Rnodes::AclSqlObjects::uris::_getId {return $_[0]->{FIELD_VALUES}{'id'};}
sub W3C::Rnodes::AclSqlObjects::uris::_checkId {return ${($_[0]->check(['id']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::uris::_setId {$_[0]->{FIELD_VALUES}{'id'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::uris::_updateId {$_[0]->update({'id' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::uris::_getUri {return $_[0]->{FIELD_VALUES}{'uri'};}
sub W3C::Rnodes::AclSqlObjects::uris::_checkUri {return ${($_[0]->check(['uri']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::uris::_setUri {$_[0]->{FIELD_VALUES}{'uri'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::uris::_updateUri {$_[0]->update({'uri' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::uris::_getAcl {return $_[0]->{FIELD_VALUES}{'acl'};}
sub W3C::Rnodes::AclSqlObjects::uris::_checkAcl {return ${($_[0]->check(['acl']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::uris::_setAcl {$_[0]->{FIELD_VALUES}{'acl'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::uris::_updateAcl {$_[0]->update({'acl' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::uris::_getLast {return $_[0]->{FIELD_VALUES}{'last'};}
sub W3C::Rnodes::AclSqlObjects::uris::_checkLast {return ${($_[0]->check(['last']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::uris::_setLast {$_[0]->{FIELD_VALUES}{'last'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::uris::_updateLast {$_[0]->update({'last' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::uris::_getIdsId {return $_[0]->{FIELD_VALUES}{'idsId'};}
sub W3C::Rnodes::AclSqlObjects::uris::_checkIdsId {return ${($_[0]->check(['idsId']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::uris::_setIdsId {$_[0]->{FIELD_VALUES}{'idsId'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::uris::_updateIdsId {$_[0]->update({'idsId' => $_[1]});}
sub W3C::Rnodes::AclSqlObjects::uris::_getValid {return $_[0]->{FIELD_VALUES}{'valid'};}
sub W3C::Rnodes::AclSqlObjects::uris::_checkValid {return ${($_[0]->check(['valid']))[0]}[0];}
sub W3C::Rnodes::AclSqlObjects::uris::_setValid {$_[0]->{FIELD_VALUES}{'valid'} = $_[1];}
sub W3C::Rnodes::AclSqlObjects::uris::_updateValid {$_[0]->update({'valid' => $_[1]});}

@W3C::Rnodes::AclSqlObjects::_TableOrder = ( 'userDetails',
                                             'groupDetails',
                                             'hierarchy',
                                             'idInclusions',
                                             'acls',
                                             'ids',
                                             'uris' );
