#Copyright Massachusetts Institute of technology, 2000.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

# Constants use by ChACL applications

use strict;
require Exporter;
#require AutoLoader;

package W3C::Rnodes::ChaclConstants;

use vars qw($REVISION $VERSION $DSLI @ISA @EXPORT @EXPORT_OK);
$REVISION = '$Id: ChaclConstants.pm,v 1.3 2001/05/31 15:25:08 eric Exp $ ';
@ISA = qw(Exporter); # AutoLoader);
@EXPORT = qw();
@EXPORT_OK = qw($DISPLAY_DIFFS $DISPLAY_LIST $DISPLAY_TABLE $DISPLAY_EXPERT $DISPLAY_RESOURCE_FIRST
		%DISPLAY_STR_TO_CONST %DISPLAY_CONST_TO_STR @DISPLAY_TYPE_LIST);
$VERSION = 0.10;
$DSLI = 'adpO';

# Display constants
use vars qw($DISPLAY_DIFFS $DISPLAY_LIST $DISPLAY_TABLE $DISPLAY_EXPERT $DISPLAY_RESOURCE_FIRST);
$DISPLAY_DIFFS = 1;
$DISPLAY_LIST = 2;
$DISPLAY_TABLE = 4;
$DISPLAY_EXPERT = 8;
$DISPLAY_RESOURCE_FIRST = 0x10;

use vars qw(%DISPLAY_STR_TO_CONST %DISPLAY_CONST_TO_STR @DISPLAY_TYPE_LIST);
%DISPLAY_STR_TO_CONST = ('diffs' => $DISPLAY_DIFFS,
			 'list' => $DISPLAY_LIST,
			 'table' => $DISPLAY_TABLE,
			 'expert' => $DISPLAY_EXPERT,
			 'rsrc1st' => $DISPLAY_RESOURCE_FIRST);
%DISPLAY_CONST_TO_STR = ($DISPLAY_DIFFS => 'diffs',
			 $DISPLAY_LIST => 'list',
			 $DISPLAY_TABLE => 'table',
			 $DISPLAY_EXPERT => 'expert',
			 $DISPLAY_RESOURCE_FIRST => 'rsrc1st');
@DISPLAY_TYPE_LIST = ($DISPLAY_DIFFS, $DISPLAY_LIST);

__END__

=head1 NAME

W3C::Rnodes::ChaclConstants - 

=head1 SYNOPSIS

  use W3C::Rnodes::ChaclConstants;

=head1 DESCRIPTION

<description>

This module is part of the W3C::Rnodes CPAN module.

=head1 AUTHOR

Eric Prud\'hommeaux <eric@w3.org>

=head1 SEE ALSO

W3C::Rnodes::ACL(3) perl(1).

=cut
