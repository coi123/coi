# Written by Dominique Hazael-Massieux
# Copyright � 2002 W3C� (MIT, INRIA, Keio), All Rights Reserved. W3C liability, trademark, document use and software licensing rules apply.
# see http://www.w3.org/Consortium/Legal/ipr-notice-20000612#Copyright for more

use strict ;
require Exporter;
$W3C::cvs::notificationParser::REVISION = '$Id: notificationParser.pm,v 1.3 2004/06/08 06:51:01 eric Exp $ ';

#BEGIN {unshift@INC,('../../..');}

package W3C::cvs::notificationParser;

use W3C::Util::Object;
use W3C::Util::Exception;

use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);
#@ISA = qw(W3C::Util::NamedParmObject Exporter); 
#@EXPORT = qw();
#@EXPORT_OK = qw();
$VERSION = 0.01 ;

sub new {
    my ($proto, @parms) = @_;
    my $class = ref($proto) || $proto;
    my $self = {};
    bless ($self, $class);
    $self->{DIR_MODIFIED}=[];
    $self->{MODIFIED}=[];
    $self->{ADDED}=[];
    $self->{UPDATED}=[];
    $self->{REMOVED}=[];
    $self->{DIR_ADDED}=[];
    $self->{DIR_UPDATED}=[];
    return $self;
}

sub parse {
    my ($self,$filename) = @_; 
    open (NOTIF,$filename) or &throw(new W3C::Util::NoSuchFileException(-file => $filename));
    while(<NOTIF>) {
	#blank lines are useless
	next unless /\S/;
	# start of the list of files
	if (m/^START$/) {
	    !eof() or last ;
	    
	    #first, the name of the directory
	    $_ = <NOTIF> ;
	    #removing the traling spaces
	    s/\s*$//;
	    #escaping the "
	    s/"/\"/; #"
	    
	    my $directory ;
	    #is it a new directory?
	    if (s/ - New directory$//) {
		$directory = $_ ;
		push(@{$self->{DIR_ADDED}},$directory);
	    } else {
		$directory = $_ ;
	    }
	    push(@{$self->{DIR_MODIFIED}},$directory);
	    
	    !eof() or last ;

	    #then, collecting the filenames
	    while (<NOTIF>) {
		#blank line means end of list
		m/\S/ or last;
		#removing the trailing spaces
		s/\s*$// ;
		push(@{$self->{MODIFIED}},$_);
	    }
	}
	$self->_parseSection(\*NOTIF,'Added');
	$self->_parseSection(\*NOTIF,'Removed');
    }
    
}

sub _parseSection {
    my ($self,$filehandle,$section) = @_ ;
    my $property = uc($section) ;
    # Parsing the "$section Files:" section
    if (m/^$section Files:$/ && !eof()) {
	while (<$filehandle>) {
            #blank line means end of list
	    m/\S/ or last ;
	    
	    #removing spaces in front and at the end of the line
	    s/^\s// ;
	    s/\s*$// ;
	    
	    
	    my $found = 0 ;
	    #doubtful workaround of a bug in the cvs notification [add random spaces in some filenames?]
	    s/  / / ;
	    
	    
	    #let's compare the current line with the filenames collected above
	    foreach my $file (@{$self->{MODIFIED}}) {
		#if the filename matches the current line, we have found
		if (m/^$file$/) {
		    
		    # escaping the "
		    if (m/"/) { #" parsing bug in emacs
			s/"/\\"/ ; 
		    }
		    push(@{$self->{$property}},$_) ;
		    $found = 1 ;
		    last ;
		}
		
		#if  the filename matches a part of the current line, we have found [might be buggish, no big deal]
		if (m/$file/) {
		    # escaping the \"
		    if ($file =~ m/"/) { #" parsing bug in emacs
			$file = ($file =~ s/"/\\"/) ; 
		    }
		    
		    push(@{$self->{$property}},$file) ;
		    $found = 1 ;
		    
		    #if that's the last name in the line, we are done for this line
		    if (m/$file$/) {
			last ;
		    }
		}
            }
	    #if the filename has not been found in the list, we are done
	    $found or last ;
	    
	}
    }
}

use W3C::cvs::notificationParser;
my $parser = new W3C::cvs::notificationParser();
$parser->parse("-");
map {print $_." ";} (@{$parser->{REMOVED}});
print "\n" ;


1;

__END__

=head1 NAME

W3C::cvs::notificationParser - Parser of CVS Notifications

=head1 SYNOPSIS

    use W3C::cvs::notificationParser;
    my $parser = new W3C::cvs::notificationParser();
    $parser->parse("-");
    map {print $_;} (@{$parser->{MODIFIED}});

=head1 DESCRIPTION
W3C::cvs::notificationParser is a parser of CVS Notifications which isolates added, removed and updated files and directories in specific arrays.

=head1 AUTHOR

Dominique Hazael-Massieux <dom@w3.org>

=cut
    
