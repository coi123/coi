#Copyright Massachusetts Institute of technology, 2000.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

# $Id: SExpr.pm,v 1.15 2004/06/06 21:03:28 eric Exp $

use strict;
require Exporter;
#require AutoLoader;

$W3C::Util::SExpr::REVISION = '$Id: SExpr.pm,v 1.15 2004/06/06 21:03:28 eric Exp $ ';

package W3C::Util::SExpr;
use W3C::Util::Object;
use vars qw($VERSION $DSLI @ISA @EXPORT @EXPORT_OK @TODO);

@ISA = qw(W3C::Util::NamedParmObject Exporter); # AutoLoader);
@EXPORT = qw();
@EXPORT_OK = qw();
$VERSION = 0.1;
$DSLI = 'adpO';
@TODO = ('');

package W3C::Util::SExpr::Atom;

sub new (;\%) {
    my ($proto, $datum, $pos, $flags) = @_;
    my $class = ref($proto) || $proto;
    my $self = {$flags ? %$flags : ()}; # just copy them for now
    bless($self, $class);
    $self->{DATUM} = $datum;
    $self->{POS} = $pos;
    return $self;
}

sub toString (;\%) {
    my ($self, $flags) = @_;
    my $ret;
    $ret .= $self.' ' if ($flags->{-showRef});
    $ret .= 'quoted ' if ($self->{-quoted});
    $ret .= $self->{DATUM};
    return $ret;
}

sub content () {return shift->{DATUM};}
sub getPos () {return shift->{POS};}

@W3C::Util::SExpr::Atom::String::ISA = qw(W3C::Util::SExpr::Atom);

@W3C::Util::SExpr::Atom::Symbol::ISA = qw(W3C::Util::SExpr::Atom);

package W3C::Util::SExpr::Atom::SExpr;
@W3C::Util::SExpr::Atom::SExpr::ISA = qw(W3C::Util::SExpr::Atom);
sub toString (;\%) {
    my ($self, $flags) = @_;
    my $ret;
    $ret .= $self.' ' if ($flags->{-showRef});
    $ret .= ' \'' if ($self->{-quoted});
    $ret .= ' ('.join (' ', map {$_->toString} @{$self->{DATUM}}).')';
    return $ret;
}

package W3C::Util::SExpr;
use W3C::Util::Exception;

sub parse ($) {
    my ($self, $str, $flagsNUKE, $flags, $depth) = @_;
    if (!defined $flags) {
	$flags = {};
    }

    # first call won't have a depth parameter
    if (!defined $depth) {
	$depth = 0;
    }

    # keep a list of parsed objects
    my (@ret, @newSymbols, @newExprs);

    # each segment starts with an optionally quoted delimiter
    while ($$str =~ m/ \G \s* (\')? (.) /gcsxi) {
	my ($quoted, $delim) = ($1, $2);

	# strings ending in whitespace will force delim to be that whitespace
	if ($delim =~ m/\s/) {
	    next;
	}

	# note where we are for error messages
	my $lastPos = pos $$str;

	my ($object, $content);

	# look for delim == '(', ')', '"' or some word char
	if ($delim eq '(') {
	    # recurse into nested s-expression
	    # print "(\n";
	    my ($recursedContents, $innerDelim, $innerSyms) = $self->parse($str, $flags, $flags, $depth+1);
	    push (@newSymbols, @$innerSyms);
	    if (!defined($innerDelim) && !$flags->{-noNonTermException}) {
		# end-of-string return doesn't return a delimiter
		# so we know we are unbalanced
		&throw(new W3C::Util::CachedContextException(-str => $$str, -pos => $lastPos, 
							     -errorMessage => 'unterminated s-expression'));
	    }
	    $object = new W3C::Util::SExpr::Atom::SExpr($recursedContents, $lastPos);
	    if (exists $flags->{-laterSymbols}) {
		foreach my $symbol (@$innerSyms) {
		    foreach my $expr (@newExprs) {
			if (!exists $flags->{-laterSymbols}{$expr}{$symbol}) {
			    $flags->{-laterSymbols}{$expr}{$symbol} = [$symbol, $object];
			}
		    }
		}
		$flags->{-laterSymbols}{$object} = {};
	    }
	    push (@newExprs, $object);
	} elsif ($delim eq ')') {
	    # close-of-s-expression returns nested data and a delimiter
	    if (!$depth) {
		&throw(new W3C::Util::CachedContextException(-str => $$str, -pos => $lastPos, 
							     -errorMessage => 'closing unopened s-expression'));
	    }
	    $self->depthError($$str, $lastPos) if ($flags->{-noTokensAtRoot} && !$depth);
	    # print ")\n";
	    return (\@ret, $delim, \@newSymbols);
	} elsif ($delim eq '"') {
	    # string started
	    $self->depthError($$str, $lastPos) if ($flags->{-noTokensAtRoot} && !$depth);
	    my $content = '';

	    # find the end of the string
	    for (my $done = 0; !$done;) {

		if ($$str =~ m/ \G (.*?) ([\\\"]) /gcsxi) {
		    # data with a following delimiter
		    my ($data, $delim2) = ($1, $2);
		    $content .= $data;

		    if ($delim2 eq '\\') {
			# delimiter demarks an escaped character
			if ($$str =~ m/ \G \\ (.) /gcsxi) {
			    $delim = $1;
			    $content .= $self->translateEscape($1, $str);
			} else {
			    &throw(new W3C::Util::CachedContextException(-str => $$str, -pos => pos $$str, 
									 -errorMessage => 'unaccompanied escape'));
			}
		    } else {
			# otherwise terminated on a non-literal close quote
			$done = 1;
		    }
		} else {
		    # data with no close quote
		    &throw(new W3C::Util::CachedContextException(-str => $$str, -pos => pos $$str, 
								 -errorMessage => 'no close quote found'));
		}
	    }
	    # print "\"$content\"\n";
	    $object = new W3C::Util::SExpr::Atom::String($content, $lastPos);
	} else {
	    # any other character (not (,),") is a word character
	    $self->depthError($$str, $lastPos) if ($flags->{-noTokensAtRoot} && !$depth);
	    my $content = '';
	    if ($delim eq '\\') {
		# token starts with an escped character
		if ($$str =~ m/ \G (.) /gcsxi) {
		    # token starts with the translated character
		    $content .= $self->translateEscape($1, $str);
		} else {
		    &throw(new W3C::Util::CachedContextException(-str => $$str, -pos => pos $$str, 
								 -errorMessage => 'unaccompanied escape'));
		}
	    } else {
		# token starts with a non-escaped character
		$content = $delim;
	    }

	    # find end of the token
	    for (my $done = 0; !$done;) {

		if ($$str =~ m/ \G (.*?) (?=([\\\s\(\)])) /gcsxi) {
		    # token terminated by delimiter
		    my ($data, $delim2) = ($1, $2);
		    $content .= $data;
		    if ($delim2 eq '\\') {
			# delimiter demarks an escaped character
			if ($$str =~ m/ \G \\ (.) /gcsxi) {
			    $content .= $self->translateEscape($1, $str);
			} else {
			    &throw(new W3C::Util::CachedContextException(-str => $$str, -pos => pos $$str, 
									 -errorMessage => 'unaccompanied escape'));
			}
		    } else {
			# otherwise a delimiter was encountered
			if ($delim2 =~ m/\s/) {
			    if ($$str !~ m/ \G \s+ /gcsxi) {
				&throw(new W3C::Util::ProgramFlowException());
			    }
			}
			$done = 1;
		    }
		} else {
		    # found no delimiter for the current string
		    if ($$str =~ m/ \G (.*?) \Z /gcsxi) {
			# grab (undelimited) remainder of token
			$content .= $1;
		    }
		    $done = 1;
		}
	    }
	    # create an Atom::Symbol to store the token
	    # print "<$content>\n";
	    $object = new W3C::Util::SExpr::Atom::Symbol($content, $lastPos) if ($content ne '');
	    push (@newSymbols, $content);
	}

	# set the quoted attribute of the created token
	$object->{-quoted} = 1 if ($quoted eq '\'');
	# store the token in the list of parsed objects
	push (@ret, $object) if ($object);
    }

    # end-of-string returns encountered contents
    return (\@ret, undef, \@newSymbols);
}

sub depthError {
    my ($self, $str, $pos) = @_;
    &throw(new W3C::Util::CachedContextException(-str => $str, -pos => $pos, 
						 -errorMessage => 'unexpected token outside of s-expression'));
}

use vars qw(%EscapeChars);
%EscapeChars = ('"' => '"', 
		"'" => '"', 
		' ' => ' ', 
		'n' => "\n", 
		'r' => "\r", 
		"\\" => '\\');

sub translateEscape {
    my ($self, $escapedChar, $str) = @_;
    my $ret = $EscapeChars{$escapedChar};
    if (defined $ret) {
	return $ret;
    }
    &throw(new W3C::Util::CachedContextException(-str => $$str, -pos => pos $$str, 
						 -errorMessage => 'unknown escape sequence'));
}

1;

__END__

=head1 NAME

W3C::Util::ScriptOpt - Extension of Getopt::Long to read script commands.

=head1 SYNOPSIS

  use W3C::Util::SExpr;
  my $p = new W3C::Util::SExpr;
  my $sexpr = "(a b '(c (d) e f) g (h) i)";
  my $t = $p->parse(\ $sexpr);

=head1 DESCRIPTION

not documented -- use the source.
need to poke around to figure it out, but the code looks reasonable.

This module is currently part of the W3C::Util CPAN module.

=head1 AUTHOR

Eric Prud'hommeaux <eric@w3.org>

=head1 SEE ALSO

Parse::Yapp(3) Term::ReadLine(3) perl(1).

=cut
