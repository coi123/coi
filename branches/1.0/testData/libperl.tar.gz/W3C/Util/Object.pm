#Copyright Massachusetts Institute of technology, 1998.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

use strict;

require Exporter;
require AutoLoader;

package W3C::Util::Object;

use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);
@ISA = qw(Exporter AutoLoader);
@EXPORT = qw();
@EXPORT_OK = qw();
$VERSION = 0.92;

$W3C::Util::Object::revision = '$Id: Object.pm,v 1.8 2005/04/30 08:39:08 eric Exp $ ';

@W3C::Util::NamedParmObject::ISA = qw(W3C::Util::Object);

#####
# per-class data
# hash table of current Objects - needed in multi-threaded environment.
%W3C::Util::Object::currentObjects = ();

#####
# constants

sub registerObject {
    my ($self) = @_;
    $W3C::Util::Object::currentObjects{$self} = $self;
}

sub DESTROY {
    my ($self) = @_;
    delete $W3C::Util::Object::currentObjects{$self};
}

package W3C::Util::NamedParmObject;
use W3C::Util::Exception;

sub new {
    my ($proto, @parms) = @_;
    my $class = ref($proto) || $proto;
    my $self;
    if (ref $parms[0] eq 'HASH') {
	$self = $parms[0];
    } elsif (!ref $parms[0] && !(@parms % 2)) {
	$self = {@parms};
    } else {
	&throw(new W3C::Util::Exception(-parameter => $parms[0], 
					-message => "$class must be constructed with a HASH or ARRAY, not \"$parms[0]\""));
    }
    eval {
	bless ($self, $class);
    }; if ($@) {
	&throw(new W3C::Util::Exception($@));
    }
    $self->registerObject;
    return $self;
}

sub missingParm {
    my ($self, $parameter) = @_;
    &throw(new W3C::Util::MissingParameterException(-parameter => $parameter));
}

package W3C::Util::Object;

1;

__END__

=head1 NAME

W3C::Util::Object - handy base object for classes

=head1 SYNOPSIS

    use W3C::Util::Object;
    @NegotiationObject::ISA = qw(W3C::Util::Object);
    eval {
	&iNeed('it yesterday');
    }; if ($@) {if (my $ex = &catch('NegotiationObject')) {
	print "Try again with larger stick or carrot.\n";
    } elsif (my $ex = &catch('W3C::Util::Object')) {
	warn 'got some random Object: '.$ex->getMessage."\n";
	$ex->toString;
	die "\n";
    } else {die $@;}}

    sub iNeed {
	throw(new NegotiationObject(-message => 'What about my needs?'));
    }

=head1 DESCRIPTION

Create an Object class and derive it from W3C::Util::Object.
Write a function that throws it.
Call the function from inside an eval.
At the end of the eval, add
    "if ($@) {"
Try each Object that could be thrown with
    "if (my $ex = &catch('NegotiationObject')) {"
At the end, have an "
    "} elsif (my $ex = &catch('W3C::Util::Object')) {"
to make sure you get all possible Objects. (Note - this is one area
where language support could make sure you've covered all the bases.)
At the end, you may want to add
    "} else {die $@;}}"
to make sure that you catch any non-Object calls to die.

Uncaught Objects may be found by putting an eval around your
program's main. Objects that are thrown and are caught by a an eval
will display with a leading block containing the Object's address
and toString value. For instance:
    "<W3C::Util::FileNotFoundObject=HASH(0x8313e1c)> Can't
     open file "asdf": No such file or directory at 
     ../../../W3C/Util/Object.pm line 34."
This should be save as long there are no '>'s allowed in object::print.

=head1 NOTES

This class can be used like like java.lang.object .

I considered using a syntax like
    try (sub {
	&iNeed('it yesterday');
    }, 'NegotiationObject', sub {
	print "Try again with larger stick or carrot.\n";
    }, 'W3C::Util::Object', sub {
	warn 'got some random Object: '.$ex->getMessage."\n";
	$ex->toString;
	die "\n";
    });
but figured it would just complicate the control without improving the
interface significantly. Anyone have any good ideas here?

This module is part of the W3C::Utils CPAN module.

=head1 AUTHOR

Eric Prud'hommeaux <eric@w3.org>

=head1 SEE ALSO

perl(1).

=cut
