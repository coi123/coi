#Copyright Massachusetts Institute of technology, 2003.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

# $Id: Scriptopt.pm,v 1.10 2004/09/23 20:39:41 eric Exp $

use strict;

package W3C::Util::Scriptopt::Exception;
use W3C::Util::Exception;
@W3C::Util::Scriptopt::Exception::ISA = qw(W3C::Util::Exception);

package W3C::Util::Scriptopt; # 2.32
use Exporter;
use Getopt::Long;
use W3C::Util::Exception;

use vars qw(@ISA @EXPORT);
@ISA = qw(Exporter Getopt::Long);

use vars qw($guess_shell);
$guess_shell = 0;		# guess if the first arg in an @script is
				# is a call to the script.

# Exported subroutines.
sub GetOptionsScript(%);		# always

BEGIN {
    @EXPORT    = qw(&GetOptionsScript @Getopt::Long::EXPORT);
}

sub import {
    my $pkg = shift;		# package
    my @syms = ();		# symbols to import
    my @config = ();		# configuration
    my $dest = \@syms;		# symbols first
    for ( @_ ) {
	if ( $_ eq ':config' ) {
	    $dest = \@config;	# config next
	    next;
	}
	if ($dest == \@config && $_ eq 'guess_shell') {
	    $guess_shell ^= 1;
	} else {
	    push(@$dest, $_);	# push
	}
    }
    # Hide one level and call super.
    local $Exporter::ExportLevel = 1;
    push(@syms, qw(&GetOptionsScript &GetOptions)) if @syms; # always export GetOptionsScript
    $pkg->SUPER::import(@syms);
    # And configure.
    &Getopt::Long::Configure(@config) if @config;
}

my $ChainedNonOpt = undef;
my @Errors;
my $LocationHandler = undef;
my $TheException = undef;
my @Locations = ();

sub setLocationHandler {
    my ($lh) = @_;
    $LocationHandler = $lh;
}

use vars qw(%copy);

# User visible variables.
sub GetOptionsScript (%) {
    my (%parms) = @_;

    # Our copy of the getopts args has out own exception-handling code.
    %copy = %parms;
    delete $copy{'<>'};
    foreach my $parm (keys %parms) {
	if (ref $parms{$parm} eq 'CODE') {
	    $copy{$parm} = sub {&GetOptionsProtect($parms{$parm}, @_);}
	}
    }

    # Install our <> handler which will called the original.
    $ChainedNonOpt = $parms{'<>'};
    $copy{'<>'} = sub {&GetOptionsProtect(\&lookForAtScript, @_);};

    # Call GetOpt
    my $ret = &GetOptions(%copy);

    # See if an exception was raised.
    if ($TheException) {
	my $ex = $TheException;
	$TheException = undef;
	local($SIG{"__DIE__"}) = '__DEFAULT__';
	die $ex;
    }

    return $ret;
}

sub GetOptionsProtect {
    my ($code, @args) = @_;
    my $origHandler = $SIG{"__DIE__"};
    eval {
	local($SIG{"__DIE__"}) = \&DieHandler;
	&$code(@args);
    };
    $SIG{"__DIE__"} = $origHandler;
    if ($@) {
	$TheException = $@;
	die "!FINISH $@";
    }
}

sub lookForAtScript {
    my ($arg) = @_;
    if ($arg =~ m/\A @(.*) \Z/x) {
	my $scriptFile;
	if ($arg =~ m/\A @(.+) \Z/x) {
	    $scriptFile = $1;
	} elsif (@ARGV) {
	    $scriptFile = shift @ARGV;
	} else {
	    push (@Errors, 'missing parm for \@ directive');
	}
	if (!open (SCRIPT_FILE, '<'.$scriptFile)) {
	    &throw(new W3C::Util::FileNotFoundException(-filename => $scriptFile));
	}
	my $script;
	{
	    local $/ = undef;
	    $script = <SCRIPT_FILE>;
	    close(SCRIPT_FILE);
	}

	my $lastLocation = @Locations ? $Locations[-1] : '-- command line --';
	push (@Locations, $scriptFile);
	if ($LocationHandler) {
	    $LocationHandler->pushLocation($scriptFile);
	}

	# Call GetOptions with ARGV pointing to the referenced args.
	my @saveArgv = @ARGV;
	@ARGV = &parseAsShellScript($script);
	eval {
	    my $ret = &GetOptions(%copy);
	}; if ($TheException) {
	    $@ = $TheException;
	} if ($@) {
	    if (my $ex = &catch('W3C::Util::CachedContextException')) {
		my $newEx = new W3C::Util::CachedContextException(-str => "\@$scriptFile", 
							      -location => $lastLocation, 
							      -pos => 2, -contextID => undef, 
							      -chainedException => $ex);
	    $newEx->assumeStackTrace($ex);
	    &throw($newEx);
	} elsif ($ex = &catch('W3C::Util::Exception')) {
	    my $newEx = new W3C::Util::CachedContextException(-str => "\@$scriptFile", 
							      -pos => 1, -contextID => undef, 
							      -errorMessage => $ex->toString);
	    $newEx->assumeStackTrace($ex);
	    &throw($newEx);
	} else {
	    my $newEx = new W3C::Util::CachedContextException(-str => "\@$scriptFile", 
							      -pos => 1, -contextID => undef, 
							      -errorMessage => $@);
	    &throw($newEx);
	}}
	@ARGV = @saveArgv;

	if ($LocationHandler) {
	    $LocationHandler->popLocation($scriptFile);
	}
	pop (@Locations);
    } elsif ($ChainedNonOpt) {
	&$ChainedNonOpt($arg);
    }
}

sub parseAsShellScript {
    my ($script) = @_;

    # Parse as shell script.
    my $line = undef;
    my $parms = [];
    while (pos $script < length $script && $script =~ m/\G ([^\s\\\'\"\#]*) ([\s\\\'\"\#])? /gcxs) {
	my ($word, $delim) = ($1, $2);
	$line .= $word if ($word);
	if ($delim =~ m/\s/) {
	    &pushParm($parms, $line);
	    $line = undef;
	    if ($script =~ m/\G \s* /gcxs) {}
	} elsif ($delim eq '\\') {
	    if ($script =~ m/\G (.) /gcxs) {$line .= $1 if ($1 ne "\r" && $1 ne "\n");}
	} elsif ($delim eq '\'') {
	    while ($script =~ m/\G ([^\\\']*) ([\\\']) /gcxs) {
		$line .= $1;
		if ($2 eq '\\') {
		    if ($script =~ m/\G (.) /gcxs) {$line .= $1 if ($1 ne "\r" && $1 ne "\n");}
		} elsif ($2 eq '\'') {
		    last;
		}
	    }
	} elsif ($delim eq '"') {
	    while ($script =~ m/\G ([^\\\"]*) ([\\\"]) /gcxs) {
		$line .= $1;
		if ($2 eq '\\') {
		    if ($script =~ m/\G (.) /gcxs) {$line .= $1 if ($1 ne "\r" && $1 ne "\n");}
		} elsif ($2 eq '"') {
		    last;
		}
	    }
	} elsif ($delim eq '#') { # eat rest of line after comment
	    $script =~ m/\G ([^\r\n]*) $ /gcxm;
	} else {
	    &pushParm($parms, $line);
	    $line = undef;
	    # \z so at end of input - hmm - can't count on that. bummer
	}
    }
    &pushParm($parms, $line);
    if ($guess_shell && $0 =~ m/$parms->[0]/) {
	shift (@$parms);
    }
    return @$parms;
}

sub pushParm {
    my ($pParms, $line) = @_;
    if (defined $line && $line ne '$*') {
	push (@$pParms, $line);
    }
}

# ALTERNATIVE APPROACH
#   make @expansion not happen when quoted or \\'d
# cost: will take away ability for client scripts to manipulate ARGV in time
#       to disable the @parms when they have another interpretation for the
#       @parm (ie, follows a parm that expects an @parm to follow).
# 
# algae -abc a @run.sh c
#   @ARGV = expandAts(@ARGV)
#   getOpt
# 
# expandAt (i, @argv)
#   for i 0 - @argv
#     if @
#       scriptFile = $1 || shift @ARGV
#       script = <scriptFile>
#       push (@ret, &parseAsShellScript($script)
#     else
#       push (@ret, i)
#   return @ret  
# 
# parseAsShellScript($script)
#   $expandAts = 0;
#   expandAts of if wordstart @ was not in quotes or \\'d

1;

__END__

=head1 NAME

W3C::Util::ScriptOpt - Extension of Getopt::Long to read script commands.

=head1 SYNOPSIS

  use W3C::Util::Scriptopt;
  my ($help, $man);
  my $someSwitch = 'xsl';
  my $res = &GetOptionsScript('m=s' => \$someSwitch, 
			      'help|?' => \$help, 
			      'man' => \$man, 
			      '<>' => \&processFile);
  sub processFile () {print "processing $_[0]\n"}

=head1 DESCRIPTION

Use Scriptopt exactly as you would Getopt::Long where you want to be able to
specify command line arguments in a file. Instead of
  myScript -m 'some' -m 'arguments' -m 'here' 'and' 'other' 'stuff'
put the argumens into a file, eg:
myArgs:
  -m 'some' \
  -m 'arguments' \
  -m 'here' \
  'and' 'other' 'stuff'
and type:
  myScript @myArgs

This module is currently part of the W3C::Util CPAN module.

=head1 AUTHOR

Eric Prud'hommeaux <eric@w3.org>

=head1 SEE ALSO

Parse::Yapp(3) Term::ReadLine(3) perl(1).

=cut
