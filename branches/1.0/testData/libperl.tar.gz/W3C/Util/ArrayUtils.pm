#Copyright Massachusetts Institute of technology, 2004.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

# Somewhat handy array manipulation utilities (well, one, at present).

use strict;

require Exporter;
require AutoLoader;

package W3C::Util::ArrayUtils;

use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);
@ISA = qw(Exporter AutoLoader);
@EXPORT = qw();
@EXPORT_OK = qw(&DecorateArray);
$VERSION = 0.95;

$W3C::Util::ArrayUtils::revision = '$Id: ArrayUtils.pm,v 1.4 2004/06/06 10:11:19 eric Exp $ ';

sub DecorateArray { # static
    my ($firstLeader, $nthLeader, $nthTrailer, $lastTrailer, @array) = @_;
    for (my $row = 0; $row < @array; $row++) {
	if ($row == 0) {
	    $array[$row] = "$firstLeader$array[$row]";
	} else {
	    $array[$row] = "$nthLeader$array[$row]";
	}
	if ($row == @array - 1) {
	    $array[$row] = "$array[$row]$lastTrailer";
	} else {
	    $array[$row] = "$array[$row]$nthTrailer";
	}
    }
    return @array;
}

1;

__END__

=head1 NAME

W3C::Util::ArrayUtils.pm - collection of array manipulation functions.

=head1 SYNOPSIS

  use W3C::Util::ArrayUtils qw(&DecorateArray);
  my @start = ['line 1', 'line 2', 'line 3', 'line 4'];
  my @ret = &DecorateArray('        { ', '         ', '', ' }} ;', @start);

=head1 Functions

This module is just a collection of static methods. Each is indepent (and
independanty documented).

=head2 DecorateArray

  @ret = &DecorateArray($firstLeader, $nthLeader, 
			$nthTrailer, $lastTrailer, @rows);

Appends leaders and trailers to each row. Not exciting, but very handy for
toString methods that indent the output of nested toString calls.

  my @start = ('line 1', 'line 2', 'line 3', 'line 4');
  my @ret = &DecorateArray('["', ' "', '",', '"];', @start);

yields:
  ('["line 1"', '"line 2"', '"line 3"', '"line 4"];')


This module is part of the W3C::Util CPAN module.

=head1 AUTHOR

Eric Prud'hommeaux <eric@w3.org>

=head1 SEE ALSO

perl(1).

=cut
