#!/usr/bin/perl

# Copyright Massachusetts Institute of technology, 2000.
# Written by Eric Prud'hommeaux

# $Id: AuthDBMUtils.pm,v 1.7 2005/02/07 17:10:39 eric Exp $

# Things that need to be done:
# 1: more docs

#####
# What It Does:

use strict;

package W3C::Util::AuthDBMUtils;
use File::Spec;
use ExtUtils::MakeMaker;
use W3C::Database::DbInterface;

use vars qw($FORMAT_ERROR);
$FORMAT_ERROR = -1;
use vars qw(@ApacheConfFileLocations);
@ApacheConfFileLocations = ('/etc/apache2/apache2.conf', 
			    '/etc/apache2/httpd.conf', 
			    '/etc/apache/httpd.conf');
use vars qw(@ApacheAuthFileLocations);
@ApacheAuthFileLocations = ('/etc/apache2/users', 
			    '/etc/apache/users');
use vars qw($AuthBlurb);
$AuthBlurb = "no AuthDBMUserFile directives found, select a specific auth file?
(type 'y' after adding one and trying it or 'n' to give up.)
(You can add one with something like `htdbm -c users <name>`";

sub new {
    my ($proto) = @_;
    my $class = ref($proto) || $proto;
    my $self = {Found => 0, ConfFileName => undef, 
		Contents => undef, DbmType => undef, 
		AuthFileName => undef};
    bless ($self, $class);
    return $self;
}

sub getConfFileName {
    my ($self) = @_;
    return $self->{ConfFileName};
}

sub getAuthDir {
    my ($self) = @_;
    if ($self->{AuthFileName}) {
	my (undef, $confDir) = File::Spec->splitpath($self->{AuthFileName});
	return $confDir;
    } else {
	return undef;
    }
}

sub findBestAuthFormat {
    my ($self) = @_;

    if (&ExtUtils::MakeMaker::prompt(
"do you want to try to guess what type of Berkely DBM file mod_auth_dbm is using?", 'y') =~ /^n/) {
	return;
    }
  readConf_read:
    if (!$self->{ConfFileName}) {
	$self->readConf();
    }
    my (undef, $confDir) = File::Spec->splitpath($self->{ConfFileName});
    my @auths = grep (/^\s*AuthDBMUserFile\s+\w+/i, @{$self->{Contents}});
    if (@auths) {
	print "trying first AuthDBMUserFile: $auths[0]";
    } else {
	if (&ExtUtils::MakeMaker::prompt($AuthBlurb, 'y') =~ /^n/) {
	    print "Giving up!\n";
	    return undef;
	} else {
	  select_passwd_file:
	    my $defaultAuthFile = $ApacheAuthFileLocations[-1];
	    foreach my $file (@ApacheAuthFileLocations) {
		if (-e $file || (-e "$file.pag" && -e "$file.dir")) {
		    $defaultAuthFile = $file;
		    last;
		}
	    }
	  readAuth_Top:
	    my $authFileName = &ExtUtils::MakeMaker::prompt("what password file would you like to use? (\"quit!\" to quit!)", $defaultAuthFile);
	    if ($authFileName =~ /quit\!/) {
		return;
	    } elsif ($authFileName =~ /^$/) {
		$authFileName = $defaultAuthFile;
	    } elsif (! (-e $authFileName || (-e "$authFileName.pag" && -e "$authFileName.dir"))) {
		print STDERR "\"$authFileName\" not found\n";
		goto readAuth_Top;
	    }
	    if ($authFileName =~ m/(.*?).(pag|dir)$/ && 
		! -e $1 && 
		-e "$1.pag" && -e "$1.dir") {
		$authFileName = $1;
		print "using NDBM base name \"$authFileName\"\n";
	    }
	    @auths = ("AuthDBMUserFile $authFileName\n");
	}
    }
    my $dbmFile;
    if ($auths[0] =~ m/^\s*AuthDBMUserFile\s+(.+)/) {
	$dbmFile = File::Spec->rel2abs($1, $confDir);
	if (! -e $dbmFile && ! -e "$dbmFile.dir" && ! -e "$dbmFile.pag") {
	    print STDERR "\"$dbmFile\" not found\n";
	    goto readConf_read;
	}
    } else {
	print STDERR "\"$auths[0]\" not found, giving up.\n";
	return undef;
    }
    foreach my $type qw(NDBM_File GDBM_File SDBM_File DB_File asdf) {
	eval {
	    eval "use $type";
	    if ($@) {
		print "Berkely DB format \"$type\" not supported\n";
		next;
	    }
	    my %dbm;
	    if (defined tie (%dbm, $type, $dbmFile, 'O_RDONLY', 0666)) {
		my $count = keys %dbm;
		untie (%dbm);
		print "$dbmFile is a $type file with $count users\n";
	    } else {
		next;
	    }
	}; if ($@) {
	    print "failed to open $dbmFile as a $type ($@)\n";
	    next;
	}
	$self->{DbmType} = $type;
	$self->{AuthFileName} = $dbmFile;
	return $type;
    }
    return undef;
}

sub readConf {
    my ($self) = @_;

    my $defaultConfFile = $ApacheConfFileLocations[-1];
    foreach my $file (@ApacheConfFileLocations) {
	if (-e $file) {
	    $defaultConfFile = $file;
	    last;
	}
    }
  readConf_Top:
    $self->{ConfFileName} = &ExtUtils::MakeMaker::prompt(
"where is apache's httpd.conf (or apache2.conf)? (\"quit!\" to quit!)", $defaultConfFile);
    if ($self->{ConfFileName} =~ /quit\!/) {
	return;
    } elsif ($self->{ConfFileName} =~ /^$/) {
	$self->{ConfFileName} = $defaultConfFile;
    } elsif (! -e $self->{ConfFileName}) {
	print STDERR "\"$self->{ConfFileName}\" not found\n";
	goto readConf_Top;
    }
    local $/ = "\n";
    if (!open (CONF, $self->{ConfFileName})) {
	print STDERR "error opening \"$self->{ConfFileName}\": $!\n";
	goto readConf_Top;
    }
    $self->_read(\*CONF, $self->{ConfFileName});
    close (CONF);
}

sub _read {
    my ($self, $handle, $src) = @_;
    for (my $lineNo = 1; my $line = <$handle>; $lineNo++) {
	push (@{$self->{Contents}}, $line);
	if ($line =~ m/^\s*Include\s+([^\s]+)/) {
	    my $fn = $self->_maybeRelativePath($1, $src);
	    # apache first interprets this as a glob so we try too.
	    my @list = glob($fn);
	    # cheesy hack to emulate apache's common use of globbing.
	    if (!@list && $fn =~ m/([^\[]+) \[ ([^\]]+) \] ([^\s]+)/x) {
		my ($l, $filter, $r) = ($1, $2, $3);
		my $glob = "$l$r";
		sub _glob2RegexpSegment { # local function for adapting to regexp.
		    my ($s) = @_;
		    $s =~ s/([\.\!\"\#\$\%\&\'\(\)\=\:\;\+\[\]])/\\$1/g;
		    $s =~ s/\?/./g;
		    $s =~ s/\*/.+/g;
		    return $s;
		}
		$l = &_glob2RegexpSegment($l);
		$filter = &_glob2RegexpSegment($filter);
		$r = &_glob2RegexpSegment($r);
		my $regexp = $l."[$filter]$r";
		@list = grep {m/$regexp/} glob($glob);
	    }
	    if (!@list) {
		push (@list, $fn); # try it as a single file reference.
	    }
	    foreach my $file (@list) {
		local *SUB;
		if (open(*SUB, $file)) {
		    $self->_read(\*SUB, $file);
		    close (*SUB);
		} else {
		    chomp $line;
		    warn "couldn't include $file at $src:$lineNo -- \"$line\"\n";
		}
	    }
	}
    }
}

sub _maybeRelativePath {
    my ($self, $maybeRel, $base) = @_;
    if ($maybeRel =~ m/~\//) {
	my (undef, $confDir) = File::Spec->splitpath($base);
	return "$confDir/$maybeRel";
    } else {
	return $maybeRel;
    }
}

1;

__END__

=head1 NAME

W3C::Util::AuthDBMUtils - tools for managing mod_auth_dbm Berkely DBs.

=head1 SYNOPSIS

  use W3C::Util::AuthDBMUtils;
  print &W3C::Util::AuthDBMUtils::findBestAuthFormat();

=head1 DESCRIPTION

This module provides utilities for working with the Berkeley DB files used by Apache's mod_auth_dbm.

This module is used with the W3C::Util CPAN module.

=head1 AUTHOR

Eric Prud'hommeaux <eric@w3.org>

=head1 SEE ALSO

L<W3C::Annotations::DBMUserRecords>

=cut

