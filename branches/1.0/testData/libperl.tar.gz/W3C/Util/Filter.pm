# Copyright Massachusetts Institute of technology, 2004.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium

# $Id: Filter.pm,v 1.10 2007/01/10 03:53:30 eric Exp $
use strict;

require Exporter;
require AutoLoader;

########################################################################
# Handle: base class for Reader and Writer
package W3C::Util::Handle;

sub new {
    my ($proto, $handle, $handler, $selector) = @_;
    my $class = ref($proto) || $proto;
    my $self = {Handle => $handle, 
		FileNo => fileno($handle), 
		PBuffer => $handler, 
		Offset => 0, 
		Selector => $selector};
    bless ($self, $class);
    return $self;
}

sub getFileNo {
    my ($self) = @_;
    return $self->{FileNo};
}

sub getHandle {
    my ($self) = @_;
    return $self->{Handle};
}

sub getLength {
    my ($self) = @_;
    return $self->{Offset};
}

########################################################################
# Reader for the Select class below
package W3C::Util::Reader;
@W3C::Util::Reader::ISA = qw(W3C::Util::Handle);

sub read {
    my ($self) = @_;
    my $buf = '';
    my $len = sysread($self->{Handle}, $buf, 2048, );
    &{$self->{PBuffer}}($buf, $self->{Offset});
    $self->{Offset} += $len;
    if ($len == 0) {
	$self->{Selector}->close($self);
    }
}

########################################################################
# Writer for the Select class below
package W3C::Util::Writer;
@W3C::Util::Writer::ISA = qw(W3C::Util::Handle);

sub new {
    my ($proto, $handle, $handler, $selector) = @_;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new($handle, $handler, $selector);
    $self->{Length} = length($$handler);
    bless ($self, $class);
    return $self;
}

sub write {
    my ($self) = @_;
    my $len = syswrite($self->{Handle}, ${$self->{PBuffer}}, 2048, $self->{Offset});
    $self->{Offset} += $len;
    if ($self->{Offset} == $self->{Length}) {
	$self->{Selector}->close($self);
    }
}

########################################################################
# SelectException: exceptions for the Select class
package W3C::Util::SelectException;
@W3C::Util::SelectException::ISA = qw(W3C::Util::Exception);
sub new {
    my ($proto, @parms) = @_;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new(@parms);
    $self->missingParm('-handle') if (!exists $self->{-handle});
    $self->fillInStackTrace;
    return $self;
}
sub getSpecificMessage {return 'I/O error on '.$_[0]->_getHandleDesc();}
sub _getHandleDesc {
    my ($self) = @_;
    my $handle = $self->getHandle();
    my $fd = $handle->getFileNo();
    my $name = $handle->getHandle();
    return "$fd ($name)";
}
sub getHandle {return $_[0]->{-handle};}

package W3C::Util::SelectReadLengthException;
@W3C::Util::SelectReadLengthException::ISA = qw(W3C::Util::SelectException);
sub new {
    my ($proto, @parms) = @_;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new(@parms);
    $self->missingParm('-limit') if (!exists $self->{-limit});
    $self->fillInStackTrace;
    return $self;
}
sub getSpecificMessage {
    my ($self) = @_;
    my $handle = $self->getHandle();
    my $red = $handle->getLength();
    my $limit = $self->getLimit();
    my $desc = $self->_getHandleDesc();
    return "read $red ($limit allowed) on $desc";
}
sub getLimit {return $_[0]->{-limit};}

########################################################################
# Select: Simple IO select handler for reading and writing
package Select;
use W3C::Util::Exception;

sub new {
    my ($proto, $pid, $maxRead) = @_;
    my $class = ref($proto) || $proto;
    my $self = {MaxRead => $maxRead, 
		Readers => {}, 
		Writers => {}, 
		RIn => '', WIn => '', EIn => ''};
    bless ($self, $class);

    $SIG{CHLD} = sub {$self->abort($pid);};
    $SIG{PIPE} = sub {$self->abort($pid);};
    return $self;
}

sub registerReader {
    my ($self, $handle, $handler) = @_;
    my $reader = new W3C::Util::Reader($handle, $handler, $self);
    my $fileNo = $reader->getFileNo();
    vec($self->{RIn}, $fileNo, 1) = 1;
    vec($self->{EIn}, $fileNo, 1) = 1;
    $self->{Readers}{$fileNo} = $reader;
}

sub registerWriter {
    my ($self, $handle, $handler) = @_;
    my $writer = new W3C::Util::Writer($handle, $handler, $self);
    my $fileNo = $writer->getFileNo();
    vec($self->{WIn}, $fileNo, 1) = 1;
    vec($self->{EIn}, $fileNo, 1) = 1;
    $self->{Writers}{$fileNo} = $writer;
}

sub selectLoop {
    my ($self) = @_;
    my ($rOut, $wOut, $eOut);
    while (keys %{$self->{Readers}} || keys %{$self->{Writers}}) {
	my $nfound = select($rOut=$self->{RIn}, $wOut=$self->{WIn}, $eOut=$self->{EIn}, undef);
	foreach my $fn (keys %{$self->{Writers}}) {
	    if (vec($wOut, $fn, 1)) {
		$self->{Writers}{$fn}->write();
	    }
	}
	foreach my $fn (keys %{$self->{Readers}}) {
	    if (vec($rOut, $fn, 1)) {
		my $reader = $self->{Readers}{$fn};
		$reader->read();
		if (defined $self->{MaxRead} && $reader->getLength() > $self->{MaxRead}) {
		    &throw(new W3C::Util::SelectReadLengthException(-handle => $reader, -limit => $self->{MaxRead}));
		    # $self->close($reader);
		}
	    }
	}
    }
}

sub close {
    my ($self, $handle) = @_;
    my $fileNo = $handle->getFileNo();
    vec($self->{RIn}, $fileNo, 1) = 0;
    vec($self->{WIn}, $fileNo, 1) = 0;
    vec($self->{EIn}, $fileNo, 1) = 0;
    delete $self->{Readers}{$fileNo};
    delete $self->{Writers}{$fileNo};
    close $handle->getHandle();
}

sub abort {
    my ($self, $pid) = @_;
    waitpid($pid, 0);
    foreach my $fh (keys %{$self->{Writers}}) {
	$self->close($self->{Writers}{$fh});
    }
}

########################################################################
# FilterN: Handle an arbitrary number of input and output handles.
package W3C::Util::FilterN;
use POSIX;
use W3C::Util::Exception;
use Symbol qw(gensym qualify);

sub new {
    my ($proto, $ios, $handles, $safe) = @_;
    my $class = ref($proto) || $proto;
    if (defined $safe) {
	if (ref $safe eq 'CODE') {
	} elsif ($safe =~ m/^[0-9]+$/) {
	    my $idx = $safe;
	    $safe = sub {${$ios->[$idx]} .= "Error executing `$_[1]`: $_[0]\n"};
	} else {
	    die "W3C::Util::FilterN constructor parm 2 must be a number or sub(error, command)";
	}
    }
    my $self = {IOs => $ios, 
		Handles => $handles, 
		Safe => $safe};
    bless ($self, $class);
    return $self;
}

sub execute {
    my ($self, $cmd, $env, $maxRead) = @_;

    my ($ios, $handles) = ($self->{IOs}, $self->{Handles});
    my $dad = [];
    my $kid = [];
    for (my $fd = 0; $fd < @$ios; $fd++) {
	$dad->[$fd] = gensym;
	$kid->[$fd] = gensym;
	my $io = $ios->[$fd];
	if (ref $io) {
	    pipe $dad->[$fd], $kid->[$fd];
	} else {
	    pipe $kid->[$fd], $dad->[$fd];
	}
    }
    my $pid = fork;
    if ($pid == 0) {		# Kid
	for (my $fd = 0; $fd < @$dad; $fd++) {
	    close $dad->[$fd];
	    if ($fd < @$handles) {
		my $io = $ios->[$fd];
		open $handles->[$fd], (ref $io ? "<&=" : "<&=") , fileno $kid->[$fd];
	    } else {
		POSIX::dup2 fileno $kid->[$fd], $fd;
	    }
	}
	foreach my $key (keys %$env) {
	    $ENV{$key} = $env->{$key};
	}
	local($")=(" ");
	exec $cmd # XXX: wrong process to croak from
	    or die "exec of $cmd failed";
    }

    select((select($dad->[0]), $| = 1)[0]); # unbuffer pipe

    my $selector = Select->new($pid, $maxRead);
    for my $fd (0..(@$ios-1)) {
	close $kid->[$fd];
	my $io = $ios->[$fd];
	if (ref $io) {
	    $selector->registerReader($dad->[$fd], 
				      ref $io eq 'CODE' ? $io : 
				        sub {${$io} .= $_[0]});
	} else {
	    $selector->registerWriter($dad->[$fd], \ $io);
	}
    }

    if ($self->{Safe}) {
	eval {
	    $selector->selectLoop();
	}; if ($@) {
	    my $msg;
	    if (my $ex = &catch('W3C::Util::Exception')) {
		$msg = $ex->toString();
	    } else {
		$msg = $@;
	    }
	    &{$self->{Safe}}($msg, $cmd);
	}
    } else {
	$selector->selectLoop();
    }

}

########################################################################
# Filter: Write to and Read from simple unix filter.
# This class makes no assumptions about size or synchronization of the filter.
package W3C::Util::Filter;
@W3C::Util::Filter::ISA = qw(W3C::Util::FilterN);
use W3C::Util::Exception;

sub new {
    my ($proto, $cmd, $stdin) = @_;
    my $class = ref($proto) || $proto;
    my ($content, $error) = ('', '');
    my $self = $class->SUPER::new([$stdin, \$content, \$error], 
				  [\*STDIN, \*STDOUT, \*STDERR]);
    $self->{Content} = \$content;
    $self->{Error} = \$error;
    $self->{Cmd} = $cmd;
    return $self;
}

sub execute {
    my ($self, $maxRead, $safe) = @_;
    if ($safe) {
	$self->{Safe} = sub {${$self->{Error}} .= "Error executing `$_[1]`: $_[0]\n"}
    }
    $self->SUPER::execute($self->{Cmd}, {}, $maxRead);
    return (${$self->{Content}}, ${$self->{Error}});
}

########################################################################
# SyncFilter: A Filter that synchronizes (as much as select will allow) stderr
#             and stdout into a single FlavorBuffer.
package W3C::Util::SyncFilter;
@W3C::Util::SyncFilter::ISA = qw(W3C::Util::FilterN);
use W3C::Util::Exception;

sub new {
    my ($proto, $cmd, $stdin) = @_;
    my $class = ref($proto) || $proto;
    require W3C::Util::FlavorBuffer;
    my $buffer = new W3C::Util::FlavorBuffer();
    my $self = $class->SUPER::new([$stdin, 
				   sub {$buffer->write('stdout', $_[0])}, 
				   sub {$buffer->write('stderr', $_[0])}], 
				  [\*STDIN, \*STDOUT, \*STDERR]);
    $self->{Buffer} = $buffer;
    $self->{Cmd} = $cmd;
    return $self;
}

sub execute {
    my ($self, $maxRead, $safe) = @_;
    if ($safe) {
	$self->{Safe} = sub {$self->{Buffer}->write('stderr', "Error executing `$_[1]`: $_[0]\n")}
    }
    $self->SUPER::execute($self->{Cmd}, {}, $maxRead);
    return ($self->{Buffer});
}


package W3C::Util::Filter;

1;

__END__

=head1 NAME

W3C::Util::Filter - perform I/O for Unix-style filters.

=head1 SYNOPSIS

    use W3C::Util::Filter;

    # Pass $data to $cmd and collect the stdout and stderr.
    my ($stdout, $stderr) = 
	W3C::Util::Filter->new($cmd, $data)->execute(4096, 1);
    print "stdout: $stdout\n\nstderr: $stderr\n";

    # Do the same, but collect stdout and stderr in a FlavorBuffer.
    my ($results) = 
      W3C::Util::SyncFilter->new($cmd, $data)->execute(4096, 1);
    print $results->toString, "\n";

    # More primitive call allowing us to set an environment variable
    # telling $cmd to send a trace to FD 3 which we capture in $trace.
    my ($stdout, $stderr, $trace);
    W3C::Util::FilterN->new([$data, \$stdout, \$stderr, \$trace], 
			    [\*STDIN, \*STDOUT, \*STDERR], 2)->
	execute($cmd, {TRACE_FD => 3}, 4096);
    print "stdout: $stdout\n\nstderr: $stderr\n\ntrace: $trace\n";

=head1 DESCRIPTION

This module is part of the W3C::Util CPAN module.

Filter provides stdin, stdout and stderr access to spawned processes.

=item B<new(cmd, data)>

Construct a filter to spawn a process to run  B<cmd> and send B<data> to it.
Returns the (B<stdout>, B<stderr>) from the process.

=item B<execute([maxLen [, safe]])>

Execute the filter. If B<maxLen> is specified, terminate the process and throw a
B<W3C::Util::SelectReadLengthException>. If B<safe> is set, catch that exception
and append diagnostic information to the returned B<stderr>.

=head1 AUTHOR

Eric Prud'hommeaux <eric@w3.org>

=head1 SEE ALSO

perl(1).

=cut
