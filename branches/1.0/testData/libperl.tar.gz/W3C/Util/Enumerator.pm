#Copyright Massachusetts Institute of technology, 1998.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

use strict;
require Exporter;
#require AutoLoader;

$W3C::Util::Enumerator::REVISION = '$Id: Enumerator.pm,v 1.7 2007/06/22 17:47:28 eric Exp $ ';

package W3C::Util::Enumerator;
use vars qw($VERSION $DSLI @ISA @EXPORT @EXPORT_OK);
@ISA = qw(Exporter); # AutoLoader);
#@EXPORT = qw();
@EXPORT_OK = qw();
$VERSION = 0.90;
$DSLI = 'adpO';

use W3C::Util::Exception;

sub new {
    my ($proto, $uri) = @_;
    my $class = ref($proto) || $proto;
    my $self = {};
    bless ($self, $class);
    return $self;
}

sub hasMoreElements {
    my ($self) = @_;
    &throw(new W3C::Util::NotImplementedException(-class => ref $self, -method => 'hasMoreElements'));
}

sub getNextElement {
    my ($self) = @_;
    &throw(new W3C::Util::NotImplementedException(-class => ref $self, -method => 'getNextElement'));
}

package W3C::Util::ArrayEnumerator;
@W3C::Util::ArrayEnumerator::ISA = qw(W3C::Util::Enumerator);

sub new {
    my ($proto, @array) = @_;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new();
    bless ($self, $class);
    $self->{ARRAY} = [@array];
    $self->{INDEX} = -1;
    return $self;
}

sub hasMoreElements {
    my ($self) = @_;
    return $self->{INDEX}+1 < @{$self->{ARRAY}};
}

sub getNextElement {
    my ($self) = @_;
    return $self->{ARRAY}[++$self->{INDEX}];
}

sub deleteFromRemaining {
    my ($self, $element) = @_;
    for (my $i = $self->{INDEX}+1; $i < @{$self->{ARRAY}}; $i++) {
	if ($self->{ARRAY}[$i] eq $element) {
	    splice (@{$self->{ARRAY}}, $i, 1);
	    return $element;
	}
    }
    return undef;
}

package W3C::Util::Enumerator;

1;

__END__

=head1 NAME

W3C::Util::Enumerator.pm - interface for iterating through collections

=head1 SYNOPSIS

  use W3C::Util::Enumerator;
  for ($self->{ENUMERATOR} = new W3C::Util::ArrayEnumerator(@toDo); $self->{ENUMERATOR}->hasMoreElements;) {
      my $subject = $self->{ENUMERATOR}->getNextElement;
  }

=head1 Methods

The methods are based on java.lang.enumerator .

=head2 new

=head2 hasMoreElements

=head2 getNextElement

=head1 Subclasses

The W3C::Util::Enumerator package simply defines an interface. Real invocations
will need to implement the pure virtual methods new, hasMoreElements, and
getNextElement. 

=head2 ArrayEnumerator

Walk throuh a simple perl array.

This module is part of the W3C::Util CPAN module.

=head1 AUTHOR

Eric Prud'hommeaux <eric@w3.org>

=head1 SEE ALSO

perl(1).

=cut
