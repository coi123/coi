#!/usr/bin/perl

use strict;
use W3C::Util::TableRenderer;
my $renderer = new W3C::Util::TableRenderer(-dataFilter => sub {s/^trimMe//});
$renderer->addHeaders("my\nletter", "your\nnumber");
$renderer->addData([qw(trimMea trimMe1)]);
$renderer->underline();
$renderer->addData(['trimMeb', 'trimMe2', "extra\ncolumn"]);
$renderer->underline();
$renderer->addData([[qw(c 3)], [qw(d 4)]]);
$renderer->underline(1);
print $renderer->toString,"\n";
