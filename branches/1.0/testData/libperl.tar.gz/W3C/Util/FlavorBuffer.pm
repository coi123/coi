# Copyright Massachusetts Institute of technology, 2004.
# Written by Eric Prud'hommeaux for the World Wide Web Consortium

# $Id: FlavorBuffer.pm,v 1.2 2006/06/19 00:52:07 eric Exp $
use strict;

########################################################################
# FlavoredData: A chunk of data associated with a flavor
package W3C::Util::FlavoredData;
use IPC::Open3;
use W3C::Util::Exception;

sub new {
    my ($proto, $flavor, $data) = @_;
    my $class = ref($proto) || $proto;
    my $self = [$flavor, $data];
    bless ($self, $class);
    return $self;
}

sub getFlavor {
    my ($self) = @_;
    return $self->[0];
}

sub getData {
    my ($self) = @_;
    return $self->[1];
}
sub toString {
    my ($self, %flags) = @_;
    return "[$self->[0], $self->[1]]";
}

########################################################################
# FlavorBuffer: A collection of FlavoredData.
package W3C::Util::FlavorBuffer;
use IPC::Open3;
use W3C::Util::Exception;

sub new {
    my ($proto) = @_;
    my $class = ref($proto) || $proto;
    my $self = [];
    bless ($self, $class);
    return $self;
}

sub write {
    my ($self, $flavor, $data) = @_;
    push (@{$self}, new W3C::Util::FlavoredData($flavor, $data));
}

sub contents {
    my ($self) = @_;
    return @$self;
}

sub getByFlavor {
    my ($self, $flavor) = @_;
    my @ret = grep {$_->getFlavor() eq $flavor ? $_->getData() : undef} @$self;
    return wantarray ? @ret : join('', @ret);
}

sub toString {
    my ($self, %flags) = @_;
    my @ret;
    foreach my $datum (@$self) {
	push (@ret, $datum->toString(%flags));
    }
    return wantarray ? @ret : join("\n", @ret);
}

1;

__END__

=head1 NAME

W3C::Util::FlavorBuffer - trivial buffer to associate an attribute with a range of data.

=head1 SYNOPSIS

    # create the buffer
    require W3C::Util::FlavorBuffer;

    # write to it
    my $buffer = new W3C::Util::FlavorBuffer();
    $buffer->write('stderr', "Something horrible happened");
    $buffer->write('stdout', "But now things are OK");

    # recite the messages
    foreach my $entry ($results->contents()) {
	print $entry->getFlavor(), ': ', $entry->getData(), "\n";
    }

=head1 DESCRIPTION

This module is part of the W3C::Util CPAN module.

Filter associates an attribute called a "flavor" with a range of data. 

=item B<new()>

Construct a FlavorBuffer.

=item B<write(flavor, data)>

Add data B<data> with the flavor B<flavor> to the buffer.

=item B<contents()>

Returns an array of all data in the buffer tagged with its flavor. Use B<getFlavor()> and B<getData()> to examine each datum.

=head1 AUTHOR

Eric Prud'hommeaux <eric@w3.org>

=head1 SEE ALSO

perl(1).

=cut
