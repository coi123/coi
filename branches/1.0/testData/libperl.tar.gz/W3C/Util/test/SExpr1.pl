#!/usr/bin/perl

$REVISION = '$Id: SExpr1.pl,v 1.2 2004/06/08 06:51:01 eric Exp $ ';

use strict;

#BEGIN {unshift@INC,('../../..');}

use W3C::Util::SExpr;

my $test = "((foo 1 2 0) (bar 1 0 3) (blech 0 2 3))";
my ($struct, undef, undef) = new W3C::Util::SExpr()->parse(\$test);
print @$struct[0]->toString, "\n";

