#!/usr/bin/perl
# -*- mode: perl -*-

$REVISION = '$Id: Logger.pm,v 1.4 2004/06/08 06:51:01 eric Exp $ ';

use strict;

package W3C::Util::Logger;
use W3C::Util::Object;
use W3C::Util::Exception;
@W3C::Util::Logger::ISA = qw(W3C::Util::NamedParmObject);

sub new {
    my ($proto, @args) = @_;
    my $class = ref $proto || $proto;
    my $self = $class->SUPER::new(@args);
    $self->{MAX_EVENT} = -1;
    if (exists $self->{-handles}) {
	foreach my $event (keys %{$self->{-handles}}) {
	    $self->{MAX_EVENT} = $event if ($event > $self->{MAX_EVENT});
	}
    } else {
	$self->{-handles} = {};
    }
    $self->{-default} = *STDERR if (!exists $self->{-default});
    return $self;
}

# Associate an event with a file handle.
sub setHandle {
    my ($self, $event, $handle) = @_;
    $self->{-handles}{$event} = $handle;
    $self->{MAX_EVENT} = $event if ($event > $self->{MAX_EVENT});
}

# Same as setHandle, but whines when you re-use an event slot.
sub setNewHandle {
    my ($self, $event, $handle) = @_;
    if (exists $self->{-handles}{$event}) {
	&throw(new W3C::Util::Exception(-message => "Logger $self already has event $event set to $self->{-handles}{$event}"));
    }
    $self->setHandle($event, $handle);
}

sub getMaxEvent {$_->[0]->{MAX_EVENT}}

sub log {
    my ($self, $level, @args) = @_;
    my $out = exists $self->{-handles}{$level} ? $self->{-handles}{$level} : $self->{-default};
    if ($out) {
	if (UNIVERSAL::isa($out,'GLOB') || 
	    UNIVERSAL::isa($out,'FileHandle')) {
	    print $out @args,"\n" if (defined $out);
	} elsif (UNIVERSAL::isa($out,'SCALAR')) {
	    $$out .= join ('', @args, "\n");
	} elsif (UNIVERSAL::isa($out, 'ARRAY')) {
	    push (@$out, join ('', @args));
	} else {
	    &throw(new W3C::Util::ProgramFlowException());
	}
    }
}

1;

__END__

=head1 NAME

W3C::Util::Logger.pm - send log messages to different outputs depending on type

=head1 SYNOPSIS

  my $logger => $logger ? $logger : 
      new W3C::Util::Logger(-handles => {'PROTOCOL' => undef, 
 					 'SELECT' => undef},
			    -default => \*STDERR), 
  };
  $logger->log('PROTOCOL', 'messages', ' are', ' n', ' argumens', ' wide');
  $logger->log('SELECT', 'this message', ' will dissapear');
  $logger->setNewHandle('SELECT', \@STDOUT);
  $logger->log('SELECT', 'this message will go to STDOUT');
  $logger->log('OTHER', 'other messages go to STDERR');

=head1 Description

This module is intended to provide syslog-like functionality.

=head1 Methods

=head2 new

=head2 setHandle

Associate an event type with a file handle.

=head2 setNewHandle

Same as setHandle, but whines when you re-use an event slot. This is safer if
you want to be warned that you've already set a handle for an event type.

=head2 log

Send the logged messages to the appropriate file handle or array or big string.

=head1 AUTHOR

Eric Prud'hommeaux <eric@w3.org>

=head1 SEE ALSO

perl(1).

=cut
