#Copyright Massachusetts Institute of technology, 1998.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

use strict;

require Exporter;
require AutoLoader;

package W3C::Util::Atoms;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);
@ISA = qw(Exporter AutoLoader);
@EXPORT = qw();
@EXPORT_OK = qw();
$VERSION = 0.12;

#####
# per-class data

$W3C::Util::Atoms::revision = '$Id: Atoms.pm,v 1.8 2000/12/07 22:45:53 eric Exp $ ';

$W3C::Util::Atoms::NULL_ATOM = \ 'null atom';
$W3C::Util::Atoms::WILD_ATOM = \ 'wild atom';

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self  = {};

    bless ($self, $class);
    $self->clear;
    return $self;
}

sub clear {
    my $self = shift;
    $self->{ATOMS} = {};	# hash table of strings
    $self->{ATOMS_I} = {};	# same but all lower case keys
}

# returns first declared instance of string so '==' will work on it.

sub get {
    my ($self, $text) = @_;
    my $ret = $self->{ATOMS}{$text};
    return $ret if (defined $ret);
    $self->{ATOMS}{$text} = \ $text;
    $self->{ATOMS_I}{lc $text} = \ $text;
    return \ $text;
}

sub getI {
    my ($self, $text) = @_;
    my $ret = $self->{ATOMS_I}{lc $text};
    return $ret if (defined $ret);
    $self->{ATOMS}{$text} = \ $text;
    $self->{ATOMS_I}{lc $text} = \ $text;
    return \ $text;
}

sub getWild {
    my ($self) = @_;
    return \ $W3C::Util::Atoms::NULL_ATOM;
}

sub getWild {
    my ($self) = @_;
    return \ $W3C::Util::Atoms::WILD_ATOM;
}

1;

__END__

=head1 NAME

W3C::Util::Atoms - Associate a scalar with any unique string

=head1 SYNOPSIS

  use W3C::Util::;
  my $ = new W3C::Utils::();
  $->();

=head1 DESCRIPTION

This module is part of the W3C::Utils CPAN module.

=head1 AUTHOR

Eric Prud\'hommeaux <eric@w3.org>

=head1 SEE ALSO

perl(1).

=cut
