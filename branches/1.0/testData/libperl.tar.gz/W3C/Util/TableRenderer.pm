#Copyright Massachusetts Institute of technology, 2002.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

use strict;
use utf8;
$W3C::Rdf::ResultSet::REVISION = '$Id: TableRenderer.pm,v 1.17 2007/02/01 15:46:15 eric Exp $ ';

package W3C::Util::TableRenderer;
use W3C::Util::Exception;
use W3C::Util::Object;
use vars qw(@ISA);
@ISA = qw(W3C::Util::NamedParmObject);

use vars qw($DATUM $HEADER $LEFT $RIGHT);
($DATUM, $HEADER, $LEFT, $RIGHT) = (1..4);

sub new {
    my ($proto, @parms) = @_;
    my $self = $proto->SUPER::new(@parms);
    $self->{DATA} = [];		# [rows x columns] matrix of added data
    $self->{TYPES} = [];	# type (DATUM or HEADER) of each row
    $self->{WIDTHS} = [];	# widths of each cell in each row
    $self->{HEIGHTS} = [];	# heights of each row
    $self->{TABLE_WIDTH} = 0;	# widths of full-row cells
    $self->{UN_MARKED_PREFIX} = [];
    $self->{MARKED_PREFIX} = [];
    $self->{LINE_NO} = 0;

    $self->{-box} ||= defined $self->{-unicode} && $self->{-unicode} ? 
	['┌─┬┐', 
	 '│ ││', 
	 '│ ││', 
	 '├─┼┤', 
	 '└─┴┘'] : 
	 ['+-++', 
	  '| ||', 
	  '[ |]', 
	  '|-||', 
	  '+-++'];

    if (exists $self->{-markRow}) {
	my $marker = exists $self->{-rowMarker} ? $self->{-rowMarker} : '->';
	$self->{UN_MARKED_PREFIX} = [' ' x length $marker];
	$self->{MARKED_PREFIX} = [$marker];
    }

    if ($self->{-firstTitle}) {
	$self->addHeaders($self->{-firstTitle});
    }

    return $self;
}

sub addHeaders {
    my ($self, @data) = @_;
    $self->_addData(\@data, $HEADER, '-headerFilter', $HEADER, 0, $RIGHT);
}

sub addData {
    my ($self, @data) = @_;
    $self->_addData(\@data, $DATUM, '-dataFilter', $DATUM, 0, $RIGHT);
}

sub addRow {
    my ($self, @data) = @_;
    $self->_addData(\@data, $DATUM, '-dataFilter', $DATUM, 1, $LEFT);
}

sub underline {
    my ($self, $index) = @_;
    if (defined $index) {
	$self->{DATA}[-1][$index][1] = $HEADER;
    } else {
	foreach my $column (@{$self->{DATA}[-1]}) {
	    $column->[1] = $HEADER;
	}
    }
}

sub toString {
    my ($self, %flags) = @_;
    my @ret;

    if ($flags{-html}) {
	push (@ret, "<table border=\"1\">");
	for (my $rowNo = 0; $rowNo < @{$self->{DATA}}; $rowNo++) {
	    my $row = $self->{DATA}[$rowNo];
	    push (@ret, join ("\n", $self->_renderRow($self->{DATA}[$rowNo], $self->{HEIGHTS}[$rowNo], %flags)));
	}
	push (@ret, "</table>");
    } else {
	# Make sure the total column widths >= table width
	if ($self->{TABLE_WIDTH}) {
	    my $totalWidth = -1;
	    map {$totalWidth += $_+1} @{$self->{WIDTHS}};
	    if ($totalWidth < $self->{TABLE_WIDTH}) {
		$self->{WIDTHS}[-1] += $self->{TABLE_WIDTH} - $totalWidth;
	    }
	}

	push (@ret, $self->_hr($self->{-box}[0]));
	for (my $rowNo = 0; $rowNo < @{$self->{DATA}}; $rowNo++) {
	    my $row = $self->{DATA}[$rowNo];
	    push (@ret, join ("\n", $self->_renderRow($self->{DATA}[$rowNo], $self->{HEIGHTS}[$rowNo], %flags)));
	}
	push (@ret, $self->_hr($self->{-box}[4]));
    }
    return join ("\n", @ret);
}

sub _addData {
    my ($self, $data, $type, $filterName, $mode, $fullSpan, $justify) = @_;
    if (ref $data->[0] eq 'ARRAY') {
	$data = [@{$data->[0]}];
    }
    if (@$data && ref $data->[0] ne 'ARRAY') {
	$data = [$data];
    }
    foreach my $row (@$data) {
	my $rowEntry = [];
	push (@{$self->{DATA}}, $rowEntry);
	push (@{$self->{TYPES}}, $DATUM);
	my $prefix = $self->{UN_MARKED_PREFIX};
	if ($mode == $DATUM) {
	    if (defined $self->{-markRow} && $self->{LINE_NO} == $self->{-markRow}) {
		$prefix = $self->{MARKED_PREFIX};
	    }
	    $self->{LINE_NO}++;
	}
	my $columnNo = 0;
	while ($columnNo < @$prefix) {
	    my $datum = $prefix->[$columnNo];
	    $self->_checkWidth($datum, @{$self->{DATA}} - 1, $columnNo, 0);
	    push (@$rowEntry, [$datum, $type, 0]);
	    $columnNo++;
	}
	while ($columnNo < @$prefix + @$row) {
	    # if ($columnNo == @{$self->{WIDTHS}}) {
	    # 	push (@{$self->{WIDTHS}}, 0);
	    # }
	    my $datum = $row->[$columnNo - @$prefix];
	    if (my $filter = $self->{$filterName}) {
		local $_ = $datum;
		&$filter;
		$datum = $_;
	    }
	    $self->_checkWidth($datum, @{$self->{DATA}} - 1, $columnNo, $fullSpan);
	    push (@$rowEntry, [$datum, $type, $fullSpan, $justify]);
	    $columnNo++;
	}
    }
    return scalar @$data;
}

sub _hr {
    my ($self, $cover) = @_;
    my @ret;
    foreach my $width (@{$self->{WIDTHS}}) {
	push (@ret, substr($self->{-box}[0], 1, 1) x $width);
    }
    return substr($cover, 0, 1).join (substr($cover, 2, 1), @ret).substr($cover, 3, 1);
}

sub _checkWidth {
    my ($self, $datum, $rowNo, $column, $fullSpan) = @_;

    my @lines = split("\n", $datum);
    if (@lines) {
	foreach my $line (@lines) {
	    if ($fullSpan) {
		if (length ($line) > $self->{TABLE_WIDTH}) {
		    $self->{TABLE_WIDTH} = length ($line);
		}
	    } else {
		if ($column > @{$self->{WIDTHS}}-1 || length ($line) > $self->{WIDTHS}[$column]) {
		    $self->{WIDTHS}[$column] = length ($line);
		}
	    }
	}
    } elsif (defined $datum && $column > @{$self->{WIDTHS}}-1) {
	# Make sure that empty cells create a column that's zero width.
	$self->{WIDTHS}[$column] = 0;
    }
    if ($rowNo > @{$self->{HEIGHTS}}-1 || @lines > $self->{HEIGHTS}[$rowNo]) {
	$self->{HEIGHTS}[$rowNo] = @lines;
    }
}

sub _renderRow {
    my ($self, $row, $height, %flags) = @_;
    my $footer = [];
    my $rows = [];
    my $needsFooter = 0;
    my @ret = ();
    my $markup = $self->{-box}[1];
    my $rowIsDone = 0;
    for (my $column = 0; $column < @{$self->{WIDTHS}}; $column++) {
	my ($datum, $type, $fullSpan, $justify) = @$row > $column ? @{$row->[$column]} : (undef, undef, 0);
	if (my $quoting = $flags{-html}) {
	    next if ($rowIsDone);
	    my $txt;
	    if ($quoting eq 'escaped') {
		$txt = $datum;
	    } else {
		my @lines = defined $datum ? split("\n", $datum) : ();
		map {s/</&lt;/g;
		     s/>/&gt;/g} @lines;
		$txt = join("<br />\n", @lines);
	    }
	    my $typeStr = defined $type && $type == $HEADER ? 'th' : 'td';
	    my $widthStr = '1';
	    if ($fullSpan) {
		$widthStr = @{$self->{WIDTHS}} - $column;
		$rowIsDone = 1;
	    }
	    my $alignStr = $justify == $LEFT ? 'left' : 'right';
	    push (@ret, "<$typeStr colspan=\"$widthStr\" style=\"text-align: $alignStr\">$txt</$typeStr>");
	} else {
	    my $cellWidth = 0;

	    if ($fullSpan) {
		# This cell encompasses the whole row.
		map {$cellWidth += $_+1} @{$self->{WIDTHS}};
		$cellWidth--; # handle the last line delimeter.
	    } else {
		# This is a normal cell.
		$cellWidth = $self->{WIDTHS}[$column];
	    }

	    my @lines = defined $datum ? split("\n", $datum) : ();

	    # Calculate the max width of the data in the cell.
	    my $dataWidth = 0;
	    map {if (length ($_) > $dataWidth) {
		$dataWidth = length ($_);}} @lines;

	    # Walk through lines, padding out with spaces.
	    my $lineNo = 0;
	    while ($lineNo < @lines) {
		my $line = $lines[$lineNo];
		my $lpad = ' ' x ($cellWidth - $dataWidth);
		my $rpad = ' ' x ($dataWidth - length ($line));
		$rows->[$lineNo][$column] = $justify == $LEFT ? "$line$lpad$rpad" : "$lpad$line$rpad";
		$lineNo++;
	    }

	    # Pad out extra lines to reach the desired height.
	    while ($lineNo < $height) {
		$rows->[$lineNo][$column] = ' ' x $cellWidth;
		$lineNo++;
	    }

	    # Add decorations for HEADER.
	    if (defined $type && $type == $HEADER) {
		push (@$footer, substr($self->{-box}[3], 1, 1) x $cellWidth);
		$needsFooter++;
	    } else {
		push (@$footer, ' ' x $cellWidth); # might need one on another column
	    }

	    # Don't iterate over any cells after a fullspan cell.
	    if ($fullSpan) {
		$markup = $self->{-box}[2];
		last;
	    }
	}
    }
    if ($flags{-html}) {
	return '<tr>'.join('', @ret).'</tr>';
    } else {
	push (@ret, map {substr($markup, 0, 1).(join (substr($markup, 2, 1), @$_)).substr($markup, 3, 1)} @$rows);
    }
    if ($needsFooter) {
	push (@ret, substr($self->{-box}[3], 0, 1).(join (substr($self->{-box}[3], 2, 1), @$footer)).substr($self->{-box}[3], 3, 1));
    }
    return @ret;
}

1;

__END__

=head1 NAME

W3C::Util::TableRenderer - spit out data in a space-extended ascii table

=head1 SYNOPSIS

 use W3C::Util::TableRenderer;
 my @a = ([1, 'a'], [2, 'b']);
 my $renderer = new W3C::Util::TableRenderer;
 $renderer->addHeaders("int", "char");
 $renderer->addData(\@a);
 print $renderer->toString,"\n";

=head1 DESCRIPTION

Display tabular data in a space-extended ascii table.

=head1 METHODS

=over 4

=item new

Create a new TableRenderer. Takes arguments in hash or array form.

=over 4

=item -dataFilter

Specify code to call to manipute the data. This code should alter C<$_> to appear as it should in the serialized ascii table.

=item -headerFilter

Specify code to call to manipute the header labels. This code should alter C<$_> to appear as it should in the serialized ascii table.

=item -markRow

Indicate a row to mark with the C<row marker>.

=item -rowMarker

A string to indicate the b<current row> as defined by C<markRow>.

=item -unicode

Use unicode box-drawing characters instead of ascii.

=back

=item addHeader

Add headers to the current TableRenderer data set. This is customarily done at the beginning, however, headers may be added anywhere in the data. Headers added after data will, in fact, appear after that data.

The headers may be passed in as a list, an array ref, or an array of arrays. The following are all equivilent:

=over 4

        $renderer->addHeaders('letters', 'numbers');
        $renderer->addHeaders(['letters', 'numbers']);
        $renderer->addHeaders([['letters', 'numbers']]);
        $renderer->addData('letters', 'numbers'); $self->underline();

=back

See L<FORMATTING> for affects of linefeeds in the data.

=item addData

Add data to the current TableRenderer data set. The data may be passed in as a list, an array ref, or an array of arrays (see L<"addHeader">). See L<FORMATTING> for affects of linefeeds in the data.

=item underline ([$index])

Underline (highlight) the last row of data. If a numeric C<$index> is provided, underline only that column.

=item toString

Serialize the added headers and data in an ascii table.

=back

=head1 FORMATTING

Cell entries may have line feeds C<"\n"> embedded in them. In this case, the data is rendered on multiple lines, but the tabular format is preserved.

Row data may have more columns than previous headers and data. This will have no affect accept that subsequent calls to L<underline> will underline the extra column.

=head1 EXAMPLES

=over 4

    use W3C::Util::TableRenderer;

    # Any data starting with "trimMe" will have that part removed.
    my $renderer = new W3C::Util::TableRenderer(-dataFilter => sub {s/^trimMe//}
						-unicode => 0);

    # Add two two-line headers
    $renderer->addHeaders("my\nletter", "your\nnumber");

    # Add a row of data that's just crying out to be filtered.
    $renderer->addData([qw(trimMea trimMe1)]);

    # Underline that last row.
    $renderer->underline();

    # Add another row, this time with an unexpected extra column ...
    $renderer->addData(['trimMeb', 'trimMe2', "extra\ncolumn"]);
    # ... and underline it.
    $renderer->underline();

    # Add a two dimensional matrix of data.
    $renderer->addData([[qw(c 3)], [qw(d 4)]]);

    # Underline just column 1 of the previous row.
    $renderer->underline(1);

    # Let's see what hath we wrought.
    print $renderer->toString,"\n";

=back

The above should produce this output:

=over 4

    +------+------+------+
    |my    |your  |      |
    |letter|number|      |
    |------|------|      |
    |     a|     1|      |
    |------|------|      |
    |     b|     2|extra |
    |      |      |column|
    |------|------|------|
    |     c|     3|      |
    |     d|     4|      |
    |      |------|      |
    +------+------+------+

=back

=head1 AUTHOR

Eric Prud\'hommeaux <eric@w3.org>

=head1 SEE ALSO

perl(1).

=cut
