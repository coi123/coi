#Copyright Massachusetts Institute of technology, 1998.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

use strict;
require Exporter;
require AutoLoader;

$W3C::Util::Properties::REVISION = '$Id: Properties.pm,v 1.22 2004/08/12 13:15:08 eric Exp $ ';

package W3C::Util::Properties;
use W3C::Util::Exception;
use vars qw($VERSION $DSLI @ISA @EXPORT @EXPORT_OK);
@ISA = qw(Exporter AutoLoader);
@EXPORT = qw();
@EXPORT_OK = qw();
$VERSION = 0.12;
$DSLI = 'adpO';

sub new {
    my ($proto, @args) = @_;
    my $class = ref($proto) || $proto;
    my $self  = {};

    bless ($self, $class);
    $self->{INITIALIZERS} = [];
    $self->clear;
    $self->slurp(@args);
    return $self;
}

sub clear {
    my ($self, $names) = @_;
    if (defined $names) {
	$names = [$names] if (ref $names ne 'ARRAY');
	foreach my $name (@$names) {
	    $self->{NOCASE}{$name} = {};
	    $self->{PROPS}{$name} = {};
	}
    } else {
	$self->{NOCASE} = {};
	$self->{PROPS} = {};
    }
}

sub read {
    my ($self, $lines, $initSource) = @_;
    my $continuedLine = undef;
    foreach my $line (@$lines) {
	chomp $line;
	if ($line !~ m/^[\#\!]/) {
	    # originally used mid-line comments but dropped
	    # for compatability with Java.Util.Properties
	    # $line =~ s/\s*\#.*\Z//;
	    if (defined $continuedLine) {
		$line =~ s/^\s*//;
		$line = $continuedLine.$line;
	    }
	    if ($self->continueLine($line)) {
		$continuedLine = substr ($line, 0, length ($line)-1);
	    } else {
		$continuedLine = undef;
		next if (!$line);
		my ($name, $value) = split('\s*[:=]\s*', $line, 2);
		push (@$initSource, [$name, $value]);
		$self->putR($name, $value);
	    }
	}
    }
    # Java.Util.Properties seems to not mind files that end in a continuation
    if (defined $continuedLine) {
	my ($name, $value) = split('\s*[:=]\s*', $continuedLine, 2);
	push (@$initSource, [$name, $value]);
	$self->put($name, $value);
    }
}

sub put {
    my ($self, $name, $value) = @_;
    push (@{$self->{PROPS}{$name}}, $value);
    $self->{NOCASE}{lc $name} = $name;
}

sub putR {
    my ($self, $name, $value) = @_;
    if (my $cur = $self->{PROPS}{$name}) {
	push (@$cur, $value);
    } else {
	$self->{PROPS}{$name} = [$value];
    }
    $self->{NOCASE}{lc $name} = $name;
}

#####
# slurp - read attribute - value pairs from an array of initializers
#
# args - each initializer may be a ref to a
#  HASH - read attribute names and values from hash
#  ARRAY - prompt names and read values from STDIN
#  SCALAR - read name:value\n pairs from the scalar
#  or a strait (unref'd) filename - read name:value\n pairs from file

sub slurp {
    my ($self, @args) = @_;
    foreach my $initializer (@args) {
	my $initSource = [$initializer];
	push (@{$self->{INITIALIZERS}}, $initSource);
	if (ref $initializer eq 'HASH') {
	    foreach my $name (keys %$initializer) {
		push (@$initSource, [$name, $initializer->{$name}]);
		$self->put($name, $initializer->{$name});
	    }
	} elsif (ref $initializer eq 'ARRAY') {
	    foreach my $name (@$initializer) {
		my $red = $self->readStdin($name, $name eq 'password');
		push (@$initSource, [$name, $red]);
		$self->put($name, $red);
	    }
	} elsif (ref $initializer eq 'SCALAR') {
	    my @lines = split("\n", $$initializer);
	    $self->read(\@lines, $initSource);
	} else {
	    my $propertyFileName = $initializer;
	    if (1) {
		local $/ = "\n";
		local *PROPS;
		open (PROPS, $propertyFileName) || &throw(new W3C::Util::FileNotFoundException(-filename => $propertyFileName));
		my @lines = (<PROPS>);
		close (PROPS);
		$self->read(\@lines, $initSource);
	    } else {
		use IO::File;
		my $fh = new IO::File;
		if (!$fh->open("< $propertyFileName")) {
		    &throw(new W3C::Util::FileNotFoundException(-filename => $propertyFileName))
		}
		$self->load($fh);
		$fh->close;
	    }
	}
    }
}

sub defaultTo {
    my ($self, $name, $value) = @_;
    $self->put($name, $value) if (!defined $self->get($name));
}

sub defaultToI {
    my ($self, $name, $value) = @_;
    $self->put($name, $value) if (!defined $self->getI($name));
}

sub get {
    my ($self, $name) = @_;
    return $self->{PROPS} if (!defined $name);
    if (my $ret = $self->{PROPS}{$name}) {
	return wantarray ? 
	    (@{$self->{PROPS}{$name}}) : 
	    $self->{PROPS}{$name}[0];
    } else {
	return wantarray ? 
	    () : 
	    undef;
    }
}

sub getI {
    my ($self, $name) = @_;
    if (my $caseSensitiveName = $self->{NOCASE}{lc $name}) {
	return wantarray ? 
	    ($self->get($caseSensitiveName)) : 
	    $self->get($caseSensitiveName);
    } else {
	return wantarray ? 
	    () : 
	    undef;
    }
}

sub readStdin {
    my ($self, $name, $hidden) = @_;
    print $name,': ';
    system('stty -echo') if ($hidden);
    my $value = <STDIN>;
    (system('stty echo') && print "\n") if ($hidden);
    return $value;
}

sub toString {
    my ($self, $prefix) = @_; $prefix = '  ' if (!defined $prefix);
    my $ret = $prefix.$self."\n";
    foreach my $key (keys %{$self->{PROPS}}) {
	$ret .= $prefix.'  '.$key.': [';
	my $array = $self->{PROPS}{$key};
	foreach my $element (@$array) {
	    $ret .= '"'.$element.'", ';
	}
	$ret .= "]\n";
    }
    my $initCount = scalar @{$self->{INITIALIZERS}};
    $ret .= "$initCount initializers:\n";
    foreach my $initializer (@{$self->{INITIALIZERS}}) {
	my $type = ref $initializer->[0] ? ref $initializer->[0] : 'file';
	$ret .= "  $type:$initializer->[0]\n";
    }
    chomp $ret;
    return $ret;
}

#
# Returns true if the given line is a line that must
# be appended to the next line
#
sub continueLine {
    my ($self, $line) = @_;
    my $slashCount = 0;
    my $index = length ($line) - 1;
    while(($index >= 0) && (substr ($line, $index--, 1) eq '\\')) {
	$slashCount++;
    }
    return ($slashCount % 2 == 1);
}

1;

__END__

=head1 NAME

W3C::Util::Properties - tool to store and recover name/attribute pairs

=head1 SYNOPSIS

  use W3C::Util::Properties;
  my $props = new W3C::Util::Properties($sourceFile);
  my $name = $props->get('name');
  my $insensitiveName = $props->get('nAMe');

=head1 DESCRIPTION

Tool to store and recover name/attribute pairs.

This is similar to java.lang.properties.

This module is part of the W3C::Utils CPAN module.

=head1 AUTHOR

Eric Prud\'hommeaux <eric@w3.org>

=head1 SEE ALSO

perl(1).

=cut
