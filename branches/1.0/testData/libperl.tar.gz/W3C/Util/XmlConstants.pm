#Copyright Massachusetts Institute of technology, 2004.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

use strict;
require Exporter;


package W3C::Util::XmlConstants;
use vars qw($VERSION $REVISION $DSLI @ISA @EXPORT @EXPORT_OK @CHANGES);
$VERSION = 0.5;
$REVISION = '$Id: XmlConstants.pm,v 1.7 2005/09/28 03:20:18 eric Exp $ ';
@ISA = qw(Exporter);
@EXPORT_OK = qw($XmlNs $NCNameStartChar $NCNameChar $NameStartChar $NameChar $NCName $QName);

use vars qw($XmlNs $NCNameStartChar $NCNameChar $NameStartChar $NameChar $NCName $QName);

# avoid a perldb wide character regexp bug that's claimed fixed in bleedperl
# require utf8 if $DB::deep; # perl #34577 <http://www.mail-archive.com/perl5-porters@perl.org/msg86438.html>
use utf8; # perl #34577 <http://www.mail-archive.com/perl5-porters@perl.org/msg86438.html>

$XmlNs = 'http://www.w3.org/XML/1998/namespace';

# Extensible Markup Language (XML) 1.1 defines NameStartChar and NameChar.
# Namespaces in XML 1.1 defines NCNameStartChar and NCNameChar in terms of
# NameStartChar and NameChar:
#   [5]   	NCNameChar	   ::=   	NameChar - ':'
#   [5a]   	NCNameStartChar	   ::=   	NameStartChar - ':'
# Since it is easier to add chars than remove them, these variables define
#         	NameChar	   ::=   	NCNameChar + ':'
#          	NameStartChar	   ::=   	NCNameStartChar + ':'

# http://www.w3.org/TR/2004/REC-xml-names11-20040204/#NT-NCNameStartChar
$NCNameStartChar = $] < 5.007 ? 'A-Z_a-z\xC0-\xD6\xD8-\xF6' : 
    'A-Z_a-z\x{C0}-\x{D6}\x{D8}-\x{F6}\x{F8}-\x{2FF}\x{370}-\x{37D}\x{37F}-\x{1FFF}\x{200C}-\x{200D}\x{2070}-\x{218F}\x{2C00}-\x{2FEF}\x{3001}-\x{D7FF}\x{F900}-\x{FDCF}\x{FDF0}-\x{FFFD}\x{10000}-\x{EFFFF}';
# http://www.w3.org/TR/2004/REC-xml-names11-20040204/#NT-NCNameChar
$NCNameChar =      $] < 5.007 ? $NCNameStartChar.'\-\.0-9\xB7' : 
    $NCNameStartChar.'\-\.0-9\xB7\x{300}-\x{36F}\x{203F}-\x{2040}';
# http://www.w3.org/TR/2004/REC-xml11-20040204/#NT-NameStartChar
$NameStartChar =   ":$NCNameStartChar";
# http://www.w3.org/TR/2004/REC-xml11-20040204/#NT-NameChar
$NameChar =       ":$NCNameChar";
# http://www.w3.org/TR/2004/REC-xml-names11-20040204/#NT-NCName
$NCName =         "[$NCNameStartChar][$NCNameChar]*";
# http://www.w3.org/TR/2004/REC-xml-names11-20040204/#NT-QName
$QName =          "(?:[$NCNameStartChar][$NCNameChar]*:)?[$NCNameStartChar][$NCNameChar]*";

1;

__END__

=head1 NAME

W3C::Util::XmlConstants.pm - some constants useful for XML, n3 and other languages with namespaces

=head1 SYNOPSIS

    use W3C::Util::XmlConstants qw($NCNameStartChar $NCNameChar $QName);
    if ($prefix ne '' && $prefix !~ m/^[$NCNameStartChar][$NCNameChar]*$/) {
	print "found prefix: $prefix\n";
    }

=head1 DESCRIPTION

The module provides character clases for XML-related regular expressions. It is not in the XML package because many languages now use these character classes but don't need the full W3C::XML package.

This module is part of the W3C::Util CPAN module.

=head1 AUTHOR

Eric Prud\'hommeaux <eric@w3.org>

=head1 SEE ALSO

L<W3C::Util::NamespaceHandler>

=head1 COPYRIGHT

Copyright Massachusetts Institute of technology, 2004.

THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND COPYRIGHT HOLDERS MAKE NO REPRESENTATIONS
OR WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO, WARRANTIES OF MERCHANTABILITY OR
FITNESS FOR ANY PARTICULAR PURPOSE OR THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL NOT INFRINGE
ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER RIGHTS. 

COPYRIGHT HOLDERS WILL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF ANY USE OF THE SOFTWARE OR DOCUMENTATION. 

The name and trademarks of copyright holders may NOT be used in advertising or publicity pertaining 
to the software without specific, written prior permission. Title to copyright in this software and 
any associated documentation will at all times remain with copyright holders. 

=cut


