#Copyright Massachusetts Institute of technology, 1998.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

use strict;
require Exporter;
require AutoLoader;

$W3C::Util::NamespaceHandler::REVISION = '$Id: NamespaceHandler.pm,v 1.45 2005/04/26 09:36:57 eric Exp $ ';

use W3C::Util::Exception;

@W3C::Util::NamespaceException::ISA = qw(W3C::Util::Exception);

package W3C::Util::UnknownNamespaceException;
@W3C::Util::UnknownNamespaceException::ISA = qw(W3C::Util::NamespaceException);
sub new {
    my ($proto, @parms) = @_;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new(@parms);
    $self->missingParm('-namespace') if (!exists $self->{-namespace});
    $self->fillInStackTrace;
    return $self;
}
sub getSpecificMessage {return 'unknown namespace: "'.$_[0]->getNamespace.'"';}
sub getNamespace {return $_[0]->{-namespace};}

package W3C::Util::InvalidNamespacePrefixException;
@W3C::Util::InvalidNamespacePrefixException::ISA = qw(W3C::Util::NamespaceException);
sub new {
    my ($proto, @parms) = @_;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new(@parms);
    if (!defined $self->{-prefix}) {
	$self->missingParm('-prefix');
    }
    $self->fillInStackTrace;
    return $self;
}
sub getSpecificMessage {return 'namespace prefix "'.$_[0]->getPrefix.'" is invalid';}
sub getPrefix {return $_[0]->{-prefix};}

package W3C::Util::NamespaceCollisionException;
@W3C::Util::NamespaceCollisionException::ISA = qw(W3C::Util::InvalidNamespacePrefixException);
sub getSpecificMessage {return 'namespace prefix "'.$_[0]->getPrefix.'" already defined';}

@W3C::Util::NamespaceCreationException::ISA = qw(W3C::Util::NamespaceException);

package W3C::Util::CantCreateNamespaceException;
@W3C::Util::CantCreateNamespaceException::ISA = qw(W3C::Util::NamespaceException);
sub new {
    my ($proto, @parms) = @_;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new(@parms);
    $self->missingParm('-namespace') if (!exists $self->{-namespace});
    $self->fillInStackTrace;
    return $self;
}
sub getSpecificMessage {return 'no namespace options for "'.$_[0]->getNamespace.'"';}
sub getNamespace {return $_[0]->{-namespace};}

package W3C::Util::NoViableLocalnameException;
@W3C::Util::NoViableLocalnameException::ISA = qw(W3C::Util::NamespaceException);
sub new {
    my ($proto, @parms) = @_;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new(@parms);
    $self->missingParm('-namespace') if (!exists $self->{-namespace});
    $self->fillInStackTrace;
    return $self;
}
sub getSpecificMessage {return 'no viable localname for namespace "'.$_[0]->getNamespace.'"';}
sub getNamespace {return $_[0]->{-namespace};}

package W3C::Util::NamespaceHandler;
use W3C::Util::Exception;
use W3C::Util::XmlConstants qw($NCNameStartChar $NCNameChar $NCName);
use vars qw($VERSION $DSLI @ISA @EXPORT @EXPORT_OK @CHANGES);
@ISA = qw(W3C::Util::NamedParmObject Exporter AutoLoader);
@EXPORT = qw();
@EXPORT_OK = qw($NS_IGNORE $NS_REPLACE $NS_FAIL 
		&staticUnmapNamespace &staticMakeUpPrefix);
$VERSION = 0.98;
$DSLI = 'adpO';
@CHANGES = (
	    {'0.96' => ['added NamespaceHandler::addNamespace']}, 
	    {'0.95' => ['started keeping track']});

use vars qw($NS_IGNORE $NS_REPLACE $NS_FAIL);
$NS_IGNORE = \ 'use older namespace';
$NS_REPLACE = \ 'use newer namespace';
$NS_FAIL = \ 'fail on namespace collision';

sub new {
    my ($proto, @parms) = @_;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new(@parms);
    bless ($self, $class);
    $self->{-separator} ||= ':';

    if (!defined $self->{-collide}) {
	$self->{-collide} = $NS_FAIL;
    }
    $self->clear;
    return $self;
}

sub clear {
    my ($self) = @_;
    $self->{NAMESPACE_FORWARD} = {};
    $self->{NAMESPACE_REVERSE} = {};
    $self->{UNKNOWN_NAMESPACES} = {};
    $self->{XML_BASE} = undef;
    $self->{XML_LANG} = undef;

    if ($self->{-copyHandler}) {
        #tricky bit to copy the namespace stack ([0] is default ns and [1] is defined ns's)
	$self->copyFrom($self->{-copyHandler});
	if (!exists $self->{-relay} && $self->{-copyHandler}{-relay}) {
	    $self->{-relay} = $self->{-copyHandler}{-relay};
	}
    }
}

sub copyFrom {
    my ($self, $copyFrom) = @_;
    foreach my $prefix (keys %{$copyFrom->{NAMESPACE_FORWARD}}) {
	$self->{NAMESPACE_FORWARD}{$prefix} = $copyFrom->{NAMESPACE_FORWARD}{$prefix};
    }
    foreach my $ns (keys %{$copyFrom->{NAMESPACE_REVERSE}}) {
	$self->{NAMESPACE_REVERSE}{$ns} = $copyFrom->{NAMESPACE_REVERSE}{$ns};
    }
    foreach my $prefix (keys %{$copyFrom->{UNKNOWN_NAMESPACES}}) {
	$self->{UNKNOWN_NAMESPACES}{$prefix} = $copyFrom->{UNKNOWN_NAMESPACES}{$prefix};
    }
    $self->{XML_BASE} = $copyFrom->{XML_BASE};
    $self->{XML_LANG} = $copyFrom->{XML_LANG};
}

sub setMode {
    my ($self, $mode) = @_;
    $self->{MODE} = $mode;
}

#    $namespaceHandler->addNamespace('xsl', 'http://www.w3.org/TR/WD-xsl', $inputSource->getPublicId);
sub addNamespace {
    my ($self, $prefix, $expanded, $flags) = @_;

    if ($prefix ne '' && $prefix !~ m/^$NCName$/) {
	&throw(new W3C::Util::InvalidNamespacePrefixException(-prefix => $prefix));
    }

    # If either the namespace or the prefix has been used...
    if (defined $self->{NAMESPACE_FORWARD}{$prefix}) {
	if ($self->{-collide} == $NS_IGNORE || 
	    ($self->{-collide} == $NS_FAIL && $self->{NAMESPACE_FORWARD}{$prefix} eq $expanded)) {
	    return;
	} elsif ($self->{-collide} == $NS_REPLACE) {
	} elsif ($self->{-collide} == $NS_FAIL) {
	    &throw(new W3C::Util::NamespaceCollisionException(-prefix => $prefix));
	} else {
	    &throw(new W3C::Util::ProgramFlowException(-message => "collide flag set to $self->{-collide}"));
	}
    }

    # Pass to relay namespace handler.
    if (my $relay = $self->{-relay}) {
	$relay->addNamespace($prefix, $expanded, $flags);
    }

    # Record locally.
    $self->{NAMESPACE_FORWARD}{$prefix} = $expanded;
    $self->{NAMESPACE_REVERSE}{$expanded} = $prefix;
    delete $self->{UNKNOWN_NAMESPACES}{$prefix};
}

sub setXmlBase {
    my ($self, $base) = @_;
    $self->{XML_BASE} = $base;
}

sub getXmlBase {
    my ($self) = @_;
    return $self->{XML_BASE};
}

sub setXmlLang {
    my ($self, $lang) = @_;
    $self->{XML_LANG} = $lang;
}

sub getXmlLang {
    my ($self) = @_;
    return $self->{XML_LANG};
}

sub getNamespace {
    my ($self, $prefix) = @_;
    return $self->{NAMESPACE_FORWARD}{$prefix};
}

sub mapNamespace {
    my ($self, $toMap, $localDefault) = @_;
    if ($toMap =~ m/^ ([^:]*) \Q$self->{-separator}\E (.*) $/x) {
	my ($prefix, $property) = ($1, $2);
	return ($self->_getNs($prefix, $property));
    }
    if ($localDefault) {
	return ($self->_getNs($localDefault, $toMap));
    }
    return ($self->_getNs('', $toMap));
}

sub _getNs {
    my ($self, $prefix, $localName) = @_;
    if (exists $self->{NAMESPACE_FORWARD}{$prefix}) {
	return ($self->{NAMESPACE_FORWARD}{$prefix}, $localName, $prefix);
    } elsif ($self->{-passUnknownNamespaces}) {
	if (!exists $self->{UNKNOWN_NAMESPACES}{$prefix}) {
	    push (@{$self->{UNKNOWN_NAMESPACES}{$prefix}}, $localName);
	}
	return (undef, defined $prefix ? $prefix.':'.$localName : $localName, $prefix);
    } else {
	&throw(new W3C::Util::UnknownNamespaceException(-namespace => $prefix));
    }
}

sub getUnknownNamespaces {
    my ($self) = @_;
    return keys %{$self->{UNKNOWN_NAMESPACES}};
}

sub getUnknownNamespaceDeclaration {
    my ($self, $namespace) = @_;
    return $self->{UNKNOWN_NAMESPACES}{$namespace};
}

# makes an attempt at reversing namespaces for printing - will not follow hierarchy
# $firstPrefixToTry is optional
sub unmapNamespace {
    my ($self, $name, $firstPrefixToTry) = @_;
    return  &staticUnmapNamespace($name, $firstPrefixToTry, $self->{NAMESPACE_FORWARD}, $self->{NAMESPACE_REVERSE});
}

sub staticUnmapNamespace {
    my ($name, $firstPrefixToTry, $prefixToNs, $nsToPrefix) = @_;

    # check for default (probably element) namespaces first
    if ($firstPrefixToTry && exists $prefixToNs->{$firstPrefixToTry}) {
	my $defaultNs = $prefixToNs->{$firstPrefixToTry};
	if ($name =~ m/\A \Q$defaultNs\E ($NCName) \Z/x) {
	    return ($defaultNs, $firstPrefixToTry, $1);
	}
    }

    # check for any matching namespaces
    foreach my $namespace (sort {length $b <=> length $a} keys %$nsToPrefix) {
	if ($name =~ m/\A \Q$namespace\E ($NCName) \Z/x) {
	    return ($namespace, $nsToPrefix->{$namespace}, $1);
	}
    }

    # no match
    return (undef, undef, undef);
}

sub staticMakeUpPrefix {
    my ($expanded, $namespaceCreativity) = @_;
    my ($ns, $prefix, $remainder);
    if ($expanded =~ m/\A (.*?) ($NCName) \Z/x) {
	($ns, $remainder) = ($1, $2);
	my $r = reverse $ns;
	if ($r =~ m/([$NCNameChar]*[$NCNameStartChar])/) {
	    $prefix = reverse $1;
	} elsif ($namespaceCreativity) {
	    if ($expanded =~ m/\A (.*?) ($NCName) (.) \Z/x) {
		($prefix, $ns, $remainder) = ($2, $1.$2, $3);
	    } elsif ($expanded =~ m/\A (.*?) ($NCName) (.*) \Z/x) {
		($prefix, $ns, $remainder) = ($1.$2, $1.$2, $3);
	    } else {
		($prefix, $ns, $remainder) = ('NS', 'http://fake.com/', $expanded);
	    }
	} else {
	    &throw(new W3C::Util::CantCreateNamespaceException(-namespace => $expanded))
	}
    } elsif ($namespaceCreativity) {
	$expanded =~ m/\A (.*?) ([\w\d_\-]*) ([^\w\d_\-]*?) \Z/x;
	($prefix, $ns, $remainder) = ($2, $1.$2, $3);
    } else {
	&throw(new W3C::Util::NoViableLocalnameException(-namespace => "$expanded"))
    }
    return ($ns, $prefix, $remainder);
}

sub toString {
    my ($self, %flags) = @_;
    my @ret;
    my $handle = $flags{-handle};
    # poke through the keys - starting with the longest so we get the best match
    foreach my $prefix (sort keys %{$self->{NAMESPACE_FORWARD}}) {
	my $url = $self->{NAMESPACE_FORWARD}{$prefix};
	my $str = $flags{-outputMode} eq 'n3' ? 
	    ($prefix ? "\@prefix $prefix=<$url> ." : "\@prefix <$url> .") : 
	    ($prefix ? "xmlns:$prefix=\"$url\"" : "xmlns=\"$url\"");
	if ($handle) {
	    print $handle "$str\n";
	} else {
	    push (@ret, $str);
	}
    }
    return $handle ? undef : wantarray ? @ret : join ("\n", @ret);
}

package W3C::Util::NamespaceAndStringHandler;
@W3C::Util::NamespaceAndStringHandler::ISA = ("W3C::Util::NamespaceHandler");

sub addStringMap ($$) {
    my ($self, $from, $to) = @_;
    $self->{STRING_REVERSE}{$from} = $to;
}

sub addResourceMap ($$) {
    my ($self, $resource) = @_;
    my $base = $resource;
    $base =~ s/[\?\#].*//;
    if ($base =~ m/([^\\\/\:]+)$/ || $base =~ m/([^\\\/\:]+)[^\\\/\:]$/) {
	$base = $1;
    }
    my $to = $base; # start with the plain base name
    my $revNo = 1;
    while (exists $self->{STRING_FORWARD}{$to}) {$to = $base.'<'.++$revNo.'>'};
    $self->{STRING_FORWARD}{$to} = $resource;
    $self->{STRING_REVERSE}{$resource} = $to;
}

sub unmapString ($) {
    my ($self, $string) = @_;
    foreach my $key (sort {length $b <=> length $a} keys %{$self->{STRING_REVERSE}}) {
	if ($string =~ m/\A \Q$key\E (.*) \Z/x) {
	    return ($key, $self->{STRING_REVERSE}{$key}, $1);
	}
    }
    return (undef, undef, undef);
}

sub unmapNamespace ($;$) {
    my ($self, $name, $firstPrefixToTry) = @_;
    my ($ns, $prefix, $remainder) = $self->SUPER::unmapNamespace($name, $firstPrefixToTry);
    if (!defined $prefix) {
	($ns, $prefix, $remainder) = $self->unmapString($name);
    }
    return ($ns, $prefix, $remainder);
}

package W3C::Util::NamespaceInventor;
@W3C::Util::NamespaceInventor::ISA = ("W3C::Util::NamespaceHandler");
use W3C::Util::Exception;

sub new {
    my ($proto, @parms) = @_;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new(@parms);
    return $self;
}
sub clearPending {
    my ($self) = @_;
    $self->{NAMESPACE_FORWARD} = {};
    $self->{NAMESPACE_REVERSE} = {};
}

sub unmapNamespace {
    my ($self, $name, $firstPrefix) = @_;
    my $namespaceHandler = undef;
    my $new = 0;

    # First try newly declared namespaces. They will override any
    # inherited namespaces.
    my ($ns, $prefix, $remainder) = $self->SUPER::unmapNamespace($name, $firstPrefix);

    if (defined($ns)) {
	# Tag name is already known from a parent element.
    } else {
	# Tag name is not known so we need to create one.
	$new = 1;

	if (my $importer = $self->{-importMap}) {
	    # Look in the importMap for one.
	    ($ns, $prefix, $remainder) = $importer->unmapNamespace($name, $firstPrefix);
	}
	if (!defined($ns)) {
	    # Make one up.
	    ($ns, $prefix, $remainder) = &W3C::Util::NamespaceHandler::staticMakeUpPrefix($name, $self->{-namespaceCreativity});
	}

	# Make sure imported or made up namespace does not collide.
	my ($base, $ordinal) = ($prefix, 0);
	while ($self->getNamespace($prefix) && $self->getNamespace($prefix) ne $ns) {
	    $prefix = $base.'-'.$ordinal;
	    $ordinal++;
	}

	# Note the new namespace for later re-use.
	$self->addNamespace($prefix, $ns,  -collide => $W3C::Util::NamespaceHandler::NS_FAIL);
    }

    return ($ns, $prefix, $remainder, $new);
}


package W3C::Util::NamespaceReducer;
@W3C::Util::NamespaceReducer::ISA = ("W3C::Util::NamespaceHandler");
use W3C::Util::Exception;

sub new {
    my ($proto, @parms) = @_;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new(@parms);
    if (!$self->{-relay}) {
	&throw(new W3C::Util::Exception(-message => "$class constructor needs a -relay to reduce from."));
    }
    return $self;
}
sub unmapNamespace {
    my ($self, $name, $firstPrefixToTry) = @_;
    my ($namespace, $prefix, $remainder) = $self->SUPER::unmapNamespace($name, $firstPrefixToTry);
    if (!$namespace) {
	($namespace, $prefix, $remainder) = $self->{-relay}->unmapNamespace($name, $firstPrefixToTry);
	if ($namespace) {
	    $self->addNamespace($prefix, $namespace,  -collide => $W3C::Util::NamespaceHandler::NS_FAIL);
	}
    }
    return ($namespace, $prefix, $remainder);
}


package W3C::Util::NamespaceHandler; # so make doesn't complain about the package

1;

__END__

=head1 NAME

W3C::Util::NamespaceHandler.pm - some namespace handlers useful for XML, n3 and other namespace formats.

=head1 SYNOPSIS

  my $nsh = new W3C::Util::NamespaceHandler();
  $nsh->addNamespace('rdf', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#');
  my ($ns, $lName, $prefix) = 
    $nsh->mapNamespace('rdf:type');
  my ($ns, $prefix, $lName) = 
    $nsh->unmapNamespace('http://www.w3.org/1999/02/22-rdf-syntax-ns#type');
  

=head1 DESCRIPTION

The module provides basic namespace mapping functions. These include declaring
namespaces, mapping qnames to namespace/localname pairs, and finding a namespace
that, when concatonated with a valid local name, will produce a given URL. This
last function is called unmapping.

=head2 Namespace Languages

Many languages benifit from abbreviating
repeated portions of URIs by finding a common substring and
inventing a short token to represent that substring. For example,
XML declares the tokens with attributes of the form
xmlns:token="<substring of URI>". This module maintains mappings
between tokens and URI substrings.

=head2 Inheriting Namespaces

Some applications have a single namespace. For example, N3 has
declarations for namespaces that are expected to apply to the entire
document. XML, on the other hand, allows namespace declarations on
any element and therefor allows nested namespaces where namespaces
may even override the namespaces of parent elments.

  <!-- http://example.com/bar#Root -->
  <foo:Root xmlns:foo="http://example.com/bar#">
      <!-- http://example.com/baz#Child -->
      <foo:Child xmlns:foo="http://example.com/baz#" />
  </foo:Root>

The NamespaceHandler constructor takes a -copyHandler parameter to
provide inherited namespaces and a -collide parameter to define what
happens when an application declares a mapping for a token that is
already decalared. In the above case, the -collide parameter should
be set to $NS_REPLACE.

=head2 Importing Namespaces
Applications wishing to serialize data may use the NamespaceHandler
to use reverse namespace mappings and possibly invent namespace
tokens where needed. Frequently, before inventing a new namespace
token, an application may wish to try to use mappings encountered
while processing other documents. The -importMap parameter points to
another namespace handler from which to take suggestions before
inventing a new mapping.

=head2 Aggregating Namespaces
In order to build a NamespaceHandler that gathers all the declared
namespaces encountered during some processing, the NamespaceHandler
specific to that processing may take an aggregate NamespaceHandler
indicated by the -relay parameteter. Each time a new namespace is
declared, it will inform the -relay NamespaceHandler. It is likely
that the application will wish to construct the aggregate
NamespaceHandler with a -collide policy of either $NS_IGNORE or
$NS_REPLACE, depending on whether the preferred mapping choice is
the first or last declared. It is unlikely that $NS_FAIL would be
used as this would imply that namespace collisions between different
documents are illegal.

=head1 Auxilliary Classes

This module defines several extra classes that enhance the utility
of the NamespaceHandler.

=head2 W3C::Util::NamespaceInventor

Works hard to invent namespaces when 
  ensureNamespace ($name, $firstPrefix, 
                   $namespaceHandler)
is called.
Typical construction:
   $nsi = new W3C::Util::NamespaceInventor(-importMap => $nsh,
					   -namespaceCreativity => 1);
Typical invocation:
   my ($ns, $prefix, $remainder, $new) = 
        $nsi->ensureNamespace($name, $firstPrefix, 
			      $curNsh, 1);

=head2 W3C::Util::NamespaceReducer

This subclass absorbs only the referenced namespaces from -relay.
It is used to eliminate extraneous namespaces on output.

Typical construction:
   my $nsr = new W3C::Util::NamespaceReducer(-relay => $bigNsHandler);
   my $ret = $self->toString(-namespaceHandler => $nsr);


This module is part of the W3C::Util CPAN module.

=head1 AUTHOR

Eric Prud\'hommeaux <eric@w3.org>

=head1 SEE ALSO

perl(1).

=cut
