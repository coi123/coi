#Copyright Massachusetts Institute of technology, 1998.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

# $Id: LocatorImpl.pm,v 1.11 2004/06/06 21:23:04 eric Exp $

use strict;
require Exporter;
require AutoLoader;

$W3C::XML::LocatorImpl::REVISION = '$Id: LocatorImpl.pm,v 1.11 2004/06/06 21:23:04 eric Exp $ ';

package W3C::XML::LocatorImpl;
use vars qw($VERSION $DSLI @ISA @EXPORT @EXPORT_OK, @TODO);
@ISA = qw(Exporter AutoLoader);
@EXPORT = qw();
@EXPORT_OK = qw();
$VERSION = 0.96;
$DSLI = 'adpO';

#####
# per-class data

my $Debugging = 0;	# whether to show debugging stuff
my $Outstanding = 0;	# count of outstanding connections

#####
# per-object data
# PUBLICID	- 
# SYSTEMID	- 
# LINENUMBER	-
# COLUMNNUMBER	-
# DEBUG		- per-object control of debugging info

#####
# new - prepare a W3C::XML::LocatorImpl with a new connection

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self  = {};
    $self->{DEBUG} = 0;
    # "private" data
    my $locator = shift;
    if (defined $locator) {
	$self->{PUBLICID} = $locator->getPublicId();
	$self->{SYSTEMID} = $locator->getSystemId();
	$self->{LINENUMBER} = $locator->getLineNumber();
	$self->{COLUMNNUMBER} = $locator->getColumnNumber();
    } else {
	$self->{PUBLICID} = undef;
	$self->{SYSTEMID} = undef;
	$self->{LINENUMBER} = undef;
	$self->{COLUMNNUMBER} = undef;
    }
    $self->{"_OUTSTANDING"} = \$Outstanding;
    bless ($self, $class);
    ++ ${ $self->{"_OUTSTANDING"} };
    return $self;
}

#####
# PublicId

sub setPublicId {
    my $self = shift;
    $self->{PUBLICID} = shift;
}

sub getPublicId {
    my $self = shift;
    return $self->{PUBLICID};
}

#####
# SystemId

sub setSystemId {
    my $self = shift;
    $self->{SYSTEMID} = shift;
}

sub getSystemId {
    my $self = shift;
    return $self->{SYSTEMID};
}

#####
# LineNumber

sub setLineNumber {
    my $self = shift;
    $self->{LINENUMBER} = shift;
}

sub getLineNumber {
    my $self = shift;
    return $self->{LINENUMBER};
}

#####
# ColumnNumber

sub setColumnNumber {
    my $self = shift;
    $self->{COLUMNNUMBER} = shift;
}

sub getColumnNumber {
    my $self = shift;
    return $self->{COLUMNNUMBER};
}


#####
# debug - cannonical debugging stuff from
# http://www.perl.com/CPAN-local/doc/manual/html/pod/perltoot/Debuging_Methods.html

sub debug {
    my $self = shift;
    warn "usage: thing->debug(level)"    unless @_ == 1;
    my $level = shift;
    if (ref($self))  {
	$self->{"_DEBUG"} = $level;         # just myself
    } else {
	$Debugging        = $level;         # whole class
    }
}

#####
# DESTROY - hook to display debugging info

sub DESTROY {
    my $self = shift;
    if ($Debugging || $self->{"_DEBUG"}) {
	warn "W3C::XML::LocatorImpl destroying $self " . $self->name;
    }
    -- ${ $self->{"_OUTSTANDING"} };
}

#####
# END - hook to display debugging info

sub END {
    if ($Debugging) {
	print "All LocatorImpls are going away now.\n";
    }
}

1;

__END__

=head1 NAME

W3C::XML::LocatorImpl - implementation of the SAX Locator interface

=head1 SYNOPSIS

@@@

=head1 DESCRIPTION

This module is part of the W3C::XML CPAN module.

=head1 AUTHOR

Eric Prud\'hommeaux <eric@w3.org>

=head1 SEE ALSO

W3C::XML::XmlParser(1) perl(1).

=cut
