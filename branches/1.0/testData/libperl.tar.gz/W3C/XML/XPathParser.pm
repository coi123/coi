#!/usr/bin/perl
####################################################################
#
#    This file was generated using Parse::Yapp version 1.05.
#
#        Don't edit this file, use source file instead.
#
#             ANY CHANGE MADE HERE WILL BE LOST !
#
####################################################################
package W3C::XML::_XPathParser;
use vars qw ( @ISA );
use strict;

@ISA= qw ( Parse::Yapp::Driver );
# use Parse::Yapp::Driver; @@ replaced by W3C::Util::YappDriver

#line 27 "XPathParser.yp"

    #BEGIN {unshift@INC,('../..');}
    use W3C::Util::YappDriver;
    @ISA= qw (W3C::Util::YappDriver);

    use W3C::XML::XPathCompileTree qw();


sub new {
        my($class)=shift;
        ref($class)
    and $class=ref($class);

    my($self)=$class->SUPER::new( yyversion => '1.05',
                                  yystates =>
[
	{#State 0
		ACTIONS => {
			"preceding" => 2,
			".." => 1,
			"\@" => 4,
			"namespace" => 6,
			"following-sibling" => 7,
			"child" => 9,
			"ancestor" => 11,
			"self" => 12,
			"descendant-or-self" => 14,
			"//" => 13,
			"preceding-sibling" => 15,
			"attribute" => 17,
			"following" => 18,
			"ancestor-or-self" => 19,
			"/" => 20,
			"." => 26,
			"descendant" => 28,
			"parent" => 27
		},
		DEFAULT => -39,
		GOTOS => {
			'Step' => 3,
			'AxisSpecifier' => 16,
			'LocationPath' => 5,
			'AbbreviatedAbsoluteLocationPath' => 21,
			'AbsoluteLocationPath' => 8,
			'AbbreviatedStep' => 10,
			'AxisName' => 22,
			'AbbreviatedAxisSpecifier' => 23,
			'RelativeLocationPath' => 25,
			'AbbreviatedRelativeLocationPath' => 24
		}
	},
	{#State 1
		DEFAULT => -38
	},
	{#State 2
		DEFAULT => -26
	},
	{#State 3
		DEFAULT => -7
	},
	{#State 4
		DEFAULT => -40
	},
	{#State 5
		ACTIONS => {
			'' => 29
		}
	},
	{#State 6
		DEFAULT => -24
	},
	{#State 7
		DEFAULT => -23
	},
	{#State 8
		DEFAULT => -2
	},
	{#State 9
		DEFAULT => -19
	},
	{#State 10
		DEFAULT => -11
	},
	{#State 11
		DEFAULT => -16
	},
	{#State 12
		DEFAULT => -28
	},
	{#State 13
		ACTIONS => {
			"preceding" => 2,
			".." => 1,
			"\@" => 4,
			"namespace" => 6,
			"following-sibling" => 7,
			"child" => 9,
			"ancestor" => 11,
			"self" => 12,
			"descendant-or-self" => 14,
			"preceding-sibling" => 15,
			"attribute" => 17,
			"following" => 18,
			"ancestor-or-self" => 19,
			"." => 26,
			"descendant" => 28,
			"parent" => 27
		},
		DEFAULT => -39,
		GOTOS => {
			'AbbreviatedStep' => 10,
			'Step' => 3,
			'AxisName' => 22,
			'AbbreviatedAxisSpecifier' => 23,
			'AxisSpecifier' => 16,
			'RelativeLocationPath' => 30,
			'AbbreviatedRelativeLocationPath' => 24
		}
	},
	{#State 14
		DEFAULT => -21
	},
	{#State 15
		DEFAULT => -27
	},
	{#State 16
		ACTIONS => {
			"processing-instruction" => 32,
			'NameTest' => 33,
			'NodeType' => 34
		},
		GOTOS => {
			'NodeTest' => 31
		}
	},
	{#State 17
		DEFAULT => -18
	},
	{#State 18
		DEFAULT => -22
	},
	{#State 19
		DEFAULT => -17
	},
	{#State 20
		ACTIONS => {
			"preceding" => 2,
			"\@" => 4,
			"namespace" => 6,
			"following-sibling" => 7,
			"child" => 9,
			"ancestor" => 11,
			"self" => 12,
			"descendant-or-self" => 14,
			"ancestor-or-self" => 19,
			'NodeType' => -39,
			"." => 26,
			"descendant" => 28,
			"parent" => 27,
			".." => 1,
			"processing-instruction" => -39,
			"preceding-sibling" => 15,
			"attribute" => 17,
			"following" => 18,
			'NameTest' => -39
		},
		DEFAULT => -5,
		GOTOS => {
			'Step' => 3,
			'AxisSpecifier' => 16,
			'RelativeLocationPathOpt' => 35,
			'AbbreviatedStep' => 10,
			'AxisName' => 22,
			'AbbreviatedAxisSpecifier' => 23,
			'AbbreviatedRelativeLocationPath' => 24,
			'RelativeLocationPath' => 36
		}
	},
	{#State 21
		DEFAULT => -4
	},
	{#State 22
		ACTIONS => {
			"::" => 37
		}
	},
	{#State 23
		DEFAULT => -15
	},
	{#State 24
		DEFAULT => -9
	},
	{#State 25
		ACTIONS => {
			"//" => 38,
			"/" => 39
		},
		DEFAULT => -1
	},
	{#State 26
		DEFAULT => -37
	},
	{#State 27
		DEFAULT => -25
	},
	{#State 28
		DEFAULT => -20
	},
	{#State 29
		DEFAULT => 0
	},
	{#State 30
		ACTIONS => {
			"//" => 38,
			"/" => 39
		},
		DEFAULT => -35
	},
	{#State 31
		DEFAULT => -12,
		GOTOS => {
			'PredicateStar' => 40
		}
	},
	{#State 32
		ACTIONS => {
			"(" => 41
		}
	},
	{#State 33
		DEFAULT => -29
	},
	{#State 34
		ACTIONS => {
			"(" => 42
		}
	},
	{#State 35
		DEFAULT => -3
	},
	{#State 36
		ACTIONS => {
			"//" => 38,
			"/" => 39
		},
		DEFAULT => -6
	},
	{#State 37
		DEFAULT => -14
	},
	{#State 38
		ACTIONS => {
			"preceding" => 2,
			".." => 1,
			"\@" => 4,
			"namespace" => 6,
			"following-sibling" => 7,
			"child" => 9,
			"ancestor" => 11,
			"self" => 12,
			"descendant-or-self" => 14,
			"preceding-sibling" => 15,
			"attribute" => 17,
			"following" => 18,
			"ancestor-or-self" => 19,
			"." => 26,
			"descendant" => 28,
			"parent" => 27
		},
		DEFAULT => -39,
		GOTOS => {
			'AbbreviatedStep' => 10,
			'Step' => 43,
			'AxisName' => 22,
			'AbbreviatedAxisSpecifier' => 23,
			'AxisSpecifier' => 16
		}
	},
	{#State 39
		ACTIONS => {
			"preceding" => 2,
			".." => 1,
			"\@" => 4,
			"namespace" => 6,
			"following-sibling" => 7,
			"child" => 9,
			"ancestor" => 11,
			"self" => 12,
			"descendant-or-self" => 14,
			"preceding-sibling" => 15,
			"attribute" => 17,
			"following" => 18,
			"ancestor-or-self" => 19,
			"." => 26,
			"descendant" => 28,
			"parent" => 27
		},
		DEFAULT => -39,
		GOTOS => {
			'AbbreviatedStep' => 10,
			'Step' => 44,
			'AxisName' => 22,
			'AbbreviatedAxisSpecifier' => 23,
			'AxisSpecifier' => 16
		}
	},
	{#State 40
		ACTIONS => {
			"[" => 45
		},
		DEFAULT => -10,
		GOTOS => {
			'Predicate' => 46
		}
	},
	{#State 41
		ACTIONS => {
			'Literal' => 47
		}
	},
	{#State 42
		ACTIONS => {
			'Literal' => 49,
			")" => 48
		}
	},
	{#State 43
		DEFAULT => -36
	},
	{#State 44
		DEFAULT => -8
	},
	{#State 45
		ACTIONS => {
			".." => 1,
			"preceding" => 2,
			"-" => 50,
			"\@" => 4,
			'FunctionName' => 62,
			"namespace" => 6,
			"following-sibling" => 7,
			"child" => 9,
			'Number' => 51,
			"ancestor" => 11,
			"self" => 12,
			"descendant-or-self" => 14,
			"//" => 13,
			"preceding-sibling" => 15,
			'VariableReference' => 55,
			"attribute" => 17,
			'Literal' => 68,
			"following" => 18,
			"ancestor-or-self" => 19,
			"/" => 20,
			"(" => 58,
			"." => 26,
			"descendant" => 28,
			"parent" => 27
		},
		DEFAULT => -39,
		GOTOS => {
			'Step' => 3,
			'PathExpr' => 60,
			'LocationPath' => 61,
			'UnionExpr' => 63,
			'AbsoluteLocationPath' => 8,
			'AbbreviatedStep' => 10,
			'OrExpr' => 65,
			'FunctionCall' => 64,
			'AdditiveExpr' => 52,
			'MultiplicativeExpr' => 53,
			'AndExpr' => 67,
			'RelationalExpr' => 66,
			'Expr' => 54,
			'UnaryExpr' => 56,
			'AxisSpecifier' => 16,
			'FilterExpr' => 57,
			'PrimaryExpr' => 69,
			'AbbreviatedAbsoluteLocationPath' => 21,
			'PredicateExpr' => 70,
			'AxisName' => 22,
			'AbbreviatedAxisSpecifier' => 23,
			'RelativeLocationPath' => 25,
			'EqualityExpr' => 59,
			'AbbreviatedRelativeLocationPath' => 24
		}
	},
	{#State 46
		DEFAULT => -13
	},
	{#State 47
		ACTIONS => {
			")" => 71
		}
	},
	{#State 48
		DEFAULT => -30
	},
	{#State 49
		ACTIONS => {
			")" => 72
		}
	},
	{#State 50
		ACTIONS => {
			".." => 1,
			"preceding" => 2,
			"-" => 50,
			"\@" => 4,
			'FunctionName' => 62,
			"namespace" => 6,
			"following-sibling" => 7,
			"child" => 9,
			'Number' => 51,
			"ancestor" => 11,
			"self" => 12,
			"descendant-or-self" => 14,
			"//" => 13,
			"preceding-sibling" => 15,
			'VariableReference' => 55,
			"attribute" => 17,
			'Literal' => 68,
			"following" => 18,
			"ancestor-or-self" => 19,
			"/" => 20,
			"(" => 58,
			"." => 26,
			"descendant" => 28,
			"parent" => 27
		},
		DEFAULT => -39,
		GOTOS => {
			'Step' => 3,
			'PathExpr' => 60,
			'LocationPath' => 61,
			'UnionExpr' => 63,
			'AbsoluteLocationPath' => 8,
			'AbbreviatedStep' => 10,
			'FunctionCall' => 64,
			'UnaryExpr' => 73,
			'AxisSpecifier' => 16,
			'FilterExpr' => 57,
			'PrimaryExpr' => 69,
			'AbbreviatedAbsoluteLocationPath' => 21,
			'AxisName' => 22,
			'AbbreviatedAxisSpecifier' => 23,
			'AbbreviatedRelativeLocationPath' => 24,
			'RelativeLocationPath' => 25
		}
	},
	{#State 51
		DEFAULT => -45
	},
	{#State 52
		ACTIONS => {
			"-" => 74,
			"+" => 75
		},
		DEFAULT => -68
	},
	{#State 53
		ACTIONS => {
			'MultiplyOperator' => 78,
			"mod" => 76,
			"div" => 77
		},
		DEFAULT => -73
	},
	{#State 54
		DEFAULT => -34
	},
	{#State 55
		DEFAULT => -42
	},
	{#State 56
		DEFAULT => -76
	},
	{#State 57
		ACTIONS => {
			"[" => 45,
			"//" => 79,
			"/" => 80
		},
		DEFAULT => -56,
		GOTOS => {
			'Predicate' => 81
		}
	},
	{#State 58
		ACTIONS => {
			".." => 1,
			"preceding" => 2,
			"-" => 50,
			"\@" => 4,
			'FunctionName' => 62,
			"namespace" => 6,
			"following-sibling" => 7,
			"child" => 9,
			'Number' => 51,
			"ancestor" => 11,
			"self" => 12,
			"descendant-or-self" => 14,
			"//" => 13,
			"preceding-sibling" => 15,
			'VariableReference' => 55,
			"attribute" => 17,
			'Literal' => 68,
			"following" => 18,
			"ancestor-or-self" => 19,
			"/" => 20,
			"(" => 58,
			"." => 26,
			"descendant" => 28,
			"parent" => 27
		},
		DEFAULT => -39,
		GOTOS => {
			'Step' => 3,
			'PathExpr' => 60,
			'LocationPath' => 61,
			'UnionExpr' => 63,
			'AbsoluteLocationPath' => 8,
			'AbbreviatedStep' => 10,
			'OrExpr' => 65,
			'FunctionCall' => 64,
			'AdditiveExpr' => 52,
			'MultiplicativeExpr' => 53,
			'AndExpr' => 67,
			'RelationalExpr' => 66,
			'Expr' => 82,
			'UnaryExpr' => 56,
			'AxisSpecifier' => 16,
			'FilterExpr' => 57,
			'PrimaryExpr' => 69,
			'AbbreviatedAbsoluteLocationPath' => 21,
			'AxisName' => 22,
			'AbbreviatedAxisSpecifier' => 23,
			'RelativeLocationPath' => 25,
			'EqualityExpr' => 59,
			'AbbreviatedRelativeLocationPath' => 24
		}
	},
	{#State 59
		ACTIONS => {
			"!=" => 83,
			"=" => 84
		},
		DEFAULT => -63
	},
	{#State 60
		DEFAULT => -53
	},
	{#State 61
		DEFAULT => -55
	},
	{#State 62
		ACTIONS => {
			"(" => 85
		}
	},
	{#State 63
		ACTIONS => {
			"|" => 86
		},
		DEFAULT => -80
	},
	{#State 64
		DEFAULT => -46
	},
	{#State 65
		ACTIONS => {
			"or" => 87
		},
		DEFAULT => -41
	},
	{#State 66
		ACTIONS => {
			"<" => 88,
			">=" => 89,
			"<=" => 90,
			">" => 91
		},
		DEFAULT => -65
	},
	{#State 67
		ACTIONS => {
			"and" => 92
		},
		DEFAULT => -61
	},
	{#State 68
		DEFAULT => -44
	},
	{#State 69
		DEFAULT => -59
	},
	{#State 70
		ACTIONS => {
			"]" => 93
		}
	},
	{#State 71
		DEFAULT => -32
	},
	{#State 72
		DEFAULT => -31
	},
	{#State 73
		DEFAULT => -81
	},
	{#State 74
		ACTIONS => {
			".." => 1,
			"preceding" => 2,
			"-" => 50,
			"\@" => 4,
			'FunctionName' => 62,
			"namespace" => 6,
			"following-sibling" => 7,
			"child" => 9,
			'Number' => 51,
			"ancestor" => 11,
			"self" => 12,
			"descendant-or-self" => 14,
			"//" => 13,
			"preceding-sibling" => 15,
			'VariableReference' => 55,
			"attribute" => 17,
			'Literal' => 68,
			"following" => 18,
			"ancestor-or-self" => 19,
			"/" => 20,
			"(" => 58,
			"." => 26,
			"descendant" => 28,
			"parent" => 27
		},
		DEFAULT => -39,
		GOTOS => {
			'Step' => 3,
			'PathExpr' => 60,
			'LocationPath' => 61,
			'UnionExpr' => 63,
			'AbsoluteLocationPath' => 8,
			'AbbreviatedStep' => 10,
			'FunctionCall' => 64,
			'MultiplicativeExpr' => 94,
			'UnaryExpr' => 56,
			'AxisSpecifier' => 16,
			'FilterExpr' => 57,
			'PrimaryExpr' => 69,
			'AbbreviatedAbsoluteLocationPath' => 21,
			'AxisName' => 22,
			'AbbreviatedAxisSpecifier' => 23,
			'RelativeLocationPath' => 25,
			'AbbreviatedRelativeLocationPath' => 24
		}
	},
	{#State 75
		ACTIONS => {
			".." => 1,
			"preceding" => 2,
			"-" => 50,
			"\@" => 4,
			'FunctionName' => 62,
			"namespace" => 6,
			"following-sibling" => 7,
			"child" => 9,
			'Number' => 51,
			"ancestor" => 11,
			"self" => 12,
			"descendant-or-self" => 14,
			"//" => 13,
			"preceding-sibling" => 15,
			'VariableReference' => 55,
			"attribute" => 17,
			'Literal' => 68,
			"following" => 18,
			"ancestor-or-self" => 19,
			"/" => 20,
			"(" => 58,
			"." => 26,
			"descendant" => 28,
			"parent" => 27
		},
		DEFAULT => -39,
		GOTOS => {
			'Step' => 3,
			'PathExpr' => 60,
			'LocationPath' => 61,
			'UnionExpr' => 63,
			'AbsoluteLocationPath' => 8,
			'AbbreviatedStep' => 10,
			'FunctionCall' => 64,
			'MultiplicativeExpr' => 95,
			'UnaryExpr' => 56,
			'AxisSpecifier' => 16,
			'FilterExpr' => 57,
			'PrimaryExpr' => 69,
			'AbbreviatedAbsoluteLocationPath' => 21,
			'AxisName' => 22,
			'AbbreviatedAxisSpecifier' => 23,
			'RelativeLocationPath' => 25,
			'AbbreviatedRelativeLocationPath' => 24
		}
	},
	{#State 76
		ACTIONS => {
			".." => 1,
			"preceding" => 2,
			"-" => 50,
			"\@" => 4,
			'FunctionName' => 62,
			"namespace" => 6,
			"following-sibling" => 7,
			"child" => 9,
			'Number' => 51,
			"ancestor" => 11,
			"self" => 12,
			"descendant-or-self" => 14,
			"//" => 13,
			"preceding-sibling" => 15,
			'VariableReference' => 55,
			"attribute" => 17,
			'Literal' => 68,
			"following" => 18,
			"ancestor-or-self" => 19,
			"/" => 20,
			"(" => 58,
			"." => 26,
			"descendant" => 28,
			"parent" => 27
		},
		DEFAULT => -39,
		GOTOS => {
			'Step' => 3,
			'PathExpr' => 60,
			'LocationPath' => 61,
			'UnionExpr' => 63,
			'AbsoluteLocationPath' => 8,
			'AbbreviatedStep' => 10,
			'FunctionCall' => 64,
			'UnaryExpr' => 96,
			'AxisSpecifier' => 16,
			'FilterExpr' => 57,
			'PrimaryExpr' => 69,
			'AbbreviatedAbsoluteLocationPath' => 21,
			'AxisName' => 22,
			'AbbreviatedAxisSpecifier' => 23,
			'AbbreviatedRelativeLocationPath' => 24,
			'RelativeLocationPath' => 25
		}
	},
	{#State 77
		ACTIONS => {
			".." => 1,
			"preceding" => 2,
			"-" => 50,
			"\@" => 4,
			'FunctionName' => 62,
			"namespace" => 6,
			"following-sibling" => 7,
			"child" => 9,
			'Number' => 51,
			"ancestor" => 11,
			"self" => 12,
			"descendant-or-self" => 14,
			"//" => 13,
			"preceding-sibling" => 15,
			'VariableReference' => 55,
			"attribute" => 17,
			'Literal' => 68,
			"following" => 18,
			"ancestor-or-self" => 19,
			"/" => 20,
			"(" => 58,
			"." => 26,
			"descendant" => 28,
			"parent" => 27
		},
		DEFAULT => -39,
		GOTOS => {
			'Step' => 3,
			'PathExpr' => 60,
			'LocationPath' => 61,
			'UnionExpr' => 63,
			'AbsoluteLocationPath' => 8,
			'AbbreviatedStep' => 10,
			'FunctionCall' => 64,
			'UnaryExpr' => 97,
			'AxisSpecifier' => 16,
			'FilterExpr' => 57,
			'PrimaryExpr' => 69,
			'AbbreviatedAbsoluteLocationPath' => 21,
			'AxisName' => 22,
			'AbbreviatedAxisSpecifier' => 23,
			'AbbreviatedRelativeLocationPath' => 24,
			'RelativeLocationPath' => 25
		}
	},
	{#State 78
		ACTIONS => {
			".." => 1,
			"preceding" => 2,
			"-" => 50,
			"\@" => 4,
			'FunctionName' => 62,
			"namespace" => 6,
			"following-sibling" => 7,
			"child" => 9,
			'Number' => 51,
			"ancestor" => 11,
			"self" => 12,
			"descendant-or-self" => 14,
			"//" => 13,
			"preceding-sibling" => 15,
			'VariableReference' => 55,
			"attribute" => 17,
			'Literal' => 68,
			"following" => 18,
			"ancestor-or-self" => 19,
			"/" => 20,
			"(" => 58,
			"." => 26,
			"descendant" => 28,
			"parent" => 27
		},
		DEFAULT => -39,
		GOTOS => {
			'Step' => 3,
			'PathExpr' => 60,
			'LocationPath' => 61,
			'UnionExpr' => 63,
			'AbsoluteLocationPath' => 8,
			'AbbreviatedStep' => 10,
			'FunctionCall' => 64,
			'UnaryExpr' => 98,
			'AxisSpecifier' => 16,
			'FilterExpr' => 57,
			'PrimaryExpr' => 69,
			'AbbreviatedAbsoluteLocationPath' => 21,
			'AxisName' => 22,
			'AbbreviatedAxisSpecifier' => 23,
			'AbbreviatedRelativeLocationPath' => 24,
			'RelativeLocationPath' => 25
		}
	},
	{#State 79
		ACTIONS => {
			".." => 1,
			"preceding" => 2,
			"\@" => 4,
			"namespace" => 6,
			"following-sibling" => 7,
			"child" => 9,
			"ancestor" => 11,
			"self" => 12,
			"descendant-or-self" => 14,
			"preceding-sibling" => 15,
			"attribute" => 17,
			"following" => 18,
			"ancestor-or-self" => 19,
			"." => 26,
			"parent" => 27,
			"descendant" => 28
		},
		DEFAULT => -39,
		GOTOS => {
			'AbbreviatedStep' => 10,
			'Step' => 3,
			'AxisName' => 22,
			'AbbreviatedAxisSpecifier' => 23,
			'AxisSpecifier' => 16,
			'RelativeLocationPath' => 99,
			'AbbreviatedRelativeLocationPath' => 24
		}
	},
	{#State 80
		ACTIONS => {
			".." => 1,
			"preceding" => 2,
			"\@" => 4,
			"namespace" => 6,
			"following-sibling" => 7,
			"child" => 9,
			"ancestor" => 11,
			"self" => 12,
			"descendant-or-self" => 14,
			"preceding-sibling" => 15,
			"attribute" => 17,
			"following" => 18,
			"ancestor-or-self" => 19,
			"." => 26,
			"parent" => 27,
			"descendant" => 28
		},
		DEFAULT => -39,
		GOTOS => {
			'AbbreviatedStep' => 10,
			'Step' => 3,
			'AxisName' => 22,
			'AbbreviatedAxisSpecifier' => 23,
			'AxisSpecifier' => 16,
			'RelativeLocationPath' => 100,
			'AbbreviatedRelativeLocationPath' => 24
		}
	},
	{#State 81
		DEFAULT => -60
	},
	{#State 82
		ACTIONS => {
			")" => 101
		}
	},
	{#State 83
		ACTIONS => {
			".." => 1,
			"preceding" => 2,
			"-" => 50,
			"\@" => 4,
			'FunctionName' => 62,
			"namespace" => 6,
			"following-sibling" => 7,
			"child" => 9,
			'Number' => 51,
			"ancestor" => 11,
			"self" => 12,
			"descendant-or-self" => 14,
			"//" => 13,
			"preceding-sibling" => 15,
			'VariableReference' => 55,
			"attribute" => 17,
			'Literal' => 68,
			"following" => 18,
			"ancestor-or-self" => 19,
			"/" => 20,
			"(" => 58,
			"." => 26,
			"descendant" => 28,
			"parent" => 27
		},
		DEFAULT => -39,
		GOTOS => {
			'Step' => 3,
			'PathExpr' => 60,
			'LocationPath' => 61,
			'UnionExpr' => 63,
			'AbsoluteLocationPath' => 8,
			'AbbreviatedStep' => 10,
			'FunctionCall' => 64,
			'AdditiveExpr' => 52,
			'MultiplicativeExpr' => 53,
			'RelationalExpr' => 102,
			'UnaryExpr' => 56,
			'AxisSpecifier' => 16,
			'FilterExpr' => 57,
			'PrimaryExpr' => 69,
			'AbbreviatedAbsoluteLocationPath' => 21,
			'AxisName' => 22,
			'AbbreviatedAxisSpecifier' => 23,
			'RelativeLocationPath' => 25,
			'AbbreviatedRelativeLocationPath' => 24
		}
	},
	{#State 84
		ACTIONS => {
			".." => 1,
			"preceding" => 2,
			"-" => 50,
			"\@" => 4,
			'FunctionName' => 62,
			"namespace" => 6,
			"following-sibling" => 7,
			"child" => 9,
			'Number' => 51,
			"ancestor" => 11,
			"self" => 12,
			"descendant-or-self" => 14,
			"//" => 13,
			"preceding-sibling" => 15,
			'VariableReference' => 55,
			"attribute" => 17,
			'Literal' => 68,
			"following" => 18,
			"ancestor-or-self" => 19,
			"/" => 20,
			"(" => 58,
			"." => 26,
			"descendant" => 28,
			"parent" => 27
		},
		DEFAULT => -39,
		GOTOS => {
			'Step' => 3,
			'PathExpr' => 60,
			'LocationPath' => 61,
			'UnionExpr' => 63,
			'AbsoluteLocationPath' => 8,
			'AbbreviatedStep' => 10,
			'FunctionCall' => 64,
			'AdditiveExpr' => 52,
			'MultiplicativeExpr' => 53,
			'RelationalExpr' => 103,
			'UnaryExpr' => 56,
			'AxisSpecifier' => 16,
			'FilterExpr' => 57,
			'PrimaryExpr' => 69,
			'AbbreviatedAbsoluteLocationPath' => 21,
			'AxisName' => 22,
			'AbbreviatedAxisSpecifier' => 23,
			'RelativeLocationPath' => 25,
			'AbbreviatedRelativeLocationPath' => 24
		}
	},
	{#State 85
		ACTIONS => {
			".." => 1,
			"preceding" => 2,
			"-" => 50,
			"\@" => 4,
			'FunctionName' => 62,
			"namespace" => 6,
			"following-sibling" => 7,
			"child" => 9,
			'Number' => 51,
			"ancestor" => 11,
			"self" => 12,
			")" => -48,
			"descendant-or-self" => 14,
			"//" => 13,
			"preceding-sibling" => 15,
			'VariableReference' => 55,
			"attribute" => 17,
			'Literal' => 68,
			"following" => 18,
			"ancestor-or-self" => 19,
			"/" => 20,
			"(" => 58,
			"." => 26,
			"descendant" => 28,
			"parent" => 27
		},
		DEFAULT => -39,
		GOTOS => {
			'Step' => 3,
			'PathExpr' => 60,
			'LocationPath' => 61,
			'UnionExpr' => 63,
			'AbsoluteLocationPath' => 8,
			'AbbreviatedStep' => 10,
			'OrExpr' => 65,
			'FunctionCall' => 64,
			'AdditiveExpr' => 52,
			'MultiplicativeExpr' => 53,
			'AndExpr' => 67,
			'RelationalExpr' => 66,
			'Expr' => 104,
			'ArgOpt' => 105,
			'UnaryExpr' => 56,
			'AxisSpecifier' => 16,
			'FilterExpr' => 57,
			'PrimaryExpr' => 69,
			'AbbreviatedAbsoluteLocationPath' => 21,
			'AxisName' => 22,
			'AbbreviatedAxisSpecifier' => 23,
			'Argument' => 106,
			'RelativeLocationPath' => 25,
			'EqualityExpr' => 59,
			'AbbreviatedRelativeLocationPath' => 24
		}
	},
	{#State 86
		ACTIONS => {
			".." => 1,
			"preceding" => 2,
			"\@" => 4,
			'FunctionName' => 62,
			"namespace" => 6,
			"following-sibling" => 7,
			"child" => 9,
			'Number' => 51,
			"ancestor" => 11,
			"self" => 12,
			"descendant-or-self" => 14,
			"//" => 13,
			"preceding-sibling" => 15,
			'VariableReference' => 55,
			"attribute" => 17,
			'Literal' => 68,
			"following" => 18,
			"ancestor-or-self" => 19,
			"/" => 20,
			"(" => 58,
			"." => 26,
			"descendant" => 28,
			"parent" => 27
		},
		DEFAULT => -39,
		GOTOS => {
			'Step' => 3,
			'AxisSpecifier' => 16,
			'PathExpr' => 107,
			'LocationPath' => 61,
			'FilterExpr' => 57,
			'PrimaryExpr' => 69,
			'AbbreviatedAbsoluteLocationPath' => 21,
			'AbsoluteLocationPath' => 8,
			'AbbreviatedStep' => 10,
			'AxisName' => 22,
			'AbbreviatedAxisSpecifier' => 23,
			'FunctionCall' => 64,
			'RelativeLocationPath' => 25,
			'AbbreviatedRelativeLocationPath' => 24
		}
	},
	{#State 87
		ACTIONS => {
			".." => 1,
			"preceding" => 2,
			"-" => 50,
			"\@" => 4,
			'FunctionName' => 62,
			"namespace" => 6,
			"following-sibling" => 7,
			"child" => 9,
			'Number' => 51,
			"ancestor" => 11,
			"self" => 12,
			"descendant-or-self" => 14,
			"//" => 13,
			"preceding-sibling" => 15,
			'VariableReference' => 55,
			"attribute" => 17,
			'Literal' => 68,
			"following" => 18,
			"ancestor-or-self" => 19,
			"/" => 20,
			"(" => 58,
			"." => 26,
			"descendant" => 28,
			"parent" => 27
		},
		DEFAULT => -39,
		GOTOS => {
			'Step' => 3,
			'PathExpr' => 60,
			'LocationPath' => 61,
			'UnionExpr' => 63,
			'AbsoluteLocationPath' => 8,
			'AbbreviatedStep' => 10,
			'FunctionCall' => 64,
			'AdditiveExpr' => 52,
			'MultiplicativeExpr' => 53,
			'AndExpr' => 108,
			'RelationalExpr' => 66,
			'UnaryExpr' => 56,
			'AxisSpecifier' => 16,
			'FilterExpr' => 57,
			'PrimaryExpr' => 69,
			'AbbreviatedAbsoluteLocationPath' => 21,
			'AxisName' => 22,
			'AbbreviatedAxisSpecifier' => 23,
			'RelativeLocationPath' => 25,
			'AbbreviatedRelativeLocationPath' => 24,
			'EqualityExpr' => 59
		}
	},
	{#State 88
		ACTIONS => {
			".." => 1,
			"preceding" => 2,
			"-" => 50,
			"\@" => 4,
			'FunctionName' => 62,
			"namespace" => 6,
			"following-sibling" => 7,
			"child" => 9,
			'Number' => 51,
			"ancestor" => 11,
			"self" => 12,
			"descendant-or-self" => 14,
			"//" => 13,
			"preceding-sibling" => 15,
			'VariableReference' => 55,
			"attribute" => 17,
			'Literal' => 68,
			"following" => 18,
			"ancestor-or-self" => 19,
			"/" => 20,
			"(" => 58,
			"." => 26,
			"descendant" => 28,
			"parent" => 27
		},
		DEFAULT => -39,
		GOTOS => {
			'Step' => 3,
			'PathExpr' => 60,
			'LocationPath' => 61,
			'UnionExpr' => 63,
			'AbsoluteLocationPath' => 8,
			'AbbreviatedStep' => 10,
			'FunctionCall' => 64,
			'AdditiveExpr' => 109,
			'MultiplicativeExpr' => 53,
			'UnaryExpr' => 56,
			'AxisSpecifier' => 16,
			'FilterExpr' => 57,
			'PrimaryExpr' => 69,
			'AbbreviatedAbsoluteLocationPath' => 21,
			'AxisName' => 22,
			'AbbreviatedAxisSpecifier' => 23,
			'RelativeLocationPath' => 25,
			'AbbreviatedRelativeLocationPath' => 24
		}
	},
	{#State 89
		ACTIONS => {
			".." => 1,
			"preceding" => 2,
			"-" => 50,
			"\@" => 4,
			'FunctionName' => 62,
			"namespace" => 6,
			"following-sibling" => 7,
			"child" => 9,
			'Number' => 51,
			"ancestor" => 11,
			"self" => 12,
			"descendant-or-self" => 14,
			"//" => 13,
			"preceding-sibling" => 15,
			'VariableReference' => 55,
			"attribute" => 17,
			'Literal' => 68,
			"following" => 18,
			"ancestor-or-self" => 19,
			"/" => 20,
			"(" => 58,
			"." => 26,
			"descendant" => 28,
			"parent" => 27
		},
		DEFAULT => -39,
		GOTOS => {
			'Step' => 3,
			'PathExpr' => 60,
			'LocationPath' => 61,
			'UnionExpr' => 63,
			'AbsoluteLocationPath' => 8,
			'AbbreviatedStep' => 10,
			'FunctionCall' => 64,
			'AdditiveExpr' => 110,
			'MultiplicativeExpr' => 53,
			'UnaryExpr' => 56,
			'AxisSpecifier' => 16,
			'FilterExpr' => 57,
			'PrimaryExpr' => 69,
			'AbbreviatedAbsoluteLocationPath' => 21,
			'AxisName' => 22,
			'AbbreviatedAxisSpecifier' => 23,
			'RelativeLocationPath' => 25,
			'AbbreviatedRelativeLocationPath' => 24
		}
	},
	{#State 90
		ACTIONS => {
			".." => 1,
			"preceding" => 2,
			"-" => 50,
			"\@" => 4,
			'FunctionName' => 62,
			"namespace" => 6,
			"following-sibling" => 7,
			"child" => 9,
			'Number' => 51,
			"ancestor" => 11,
			"self" => 12,
			"descendant-or-self" => 14,
			"//" => 13,
			"preceding-sibling" => 15,
			'VariableReference' => 55,
			"attribute" => 17,
			'Literal' => 68,
			"following" => 18,
			"ancestor-or-self" => 19,
			"/" => 20,
			"(" => 58,
			"." => 26,
			"descendant" => 28,
			"parent" => 27
		},
		DEFAULT => -39,
		GOTOS => {
			'Step' => 3,
			'PathExpr' => 60,
			'LocationPath' => 61,
			'UnionExpr' => 63,
			'AbsoluteLocationPath' => 8,
			'AbbreviatedStep' => 10,
			'FunctionCall' => 64,
			'AdditiveExpr' => 111,
			'MultiplicativeExpr' => 53,
			'UnaryExpr' => 56,
			'AxisSpecifier' => 16,
			'FilterExpr' => 57,
			'PrimaryExpr' => 69,
			'AbbreviatedAbsoluteLocationPath' => 21,
			'AxisName' => 22,
			'AbbreviatedAxisSpecifier' => 23,
			'RelativeLocationPath' => 25,
			'AbbreviatedRelativeLocationPath' => 24
		}
	},
	{#State 91
		ACTIONS => {
			".." => 1,
			"preceding" => 2,
			"-" => 50,
			"\@" => 4,
			'FunctionName' => 62,
			"namespace" => 6,
			"following-sibling" => 7,
			"child" => 9,
			'Number' => 51,
			"ancestor" => 11,
			"self" => 12,
			"descendant-or-self" => 14,
			"//" => 13,
			"preceding-sibling" => 15,
			'VariableReference' => 55,
			"attribute" => 17,
			'Literal' => 68,
			"following" => 18,
			"ancestor-or-self" => 19,
			"/" => 20,
			"(" => 58,
			"." => 26,
			"descendant" => 28,
			"parent" => 27
		},
		DEFAULT => -39,
		GOTOS => {
			'Step' => 3,
			'PathExpr' => 60,
			'LocationPath' => 61,
			'UnionExpr' => 63,
			'AbsoluteLocationPath' => 8,
			'AbbreviatedStep' => 10,
			'FunctionCall' => 64,
			'AdditiveExpr' => 112,
			'MultiplicativeExpr' => 53,
			'UnaryExpr' => 56,
			'AxisSpecifier' => 16,
			'FilterExpr' => 57,
			'PrimaryExpr' => 69,
			'AbbreviatedAbsoluteLocationPath' => 21,
			'AxisName' => 22,
			'AbbreviatedAxisSpecifier' => 23,
			'RelativeLocationPath' => 25,
			'AbbreviatedRelativeLocationPath' => 24
		}
	},
	{#State 92
		ACTIONS => {
			".." => 1,
			"preceding" => 2,
			"-" => 50,
			"\@" => 4,
			'FunctionName' => 62,
			"namespace" => 6,
			"following-sibling" => 7,
			"child" => 9,
			'Number' => 51,
			"ancestor" => 11,
			"self" => 12,
			"descendant-or-self" => 14,
			"//" => 13,
			"preceding-sibling" => 15,
			'VariableReference' => 55,
			"attribute" => 17,
			'Literal' => 68,
			"following" => 18,
			"ancestor-or-self" => 19,
			"/" => 20,
			"(" => 58,
			"." => 26,
			"descendant" => 28,
			"parent" => 27
		},
		DEFAULT => -39,
		GOTOS => {
			'Step' => 3,
			'PathExpr' => 60,
			'LocationPath' => 61,
			'UnionExpr' => 63,
			'AbsoluteLocationPath' => 8,
			'AbbreviatedStep' => 10,
			'FunctionCall' => 64,
			'AdditiveExpr' => 52,
			'MultiplicativeExpr' => 53,
			'RelationalExpr' => 66,
			'UnaryExpr' => 56,
			'AxisSpecifier' => 16,
			'FilterExpr' => 57,
			'PrimaryExpr' => 69,
			'AbbreviatedAbsoluteLocationPath' => 21,
			'AxisName' => 22,
			'AbbreviatedAxisSpecifier' => 23,
			'RelativeLocationPath' => 25,
			'EqualityExpr' => 113,
			'AbbreviatedRelativeLocationPath' => 24
		}
	},
	{#State 93
		DEFAULT => -33
	},
	{#State 94
		ACTIONS => {
			'MultiplyOperator' => 78,
			"mod" => 76,
			"div" => 77
		},
		DEFAULT => -75
	},
	{#State 95
		ACTIONS => {
			'MultiplyOperator' => 78,
			"mod" => 76,
			"div" => 77
		},
		DEFAULT => -74
	},
	{#State 96
		DEFAULT => -79
	},
	{#State 97
		DEFAULT => -78
	},
	{#State 98
		DEFAULT => -77
	},
	{#State 99
		ACTIONS => {
			"//" => 38,
			"/" => 39
		},
		DEFAULT => -58
	},
	{#State 100
		ACTIONS => {
			"//" => 38,
			"/" => 39
		},
		DEFAULT => -57
	},
	{#State 101
		DEFAULT => -43
	},
	{#State 102
		ACTIONS => {
			"<" => 88,
			">=" => 89,
			"<=" => 90,
			">" => 91
		},
		DEFAULT => -67
	},
	{#State 103
		ACTIONS => {
			"<" => 88,
			">=" => 89,
			"<=" => 90,
			">" => 91
		},
		DEFAULT => -66
	},
	{#State 104
		DEFAULT => -52
	},
	{#State 105
		ACTIONS => {
			")" => 114
		}
	},
	{#State 106
		DEFAULT => -50,
		GOTOS => {
			'MoreArgStar' => 115
		}
	},
	{#State 107
		DEFAULT => -54
	},
	{#State 108
		ACTIONS => {
			"and" => 92
		},
		DEFAULT => -62
	},
	{#State 109
		ACTIONS => {
			"-" => 74,
			"+" => 75
		},
		DEFAULT => -69
	},
	{#State 110
		ACTIONS => {
			"-" => 74,
			"+" => 75
		},
		DEFAULT => -72
	},
	{#State 111
		ACTIONS => {
			"-" => 74,
			"+" => 75
		},
		DEFAULT => -71
	},
	{#State 112
		ACTIONS => {
			"-" => 74,
			"+" => 75
		},
		DEFAULT => -70
	},
	{#State 113
		ACTIONS => {
			"!=" => 83,
			"=" => 84
		},
		DEFAULT => -64
	},
	{#State 114
		DEFAULT => -47
	},
	{#State 115
		ACTIONS => {
			"," => 116
		},
		DEFAULT => -49
	},
	{#State 116
		ACTIONS => {
			".." => 1,
			"preceding" => 2,
			"-" => 50,
			"\@" => 4,
			'FunctionName' => 62,
			"namespace" => 6,
			"following-sibling" => 7,
			"child" => 9,
			'Number' => 51,
			"ancestor" => 11,
			"self" => 12,
			"descendant-or-self" => 14,
			"//" => 13,
			"preceding-sibling" => 15,
			'VariableReference' => 55,
			"attribute" => 17,
			'Literal' => 68,
			"following" => 18,
			"ancestor-or-self" => 19,
			"/" => 20,
			"(" => 58,
			"." => 26,
			"descendant" => 28,
			"parent" => 27
		},
		DEFAULT => -39,
		GOTOS => {
			'Step' => 3,
			'PathExpr' => 60,
			'LocationPath' => 61,
			'UnionExpr' => 63,
			'AbsoluteLocationPath' => 8,
			'AbbreviatedStep' => 10,
			'OrExpr' => 65,
			'FunctionCall' => 64,
			'AdditiveExpr' => 52,
			'MultiplicativeExpr' => 53,
			'AndExpr' => 67,
			'RelationalExpr' => 66,
			'Expr' => 104,
			'UnaryExpr' => 56,
			'AxisSpecifier' => 16,
			'FilterExpr' => 57,
			'PrimaryExpr' => 69,
			'AbbreviatedAbsoluteLocationPath' => 21,
			'AxisName' => 22,
			'AbbreviatedAxisSpecifier' => 23,
			'Argument' => 117,
			'RelativeLocationPath' => 25,
			'EqualityExpr' => 59,
			'AbbreviatedRelativeLocationPath' => 24
		}
	},
	{#State 117
		DEFAULT => -51
	}
],
                                  yyrules  =>
[
	[#Rule 0
		 '$start', 2, undef
	],
	[#Rule 1
		 'LocationPath', 1, undef
	],
	[#Rule 2
		 'LocationPath', 1, undef
	],
	[#Rule 3
		 'AbsoluteLocationPath', 2,
sub
#line 43 "XPathParser.yp"
{   my ($self, undef, $pathOpt) = @_;
    new W3C::XML::XPathCompileTree::AbsoluteLocationPath($pathOpt, $self)
}
	],
	[#Rule 4
		 'AbsoluteLocationPath', 1, undef
	],
	[#Rule 5
		 'RelativeLocationPathOpt', 0, undef
	],
	[#Rule 6
		 'RelativeLocationPathOpt', 1, undef
	],
	[#Rule 7
		 'RelativeLocationPath', 1, undef
	],
	[#Rule 8
		 'RelativeLocationPath', 3,
sub
#line 53 "XPathParser.yp"
{   my ($self, $rel, undef, $step) = @_;
    new W3C::XML::XPathCompileTree::RelativeLocationPath($rel, $step, $self)
}
	],
	[#Rule 9
		 'RelativeLocationPath', 1, undef
	],
	[#Rule 10
		 'Step', 3,
sub
#line 59 "XPathParser.yp"
{   my ($self, $axis, $test, $predicates) = @_;
    new W3C::XML::XPathCompileTree::Step($axis, $test, $predicates, $self);
}
	],
	[#Rule 11
		 'Step', 1, undef
	],
	[#Rule 12
		 'PredicateStar', 0,
sub
#line 65 "XPathParser.yp"
{   []}
	],
	[#Rule 13
		 'PredicateStar', 2,
sub
#line 67 "XPathParser.yp"
{   my ($self, $list, $predicate) = @_;
    [@$list, $predicate];
}
	],
	[#Rule 14
		 'AxisSpecifier', 2,
sub
#line 72 "XPathParser.yp"
{   my ($self, $name, undef) = @_;
    W3C::XML::XPathCompileTree::AxisSpecifier::factory($name, $self);
}
	],
	[#Rule 15
		 'AxisSpecifier', 1, undef
	],
	[#Rule 16
		 'AxisName', 1, undef
	],
	[#Rule 17
		 'AxisName', 1, undef
	],
	[#Rule 18
		 'AxisName', 1, undef
	],
	[#Rule 19
		 'AxisName', 1, undef
	],
	[#Rule 20
		 'AxisName', 1, undef
	],
	[#Rule 21
		 'AxisName', 1, undef
	],
	[#Rule 22
		 'AxisName', 1, undef
	],
	[#Rule 23
		 'AxisName', 1, undef
	],
	[#Rule 24
		 'AxisName', 1, undef
	],
	[#Rule 25
		 'AxisName', 1, undef
	],
	[#Rule 26
		 'AxisName', 1, undef
	],
	[#Rule 27
		 'AxisName', 1, undef
	],
	[#Rule 28
		 'AxisName', 1, undef
	],
	[#Rule 29
		 'NodeTest', 1,
sub
#line 92 "XPathParser.yp"
{   my ($self, $name) = @_;
    new W3C::XML::XPathCompileTree::NameTest($name, $self);
}
	],
	[#Rule 30
		 'NodeTest', 3,
sub
#line 96 "XPathParser.yp"
{   my ($self, $type, undef, undef) = @_;
    new W3C::XML::XPathCompileTree::NodeType($type, undef, $self);
}
	],
	[#Rule 31
		 'NodeTest', 4,
sub
#line 101 "XPathParser.yp"
{   my ($self, $type, undef, $literal, undef) = @_;
    new W3C::XML::XPathCompileTree::NodeType($type, $literal, $self);
}
	],
	[#Rule 32
		 'NodeTest', 4,
sub
#line 105 "XPathParser.yp"
{   my ($self, undef, undef, $pi, undef) = @_;
    new W3C::XML::XPathCompileTree::PI($pi, $self);
}
	],
	[#Rule 33
		 'Predicate', 3,
sub
#line 110 "XPathParser.yp"
{   my ($self, undef, $expr, undef) = @_;
    $expr;
}
	],
	[#Rule 34
		 'PredicateExpr', 1, undef
	],
	[#Rule 35
		 'AbbreviatedAbsoluteLocationPath', 2,
sub
#line 117 "XPathParser.yp"
{   my ($self, undef, $path) = @_;
    my $axis = new W3C::XML::XPathCompileTree::DescendantOrSelfAxis($self);
    my $test = new W3C::XML::XPathCompileTree::NodeType('node', undef, $self);
    my $step = new W3C::XML::XPathCompileTree::Step($axis, $test, [], $self);
    my $full = new W3C::XML::XPathCompileTree::RelativeLocationPath($step, $path, $self);
    new W3C::XML::XPathCompileTree::AbsoluteLocationPath($full, $self);
}
	],
	[#Rule 36
		 'AbbreviatedRelativeLocationPath', 3,
sub
#line 126 "XPathParser.yp"
{   my ($self, $path, undef, $step) = @_;
    my $axis = new W3C::XML::XPathCompileTree::DescendantOrSelfAxis($self);
    my $test = new W3C::XML::XPathCompileTree::NodeType('node', undef, $self);
    my $descOrSelf = new W3C::XML::XPathCompileTree::Step($axis, $test, [], $self);
    my $descOrSelfStep = new W3C::XML::XPathCompileTree::RelativeLocationPath($descOrSelf, $step, $self);
    new W3C::XML::XPathCompileTree::RelativeLocationPath($path, $descOrSelfStep, $self);
}
	],
	[#Rule 37
		 'AbbreviatedStep', 1,
sub
#line 135 "XPathParser.yp"
{   my ($self) = @_;
    my $axis = new W3C::XML::XPathCompileTree::SelfAxis($self);
    my $test = new W3C::XML::XPathCompileTree::NodeType('node', undef, $self);
    new W3C::XML::XPathCompileTree::Step($axis, $test, [], $self);
}
	],
	[#Rule 38
		 'AbbreviatedStep', 1,
sub
#line 141 "XPathParser.yp"
{   my ($self) = @_;
    my $axis = new W3C::XML::XPathCompileTree::ParentAxis($self);
    my $test = new W3C::XML::XPathCompileTree::NodeType('node', undef, $self);
    new W3C::XML::XPathCompileTree::Step($axis, $test, [], $self);
}
	],
	[#Rule 39
		 'AbbreviatedAxisSpecifier', 0,
sub
#line 148 "XPathParser.yp"
{   my ($self) = @_;
    new W3C::XML::XPathCompileTree::ChildAxis($self);
}
	],
	[#Rule 40
		 'AbbreviatedAxisSpecifier', 1,
sub
#line 152 "XPathParser.yp"
{   my ($self) = @_;
    new W3C::XML::XPathCompileTree::AttributeAxis($self);
}
	],
	[#Rule 41
		 'Expr', 1, undef
	],
	[#Rule 42
		 'PrimaryExpr', 1,
sub
#line 159 "XPathParser.yp"
{   my ($self, $var) = @_;
    new W3C::XML::XPathCompileTree::VariableReference($var, $self);
}
	],
	[#Rule 43
		 'PrimaryExpr', 3,
sub
#line 163 "XPathParser.yp"
{   my ($self, undef, $expr, undef) = @_;
    $expr;
}
	],
	[#Rule 44
		 'PrimaryExpr', 1,
sub
#line 167 "XPathParser.yp"
{   my ($self, $literal) = @_;
    new W3C::XML::XPathCompileTree::Literal($literal, $self);
}
	],
	[#Rule 45
		 'PrimaryExpr', 1,
sub
#line 171 "XPathParser.yp"
{   my ($self, $number) = @_;
    new W3C::XML::XPathCompileTree::Number($number, $self);
}
	],
	[#Rule 46
		 'PrimaryExpr', 1, undef
	],
	[#Rule 47
		 'FunctionCall', 4,
sub
#line 177 "XPathParser.yp"
{   my ($self, $name, undef, $args, undef) = @_;
    new W3C::XML::XPathCompileTree::FunctionCall($name, $args, $self);
}
	],
	[#Rule 48
		 'ArgOpt', 0,
sub
#line 182 "XPathParser.yp"
{   []}
	],
	[#Rule 49
		 'ArgOpt', 2,
sub
#line 184 "XPathParser.yp"
{   my ($self, $arg, $list) = @_;
    [$arg, @$list];
}
	],
	[#Rule 50
		 'MoreArgStar', 0,
sub
#line 189 "XPathParser.yp"
{   []}
	],
	[#Rule 51
		 'MoreArgStar', 3,
sub
#line 191 "XPathParser.yp"
{   my ($self, $list, undef, $arg) = @_;
    [@$list, $arg];
}
	],
	[#Rule 52
		 'Argument', 1, undef
	],
	[#Rule 53
		 'UnionExpr', 1, undef
	],
	[#Rule 54
		 'UnionExpr', 3, undef
	],
	[#Rule 55
		 'PathExpr', 1, undef
	],
	[#Rule 56
		 'PathExpr', 1, undef
	],
	[#Rule 57
		 'PathExpr', 3, undef
	],
	[#Rule 58
		 'PathExpr', 3, undef
	],
	[#Rule 59
		 'FilterExpr', 1, undef
	],
	[#Rule 60
		 'FilterExpr', 2, undef
	],
	[#Rule 61
		 'OrExpr', 1, undef
	],
	[#Rule 62
		 'OrExpr', 3,
sub
#line 210 "XPathParser.yp"
{   my ($self, $l, undef, $r) = @_;
    my $full = new W3C::XML::XPathCompileTree::OrExpr($l, $r, $self);
}
	],
	[#Rule 63
		 'AndExpr', 1, undef
	],
	[#Rule 64
		 'AndExpr', 3,
sub
#line 216 "XPathParser.yp"
{   my ($self, $l, undef, $r) = @_;
    my $full = new W3C::XML::XPathCompileTree::AndExpr($l, $r, $self);
}
	],
	[#Rule 65
		 'EqualityExpr', 1, undef
	],
	[#Rule 66
		 'EqualityExpr', 3,
sub
#line 222 "XPathParser.yp"
{   my ($self, $l, undef, $r) = @_;
    my $full = new W3C::XML::XPathCompileTree::EqExpr($l, $r, $self);
}
	],
	[#Rule 67
		 'EqualityExpr', 3, undef
	],
	[#Rule 68
		 'RelationalExpr', 1, undef
	],
	[#Rule 69
		 'RelationalExpr', 3, undef
	],
	[#Rule 70
		 'RelationalExpr', 3, undef
	],
	[#Rule 71
		 'RelationalExpr', 3, undef
	],
	[#Rule 72
		 'RelationalExpr', 3, undef
	],
	[#Rule 73
		 'AdditiveExpr', 1, undef
	],
	[#Rule 74
		 'AdditiveExpr', 3, undef
	],
	[#Rule 75
		 'AdditiveExpr', 3, undef
	],
	[#Rule 76
		 'MultiplicativeExpr', 1, undef
	],
	[#Rule 77
		 'MultiplicativeExpr', 3, undef
	],
	[#Rule 78
		 'MultiplicativeExpr', 3, undef
	],
	[#Rule 79
		 'MultiplicativeExpr', 3, undef
	],
	[#Rule 80
		 'UnaryExpr', 1, undef
	],
	[#Rule 81
		 'UnaryExpr', 2, undef
	]
],
                                  @_);
    bless($self,$class);
}

#line 246 "XPathParser.yp"


#BEGIN {unshift@INC,('../..');}
use W3C::Util::Exception qw(&throw &catch);

sub _Error {
    my ($self) = @_;
    if (exists $self->YYData->{EXCEPTION}) {
	&throw($self->YYData->{EXCEPTION});
    }
    if (exists $self->YYData->{ERRMSG}) {
	&throw(new W3C::Util::YappDriver::GrammarException(-message => $self->YYData->{ERRMSG}, 
							   -location => $self->YYData->{LOCATION}));
        delete $self->YYData->{ERRMSG};
        return;
    }
    &throw(new W3C::Util::YappDriver::MesgYappContextException($self, -location => $self->YYData->{LOCATION}));
    my $trimmed = $self->YYData->{INPUT};
    $trimmed =~ s/[\r\n]*\Z//m;

    my ($token, $value, $expect, $data) = ($self->YYCurtok(), $self->YYCurval(), $self->YYExpect(), $self->YYData);
    my $tokenStr = defined $token && $token ne $value ? "$token " : '';
    my $valueStr = defined $value ? "'$value'" : 'EOF';
    my $dataStr = ref $data eq 'HASH' ? join ("\n", map {"$_: $data->{$_}"} keys %$data) : $data;
    $dataStr = substr($trimmed, $self->YYData->{my_LASTPOS}, 20);
    print "expected '$expect', got $tokenStr$valueStr at \"$dataStr\"\n";

    my $before = substr($trimmed, 0, $self->YYData->{my_LASTPOS}+1);
    $before =~ m/([^\r\n]*)\Z/m;
    my $column = length ($1) - 1;
    my $after = substr($trimmed, $self->YYData->{my_LASTPOS}+1);

    $after =~ m/([^\r\n]*)[\r\n]?(.*)/s;
    my ($line, $last) = ($1, $2);
    print "$before$line\n";
    print '=' x $column, "^\n";
    print "$last\n" if ($last);
    foreach my $entry (@{$self->{STACK}}) {
	print join (' | ', @$entry),"\n";
    }
}

use vars qw($NCName $Mode2Test $Mode3Test);
$NCName = '\w[\w\d\.\-]*';

sub _Lexer {
    my($self)=shift;

    if (defined $self->YYData->{INPUT} && pos $self->YYData->{INPUT} < length ($self->YYData->{INPUT})) {
    } else {
	if ($self->YYData->{my_DONE}) {
	    return ('', undef);
	}
	if (0) {
	if (!($self->YYData->{INPUT} = $self->nextChunk())) {
	    undef $self->YYData->{INPUT};
	    return ('', undef);
	}
	} else {
	my $pos = pos $self->YYData->{INPUT};
	my $chunk = $self->nextChunk();
	#print "\nchunk: $chunk\n";
	if (!$chunk) {
	    undef $self->YYData->{INPUT};
	    return ('', undef);
	}
	$self->YYData->{INPUT} .= $chunk;
	pos $self->YYData->{INPUT} = $pos;
	}
	#my $txt = $self->YYData->{INPUT};
	#print "\ntxt: $txt\n";
    }

    my ($token, $value) = ('', undef);
    while ($self->YYData->{INPUT} =~ m/\G\s*\#[^\n]*\n/gc) {}
    $self->YYData->{INPUT} =~ m/\G\s*/gc;
    $self->YYData->{my_LASTPOS} = pos $self->YYData->{INPUT};

# [[
# If there is a preceding token and the preceding token is not one of @, ::, (,
# [, , or an Operator, then a * must be recognized as a MultiplyOperator and an
# NCName must be recognized as an OperatorName.
# ]]
# Mode 0 -- normal
# Mode 1 -- follows @, ::, (, [, , or an Operator
    my $curState = $self->YYData->{STATE};

# [[
# If the character following an NCName (possibly after intervening
# ExprWhitespace) is (, then the token must be recognized as a NodeType or a
# FunctionName.
# ]]
# Test with 0-width look-ahead assertion.
    $Mode2Test = '(?=\s*\()';

# [[
# If the two characters following an NCName (possibly after intervening
# ExprWhitespace) are ::, then the token must be recognized as an AxisName.
# ]]
# Also test this with a 0-width look-ahead assertion.
    $Mode3Test = '(?=::)';

# Literal:   		'"' [^"]* '"'	
    if ($self->YYData->{INPUT} =~ m/\G\"((?:[^\\\"]|(?:\\[\"\'\\trn]))*)\"/gc) {
	my $str = &_unescapeString($1);
	($token, $value) = ('Literal', $str);
	$self->YYData->{STATE} = 0;
# Literal:   		"'" [^']* "'"	
    } elsif ($self->YYData->{INPUT} =~ m/\G\'((?:[^\\\']|(?:\\[\'\"\\trn]))*)\'/gc) {
	my $str = &_unescapeString($1);
	($token, $value) = ('Literal', $str);
	$self->YYData->{STATE} = 0;
# Number:		Digits '.' Digits
    } elsif ($self->YYData->{INPUT} =~ m/\G([0-9]+\.[0-9]+)/gc) {
	($token, $value) = ('Number',$1);
	$self->YYData->{STATE} = 0;
# Number:		Digits '.'
    } elsif ($self->YYData->{INPUT} =~ m/\G([0-9]+\.)/gc) {
	($token, $value) = ('Number',$1);
	$self->YYData->{STATE} = 0;
# Number:		'.' Digits	
    } elsif ($self->YYData->{INPUT} =~ m/\G(\.[0-9]+)/gc) {
	($token, $value) = ('Number',$1);
	$self->YYData->{STATE} = 0;
# Number:		Digits
    } elsif ($self->YYData->{INPUT} =~ m/\G([0-9]+)/gc) {
	($token, $value) = ('Number',$1);
	$self->YYData->{STATE} = 0;
# Operator:   		OperatorName	
# OperatorName:   	'and' | 'or' | 'mod' | 'div'	
    } elsif ($curState != 1 && $self->YYData->{INPUT} =~ m/\G(and|or|mod|div)/gc) {
	($token, $value) = ($1,$1);
	$self->YYData->{STATE} = 1;
# Operator:		| '/' | '//' | '|' | '+' | '-' | '=' | '!=' | '<' | '<=' | '>' | '>='	
    } elsif ($self->YYData->{INPUT} =~ m/\G(\/\/|\/|\||\+|\-|=|!=|<|<=|>|>=)/gc) {
	($token, $value) = ($1,$1);
	$self->YYData->{STATE} = 1;
# Operator:   		MultiplyOperator	
# MultiplyOperator:   	'*'	
    } elsif ($curState != 1 && $self->YYData->{INPUT} =~ m/\G(\*)/gc) {
	($token, $value) = ('MultiplyOperator',$1);
	$self->YYData->{STATE} = 1;
# NodeType:   		'comment' | 'text' | 'processing-instruction' | 'node'	
    } elsif ($self->YYData->{INPUT} =~ m/\G(comment|text|processing-instruction|node)$Mode2Test/gc) {
	($token, $value) = ('NodeType',$1);
	$self->YYData->{STATE} = 0;
# FunctionName:   	QName - NodeType 	
    } elsif ($self->YYData->{INPUT} =~ m/\G($NCName(?::$NCName)?$Mode2Test)$Mode2Test/gc) {
	($token, $value) = ('FunctionName' ,$1);
	$self->YYData->{STATE} = 0;
# AxisName:		'ancestor' | 'ancestor-or-self' | 'attribute' | 'child' | 'descendant' | 'descendant-or-self' | 'following' | 'following-sibling' | 'namespace' | 'parent' | 'preceding' | 'preceding-sibling' | 'self'
# Rule 2
    } elsif ($self->YYData->{INPUT} =~ m/\G(ancestor|ancestor-or-self|attribute|child|descendant|descendant-or-self|following|following-sibling|namespace|parent|preceding|preceding-sibling|self)$Mode2Test/gc) {
	($token, $value) = ('NodeType',$1);
	$self->YYData->{STATE} = 0;
# AxisName:		'ancestor' | 'ancestor-or-self' | 'attribute' | 'child' | 'descendant' | 'descendant-or-self' | 'following' | 'following-sibling' | 'namespace' | 'parent' | 'preceding' | 'preceding-sibling' | 'self'
# Rule 3
    } elsif ($self->YYData->{INPUT} =~ m/\G(ancestor|ancestor-or-self|attribute|child|descendant|descendant-or-self|following|following-sibling|namespace|parent|preceding|preceding-sibling|self)$Mode3Test/gc) {
	($token, $value) = ($1,$1);
	$self->YYData->{STATE} = 0;
# VariableReference:   	'$' QName	
    } elsif ($self->YYData->{INPUT} =~ m/\G(\$$NCName(?::$NCName)?)$Mode2Test/gc) {
	($token, $value) = ('FunctionName' ,$1);
	$self->YYData->{STATE} = 0;
# NameTest:   		'*'	
    } elsif ($self->YYData->{INPUT} =~ m/\G(\*)/gc) {
	($token, $value) = ('NameTest' ,$1);
	$self->YYData->{STATE} = 0;
# NameTest:		NCName ':' '*'	
    } elsif ($self->YYData->{INPUT} =~ m/\G($NCName(?::$NCName)?:\*)/gc) {
	($token, $value) = ('NameTest' ,$1);
	$self->YYData->{STATE} = 0;
# NameTest:		QName	
    } elsif ($self->YYData->{INPUT} =~ m/\G($NCName(?::$NCName)?)/gc) {
	($token, $value) = ('NameTest' ,$1);
	$self->YYData->{STATE} = 0;
# ExprToken	   ::=   	'(' | ')' | '[' | ']' | '.' | '..' | '@' | ',' | '::'
# Mode1
    } elsif ($self->YYData->{INPUT} =~ m/\G(\@|::|\(|\[|)/gc) {
	($token, $value) = ($1,$1);
	$self->YYData->{STATE} = 1;
# ExprToken	   ::=   	'(' | ')' | '[' | ']' | '.' | '..' | '@' | ',' | '::'
# Mode0
    } elsif ($self->YYData->{INPUT} =~ m/\G(\)|\]|\.\.|\.|,)/gc) {
	($token, $value) = ($1,$1);
	$self->YYData->{STATE} = 0;
    } elsif ($self->YYData->{INPUT} =~ m/\G(.)/gc) {
	($token, $value) = ($1,$1);
	$self->YYData->{STATE} = 0;
	die "default rule for \"$1\"\n";
    }
    my $pos = pos $self->YYData->{INPUT};
    #my $rest = substr($self->YYData->{INPUT}, $pos, 99999);
    #print "\n$pos,$token,$value,$curState,$rest\n";
    return ($token, $value);
}
sub _unescapeString {
    my ($str) = @_;
    $str =~ s/\\r/\r/g;
    $str =~ s/\\n/\n/g;
    $str =~ s/\\t/\t/g;
    $str =~ s/\\\"/\"/g;
    $str =~ s/\\\'/\'/g;
    $str =~ s/\\\\/\\/g;
    return $str;
}

# Provide (one) chunk of text to parse.
sub nextChunk {
    my ($self) = @_;
    #return shift (@{$self->YYData->{my_CHUNKS}});
    #return shift (@ARGV);
    return <STDIN>;
}

# Handy debugging wrapper for calling semantics actions.
sub _wrap {
    my ($self, $obj, $method, @args) = @_;
    my @ret;
    eval {
	@ret = $obj->$method(@args);
    }; if ($@) {if (my $ex = &catch('W3C::Util::CachedContextException')) {
	&throw($ex);;
    } elsif ($ex = &catch('W3C::Util::Exception')) {
	my $newEx = new W3C::Util::CachedContextException(-str => $self->YYData->{INPUT}, 
							  -pos => $self->YYData->{my_LASTPOS}+1, 
							  -errorMessage => $ex->toString);
	$newEx->assumeStackTrace($ex);
	&throw($newEx);
    } else {
	my $newEx = new W3C::Util::CachedContextException(-str => $self->YYData->{INPUT}, 
							  -pos => $self->YYData->{my_LASTPOS}+1, 
							  -errorMessage => "$obj->$method: $@");
	&throw($newEx);
    }}
    return wantarray ? @ret : $ret[-1];
}

package W3C::XML::XPathParser;
@W3C::XML::XPathParser::ISA = qw(W3C::XML::_XPathParser);
use W3C::Util::Exception;

sub new {
    my ($proto, @yappParms) = @_;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new(@yappParms);
    return $self;
}

sub nextChunk {
    my ($self) = @_;
    my $ret = $self->YYData->{XPATH_STRING};
    $self->YYData->{XPATH_STRING} = undef;
    return $ret;
}

sub _errorContext { # static
    my ($pXPointer) = @_;
    my $pos = pos $$pXPointer;
    my $len = length $$pXPointer;
    $len = 50 if ($len > 50);
    return (substr($$pXPointer, $pos, $len), $pos, $len);
}

# Read the contents of xpath-encoded parens
sub schemeData { # static
    my ($pXPointer) = @_;
    my $extracted = '';
    for (my $depth = 1; $depth;) {
	if ($$pXPointer !~ m/\G([^\^\(\)]*)([\^\(\)])/gcxs) {
	    my ($ctx, $pos, $len) = &_errorContext($$pXPointer);
	    &throw(new W3C::Util::Exception(-message => "string \"$ctx\" at $pos ended still needing $depth close parens"));
	}
	$extracted .= $1;
	my $delim = $2;
	if ($delim eq '^') {
	    if ($$pXPointer !~ m/\G(.)/gcxs) {
		my ($ctx, $pos, $len) = &_errorContext($$pXPointer);
		&throw(new W3C::Util::Exception(-message => "string \"$ctx\" at $pos ended after an escape char (^)"));
	    }
	    $extracted .= $1;
	} elsif ($delim eq '(') {
	    $extracted .= '(';
	    $depth++;
	} elsif ($delim eq ')') {
	    if (--$depth) {
		$extracted .= ')';
	    }
	}
    }
    return $extracted;
}

# Read ','-separated parameters, handy for most xpointer schemes
sub delimitedSchemeData { # static
    my ($pXPointer, $delim) = @_;
    my @params;
    my $extracted = '';
    for (my $depth = 1; $depth;) {
	if ($$pXPointer !~ m/\G([^\^\(\)\Q$delim\E]*)([\^\(\)\Q$delim\E])/gcxs) {
	    my ($ctx, $pos, $len) = &_errorContext($pXPointer);
	    &throw(new W3C::Util::Exception(-message => "string \"$ctx\" at $pos ended still needing $depth close parens"));
	}
	$extracted .= $1;
	my $delim = $2;
	if ($delim eq '^') {
	    if ($$pXPointer !~ m/\G(.)/gcxs) {
		my ($ctx, $pos, $len) = &_errorContext($pXPointer);
		&throw(new W3C::Util::Exception(-message => "string \"$ctx\" at $pos ended after an escape char (^)"));
	    }
	    $extracted .= $1;
	} elsif ($delim eq '(') {
	    $extracted .= '(';
	    $depth++;
	} elsif ($delim eq ')') {
	    if (--$depth) {
		$extracted .= ')';
	    }
	} elsif ($delim eq $delim) {
	    if ($depth == 1) {
		$extracted =~ s/\s*$//;
		push (@params, $extracted);
		$extracted = '';
		$$pXPointer =~ m/\G\s*/gcxs;
	    } else {
		$extracted .= $delim;
	    }
	}
    }
    $extracted =~ s/\s*$//;
    push (@params, $extracted);
    $extracted = '';
    $$pXPointer =~ m/\G\s*/gcxs;
    my $trailingSlash = $$pXPointer =~ m/\G\//gcxs;
    return ($trailingSlash, @params);
}

sub _xpointer {
    my ($self, $nodeSet, $xpointer) = @_;
    my $startNodeSet = $nodeSet; # for range-to's cheeeezy semantics
    while (pos $xpointer < length $xpointer) {
	my $ret = new W3C::XML::XPathCompileTree::NodeSet();
	if ($xpointer =~ m/\G(string-range|id|range-to|(?:start|end)-point)\(/gcxs) {
	    my $cmd = $1;
	    my $args = {'string-range' => 4, 'range-to' => 1, 'id' => 1, 'start-point' => 4, 'end-point' => 4};
	    my ($slash, @args) = &delimitedSchemeData(\$xpointer, ',', $args->{$cmd});
	    if ($cmd eq 'string-range') {
		my ($subPointer, $matchSomething, $start, $length) = @args;
		my $workingNodes = $self->_xpointer($nodeSet, $subPointer);
		foreach my $vessel ($workingNodes->getNodes()) {
		    my $doc = $vessel->getNodeType() == $vessel->DOCUMENT_NODE ? $vessel : $vessel->getOwnerDocument();
		    # Hunt through the child nodes 'till we meet our range need.
		    my $range = undef;
		    for (my $oldData = $vessel->getFirstChild; !$range && $oldData; $oldData = $oldData->getNextSibling) {
			eval {
			    $range = $doc->createRangeNode($oldData->getData(), $start, $start+$length, $vessel);
			    $ret->addNodes($range);
			};
			if (!$range) {
			    eval {
				$start -= length($self->__cullText($oldData, $start));
			    };
			}
		    }
		    if (!$range) {
			&throw(new W3C::Util::Exception(-message => "didn't resolve test range in \"$xpointer\""));
		    }
		}
	    } elsif ($cmd eq 'range-to') {
		my ($subPointer) = @args;
		my $workingNodes = $self->_xpointer($startNodeSet, $subPointer);
		foreach my $start ($nodeSet->getNodes()) {
		    foreach my $end ($workingNodes->getNodes()) {
			my $doc = $end->getNodeType() == $end->DOCUMENT_NODE ? $end : $end->getOwnerDocument();
			my ($from, $to) = ($start->documentOrderSort($end) < 0) ? ($start, $end) : ($end, $start);
			$ret->addNodes($from);
			if ($to != $from) {
			    # Add all the intervening ancestors.
			    my ($l, $r) = $from->deviatingAncestors($to);
			    if ($l) {
				for ($l = $l->getNextSibling(); $l != $r; $l = $l->getNextSibling()) {
				    $ret->addNodes($l);
				}
			    }
			    $ret->addNodes($to);
			}
		    }
		}
	    } elsif ($cmd eq 'id') {
		my ($name) = @args;
		if ($name !~ m/\G\"([\w\d]+)\"/gcxs && 
		    $name !~ m/\G\'([\w\d]+)\'/gcxs) {
		    my ($ctx, $pos, $len) = &_errorContext(\$xpointer);
		    $pos -= length ($name);
		    &throw(new W3C::Util::Exception(-message => "string \"$name$ctx\" at $pos is not a valid id() parameter"));
		}
		$name = $1;
		my $compileTree = $self->compile("//*[\@id='$name' or \@name='$name']");
		$ret = $compileTree->test($nodeSet);
	    } elsif ($cmd eq 'start-point' || 
		     $cmd eq 'end-point') {
		my $isStart = $cmd eq 'start-point';
		my ($subPointer, $matchSomething, $start, $length) = @args;
		if (my @all = $self->_xpointer($nodeSet, $subPointer)->getNodes()) {
		    my $node = $isStart ? $all[0] : $all[-1];
		    if ($node->isa('W3C::DOM::Range999')) {
			$ret->addNodes($node->getParentNode());
		    } elsif ($node->isa('W3C::XML::XPathCompileTree::RangeNode')) {
			$ret->addNodes($isStart ? $node->getL() : $node->getR());
		    } else {
			$ret->addNodes($node);
		    }
		}
	    }
	} else {
	    $xpointer =~ m/\G(.*)\Z/gcxs;
	    # Might fail -- might not be an xpath, but how are we supposed to know?
	    my $compileTree = $self->compile($1);
	    $ret = $compileTree->test($nodeSet);
	}
	$nodeSet = $ret;
    }
    return $nodeSet;
}

sub __cullText {
    my ($self, $node, $length) = @_;
    my $ret = '';

    if ($node->getNodeType() == $node->TEXT_NODE) {
	my $data = $node->getData();
	$data =~ s/\s+/ /g;
	if ($data =~ m/^\s*$/) {
	    if ($ret =~ m/\s$/) {
	    } elsif ($ret =~ m/^$/) {
	    } else {
		$ret .= ' ';
		$length--;
	    }
	} else {
	    if (length($data) > $length) {
		$data = substr($data, 0, $length);
	    }
	    $ret .= $data;
	    $length -= length($data);
	}
    } elsif ($node->getNodeType() == $node->ELEMENT_NODE && 
	     $node->getTagName() ne 'head') {
	for (my $child = $node->getFirstChild();
	     $child && $length > 0; 
	     $child = $child->getNextSibling()) {
	    my $data = $self->__cullText($child, $length);
	    $ret .= $data;
	    $length -= length($data);
	}
    }

    return $ret;
}

sub compile {
    my ($self, $xpathString, @args) = @_;
    $self->YYData->{STATE} = 0;
    $self->YYData->{INPUT} = undef;
    $self->YYData->{XPATH_STRING} = $xpathString;
    return $self->SUPER::parse(@args);
}

sub match {
    my ($self, $start, $xpathString, @args) = @_;
#    return $self->getMatchingNodeSet($start, $xpathString, @args)->getNodes();
#}
#sub getMatchingNodeSet {
#    my ($self, $start, $xpathString, @args) = @_;
    my $compileTree = $self->compile($xpathString, @args);
    my $nodeSet = new W3C::XML::XPathCompileTree::NodeSet($start);
    return $compileTree->test($nodeSet)->getNodes();
}

sub create {
    my ($self, $start, $xpathString, $before, @args) = @_;
    my $compileTree = $self->compile($xpathString, @args);
    return ($compileTree->create($start, $before))[0];
}

sub xpointer {
    my ($self, $doc, $xpointer) = @_;
    return $self->_xpointer(new W3C::XML::XPathCompileTree::NodeSet($doc), $xpointer)->getNodes();
}

sub main::normalize {
    foreach my $arg (@ARGV) {
	my $xpath = new W3C::XML::XPathParser();
	my $compileTree = $xpath->compile($arg);
	print "$arg => ",$compileTree->toString(),"\n";
    }
}

1;

__END__

=head1 NAME

W3C::XML::XPathParser - parse the XPath language

=head1 SYNOPSIS

    use XML::DOM;
    use W3C::XML::XPathParser;
    use W3C::Util::Exception;
    my $xpath = new W3C::XML::XPathParser();
    my $parser = new XML::DOM::Parser();
    my $doc = $parser->parsefile('test/test1.xhtml');
    my @ret = $xpath->match($doc, '//*[@id=\'name\' or @name=\'name\']');
    print join(' | ', map {$_->toString()} @ret),"\n";

Or, if you want to execute the xpath multiple times, you can compile the xpath
string and use it multiple times:

    use XML::DOM;
    use W3C::XML::XPathParser;
    use W3C::Util::Exception;
    my $xpath = new W3C::XML::XPathParser();
    my $compileTree = $self->compile($xpathString, @args);
    my $parser = new XML::DOM::Parser();

    my $doc1 = $parser->parsefile('test/test1.xhtml');
    my $nodeSet1 = new W3C::XML::XPathCompileTree::NodeSet($doc1);
    my $res1 = $compileTree->test($nodeSet1);

    my $doc2 = $parser->parsefile('test/test2.xhtml');
    my $nodeSet2 = new W3C::XML::XPathCompileTree::NodeSet($doc2);
    my $res2 = $compileTree->test($nodeSet2);

=head1 DESCRIPTION

XPathParser executes XPath node selections on a DOM. The result of execution is
an array of 0 or more DOM nodes.

=head1 NORMALIZE

XPathParser can convert abbreviated XPaths to the unabbreviated form. This is
handy as when learning XPath.

perl -MXPathParser -e normalize "//*[@id='name' or @name='name']"
//*[@id='name' or @name='name'] => 
  /descendant-or-self::node()/child::*[attribute::id="name" or attribute::name="name"]

-head1 EXTENSION

The XPathParser module binds a yapp grammar to semantic actions that build an
XPathCompileTree. In general, client applicatiosn have no direct interaction
with XPathParser. Devlopers wishing to extend the XPath2 query language
  http://www.w3.org/xpath/

will need the perl yapp modules. The Makefile included with the W3C::XML CPAN
module has a target to re-compile the XPathParser grammar. Invoke this with
  make XPathParser.pm
It is likely that someone extending the XPathParser grammar will also want to
extend XPathCompileTree.

This module is part of the W3C::XML CPAN module.

=head1 AUTHOR

Eric Prud\'hommeaux <eric@w3.org>

=head1 SEE ALSO

W3C::XML::XPath2(3) W3C::XML::XPathCompileTree(3) perl(1).

=cut

1;
