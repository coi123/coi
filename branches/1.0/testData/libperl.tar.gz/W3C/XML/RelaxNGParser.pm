#!/usr/bin/perl
####################################################################
#
#    This file was generated using Parse::Yapp version 1.05.
#
#        Don't edit this file, use source file instead.
#
#             ANY CHANGE MADE HERE WILL BE LOST !
#
####################################################################
package W3C::XML::_RelaxNGParser;
use vars qw ( @ISA );
use strict;

@ISA= qw ( Parse::Yapp::Driver );
# use Parse::Yapp::Driver; @@ replaced by W3C::Util::YappDriver

#line 11 "RelaxNGParser.yp"

    use strict;
    use W3C::Util::YappDriver;
    use W3C::XML::SchemaValidatorDataTypes qw($TYPE_prefix $TYPE_follow $NS_default);
    use vars qw($DTN_string $DTN_token $DTN_anyName $NAME_namespace);
    ($DTN_string, $DTN_token, $DTN_anyName, $NAME_namespace) = (\ 'DTN_string', \ 'DTN_token', \ 'DTN_anyName', \ 'NAME_namespace');


sub new {
        my($class)=shift;
        ref($class)
    and $class=ref($class);

    my($self)=$class->SUPER::new( yyversion => '1.05',
                                  yystates =>
[
	{#State 0
		ACTIONS => {
			"namespace" => 6,
			"datatypes" => 2,
			"default" => 5
		},
		DEFAULT => -5,
		GOTOS => {
			'decl' => 1,
			'topLevel' => 4,
			'declStar' => 3
		}
	},
	{#State 1
		ACTIONS => {
			"namespace" => 6,
			"datatypes" => 2,
			"default" => 5
		},
		DEFAULT => -5,
		GOTOS => {
			'decl' => 1,
			'declStar' => 7
		}
	},
	{#State 2
		ACTIONS => {
			"string" => 9,
			"external" => 12,
			"namespace" => 11,
			"empty" => 14,
			"mixed" => 13,
			"grammar" => 16,
			'NCName' => 17,
			"start" => 18,
			"include" => 19,
			"notAllowed" => 20,
			"div" => 21,
			"attribute" => 22,
			"text" => 24,
			"inherit" => 25,
			"element" => 26,
			"token" => 27,
			"list" => 28,
			"datatypes" => 29,
			"default" => 30,
			"\\" => 31,
			"parent" => 32
		},
		GOTOS => {
			'keyword' => 8,
			'quotedIdentifier' => 10,
			'namespaceName' => 23,
			'nameIdentifier' => 15
		}
	},
	{#State 3
		ACTIONS => {
			"string" => 37,
			"external" => 54,
			"empty" => 55,
			"mixed" => 38,
			"grammar" => 39,
			'NCName' => 56,
			"start" => 41,
			"[" => 42,
			"include" => 43,
			"notAllowed" => 44,
			"div" => 45,
			"attribute" => 58,
			"text" => 47,
			"element" => 48,
			"token" => 49,
			"(" => 50,
			"list" => 62,
			'LITERAL_SEGMENT' => -70,
			"\\" => 31,
			"parent" => 52
		},
		DEFAULT => -41,
		GOTOS => {
			'gramCtntStar' => 35,
			'commaPatternPlus' => 34,
			'pipePatternPlus' => 33,
			'datatypeName' => 53,
			'CName' => 46,
			'gramCtnt' => 59,
			'quotedIdentifier' => 36,
			'define' => 60,
			'patORgramCtntStar' => 57,
			'pattern' => 61,
			'identifier' => 40,
			'datatypeNameOpt' => 63,
			'ampPatternPlus' => 64,
			'start' => 51
		}
	},
	{#State 4
		ACTIONS => {
			'' => 65
		}
	},
	{#State 5
		ACTIONS => {
			"namespace" => 66
		}
	},
	{#State 6
		ACTIONS => {
			"string" => 9,
			"external" => 12,
			"namespace" => 11,
			"empty" => 14,
			"mixed" => 13,
			"grammar" => 16,
			'NCName' => 17,
			"start" => 18,
			"include" => 19,
			"notAllowed" => 20,
			"div" => 21,
			"attribute" => 22,
			"text" => 24,
			"inherit" => 25,
			"element" => 26,
			"token" => 27,
			"list" => 28,
			"datatypes" => 29,
			"default" => 30,
			"\\" => 31,
			"parent" => 32
		},
		GOTOS => {
			'keyword' => 8,
			'quotedIdentifier' => 10,
			'namespaceName' => 67,
			'nameIdentifier' => 15
		}
	},
	{#State 7
		DEFAULT => -6
	},
	{#State 8
		DEFAULT => -87
	},
	{#State 9
		DEFAULT => -115
	},
	{#State 10
		DEFAULT => -89
	},
	{#State 11
		DEFAULT => -111
	},
	{#State 12
		DEFAULT => -105
	},
	{#State 13
		DEFAULT => -110
	},
	{#State 14
		DEFAULT => -104
	},
	{#State 15
		DEFAULT => -86
	},
	{#State 16
		DEFAULT => -106
	},
	{#State 17
		DEFAULT => -88
	},
	{#State 18
		DEFAULT => -114
	},
	{#State 19
		DEFAULT => -107
	},
	{#State 20
		DEFAULT => -112
	},
	{#State 21
		DEFAULT => -102
	},
	{#State 22
		DEFAULT => -99
	},
	{#State 23
		ACTIONS => {
			"=" => 68
		}
	},
	{#State 24
		DEFAULT => -116
	},
	{#State 25
		DEFAULT => -108
	},
	{#State 26
		DEFAULT => -103
	},
	{#State 27
		DEFAULT => -117
	},
	{#State 28
		DEFAULT => -109
	},
	{#State 29
		DEFAULT => -101
	},
	{#State 30
		DEFAULT => -100
	},
	{#State 31
		ACTIONS => {
			'NCName' => 69
		}
	},
	{#State 32
		DEFAULT => -113
	},
	{#State 33
		DEFAULT => -17
	},
	{#State 34
		DEFAULT => -15
	},
	{#State 35
		DEFAULT => -4
	},
	{#State 36
		DEFAULT => -91
	},
	{#State 37
		DEFAULT => -73
	},
	{#State 38
		ACTIONS => {
			"{" => 70
		}
	},
	{#State 39
		ACTIONS => {
			"{" => 71
		}
	},
	{#State 40
		ACTIONS => {
			"=" => 75,
			"|=" => 73,
			"&=" => 74
		},
		DEFAULT => -23,
		GOTOS => {
			'assignMethod' => 72
		}
	},
	{#State 41
		ACTIONS => {
			"|=" => 73,
			"&=" => 74,
			"=" => 75
		},
		GOTOS => {
			'assignMethod' => 76
		}
	},
	{#State 42
		ACTIONS => {
			"string" => 9,
			"external" => 12,
			"namespace" => 11,
			"empty" => 14,
			"mixed" => 13,
			"grammar" => 16,
			'NCName' => 56,
			"start" => 18,
			"include" => 19,
			"notAllowed" => 20,
			"div" => 21,
			"attribute" => 22,
			"text" => 24,
			"inherit" => 25,
			"element" => 26,
			"token" => 27,
			"list" => 28,
			"datatypes" => 29,
			"default" => 30,
			"\\" => 31,
			"parent" => 32
		},
		GOTOS => {
			'anoAttribStar' => 82,
			'keyword' => 81,
			'identifier' => 77,
			'CName' => 79,
			'idOrKey' => 78,
			'quotedIdentifier' => 36,
			'name' => 80
		}
	},
	{#State 43
		ACTIONS => {
			'LITERAL_SEGMENT' => 84
		},
		GOTOS => {
			'anyURILiteral' => 86,
			'literal' => 83,
			'literalSegmentPlus' => 85
		}
	},
	{#State 44
		DEFAULT => -29
	},
	{#State 45
		ACTIONS => {
			"{" => 87
		}
	},
	{#State 46
		DEFAULT => -72
	},
	{#State 47
		DEFAULT => -26
	},
	{#State 48
		ACTIONS => {
			"[" => 89
		},
		DEFAULT => -118,
		GOTOS => {
			'anoOpt' => 88
		}
	},
	{#State 49
		DEFAULT => -74
	},
	{#State 50
		ACTIONS => {
			"[" => 89
		},
		DEFAULT => -118,
		GOTOS => {
			'anoOpt' => 90
		}
	},
	{#State 51
		DEFAULT => -44
	},
	{#State 52
		ACTIONS => {
			"\\" => 31,
			'NCName' => 92
		},
		GOTOS => {
			'identifier' => 91,
			'quotedIdentifier' => 36
		}
	},
	{#State 53
		ACTIONS => {
			"{" => 93,
			'LITERAL_SEGMENT' => -71
		},
		DEFAULT => -33,
		GOTOS => {
			'paramOptSec' => 94
		}
	},
	{#State 54
		ACTIONS => {
			'LITERAL_SEGMENT' => 84
		},
		GOTOS => {
			'anyURILiteral' => 95,
			'literal' => 83,
			'literalSegmentPlus' => 85
		}
	},
	{#State 55
		DEFAULT => -25
	},
	{#State 56
		ACTIONS => {
			":" => 96
		},
		DEFAULT => -90
	},
	{#State 57
		DEFAULT => -1
	},
	{#State 58
		ACTIONS => {
			"[" => 89
		},
		DEFAULT => -118,
		GOTOS => {
			'anoOpt' => 97
		}
	},
	{#State 59
		ACTIONS => {
			">" => 99
		},
		DEFAULT => -127,
		GOTOS => {
			'followAnoStar' => 100,
			'followAnnotation' => 98
		}
	},
	{#State 60
		DEFAULT => -45
	},
	{#State 61
		ACTIONS => {
			"?" => 105,
			"+" => 103,
			"&" => 106,
			"," => 104,
			"|" => 102,
			"*" => 101
		},
		DEFAULT => -2
	},
	{#State 62
		ACTIONS => {
			"{" => 107
		}
	},
	{#State 63
		ACTIONS => {
			'LITERAL_SEGMENT' => 84
		},
		GOTOS => {
			'literal' => 108,
			'datatypeValue' => 109,
			'literalSegmentPlus' => 85
		}
	},
	{#State 64
		DEFAULT => -16
	},
	{#State 65
		DEFAULT => 0
	},
	{#State 66
		ACTIONS => {
			"string" => 9,
			"external" => 12,
			"namespace" => 11,
			"empty" => 14,
			"mixed" => 13,
			"grammar" => 16,
			'NCName' => 92,
			"start" => 18,
			"include" => 19,
			"notAllowed" => 20,
			"div" => 21,
			"attribute" => 22,
			"text" => 24,
			"inherit" => 25,
			"element" => 26,
			"token" => 27,
			"list" => 28,
			"datatypes" => 29,
			"default" => 30,
			"\\" => 31,
			"parent" => 32
		},
		DEFAULT => -82,
		GOTOS => {
			'keyword' => 81,
			'identifier' => 77,
			'idOrKey' => 110,
			'quotedIdentifier' => 36,
			'idOrKeyOpt' => 111
		}
	},
	{#State 67
		ACTIONS => {
			"=" => 112
		}
	},
	{#State 68
		ACTIONS => {
			'LITERAL_SEGMENT' => 84
		},
		GOTOS => {
			'literal' => 113,
			'literalSegmentPlus' => 85
		}
	},
	{#State 69
		DEFAULT => -92
	},
	{#State 70
		ACTIONS => {
			"[" => 89
		},
		DEFAULT => -118,
		GOTOS => {
			'anoOpt' => 114
		}
	},
	{#State 71
		ACTIONS => {
			"div" => 45,
			'NCName' => 92,
			"start" => 41,
			"[" => 117,
			"\\" => 31,
			"include" => 43
		},
		DEFAULT => -41,
		GOTOS => {
			'gramCtntStar' => 115,
			'identifier' => 116,
			'gramCtnt' => 59,
			'quotedIdentifier' => 36,
			'define' => 60,
			'start' => 51
		}
	},
	{#State 72
		ACTIONS => {
			"[" => 89
		},
		DEFAULT => -118,
		GOTOS => {
			'anoOpt' => 118
		}
	},
	{#State 73
		DEFAULT => -58
	},
	{#State 74
		DEFAULT => -59
	},
	{#State 75
		DEFAULT => -57
	},
	{#State 76
		ACTIONS => {
			"[" => 89
		},
		DEFAULT => -118,
		GOTOS => {
			'anoOpt' => 119
		}
	},
	{#State 77
		DEFAULT => -84
	},
	{#State 78
		DEFAULT => -65
	},
	{#State 79
		DEFAULT => -66
	},
	{#State 80
		ACTIONS => {
			"=" => 120
		}
	},
	{#State 81
		DEFAULT => -85
	},
	{#State 82
		ACTIONS => {
			"string" => 9,
			"external" => 12,
			"namespace" => 11,
			"empty" => 14,
			"mixed" => 13,
			"grammar" => 16,
			'NCName' => 56,
			"start" => 18,
			"include" => 19,
			"notAllowed" => 20,
			"div" => 21,
			"attribute" => 22,
			"text" => 24,
			"inherit" => 25,
			"element" => 26,
			"token" => 27,
			"list" => 28,
			"datatypes" => 29,
			"default" => 30,
			"\\" => 31,
			"parent" => 32
		},
		DEFAULT => -121,
		GOTOS => {
			'keyword' => 81,
			'identifier' => 77,
			'CName' => 79,
			'idOrKey' => 78,
			'annotationElement' => 121,
			'quotedIdentifier' => 36,
			'name' => 122,
			'anoEltStar' => 123
		}
	},
	{#State 83
		DEFAULT => -76
	},
	{#State 84
		ACTIONS => {
			"~" => 124
		},
		DEFAULT => -97
	},
	{#State 85
		DEFAULT => -96
	},
	{#State 86
		ACTIONS => {
			"inherit" => 125
		},
		DEFAULT => -79,
		GOTOS => {
			'inheritOpt' => 127,
			'inherit' => 126
		}
	},
	{#State 87
		ACTIONS => {
			"div" => 45,
			'NCName' => 92,
			"start" => 41,
			"[" => 117,
			"\\" => 31,
			"include" => 43
		},
		DEFAULT => -41,
		GOTOS => {
			'gramCtntStar' => 128,
			'identifier' => 116,
			'gramCtnt' => 59,
			'quotedIdentifier' => 36,
			'define' => 60,
			'start' => 51
		}
	},
	{#State 88
		ACTIONS => {
			"string" => 9,
			"external" => 12,
			"namespace" => 11,
			"empty" => 14,
			"mixed" => 13,
			"grammar" => 16,
			'NCName' => 133,
			"start" => 18,
			"*" => 130,
			"include" => 19,
			"notAllowed" => 20,
			"div" => 21,
			"attribute" => 22,
			"text" => 24,
			"inherit" => 25,
			"element" => 26,
			"token" => 27,
			"(" => 132,
			"list" => 28,
			"datatypes" => 29,
			"default" => 30,
			"\\" => 31,
			"parent" => 32
		},
		GOTOS => {
			'keyword' => 81,
			'CName' => 79,
			'quotedIdentifier' => 36,
			'name' => 131,
			'nsName' => 129,
			'nameClass' => 134,
			'identifier' => 77,
			'anyName' => 135,
			'idOrKey' => 78
		}
	},
	{#State 89
		ACTIONS => {
			"string" => 9,
			"external" => 12,
			"namespace" => 11,
			"empty" => 14,
			"mixed" => 13,
			"grammar" => 16,
			'NCName' => 56,
			"start" => 18,
			"include" => 19,
			"notAllowed" => 20,
			"div" => 21,
			"attribute" => 22,
			"text" => 24,
			"inherit" => 25,
			"element" => 26,
			"token" => 27,
			"list" => 28,
			"datatypes" => 29,
			"default" => 30,
			"\\" => 31,
			"parent" => 32
		},
		DEFAULT => -121,
		GOTOS => {
			'keyword' => 81,
			'identifier' => 77,
			'CName' => 79,
			'idOrKey' => 78,
			'annotationElement' => 121,
			'quotedIdentifier' => 36,
			'name' => 122,
			'anoEltStar' => 136
		}
	},
	{#State 90
		ACTIONS => {
			"string" => 37,
			"external" => 54,
			"empty" => 55,
			"mixed" => 38,
			"grammar" => 39,
			'NCName' => 56,
			"notAllowed" => 44,
			"attribute" => 58,
			"text" => 47,
			"element" => 48,
			"token" => 49,
			"(" => 50,
			"list" => 62,
			"\\" => 31,
			"parent" => 52
		},
		DEFAULT => -70,
		GOTOS => {
			'commaPatternPlus' => 34,
			'pipePatternPlus' => 33,
			'pattern' => 138,
			'datatypeName' => 53,
			'identifier' => 137,
			'CName' => 46,
			'quotedIdentifier' => 36,
			'datatypeNameOpt' => 63,
			'ampPatternPlus' => 64
		}
	},
	{#State 91
		DEFAULT => -24
	},
	{#State 92
		DEFAULT => -90
	},
	{#State 93
		ACTIONS => {
			"string" => 9,
			"external" => 12,
			"namespace" => 11,
			"empty" => 14,
			"mixed" => 13,
			"grammar" => 16,
			'NCName' => 92,
			"start" => 18,
			"include" => 19,
			"notAllowed" => 20,
			"div" => 21,
			"attribute" => 22,
			"text" => 24,
			"inherit" => 25,
			"element" => 26,
			"token" => 27,
			"list" => 28,
			"datatypes" => 29,
			"default" => 30,
			"\\" => 31,
			"parent" => 32
		},
		DEFAULT => -35,
		GOTOS => {
			'keyword' => 81,
			'identifier' => 77,
			'idOrKey' => 139,
			'quotedIdentifier' => 36,
			'paramStar' => 141,
			'param' => 140
		}
	},
	{#State 94
		ACTIONS => {
			"-" => 142
		},
		DEFAULT => -38,
		GOTOS => {
			'exceptPatternOpt' => 144,
			'exceptPattern' => 143
		}
	},
	{#State 95
		ACTIONS => {
			"inherit" => 125
		},
		DEFAULT => -79,
		GOTOS => {
			'inheritOpt' => 145,
			'inherit' => 126
		}
	},
	{#State 96
		ACTIONS => {
			'NCName' => 146
		}
	},
	{#State 97
		ACTIONS => {
			"string" => 9,
			"external" => 12,
			"namespace" => 11,
			"empty" => 14,
			"mixed" => 13,
			"grammar" => 16,
			'NCName' => 133,
			"start" => 18,
			"*" => 130,
			"include" => 19,
			"notAllowed" => 20,
			"div" => 21,
			"attribute" => 22,
			"text" => 24,
			"inherit" => 25,
			"element" => 26,
			"token" => 27,
			"(" => 132,
			"list" => 28,
			"datatypes" => 29,
			"default" => 30,
			"\\" => 31,
			"parent" => 32
		},
		GOTOS => {
			'keyword' => 81,
			'CName' => 79,
			'quotedIdentifier' => 36,
			'name' => 131,
			'nsName' => 129,
			'nameClass' => 147,
			'identifier' => 77,
			'anyName' => 135,
			'idOrKey' => 78
		}
	},
	{#State 98
		ACTIONS => {
			">" => 99
		},
		DEFAULT => -127,
		GOTOS => {
			'followAnoStar' => 148,
			'followAnnotation' => 98
		}
	},
	{#State 99
		ACTIONS => {
			">" => 149
		}
	},
	{#State 100
		ACTIONS => {
			"div" => 45,
			'NCName' => 92,
			"start" => 41,
			"[" => 117,
			"\\" => 31,
			"include" => 43
		},
		DEFAULT => -41,
		GOTOS => {
			'gramCtntStar' => 150,
			'identifier' => 116,
			'gramCtnt' => 59,
			'quotedIdentifier' => 36,
			'define' => 60,
			'start' => 51
		}
	},
	{#State 101
		DEFAULT => -19
	},
	{#State 102
		ACTIONS => {
			"[" => 89
		},
		DEFAULT => -118,
		GOTOS => {
			'anoOpt' => 151
		}
	},
	{#State 103
		DEFAULT => -20
	},
	{#State 104
		ACTIONS => {
			"[" => 89
		},
		DEFAULT => -118,
		GOTOS => {
			'anoOpt' => 152
		}
	},
	{#State 105
		DEFAULT => -18
	},
	{#State 106
		ACTIONS => {
			"[" => 89
		},
		DEFAULT => -118,
		GOTOS => {
			'anoOpt' => 153
		}
	},
	{#State 107
		ACTIONS => {
			"[" => 89
		},
		DEFAULT => -118,
		GOTOS => {
			'anoOpt' => 154
		}
	},
	{#State 108
		DEFAULT => -75
	},
	{#State 109
		DEFAULT => -27
	},
	{#State 110
		DEFAULT => -83
	},
	{#State 111
		ACTIONS => {
			"=" => 155
		}
	},
	{#State 112
		ACTIONS => {
			'LITERAL_SEGMENT' => 84,
			"inherit" => 158
		},
		GOTOS => {
			'literal' => 157,
			'literalSegmentPlus' => 85,
			'nsUriLit' => 156
		}
	},
	{#State 113
		DEFAULT => -9
	},
	{#State 114
		ACTIONS => {
			"string" => 37,
			"external" => 54,
			"empty" => 55,
			"mixed" => 38,
			"grammar" => 39,
			'NCName' => 56,
			"notAllowed" => 44,
			"attribute" => 58,
			"text" => 47,
			"element" => 48,
			"token" => 49,
			"(" => 50,
			"list" => 62,
			"\\" => 31,
			"parent" => 52
		},
		DEFAULT => -70,
		GOTOS => {
			'commaPatternPlus' => 34,
			'pipePatternPlus' => 33,
			'pattern' => 159,
			'datatypeName' => 53,
			'identifier' => 137,
			'CName' => 46,
			'quotedIdentifier' => 36,
			'datatypeNameOpt' => 63,
			'ampPatternPlus' => 64
		}
	},
	{#State 115
		ACTIONS => {
			"}" => 160
		}
	},
	{#State 116
		ACTIONS => {
			"|=" => 73,
			"&=" => 74,
			"=" => 75
		},
		GOTOS => {
			'assignMethod' => 72
		}
	},
	{#State 117
		ACTIONS => {
			"string" => 9,
			"external" => 12,
			"namespace" => 11,
			"empty" => 14,
			"mixed" => 13,
			"grammar" => 16,
			'NCName' => 56,
			"start" => 18,
			"include" => 19,
			"notAllowed" => 20,
			"div" => 21,
			"attribute" => 22,
			"text" => 24,
			"inherit" => 25,
			"element" => 26,
			"token" => 27,
			"list" => 28,
			"datatypes" => 29,
			"default" => 30,
			"\\" => 31,
			"parent" => 32
		},
		GOTOS => {
			'anoAttribStar' => 161,
			'keyword' => 81,
			'identifier' => 77,
			'CName' => 79,
			'idOrKey' => 78,
			'quotedIdentifier' => 36,
			'name' => 80
		}
	},
	{#State 118
		ACTIONS => {
			"string" => 37,
			"external" => 54,
			"empty" => 55,
			"mixed" => 38,
			"grammar" => 39,
			'NCName' => 56,
			"notAllowed" => 44,
			"attribute" => 58,
			"text" => 47,
			"element" => 48,
			"token" => 49,
			"(" => 50,
			"list" => 62,
			"\\" => 31,
			"parent" => 52
		},
		DEFAULT => -70,
		GOTOS => {
			'commaPatternPlus' => 34,
			'pipePatternPlus' => 33,
			'pattern' => 162,
			'datatypeName' => 53,
			'identifier' => 137,
			'CName' => 46,
			'quotedIdentifier' => 36,
			'datatypeNameOpt' => 63,
			'ampPatternPlus' => 64
		}
	},
	{#State 119
		ACTIONS => {
			"string" => 37,
			"external" => 54,
			"empty" => 55,
			"mixed" => 38,
			"grammar" => 39,
			'NCName' => 56,
			"notAllowed" => 44,
			"attribute" => 58,
			"text" => 47,
			"element" => 48,
			"token" => 49,
			"(" => 50,
			"list" => 62,
			"\\" => 31,
			"parent" => 52
		},
		DEFAULT => -70,
		GOTOS => {
			'commaPatternPlus' => 34,
			'pipePatternPlus' => 33,
			'pattern' => 163,
			'datatypeName' => 53,
			'identifier' => 137,
			'CName' => 46,
			'quotedIdentifier' => 36,
			'datatypeNameOpt' => 63,
			'ampPatternPlus' => 64
		}
	},
	{#State 120
		ACTIONS => {
			'LITERAL_SEGMENT' => 84
		},
		GOTOS => {
			'literal' => 164,
			'literalSegmentPlus' => 85
		}
	},
	{#State 121
		ACTIONS => {
			"string" => 9,
			"external" => 12,
			"namespace" => 11,
			"empty" => 14,
			"mixed" => 13,
			"grammar" => 16,
			'NCName' => 56,
			"start" => 18,
			"include" => 19,
			"notAllowed" => 20,
			"div" => 21,
			"attribute" => 22,
			"text" => 24,
			"inherit" => 25,
			"element" => 26,
			"token" => 27,
			"list" => 28,
			"datatypes" => 29,
			"default" => 30,
			"\\" => 31,
			"parent" => 32
		},
		DEFAULT => -121,
		GOTOS => {
			'keyword' => 81,
			'identifier' => 77,
			'CName' => 79,
			'idOrKey' => 78,
			'annotationElement' => 121,
			'quotedIdentifier' => 36,
			'name' => 122,
			'anoEltStar' => 165
		}
	},
	{#State 122
		ACTIONS => {
			"[" => 166
		}
	},
	{#State 123
		ACTIONS => {
			"]" => 167
		}
	},
	{#State 124
		ACTIONS => {
			'LITERAL_SEGMENT' => 84
		},
		GOTOS => {
			'literalSegmentPlus' => 168
		}
	},
	{#State 125
		ACTIONS => {
			"=" => 169
		}
	},
	{#State 126
		DEFAULT => -80
	},
	{#State 127
		ACTIONS => {
			"{" => 170
		},
		DEFAULT => -48,
		GOTOS => {
			'incOptSec' => 171
		}
	},
	{#State 128
		ACTIONS => {
			"}" => 172
		}
	},
	{#State 129
		ACTIONS => {
			"-" => 173
		},
		DEFAULT => -67,
		GOTOS => {
			'exceptNameClass' => 175,
			'exceptNameClassOpt' => 174
		}
	},
	{#State 130
		DEFAULT => -95
	},
	{#State 131
		DEFAULT => -60
	},
	{#State 132
		ACTIONS => {
			"[" => 89
		},
		DEFAULT => -118,
		GOTOS => {
			'anoOpt' => 176
		}
	},
	{#State 133
		ACTIONS => {
			":" => 177
		},
		DEFAULT => -90
	},
	{#State 134
		ACTIONS => {
			"|" => 178,
			"{" => 179
		}
	},
	{#State 135
		ACTIONS => {
			"-" => 173
		},
		DEFAULT => -67,
		GOTOS => {
			'exceptNameClass' => 175,
			'exceptNameClassOpt' => 180
		}
	},
	{#State 136
		ACTIONS => {
			"]" => 181
		}
	},
	{#State 137
		DEFAULT => -23
	},
	{#State 138
		ACTIONS => {
			"|" => 102,
			"?" => 105,
			"*" => 101,
			"+" => 103,
			"&" => 106,
			"," => 104,
			")" => 182
		}
	},
	{#State 139
		ACTIONS => {
			"=" => 183
		}
	},
	{#State 140
		ACTIONS => {
			"string" => 9,
			"external" => 12,
			"namespace" => 11,
			"empty" => 14,
			"mixed" => 13,
			"grammar" => 16,
			'NCName' => 92,
			"start" => 18,
			"include" => 19,
			"notAllowed" => 20,
			"div" => 21,
			"attribute" => 22,
			"text" => 24,
			"inherit" => 25,
			"element" => 26,
			"token" => 27,
			"list" => 28,
			"datatypes" => 29,
			"default" => 30,
			"\\" => 31,
			"parent" => 32
		},
		DEFAULT => -35,
		GOTOS => {
			'keyword' => 81,
			'identifier' => 77,
			'idOrKey' => 139,
			'quotedIdentifier' => 36,
			'paramStar' => 184,
			'param' => 140
		}
	},
	{#State 141
		ACTIONS => {
			"}" => 185
		}
	},
	{#State 142
		ACTIONS => {
			"[" => 89
		},
		DEFAULT => -118,
		GOTOS => {
			'anoOpt' => 186
		}
	},
	{#State 143
		DEFAULT => -39
	},
	{#State 144
		DEFAULT => -28
	},
	{#State 145
		DEFAULT => -30
	},
	{#State 146
		DEFAULT => -93
	},
	{#State 147
		ACTIONS => {
			"|" => 178,
			"{" => 187
		}
	},
	{#State 148
		DEFAULT => -128
	},
	{#State 149
		ACTIONS => {
			"string" => 9,
			"external" => 12,
			"namespace" => 11,
			"empty" => 14,
			"mixed" => 13,
			"grammar" => 16,
			'NCName' => 56,
			"start" => 18,
			"include" => 19,
			"notAllowed" => 20,
			"div" => 21,
			"attribute" => 22,
			"text" => 24,
			"inherit" => 25,
			"element" => 26,
			"token" => 27,
			"list" => 28,
			"datatypes" => 29,
			"default" => 30,
			"\\" => 31,
			"parent" => 32
		},
		GOTOS => {
			'keyword' => 81,
			'identifier' => 77,
			'CName' => 79,
			'idOrKey' => 78,
			'annotationElement' => 188,
			'quotedIdentifier' => 36,
			'name' => 122
		}
	},
	{#State 150
		DEFAULT => -42
	},
	{#State 151
		ACTIONS => {
			"string" => 37,
			"external" => 54,
			"empty" => 55,
			"mixed" => 38,
			"grammar" => 39,
			'NCName' => 56,
			"notAllowed" => 44,
			"attribute" => 58,
			"text" => 47,
			"element" => 48,
			"token" => 49,
			"(" => 50,
			"list" => 62,
			"\\" => 31,
			"parent" => 52
		},
		DEFAULT => -70,
		GOTOS => {
			'commaPatternPlus' => 34,
			'pipePatternPlus' => 33,
			'pattern' => 189,
			'datatypeName' => 53,
			'identifier' => 137,
			'CName' => 46,
			'quotedIdentifier' => 36,
			'datatypeNameOpt' => 63,
			'ampPatternPlus' => 64
		}
	},
	{#State 152
		ACTIONS => {
			"string" => 37,
			"external" => 54,
			"empty" => 55,
			"mixed" => 38,
			"grammar" => 39,
			'NCName' => 56,
			"notAllowed" => 44,
			"attribute" => 58,
			"text" => 47,
			"element" => 48,
			"token" => 49,
			"(" => 50,
			"list" => 62,
			"\\" => 31,
			"parent" => 52
		},
		DEFAULT => -70,
		GOTOS => {
			'commaPatternPlus' => 34,
			'pipePatternPlus' => 33,
			'pattern' => 190,
			'datatypeName' => 53,
			'identifier' => 137,
			'CName' => 46,
			'quotedIdentifier' => 36,
			'datatypeNameOpt' => 63,
			'ampPatternPlus' => 64
		}
	},
	{#State 153
		ACTIONS => {
			"string" => 37,
			"external" => 54,
			"empty" => 55,
			"mixed" => 38,
			"grammar" => 39,
			'NCName' => 56,
			"notAllowed" => 44,
			"attribute" => 58,
			"text" => 47,
			"element" => 48,
			"token" => 49,
			"(" => 50,
			"list" => 62,
			"\\" => 31,
			"parent" => 52
		},
		DEFAULT => -70,
		GOTOS => {
			'commaPatternPlus' => 34,
			'pipePatternPlus' => 33,
			'pattern' => 191,
			'datatypeName' => 53,
			'identifier' => 137,
			'CName' => 46,
			'quotedIdentifier' => 36,
			'datatypeNameOpt' => 63,
			'ampPatternPlus' => 64
		}
	},
	{#State 154
		ACTIONS => {
			"string" => 37,
			"external" => 54,
			"empty" => 55,
			"mixed" => 38,
			"grammar" => 39,
			'NCName' => 56,
			"notAllowed" => 44,
			"attribute" => 58,
			"text" => 47,
			"element" => 48,
			"token" => 49,
			"(" => 50,
			"list" => 62,
			"\\" => 31,
			"parent" => 52
		},
		DEFAULT => -70,
		GOTOS => {
			'commaPatternPlus' => 34,
			'pipePatternPlus' => 33,
			'pattern' => 192,
			'datatypeName' => 53,
			'identifier' => 137,
			'CName' => 46,
			'quotedIdentifier' => 36,
			'datatypeNameOpt' => 63,
			'ampPatternPlus' => 64
		}
	},
	{#State 155
		ACTIONS => {
			'LITERAL_SEGMENT' => 84,
			"inherit" => 158
		},
		GOTOS => {
			'literal' => 157,
			'literalSegmentPlus' => 85,
			'nsUriLit' => 193
		}
	},
	{#State 156
		DEFAULT => -7
	},
	{#State 157
		DEFAULT => -77
	},
	{#State 158
		DEFAULT => -78
	},
	{#State 159
		ACTIONS => {
			"}" => 194,
			"|" => 102,
			"?" => 105,
			"*" => 101,
			"+" => 103,
			"&" => 106,
			"," => 104
		}
	},
	{#State 160
		DEFAULT => -31
	},
	{#State 161
		ACTIONS => {
			"string" => 9,
			"external" => 12,
			"namespace" => 11,
			"empty" => 14,
			"mixed" => 13,
			"grammar" => 16,
			'NCName' => 56,
			"start" => 18,
			"include" => 19,
			"notAllowed" => 20,
			"div" => 21,
			"attribute" => 22,
			"text" => 24,
			"inherit" => 25,
			"element" => 26,
			"token" => 27,
			"list" => 28,
			"datatypes" => 29,
			"default" => 30,
			"\\" => 31,
			"parent" => 32
		},
		DEFAULT => -121,
		GOTOS => {
			'keyword' => 81,
			'identifier' => 77,
			'CName' => 79,
			'idOrKey' => 78,
			'annotationElement' => 121,
			'quotedIdentifier' => 36,
			'name' => 122,
			'anoEltStar' => 195
		}
	},
	{#State 162
		ACTIONS => {
			"?" => 105,
			"+" => 103,
			"&" => 106,
			"," => 104,
			"|" => 102,
			"*" => 101
		},
		DEFAULT => -56
	},
	{#State 163
		ACTIONS => {
			"?" => 105,
			"+" => 103,
			"&" => 106,
			"," => 104,
			"|" => 102,
			"*" => 101
		},
		DEFAULT => -55
	},
	{#State 164
		DEFAULT => -120
	},
	{#State 165
		DEFAULT => -122
	},
	{#State 166
		ACTIONS => {
			"string" => 9,
			"external" => 12,
			"namespace" => 11,
			"empty" => 14,
			"mixed" => 13,
			"grammar" => 16,
			'NCName' => 56,
			"start" => 18,
			"include" => 19,
			"notAllowed" => 20,
			"div" => 21,
			"attribute" => 22,
			"text" => 24,
			"inherit" => 25,
			"element" => 26,
			"token" => 27,
			"list" => 28,
			"datatypes" => 29,
			"default" => 30,
			'LITERAL_SEGMENT' => 84,
			"\\" => 31,
			"parent" => 32
		},
		DEFAULT => -124,
		GOTOS => {
			'keyword' => 81,
			'CName' => 79,
			'annotationElement' => 196,
			'quotedIdentifier' => 36,
			'name' => 122,
			'literal' => 197,
			'anoEltORlitStar' => 198,
			'identifier' => 77,
			'idOrKey' => 78,
			'literalSegmentPlus' => 85
		}
	},
	{#State 167
		ACTIONS => {
			"string" => 37,
			"external" => 54,
			"empty" => 55,
			"mixed" => 38,
			"grammar" => 39,
			'NCName' => 56,
			"start" => 41,
			"include" => 43,
			"notAllowed" => 44,
			"div" => 45,
			"attribute" => 58,
			"text" => 47,
			"element" => 48,
			"token" => 49,
			"(" => 50,
			"list" => 62,
			"\\" => 31,
			"parent" => 52
		},
		DEFAULT => -70,
		GOTOS => {
			'commaPatternPlus' => 34,
			'pipePatternPlus' => 33,
			'datatypeName' => 53,
			'CName' => 46,
			'gramCtnt' => 199,
			'quotedIdentifier' => 36,
			'define' => 60,
			'pattern' => 200,
			'identifier' => 40,
			'datatypeNameOpt' => 63,
			'ampPatternPlus' => 64,
			'start' => 51
		}
	},
	{#State 168
		DEFAULT => -98
	},
	{#State 169
		ACTIONS => {
			"string" => 9,
			"external" => 12,
			"namespace" => 11,
			"empty" => 14,
			"mixed" => 13,
			"grammar" => 16,
			'NCName' => 92,
			"start" => 18,
			"include" => 19,
			"notAllowed" => 20,
			"div" => 21,
			"attribute" => 22,
			"text" => 24,
			"inherit" => 25,
			"element" => 26,
			"token" => 27,
			"list" => 28,
			"datatypes" => 29,
			"default" => 30,
			"\\" => 31,
			"parent" => 32
		},
		GOTOS => {
			'keyword' => 81,
			'identifier' => 77,
			'idOrKey' => 201,
			'quotedIdentifier' => 36
		}
	},
	{#State 170
		ACTIONS => {
			"}" => -50,
			"[" => 89
		},
		DEFAULT => -118,
		GOTOS => {
			'anoOpt' => 203,
			'includeContentStar' => 202
		}
	},
	{#State 171
		DEFAULT => -47
	},
	{#State 172
		DEFAULT => -46
	},
	{#State 173
		ACTIONS => {
			"[" => 89
		},
		DEFAULT => -118,
		GOTOS => {
			'anoOpt' => 204
		}
	},
	{#State 174
		DEFAULT => -61
	},
	{#State 175
		DEFAULT => -68
	},
	{#State 176
		ACTIONS => {
			"string" => 9,
			"external" => 12,
			"namespace" => 11,
			"empty" => 14,
			"mixed" => 13,
			"grammar" => 16,
			'NCName' => 133,
			"start" => 18,
			"*" => 130,
			"include" => 19,
			"notAllowed" => 20,
			"div" => 21,
			"attribute" => 22,
			"text" => 24,
			"inherit" => 25,
			"element" => 26,
			"token" => 27,
			"(" => 132,
			"list" => 28,
			"datatypes" => 29,
			"default" => 30,
			"\\" => 31,
			"parent" => 32
		},
		GOTOS => {
			'keyword' => 81,
			'CName' => 79,
			'quotedIdentifier' => 36,
			'name' => 131,
			'nsName' => 129,
			'nameClass' => 205,
			'identifier' => 77,
			'anyName' => 135,
			'idOrKey' => 78
		}
	},
	{#State 177
		ACTIONS => {
			"*" => 206,
			'NCName' => 146
		}
	},
	{#State 178
		ACTIONS => {
			"[" => 89
		},
		DEFAULT => -118,
		GOTOS => {
			'anoOpt' => 207
		}
	},
	{#State 179
		ACTIONS => {
			"[" => 89
		},
		DEFAULT => -118,
		GOTOS => {
			'anoOpt' => 208
		}
	},
	{#State 180
		DEFAULT => -62
	},
	{#State 181
		DEFAULT => -119
	},
	{#State 182
		DEFAULT => -32
	},
	{#State 183
		ACTIONS => {
			'LITERAL_SEGMENT' => 84
		},
		GOTOS => {
			'literal' => 209,
			'literalSegmentPlus' => 85
		}
	},
	{#State 184
		DEFAULT => -36
	},
	{#State 185
		DEFAULT => -34
	},
	{#State 186
		ACTIONS => {
			"string" => 37,
			"external" => 54,
			"empty" => 55,
			"mixed" => 38,
			"grammar" => 39,
			'NCName' => 56,
			"notAllowed" => 44,
			"attribute" => 58,
			"text" => 47,
			"element" => 48,
			"token" => 49,
			"(" => 50,
			"list" => 62,
			"\\" => 31,
			"parent" => 52
		},
		DEFAULT => -70,
		GOTOS => {
			'commaPatternPlus' => 34,
			'pipePatternPlus' => 33,
			'pattern' => 210,
			'datatypeName' => 53,
			'identifier' => 137,
			'CName' => 46,
			'quotedIdentifier' => 36,
			'datatypeNameOpt' => 63,
			'ampPatternPlus' => 64
		}
	},
	{#State 187
		ACTIONS => {
			"[" => 89
		},
		DEFAULT => -118,
		GOTOS => {
			'anoOpt' => 211
		}
	},
	{#State 188
		DEFAULT => -129
	},
	{#State 189
		ACTIONS => {
			"+" => 103,
			"," => 104,
			"*" => 101,
			"?" => 105
		},
		DEFAULT => -12
	},
	{#State 190
		ACTIONS => {
			"+" => 103,
			"*" => 101,
			"?" => 105
		},
		DEFAULT => -10
	},
	{#State 191
		ACTIONS => {
			"+" => 103,
			"," => 104,
			"*" => 101,
			"?" => 105,
			"|" => 102
		},
		DEFAULT => -11
	},
	{#State 192
		ACTIONS => {
			"}" => 212,
			"|" => 102,
			"?" => 105,
			"*" => 101,
			"+" => 103,
			"&" => 106,
			"," => 104
		}
	},
	{#State 193
		DEFAULT => -8
	},
	{#State 194
		DEFAULT => -22
	},
	{#State 195
		ACTIONS => {
			"]" => 213
		}
	},
	{#State 196
		ACTIONS => {
			"string" => 9,
			"external" => 12,
			"namespace" => 11,
			"empty" => 14,
			"mixed" => 13,
			"grammar" => 16,
			'NCName' => 56,
			"start" => 18,
			"include" => 19,
			"notAllowed" => 20,
			"div" => 21,
			"attribute" => 22,
			"text" => 24,
			"inherit" => 25,
			"element" => 26,
			"token" => 27,
			"list" => 28,
			"datatypes" => 29,
			"default" => 30,
			'LITERAL_SEGMENT' => 84,
			"\\" => 31,
			"parent" => 32
		},
		DEFAULT => -124,
		GOTOS => {
			'keyword' => 81,
			'CName' => 79,
			'annotationElement' => 196,
			'quotedIdentifier' => 36,
			'name' => 122,
			'literal' => 197,
			'anoEltORlitStar' => 214,
			'identifier' => 77,
			'idOrKey' => 78,
			'literalSegmentPlus' => 85
		}
	},
	{#State 197
		ACTIONS => {
			"string" => 9,
			"external" => 12,
			"namespace" => 11,
			"empty" => 14,
			"mixed" => 13,
			"grammar" => 16,
			'NCName' => 56,
			"start" => 18,
			"include" => 19,
			"notAllowed" => 20,
			"div" => 21,
			"attribute" => 22,
			"text" => 24,
			"inherit" => 25,
			"element" => 26,
			"token" => 27,
			"list" => 28,
			"datatypes" => 29,
			"default" => 30,
			'LITERAL_SEGMENT' => 84,
			"\\" => 31,
			"parent" => 32
		},
		DEFAULT => -124,
		GOTOS => {
			'keyword' => 81,
			'CName' => 79,
			'annotationElement' => 196,
			'quotedIdentifier' => 36,
			'name' => 122,
			'literal' => 197,
			'anoEltORlitStar' => 215,
			'identifier' => 77,
			'idOrKey' => 78,
			'literalSegmentPlus' => 85
		}
	},
	{#State 198
		ACTIONS => {
			"]" => 216
		}
	},
	{#State 199
		ACTIONS => {
			"div" => 45,
			'NCName' => 92,
			"start" => 41,
			"[" => 117,
			"\\" => 31,
			"include" => 43
		},
		DEFAULT => -41,
		GOTOS => {
			'gramCtntStar' => 217,
			'identifier' => 116,
			'gramCtnt' => 59,
			'quotedIdentifier' => 36,
			'define' => 60,
			'start' => 51
		}
	},
	{#State 200
		ACTIONS => {
			"?" => 105,
			"+" => 103,
			"&" => 106,
			"," => 104,
			"|" => 102,
			"*" => 101
		},
		DEFAULT => -3
	},
	{#State 201
		DEFAULT => -81
	},
	{#State 202
		ACTIONS => {
			"}" => 218
		}
	},
	{#State 203
		ACTIONS => {
			"div" => 219,
			"start" => 41,
			"\\" => 31,
			'NCName' => 92
		},
		GOTOS => {
			'identifier' => 116,
			'includeContent' => 221,
			'quotedIdentifier' => 36,
			'define' => 222,
			'start' => 220
		}
	},
	{#State 204
		ACTIONS => {
			"string" => 9,
			"external" => 12,
			"namespace" => 11,
			"empty" => 14,
			"mixed" => 13,
			"grammar" => 16,
			'NCName' => 133,
			"start" => 18,
			"*" => 130,
			"include" => 19,
			"notAllowed" => 20,
			"div" => 21,
			"attribute" => 22,
			"text" => 24,
			"inherit" => 25,
			"element" => 26,
			"token" => 27,
			"(" => 132,
			"list" => 28,
			"datatypes" => 29,
			"default" => 30,
			"\\" => 31,
			"parent" => 32
		},
		GOTOS => {
			'keyword' => 81,
			'CName' => 79,
			'quotedIdentifier' => 36,
			'name' => 131,
			'nsName' => 129,
			'nameClass' => 223,
			'identifier' => 77,
			'anyName' => 135,
			'idOrKey' => 78
		}
	},
	{#State 205
		ACTIONS => {
			"|" => 178,
			")" => 224
		}
	},
	{#State 206
		DEFAULT => -94
	},
	{#State 207
		ACTIONS => {
			"string" => 9,
			"external" => 12,
			"namespace" => 11,
			"empty" => 14,
			"mixed" => 13,
			"grammar" => 16,
			'NCName' => 133,
			"start" => 18,
			"*" => 130,
			"include" => 19,
			"notAllowed" => 20,
			"div" => 21,
			"attribute" => 22,
			"text" => 24,
			"inherit" => 25,
			"element" => 26,
			"token" => 27,
			"(" => 132,
			"list" => 28,
			"datatypes" => 29,
			"default" => 30,
			"\\" => 31,
			"parent" => 32
		},
		GOTOS => {
			'keyword' => 81,
			'CName' => 79,
			'quotedIdentifier' => 36,
			'name' => 131,
			'nsName' => 129,
			'nameClass' => 225,
			'identifier' => 77,
			'anyName' => 135,
			'idOrKey' => 78
		}
	},
	{#State 208
		ACTIONS => {
			"string" => 37,
			"external" => 54,
			"empty" => 55,
			"mixed" => 38,
			"grammar" => 39,
			'NCName' => 56,
			"notAllowed" => 44,
			"attribute" => 58,
			"text" => 47,
			"element" => 48,
			"token" => 49,
			"(" => 50,
			"list" => 62,
			"\\" => 31,
			"parent" => 52
		},
		DEFAULT => -70,
		GOTOS => {
			'commaPatternPlus' => 34,
			'pipePatternPlus' => 33,
			'pattern' => 226,
			'datatypeName' => 53,
			'identifier' => 137,
			'CName' => 46,
			'quotedIdentifier' => 36,
			'datatypeNameOpt' => 63,
			'ampPatternPlus' => 64
		}
	},
	{#State 209
		DEFAULT => -37
	},
	{#State 210
		ACTIONS => {
			"+" => 103,
			"?" => 105
		},
		DEFAULT => -40
	},
	{#State 211
		ACTIONS => {
			"string" => 37,
			"external" => 54,
			"empty" => 55,
			"mixed" => 38,
			"grammar" => 39,
			'NCName' => 56,
			"notAllowed" => 44,
			"attribute" => 58,
			"text" => 47,
			"element" => 48,
			"token" => 49,
			"(" => 50,
			"list" => 62,
			"\\" => 31,
			"parent" => 52
		},
		DEFAULT => -70,
		GOTOS => {
			'commaPatternPlus' => 34,
			'pipePatternPlus' => 33,
			'pattern' => 227,
			'datatypeName' => 53,
			'identifier' => 137,
			'CName' => 46,
			'quotedIdentifier' => 36,
			'datatypeNameOpt' => 63,
			'ampPatternPlus' => 64
		}
	},
	{#State 212
		DEFAULT => -21
	},
	{#State 213
		ACTIONS => {
			"div" => 45,
			"start" => 41,
			"\\" => 31,
			'NCName' => 92,
			"include" => 43
		},
		GOTOS => {
			'identifier' => 116,
			'gramCtnt' => 199,
			'quotedIdentifier' => 36,
			'define' => 60,
			'start' => 51
		}
	},
	{#State 214
		DEFAULT => -125
	},
	{#State 215
		DEFAULT => -126
	},
	{#State 216
		DEFAULT => -123
	},
	{#State 217
		DEFAULT => -43
	},
	{#State 218
		DEFAULT => -49
	},
	{#State 219
		ACTIONS => {
			"{" => 228
		}
	},
	{#State 220
		DEFAULT => -53
	},
	{#State 221
		ACTIONS => {
			"}" => -50,
			"[" => 89
		},
		DEFAULT => -118,
		GOTOS => {
			'anoOpt' => 203,
			'includeContentStar' => 229
		}
	},
	{#State 222
		DEFAULT => -52
	},
	{#State 223
		DEFAULT => -69
	},
	{#State 224
		DEFAULT => -64
	},
	{#State 225
		DEFAULT => -63
	},
	{#State 226
		ACTIONS => {
			"}" => 230,
			"|" => 102,
			"?" => 105,
			"*" => 101,
			"+" => 103,
			"&" => 106,
			"," => 104
		}
	},
	{#State 227
		ACTIONS => {
			"}" => 231,
			"|" => 102,
			"?" => 105,
			"*" => 101,
			"+" => 103,
			"&" => 106,
			"," => 104
		}
	},
	{#State 228
		ACTIONS => {
			"}" => -50,
			"[" => 89
		},
		DEFAULT => -118,
		GOTOS => {
			'anoOpt' => 203,
			'includeContentStar' => 232
		}
	},
	{#State 229
		DEFAULT => -51
	},
	{#State 230
		DEFAULT => -13
	},
	{#State 231
		DEFAULT => -14
	},
	{#State 232
		ACTIONS => {
			"}" => 233
		}
	},
	{#State 233
		DEFAULT => -54
	}
],
                                  yyrules  =>
[
	[#Rule 0
		 '$start', 2, undef
	],
	[#Rule 1
		 'topLevel', 2,
sub
#line 36 "RelaxNGParser.yp"
{$_[0]->_resolveReferencePatterns();
     new W3C::XML::SchemaValidator::Grammar($_[0], $_[1], $_[2], $_[0]->YYData->{START})}
	],
	[#Rule 2
		 'patORgramCtntStar', 1, undef
	],
	[#Rule 3
		 'patORgramCtntStar', 5, undef
	],
	[#Rule 4
		 'patORgramCtntStar', 1, undef
	],
	[#Rule 5
		 'declStar', 0, undef
	],
	[#Rule 6
		 'declStar', 2,
sub
#line 45 "RelaxNGParser.yp"
{unshift(@{$_[2]},$_[1]); $_[2]}
	],
	[#Rule 7
		 'decl', 4,
sub
#line 48 "RelaxNGParser.yp"
{my $ret = new W3C::XML::SchemaValidator::NsDecl($_[0], $_[2], $_[4]); 
     $_[0]->_registerNamespace($_[2], $_[4]); 
     return $ret}
	],
	[#Rule 8
		 'decl', 5,
sub
#line 52 "RelaxNGParser.yp"
{new W3C::XML::SchemaValidator::DefaultNsDecl($_[0], $_[3], $_[5])}
	],
	[#Rule 9
		 'decl', 4,
sub
#line 54 "RelaxNGParser.yp"
{my $ret=new W3C::XML::SchemaValidator::DatatypesDecl($_[0], $_[2], $_[4]); 
     $_[0]->_registerDataType($_[2], $_[4]); 
     return $ret}
	],
	[#Rule 10
		 'commaPatternPlus', 4,
sub
#line 59 "RelaxNGParser.yp"
{new W3C::XML::SchemaValidator::PatternSequence($_[0], $_[1], $_[4], $_[3])}
	],
	[#Rule 11
		 'ampPatternPlus', 4, undef
	],
	[#Rule 12
		 'pipePatternPlus', 4,
sub
#line 64 "RelaxNGParser.yp"
{new W3C::XML::SchemaValidator::PatternPipe($_[0], $_[1], $_[4], $_[3])}
	],
	[#Rule 13
		 'pattern', 7,
sub
#line 67 "RelaxNGParser.yp"
{new W3C::XML::SchemaValidator::Element($_[0], $_[3], $_[6], $_[2], $_[5])}
	],
	[#Rule 14
		 'pattern', 7,
sub
#line 69 "RelaxNGParser.yp"
{new W3C::XML::SchemaValidator::Attribute($_[0], $_[3], $_[6], $_[2], $_[5])}
	],
	[#Rule 15
		 'pattern', 1, undef
	],
	[#Rule 16
		 'pattern', 1, undef
	],
	[#Rule 17
		 'pattern', 1, undef
	],
	[#Rule 18
		 'pattern', 2,
sub
#line 74 "RelaxNGParser.yp"
{new W3C::XML::SchemaValidator::PatternOpt($_[0], $_[1])}
	],
	[#Rule 19
		 'pattern', 2,
sub
#line 76 "RelaxNGParser.yp"
{new W3C::XML::SchemaValidator::PatternStar($_[0], $_[1])}
	],
	[#Rule 20
		 'pattern', 2, undef
	],
	[#Rule 21
		 'pattern', 5, undef
	],
	[#Rule 22
		 'pattern', 5,
sub
#line 80 "RelaxNGParser.yp"
{new W3C::XML::SchemaValidator::Mixed($_[0], $_[4], $_[3])}
	],
	[#Rule 23
		 'pattern', 1,
sub
#line 82 "RelaxNGParser.yp"
{$_[0]->_make_ReferencePattern($_[1])}
	],
	[#Rule 24
		 'pattern', 2, undef
	],
	[#Rule 25
		 'pattern', 1,
sub
#line 85 "RelaxNGParser.yp"
{new W3C::XML::SchemaValidator::Empty($_[0])}
	],
	[#Rule 26
		 'pattern', 1,
sub
#line 87 "RelaxNGParser.yp"
{new W3C::XML::SchemaValidator::Text($_[0])}
	],
	[#Rule 27
		 'pattern', 2,
sub
#line 89 "RelaxNGParser.yp"
{new W3C::XML::SchemaValidator::NameOptDTV($_[0], $_[2], $_[1])}
	],
	[#Rule 28
		 'pattern', 3, undef
	],
	[#Rule 29
		 'pattern', 1, undef
	],
	[#Rule 30
		 'pattern', 3, undef
	],
	[#Rule 31
		 'pattern', 4, undef
	],
	[#Rule 32
		 'pattern', 4,
sub
#line 95 "RelaxNGParser.yp"
{new W3C::XML::SchemaValidator::PatternGroup($_[0], $_[3], $_[2])}
	],
	[#Rule 33
		 'paramOptSec', 0, undef
	],
	[#Rule 34
		 'paramOptSec', 3, undef
	],
	[#Rule 35
		 'paramStar', 0, undef
	],
	[#Rule 36
		 'paramStar', 2, undef
	],
	[#Rule 37
		 'param', 3, undef
	],
	[#Rule 38
		 'exceptPatternOpt', 0, undef
	],
	[#Rule 39
		 'exceptPatternOpt', 1, undef
	],
	[#Rule 40
		 'exceptPattern', 3,
sub
#line 109 "RelaxNGParser.yp"
{new W3C::XML::SchemaValidator::NegatedPattern($_[0], $_[3], $_[2])}
	],
	[#Rule 41
		 'gramCtntStar', 0, undef
	],
	[#Rule 42
		 'gramCtntStar', 3,
sub
#line 113 "RelaxNGParser.yp"
{$_[1]->setFollowAnnots($_[2]); unshift(@{$_[3]}, $_[1]); $_[3]}
	],
	[#Rule 43
		 'gramCtntStar', 6, undef
	],
	[#Rule 44
		 'gramCtnt', 1, undef
	],
	[#Rule 45
		 'gramCtnt', 1, undef
	],
	[#Rule 46
		 'gramCtnt', 4, undef
	],
	[#Rule 47
		 'gramCtnt', 4, undef
	],
	[#Rule 48
		 'incOptSec', 0, undef
	],
	[#Rule 49
		 'incOptSec', 3, undef
	],
	[#Rule 50
		 'includeContentStar', 0, undef
	],
	[#Rule 51
		 'includeContentStar', 3, undef
	],
	[#Rule 52
		 'includeContent', 1, undef
	],
	[#Rule 53
		 'includeContent', 1, undef
	],
	[#Rule 54
		 'includeContent', 4, undef
	],
	[#Rule 55
		 'start', 4,
sub
#line 132 "RelaxNGParser.yp"
{my $ret = new W3C::XML::SchemaValidator::Start($_[0], 
				      $_[0]->_find_NCNameAtom(undef, 'start'), 
						    $_[4]); 
     if (my $oldStart = $_[0]->YYData->{START}) {
	 &throw(new W3C::Util::Exception(-message => 
	 "start production already declared to be $oldStart->{VAL}{ID}{VAL}."));
     }
     $_[0]->YYData->{START} = $ret;
     return $ret}
	],
	[#Rule 56
		 'define', 4,
sub
#line 143 "RelaxNGParser.yp"
{$_[0]->_noteAssign(new W3C::XML::SchemaValidator::Define($_[0], 
							      $_[1], $_[4]))}
	],
	[#Rule 57
		 'assignMethod', 1, undef
	],
	[#Rule 58
		 'assignMethod', 1, undef
	],
	[#Rule 59
		 'assignMethod', 1, undef
	],
	[#Rule 60
		 'nameClass', 1, undef
	],
	[#Rule 61
		 'nameClass', 2, undef
	],
	[#Rule 62
		 'nameClass', 2,
sub
#line 153 "RelaxNGParser.yp"
{new W3C::XML::SchemaValidator::AnyNameExcept($_[0], $_[1], $_[2])}
	],
	[#Rule 63
		 'nameClass', 4,
sub
#line 155 "RelaxNGParser.yp"
{new W3C::XML::SchemaValidator::NamePipe($_[0], $_[1], $_[4], $_[3])}
	],
	[#Rule 64
		 'nameClass', 4,
sub
#line 158 "RelaxNGParser.yp"
{new W3C::XML::SchemaValidator::NameGroup($_[0], $_[3], $_[2])}
	],
	[#Rule 65
		 'name', 1, undef
	],
	[#Rule 66
		 'name', 1, undef
	],
	[#Rule 67
		 'exceptNameClassOpt', 0, undef
	],
	[#Rule 68
		 'exceptNameClassOpt', 1, undef
	],
	[#Rule 69
		 'exceptNameClass', 3,
sub
#line 167 "RelaxNGParser.yp"
{new W3C::XML::SchemaValidator::NegatedName($_[0], $_[3], $_[2])}
	],
	[#Rule 70
		 'datatypeNameOpt', 0, undef
	],
	[#Rule 71
		 'datatypeNameOpt', 1, undef
	],
	[#Rule 72
		 'datatypeName', 1, undef
	],
	[#Rule 73
		 'datatypeName', 1,
sub
#line 174 "RelaxNGParser.yp"
{$_[0]->YYData->{CONSTANTS}{$DTN_string}}
	],
	[#Rule 74
		 'datatypeName', 1,
sub
#line 176 "RelaxNGParser.yp"
{$_[0]->YYData->{CONSTANTS}{$DTN_token}}
	],
	[#Rule 75
		 'datatypeValue', 1, undef
	],
	[#Rule 76
		 'anyURILiteral', 1, undef
	],
	[#Rule 77
		 'nsUriLit', 1, undef
	],
	[#Rule 78
		 'nsUriLit', 1, undef
	],
	[#Rule 79
		 'inheritOpt', 0, undef
	],
	[#Rule 80
		 'inheritOpt', 1, undef
	],
	[#Rule 81
		 'inherit', 3, undef
	],
	[#Rule 82
		 'idOrKeyOpt', 0, undef
	],
	[#Rule 83
		 'idOrKeyOpt', 1, undef
	],
	[#Rule 84
		 'idOrKey', 1, undef
	],
	[#Rule 85
		 'idOrKey', 1, undef
	],
	[#Rule 86
		 'namespaceName', 1, undef
	],
	[#Rule 87
		 'namespaceName', 1, undef
	],
	[#Rule 88
		 'nameIdentifier', 1,
sub
#line 200 "RelaxNGParser.yp"
{$_[0]->_find_NSAtom($_[1])}
	],
	[#Rule 89
		 'nameIdentifier', 1, undef
	],
	[#Rule 90
		 'identifier', 1,
sub
#line 204 "RelaxNGParser.yp"
{$_[0]->_find_NCNameAtom($NS_default, $_[1])}
	],
	[#Rule 91
		 'identifier', 1, undef
	],
	[#Rule 92
		 'quotedIdentifier', 2, undef
	],
	[#Rule 93
		 'CName', 3,
sub
#line 210 "RelaxNGParser.yp"
{$_[0]->_find_NCNameAtom($_[1], $_[3])}
	],
	[#Rule 94
		 'nsName', 3,
sub
#line 213 "RelaxNGParser.yp"
{$_[0]->_find_NCNameAtom($_[1], $_[3])}
	],
	[#Rule 95
		 'anyName', 1,
sub
#line 216 "RelaxNGParser.yp"
{$_[0]->YYData->{CONSTANTS}{$DTN_anyName}}
	],
	[#Rule 96
		 'literal', 1,
sub
#line 219 "RelaxNGParser.yp"
{new W3C::XML::SchemaValidator::Literal($_[0], $_[1])}
	],
	[#Rule 97
		 'literalSegmentPlus', 1,
sub
#line 222 "RelaxNGParser.yp"
{$_[1]}
	],
	[#Rule 98
		 'literalSegmentPlus', 3,
sub
#line 224 "RelaxNGParser.yp"
{$_[1].$_[3]}
	],
	[#Rule 99
		 'keyword', 1, undef
	],
	[#Rule 100
		 'keyword', 1, undef
	],
	[#Rule 101
		 'keyword', 1, undef
	],
	[#Rule 102
		 'keyword', 1, undef
	],
	[#Rule 103
		 'keyword', 1, undef
	],
	[#Rule 104
		 'keyword', 1, undef
	],
	[#Rule 105
		 'keyword', 1, undef
	],
	[#Rule 106
		 'keyword', 1, undef
	],
	[#Rule 107
		 'keyword', 1, undef
	],
	[#Rule 108
		 'keyword', 1, undef
	],
	[#Rule 109
		 'keyword', 1, undef
	],
	[#Rule 110
		 'keyword', 1, undef
	],
	[#Rule 111
		 'keyword', 1, undef
	],
	[#Rule 112
		 'keyword', 1, undef
	],
	[#Rule 113
		 'keyword', 1, undef
	],
	[#Rule 114
		 'keyword', 1, undef
	],
	[#Rule 115
		 'keyword', 1, undef
	],
	[#Rule 116
		 'keyword', 1, undef
	],
	[#Rule 117
		 'keyword', 1, undef
	],
	[#Rule 118
		 'anoOpt', 0, undef
	],
	[#Rule 119
		 'anoOpt', 3,
sub
#line 249 "RelaxNGParser.yp"
{map {$_[0]->_dispatchParsers($_, $TYPE_prefix)} @{$_[2]}; $_[2]}
	],
	[#Rule 120
		 'anoAttribStar', 3, undef
	],
	[#Rule 121
		 'anoEltStar', 0, undef
	],
	[#Rule 122
		 'anoEltStar', 2,
sub
#line 255 "RelaxNGParser.yp"
{unshift(@{$_[2]},$_[1]); $_[2]}
	],
	[#Rule 123
		 'annotationElement', 4,
sub
#line 258 "RelaxNGParser.yp"
{new W3C::XML::SchemaValidator::Annotation($_[0], $_[1], $_[3])}
	],
	[#Rule 124
		 'anoEltORlitStar', 0, undef
	],
	[#Rule 125
		 'anoEltORlitStar', 2, undef
	],
	[#Rule 126
		 'anoEltORlitStar', 2,
sub
#line 263 "RelaxNGParser.yp"
{unshift(@{$_[2]},$_[1]); $_[2]}
	],
	[#Rule 127
		 'followAnoStar', 0, undef
	],
	[#Rule 128
		 'followAnoStar', 2,
sub
#line 267 "RelaxNGParser.yp"
{unshift(@{$_[2]},$_[1]);$_[2]}
	],
	[#Rule 129
		 'followAnnotation', 3,
sub
#line 270 "RelaxNGParser.yp"
{$_[0]->_dispatchParsers($_[3], $TYPE_follow); $_[3]}
	]
],
                                  @_);
    bless($self,$class);
}

#line 273 "RelaxNGParser.yp"


BEGIN {unshift@INC,('../..');}
use W3C::Util::Exception qw(&throw &catch);
use W3C::Util::NamespaceHandler;

# -------------------- PARSE TREE SUPPORT -------------------- #

sub _make_ReferencePattern {
    my ($self, $identifier) = @_;
    my $data = $self->YYData;
    my $refPat = new W3C::XML::SchemaValidator::ReferencePattern($self, $identifier);
    if (exists $data->{PATTERN_REFERENCES}{$identifier}) {
	push (@{$data->{PATTERN_REFERENCES}{$identifier}}, $refPat);
    } else {
	$data->{PATTERN_REFERENCES}{$identifier} = [$refPat];
    }
    return $refPat;
}

sub registerAnnotationHandler {
    my ($self, $ns, $handler) = @_;
    my $data = $self->YYData;
    if (exists $data->{ANNOT_HANDLERS}{$ns}) {
	&throw(new W3C::Util::Exception(-message => "\"$ns\" annotation handler is already set to $data->{ANNOT_HANDLERS}{$ns}"));
    }
    $data->{ANNOT_HANDLERS}{$ns} = $handler;
}

sub _dispatchParsers {
    my ($self, $annot, $type) = @_;
    $annot->setType($type);
    my $data = $self->YYData;
    if (my $h = $data->{ANNOT_HANDLERS}{$annot->getNamespace()}) {
	$h->parse($annot);
    }
}

sub _resolveReferencePatterns {
    my ($self) = @_;
    my $data = $self->YYData;
    foreach my $ref (keys %{$data->{PATTERN_REFERENCES}}) {
	foreach my $refPat (@{$data->{PATTERN_REFERENCES}{$ref}}) {
	    my $pat = $data->{PATTERNS}{$ref};
	    if (!$pat) {
		&throw(new W3C::Util::Exception(-message => $refPat->toString.' references unknown pattern.'));
	    }
	    $refPat->fixReference($pat);
	}
    }
}

sub _noteAssign {
    my ($self, $assign) = @_;
    $self->YYData->{PATTERNS}{$assign->getId} = $assign;
}

sub _find_NSAtom {
    my ($self, $prefix) = @_;
    my $data = $self->YYData;
    #if ($prefix eq 'local') {
    #	$prefix = '';
    #}
    my $ret = $data->{NCNames}{$prefix};
    if (!$ret) {
	$ret = new W3C::XML::SchemaValidator::Namespace($self, $prefix);
	$data->{NCNames}{$prefix} = $ret;
    }
    return $ret;
}

sub _find_NCNameAtom {
    my ($self, $prefix, $localName) = @_;
    my $data = $self->YYData;
    if ($prefix == $NS_default) {
	undef $prefix
    }
    my $ns = defined $prefix ? $self->YYData->{NAMESPACES}->getNamespace($prefix) : $NS_default;
    if (!$ns) {
	&throw(new W3C::Util::Exception(-message => "namespace for prefix \"$prefix\" not declared."));
    }
    my $ret = $data->{NCNames}{$prefix}{$localName};
    if (!$ret) {
	$ret = new W3C::XML::SchemaValidator::NCName($self, $ns, $prefix, $localName);
	$data->{NCNames}{$prefix}{$localName} = $ret;
    }
    return $ret;
}

sub _registerNamespace {
    my ($self, $prefix, $ns) = @_;
    # $self->YYData->{NAMESPACES}{$prefix eq 'local' ? '' : $prefix} = $ns;
    $self->YYData->{NAMESPACES}->addNamespace($prefix->getNS, $ns);
}

sub _registerDataType {
    my ($self, $prefix, $ns) = @_;
    return $self->_registerNamespace($prefix, $ns);
    #$self->YYData->{DATATYPES}{$prefix} = $ns;
}

# -------------------- ERROR HANDLING -------------------- #
sub _Error {
    my ($self) = @_;
    if (exists $self->YYData->{EXCEPTION}) {
	&throw($self->YYData->{EXCEPTION});
    }
    if (exists $self->YYData->{ERRMSG}) {
	&throw(new W3C::Util::YappDriver::GrammarException(-message => $self->YYData->{ERRMSG}, 
							   -location => $self->YYData->{LOCATION}));
        delete $self->YYData->{ERRMSG};
        return;
    }
    &throw(new W3C::Util::YappDriver::MesgYappContextException($self, -location => $self->YYData->{LOCATION}));
}

sub _Error999 {
    my ($self) = @_;
    if (exists $self->YYData->{ERRMSG}) {
	print $self->YYData->{ERRMSG};
        delete $self->YYData->{ERRMSG};
        return;
    }
    my $parseState = $self->ErrorStrArgs;
    print $self->ErrorStr(@$parseState);
#    print $self->ErrorStr($self->{STACK}, $self->YYData->{INPUT}, pos $self->YYData->{INPUT}, $self->YYData->{my_LASTPOS});
}

sub ErrorStr {
    my ($self, $stack, $input, $pos, $lastPos) = @_;
    my @ret;

    my ($above, $begin, $middle, $end, $below) = $self->ErrContext($input, $pos, $lastPos);
    push (@ret, $self->ErrExpected($middle, $end));
    push (@ret, $self->ErrContextStr($above, $begin, $middle, $end, $below));
    foreach my $entry (@$stack) {
	push (@ret, join (' | ', @$entry));
    }
    return join ("\n", @ret);
}

sub ErrContext {
    my ($self, $input, $pos, $lastPos) = @_;
    my (@above, @below, $begin, $end);
    my $a = substr ($input, 0, $lastPos);
    while ($a =~ m/\G([^\r\n]*[\r\n])/gcm) {
	push (@above, $1);
    }
    if ($a =~ m/\G(.*)\Z/gcm) {
	$begin = $1;
    }

    my $middle = substr ($input, $lastPos, $pos - $lastPos);
    $a = substr ($input, $pos);
    ($end, @below) = split(/\n/, $a);
    return (\@above, $begin, $middle, $end, \@below);
}

sub ErrExpected {
    my ($self, $middle, $end) = @_;
    my $dataStr = substr("$middle$end", 0, 20);
    my $value = $self->YYCurval();
    my $token = $self->YYCurtok();
    my $tokenStr = defined $token && $token ne $value ? "$token " : '';
    my $valueStr = defined $value ? "'$value'" : 'EOF';
    my $expect = undef;
    eval {
	$expect = $self->YYExpect();
    }; if ($@) {
	$expect = '$start';
    }
    return "expected '$expect', got $tokenStr$valueStr at \"$dataStr\".";
}

sub ErrContextStr {
    my ($self, $above, $begin, $middle, $end, $below) = @_;
    my @ret;
    my $aboveStr = join ('', @{$above}[-2..-1]);
    push (@ret, "$aboveStr$begin$middle$end");
    my $spaceStr = ' ' x length ($begin);
    my $middleCol = length ($middle) - 2;
    my $hereStr = $middleCol > 0 ? '-' x $middleCol.'^' : '';
    push (@ret, "$spaceStr^$hereStr");
    my $belowStr = join ("\n", @{$below}[0..2]);
    push (@ret, "$belowStr") if (@$below);
    return join ("\n", @ret);
}

sub ErrorStrArgs {
    my ($self) = @_;
    my $data = $self->YYData;
    my $ret = [[@{$self->{STACK}}], 
	       $data->{INPUT}, 
	       pos $data->{INPUT}, 
	       $data->{my_LASTPOS}];
    return $ret;
}

# ------------------------ STATE MACHINE NAVIGATION ------------------------ #
sub getActions {
    my ($self) = @_;
    my $actions = {};
    my $stack = [@{$self->{STACK}}];
    for (my $stateNo = $stack->[-1][0]; 
	 $stateNo; 
	 $stateNo = $self->followDefault($stack, $stateNo)) {
	if (exists $self->{STATES}[$stateNo]{ACTIONS}) {
	    $actions = {%$actions, %{$self->{STATES}[$stateNo]{ACTIONS}}};
	}
    }
    return $actions;
}

sub followDefault {
    my ($self, $stack, $stateNo) = @_;
    my $state = $self->{STATES}[$stateNo];
    my $def = $state->{DEFAULT};
    if ($def < 0) {
	my ($lhs, $len, $code) = @{$self->{RULES}[-$def]};
	if (unpack('A1',$lhs) eq '@') {
	    $lhs =~ /^\@[0-9]+\-([0-9]+)$/;
	}
	splice(@$stack,-$len,$len);
	my $parentStateNo = $stack->[-1][0];
	push(@$stack,
	     [$self->{STATES}[$parentStateNo]{GOTOS}{$lhs}, 'semval']);

	$def = $self->{STATES}[$parentStateNo]{GOTOS}{$lhs};
    }
    return $def;
}

# -------------------- YACC CALLBACKS -------------------- #
sub _Lexer {
    my($self)=shift;

    do {
	$self->YYData->{my_LASTPOS} = pos $self->YYData->{INPUT},"\n";
    } while ($self->YYData->{INPUT} =~ /\G\s*\#[^\r\n]*[\r\n]/gcm || 
	     $self->YYData->{INPUT} =~ /\G^\s*[\r\n]/gcm || 
	     $self->YYData->{INPUT} =~ /\G\s+/gcm);
    #print "actions: ",join (' | ', keys %$actions),"\n";
    my ($token, $value) = ('', undef);

    # This Lexer knows that:

    # Any quoted thing is a LITERAL_SEGMENT
    if (# exists $actions->{LITERAL_SEGMENT} && 
	$self->YYData->{INPUT} =~ /\G\"([^\"\n]*)\"/gc ||		# '"' (Char - ('"' | newline))* '"'
	$self->YYData->{INPUT} =~ /\G\'([^\'\n]*)\'/gc ||		# "'" (Char - ("'" | newline))* "'"
	$self->YYData->{INPUT} =~ /\G\"\"\"(\"?\"?[^\"]*)\"\"\"/gc ||	# '"""' (['"'] ['"'] (Char - '"'))* '"""'
	$self->YYData->{INPUT} =~ /\G\'\'\'(\'?\'?[^\']*)\'\'\'/gc) {	# "'''" (["'"] ["'"] (Char - "'"))* "'''"
	$token = 'LITERAL_SEGMENT';
	$value = $1;
    } 
    # identifier ::= NCName - keyword
    elsif ($self->YYData->{INPUT} =~ /\G([\w\d_\*][\w\d_\-]*)/gc) {
	my $actions = $self->getActions();
	$token = exists $actions->{'NCName'} && !exists $actions->{$1} ? 'NCName' : $1;
	$value = $1;
    } elsif ($self->YYData->{INPUT} =~ /\G(.)/gc) {
	($token, $value) = ($1, $1);
    }
    return ($token, $value);
}

sub Run {
    my ($self, $loadMe) = @_;
    {
	my $data = $self->YYData;

	$data->{START} = undef;
	$data->{NCNames} = {};
	$data->{PATTERN_REFERENCES} = {};
	$data->{PATTERNS} = {};
	$data->{NAMESPACES} = new W3C::Util::NamespaceHandler();
	$data->{DATATYPES} = {};
	$data->{CONSTANTS} = {
	    $DTN_string => new W3C::XML::SchemaValidator::String($self), 
	    $DTN_token => new W3C::XML::SchemaValidator::Token($self), 
	    $DTN_anyName => new W3C::XML::SchemaValidator::AnyName($self)};
	$data->{LOCATION} = $loadMe;

	$data->{NAMESPACES}->addNamespace('xml', new W3C::XML::SchemaValidator::Literal($self, 'http://www.w3.org/TR/REC-xml'));

	local ($/);
	$/ = undef;
	open (FH, $loadMe) || die "ARGV[0] should be a file (not \"$loadMe\").";
	$data->{INPUT} = <FH>;
	close (FH);
    }
    my $grammar = $self->YYParse( yylex => \&_Lexer, yyerror => \&_Error, yydebug => $main::yydebug);
    return $grammar;
}

# -------------------- UPPER API -------------------- #

sub getStartState {new W3C::XML::SchemaValidator::ParseState($_[0], $_[0]->YYData->{START})}

sub mapNamespace {
    my ($self, $toMap) = @_;
    return $self->YYData->{NAMESPACES}->mapNamespace($toMap);
}

# -------------------- MAIN -------------------- #

#&main (\@ARGV);

sub main::main () {
    my ($argv) = @_;
    eval {
	my $parser = W3C::XML::RelaxNGParser->new();
	my $grammar;
	open (FH, $argv->[0]) || die "ARGV[0] should be a file (not \"$argv->[0]\").";
	close FH;
	eval {
	    $grammar = $parser->Run($argv->[0]);
	}; if ($@) {
	    my $message;
	    if (my $ex = &catch('W3C::Util::Exception')) {
		$message = $ex->toString;
	    } else {
		$message = $@;
	    }
	    my $parseState = $parser->ErrorStrArgs;
	    $message .= $parser->ErrorStr(@$parseState);
	    die $message;
	}
	$parser->_resolveReferencePatterns;
	print $grammar->toString(), "\n";
    }; if ($@) {if (my $ex = &catch('W3C::Util::Exception')) {
	die $ex->toString;
    } else {
	die $@;
    }}
}

@W3C::XML::RelaxNGParser::ISA = qw(W3C::XML::_RelaxNGParser);

1;

__END__

=head1 NAME

W3C::XML::RelaxNGParser - parse RelaxNG compact syntax

=head1 SYNOPSIS

  use W3C::XML::RelaxNGParser;
  my $parser = new W3C::XML::RelaxNGParser();
  $parser->registerAnnotationHandler('http://...', $self);
  my $grammar = $parser->Run('# default namespace = "http://example.com/Personel"
namespace per = "http://example.com/Personel"
namespace addr = "http://example.com/Address"

start = doc

doc = 
  Personel

Personel = 
  element per:Personel {
     PersonelElts+
  }');
  $parser->_resolveReferencePatterns();

  sub parse {
      my ($self, $element) = @_;
      ...
      1;
  }
  sub dispatch {
      my ($self, $element) = @_;
      1;
  }

=head1 DESCRIPTION

B<RelaxNGParser> parses RelaxNG compact syntax schemas. It produces a grammar
which is a tree of SchemaValidatorDataTypes. The grammar can, eventually, be
used to check instance documents against the schema constraints. The perl
module RelaxNGParser.pm is produced by Parse::Yapp from RelaxNGParser.yp. The
accompanying Makefile.PL provides a target called "parsers" which is used to
produce DFAs in the form of perl modules from .yp files. After editing the
.yp file, run
  make parsers

This work is undocumented. See RelaxNGParser.yp.

This module is part of the W3C::XML CPAN module.

=head1 AUTHOR

Eric Prud'hommeaux <eric@w3.org>

=head1 SEE ALSO

W3C::XML::SchemaValidatorDataTypes(3) W3C::XML::SAXParseException(3) perl(1).

=cut

1;
