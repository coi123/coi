#Copyright Massachusetts Institute of technology, 1998.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

# $Id: SAXException.pm,v 1.17 2004/06/06 21:50:09 eric Exp $

use strict;
require Exporter;
require AutoLoader;

$W3C::XML::SAXException::REVISION = '$Id: SAXException.pm,v 1.17 2004/06/06 21:50:09 eric Exp $ ';

package W3C::XML::SAXException;
use vars qw($VERSION $DSLI @ISA @EXPORT @EXPORT_OK);
@ISA = qw(W3C::Util::Exception Exporter AutoLoader);
@EXPORT = qw();
@EXPORT_OK = qw();
$VERSION = 0.92;
$DSLI = 'adpO';

#####
# per-object data
# -message	-  text of warning message
# -exception	-  complete type with whatever exception we write

#####
# new - aggregation of all constructors

#####
# message - get/set message

#####
# exception - get/set exception

#####
# toString - get text format of this exception

sub getSpecificMessage {return $_[0]->{-message} ? $_[0]->{-message} : $_[0]->{-exception}->toString;}
sub getException {return $_[0]->{-exception}}

1;

__END__

=head1 NAME

W3C::XML::SAXException - placeholder for SAX exceptions;

=head1 SYNOPSIS

  @MyException::ISA = qw(W3C::XML::SAXException);

=head1 DESCRIPTION

This is much like an interface file in jave. It advertises a certain set of
methods.

This module is part of the W3C::XML CPAN module.

=head1 AUTHOR

Eric Prud\'hommeaux <eric@w3.org>

=head1 SEE ALSO

W3C::XML::XmlParser(3) W3C::XML::SAXParseException(3) perl(1).

=cut
