#Copyright Massachusetts Institute of technology, 1998.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

# $Id: ErrorHandlerImpl.pm,v 1.12 2004/06/06 21:20:51 eric Exp $

use strict;

$W3C::XML::ErrorHandlerImpl::REVISION = '$Id: ErrorHandlerImpl.pm,v 1.12 2004/06/06 21:20:51 eric Exp $ ';

package W3C::XML::ErrorHandlerImpl;
use W3C::Util::Object;
use vars qw($VERSION $DSLI @ISA @EXPORT @EXPORT_OK @TODO);
use W3C::Util::Exception;
@ISA = qw(W3C::Util::NamedParmObject);
@EXPORT = qw();
@EXPORT_OK = qw();
$VERSION = 0.92;
$DSLI = 'adpO';
@TODO = ();

# this error handler is general enough to handle SAXExceptions and RdfDBExceptions

sub setDocumentLocator {
    my ($self, $documentLocator) = @_;
    $self->{-documentLocator} = $documentLocator;
}

sub warning {
    my ($self, $exception) = @_;
    print 'warning: '.$exception->toString."\n";
}

sub error {
    my ($self, $exception) = @_;
    warn 'error: '.$exception->toString."\n";
}

sub fatalError {
    my ($self, $exception) = @_;
    &throw($exception);
}

1;

__END__

=head1 NAME

W3C::XML::ErrorHandlerImpl - implementation of the SAX ErrorHandler interface

=head1 SYNOPSIS

  my $xmlParser = new W3C::XML::PerlXmlParser;
  use W3C::XML::ErrorHandlerImpl;
  my $errorHandler = new W3C::XML::ErrorHandlerImpl({-documentLocator => $xmlParser});
  $xmlParser->setErrorHandler($errorHandler);

=head1 DESCRIPTION

This is an implementation of the SAX ErrorHandler interface.

This module is part of the W3C::XML CPAN module.

=head1 AUTHOR

Eric Prud\'hommeaux <eric@w3.org>

=head1 SEE ALSO

W3C::XML::XmlParser(3) W3C::XML::SAXParseException(3) perl(1).

=cut

