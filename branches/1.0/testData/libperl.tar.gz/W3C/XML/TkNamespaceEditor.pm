package W3C::XML::TkNamespaceEditor;

use strict;
use vars qw($VERSION $SET_PALETTE);
$VERSION = '3.026'; # $Id: TkNamespaceEditor.pm,v 1.3 2004/03/29 06:45:50 eric Exp $

use Tk qw(lsearch Ev);
use Tk::Toplevel;
use base  qw(Tk::Toplevel);
Construct Tk::Widget 'TkNamespaceEditor';

%Tk::TkNamespaceEditor::names = ();


use Tk::Dialog;
use Tk::Pretty;

BEGIN { $SET_PALETTE = 'Set Palette' };

use subs qw(color_space hsvToRgb rgbToHsv);

sub ApplyDefault1
{
 my($objref) = @_;
 my $cb = $objref->cget('-command');
 my $h;
 foreach $h (@{$objref->{'highlight_list'}})
  {
   next if $h =~ /TEAR_SEP|SEP/;
   $cb->Call($h);
   die unless (defined $cb);
  }
}

sub Populate
{

    # TkNamespaceEditor constructor.

    my($self, $args) = @_;

    $self->SUPER::Populate($args);
#    $self->withdraw;
#    return;

    # build list of known sourceIds
    my %everyDamnedResource;
    foreach my $sourceId (keys %{$args->{-namespaceHandler}{NAMESPACE_REVERSE}}) {
	$everyDamnedResource{$sourceId} = 1;
    }
    foreach my $sourceId (keys %{$args->{-knownAttributions}}) {
	$everyDamnedResource{$sourceId} = 1;
    }
    foreach my $sourceId (keys %{$args->{-attributionsByInputSource}}) {
	$everyDamnedResource{$sourceId} = 1;
    }
    # put 'em all in a BrowseEntry
    my $sourceIdWidget = $self->BrowseEntry(-label => 'source ID', -variable => \ $self->{-sourceIdVariable});
    foreach my $sourceId (keys %everyDamnedResource) {
	$sourceIdWidget->insert('end', $sourceId);
    }
    $sourceIdWidget->pack(-side => 'top', -fill => 'both');

    $self->{-namespaceWidget} = $self->BrowseEntry(-label => 'namespace', 
						   -variable => \ $self->{-namespaceVariable}, 
						   -listcmd => sub {$self->fillNamespaceEntry}, 
						   -browsecmd => sub {$self->fillUrlWidget});
    $self->{-namespaceWidget}->pack(-side => 'top', -fill => 'both');

    $self->{-urlWidget} = $self->LabEntry(-label => 'URL', -textvariable => \ $self->{-urlVariable});
    $self->{-urlWidget}->pack(-side => 'top', -fill => 'both');

    my $buttonFrame = $self->Frame;
    $buttonFrame->pack(-side => 'bottom', -fill => 'x');
    my $ok = $buttonFrame->Button(-text => 'OK', -command => sub {$self->buttonHandler('OK')});
    $ok->pack(-side => 'left');
    my $cancel = $buttonFrame->Button(-text => 'cancel', -command => sub {$self->buttonHandler('cancel')});
    $cancel->pack(-side => 'right');

    # Create the status window.

    my $status = $self->Toplevel;
 #   $status->withdraw;
    $status->geometry('+0+0');
    my $status_l = $status->Label(-width => 50,  -anchor => 'w');
    $status_l->pack(-side => 'top');

    $self->ConfigSpecs(DEFAULT         => [$self->{-namespaceWidget}],
		       -widgets        => ['PASSIVE', undef, undef,
					   [$self->parent->Descendants]],
		       -display_status => ['PASSIVE', undef, undef, 0],
		       -title          => ['PASSIVE', undef, undef, ''],
		       -defaultNamespace => ['PASSIVE', undef, undef],
		       -windowSet        => ['PASSIVE', undef, undef],
		       -namespaceHandler	=> ['PASSIVE', undef, undef], 
		       -knownAttributions => ['PASSIVE', undef, undef], 
		       -attributionsByInputSource => ['PASSIVE', undef, undef], 
    );
} # end Populate, TkNamespaceEditor constructor

sub Show {

    my($objref) = @_;

    $objref->deiconify;

} # end show

sub fillNamespaceEntry {
    my ($self) = @_;

    # clear out the current list
    $self->{-namespaceWidget}->delete(0, 'end');
    $self->{-urls} = {};

    # add values for currently selected sourceId
    my $sourceId = $self->{-sourceIdVariable};
    if (my $namespaces = $self->cget(-namespaceHandler)->{NAMESPACE_REVERSE}{$sourceId}) {
	foreach my $url (keys %$namespaces) {
	    my $namespace = $namespaces->{$url};
	    $self->{-namespaceWidget}->insert('end', $namespace);
	    $self->{-urls}{$sourceId}{$namespace} = $url;
	}
    }
}

sub fillUrlWidget {
    my ($self) = @_;

    if (!$self->{-urlVariable} || $self->{-urlVariable} eq $self->{-urlLast}) {
	$self->{-urlLast} = $self->{-urlVariable} = $self->{-urls}{$self->{-sourceIdVariable}}{$self->{-namespaceVariable}};
    }
}

sub buttonHandler {
    my ($self, $action) = @_;
    if ($action eq 'OK') {
	my $namespaceHandler = $self->cget(-namespaceHandler);
	my $namespace = $self->{-namespaceVariable};
	my $url = $self->{-urlVariable};
	my $sourceId = $self->{-sourceIdVariable};
	if ($sourceId) {
	    if ($namespace && $url) {
		$namespaceHandler->addNamespace($namespace, $url, $sourceId);
	    } elsif ($url) {
		delete $namespaceHandler->{NAMESPACE_REVERSE}{$sourceId}{$url};
	    } elsif ($namespace) {
		delete $namespaceHandler->{NAMESPACE_REVERSE}{$sourceId}{$self->{-urls}{$sourceId}{$namespace}};;
	    } else {
		delete $namespaceHandler->{NAMESPACE_REVERSE}{$sourceId};
	    }
	    $self->cget(-windowSet)->refreshList;
	}
    }
    $self->destroy;
}

1;

__END__

=cut

