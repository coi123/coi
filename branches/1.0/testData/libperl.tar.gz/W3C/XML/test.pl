#!/usr/bin/perl
# Before `make install' is performed this script should be runnable with
# `make test'. After `make install' it should work as `perl test.pl'

######################### We start with some black magic to print on failure.

# Change 1..1 below to 1..last_test_to_print .
# (It may become useful if the test is moved to ./t subdirectory.)

BEGIN {unshift@INC,('../..');}
BEGIN { $| = 1; print "1..2\n"; }
END {print "not ok 1\n" unless $loaded;}
use W3C::XML::XmlParser;
$loaded = 1;
print "ok 1\n";

# This section of testing requires DOM.
use XML::DOM;
# Prepare a DOM.
my $parser = new XML::DOM::Parser();
my $doc = $parser->parsefile('test/test1.xhtml');
my $Expect1 = '<p id="name"><a class="annolink" href="/annotations"><img src="/annot-icons/annotea_home.png" alt="Annotea" style="border:none;"/></a></p> | <p name="name">You must have a user account before using this service.</p>';

use W3C::XML::XPathParser;
use W3C::Util::Exception;
eval {
    my $xpath = new W3C::XML::XPathParser();
    # my @bodyEl = $xpath->match($doc, '/html[1]/head[1]', 0, undef);
    # my $spot = $xpath->create($bodyEl[0], 'script[@type="text/javascript"]/text("some text")', 0);
    #my $bodyEls = $xpath->getMatchingNodeSet($doc, '//body[1]', 0, undef);
    my @bodyEls = $xpath->match($doc, '//body[1]', 0, undef);
    my $spot = $xpath->create($bodyEls[0], 'ul[@id="annotIndex"]/li', 0);
    # print $spot->toString();

    foreach my $testStr ('string-range(html[1]/body[1]/p[2],"",4,2)', 
			 'string-range(id("name1"),"",4,2)', 
			 'html[1]/body[1]/p[1]/a[1]/img[1]', 
			 '//*[@id=\'name1\' or @name=\'name1\']', 
			 '//*[@id=\'name\' or @name=\'name\']', 
			 'html[1]/body[1]/p[1]/a[1]/img[1]', 
			 'start-point(string-range(id("name1"),"",4,2))', 
			 'end-point(string-range(id("name1"),"",4,2))', 
			 'html[1]/body[1]/p[2]', ) {
	print "trying $testStr ::\n";
	my @ret = $xpath->xpointer($doc, $testStr, 0, undef);
	print join(' | ', map {$_->toString()} @ret),"\n";
    }
    # my @ret = $xpath->match($doc, 'html[1]/body[1]/p[1]/a[1]/img[1]', 0, undef);
    my @ret = $xpath->match($doc, '//*[@id=\'name\' or @name=\'name\']', 0, undef);
    if (join(' | ', map {$_->toString()} @ret) eq $Expect1) {
	print "ok 2\n";
    }
}; if ($@) {
    if (my $ex = &catch('W3C::Util::Exception')) {
	die $ex->toString;
    } else {
	die $@;
    }
}

######################### End of black magic.

# Insert your test code below (better if it prints "ok 13"
# (correspondingly "not ok 13") depending on the success of chunk 13
# of the test code):

