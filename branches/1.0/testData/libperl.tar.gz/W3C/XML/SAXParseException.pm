#Copyright Massachusetts Institute of technology, 1998.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

# $Id: SAXParseException.pm,v 1.31 2004/06/06 21:55:29 eric Exp $

use strict;
require Exporter;
require AutoLoader;

use W3C::XML::SAXException;

$W3C::XML::SAXParseException::REVISION = '$Id: SAXParseException.pm,v 1.31 2004/06/06 21:55:29 eric Exp $ ';

package W3C::XML::SAXParseException;
use vars qw($VERSION $DSLI @ISA @EXPORT @EXPORT_OK);
@ISA = qw(W3C::Util::BaseContextException W3C::XML::SAXException);
@EXPORT = qw();
@EXPORT_OK = qw();
$VERSION = 0.92;
$DSLI = 'adpO';

sub new {
    my ($proto, @parms) = @_;
    my $class = ref($proto) || $proto;

    # Put in phony contextID so we don't have to parse @parms twice.
    my $self = $class->SUPER::new(-contextID => undef, @parms);
    $self->missingParm('-locator') if (!exists $self->{-locator});
    $self->{-contextID} = $self->{-locator};

    if ($self->{-locator}->can('getContextString')) {
	($self->{-head}, $self->{-lineHead}, $self->{-ctxString}, 
	 $self->{-indicator}, $self->{-lineTail}, $self->{-tail}, 
	 $self->{-line}, $self->{-column}) = 
	     $self->{-locator}->getContextString('context: ', undef, 71);
    }
    $self->{-location} = $self->{-locator}->getPublicId;
    $self->fillInStackTrace;
    return $self;
}

sub getLocationString {
    my ($self) = @_;
    my $loc = $self->{-locator}->getPublicId ? $self->{-locator}->getPublicId : $self->{-locator}->getSystemId;
    my $prefix = "$loc:".
	$self->{-locator}->getLineNumber.':'.$self->{-locator}->getColumnNumber;
    $prefix .= '('.$self->{-locator}->getByteNumber.')' if ($self->{-locator}->can('getByteNumber'));
    return $prefix;
}

package W3C::XML::DieSAXParseException;
@W3C::XML::DieSAXParseException::ISA = qw(W3C::XML::SAXParseException);

sub new {
    my ($proto, @parms) = @_;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new(@parms);
    $self->missingParm('-dieException') if (!$self->{-dieException});
    $self->{-errorMessage} = $self->{-dieException};
    $self->{-errorMessage} =~ s/^\s*//;
    $self->{-errorMessage} =~ s/\s*$//;
    $self->fillInStackTrace;
    return $self;
}

package W3C::XML::ChainedSAXParseException;
@W3C::XML::ChainedSAXParseException::ISA = qw(W3C::XML::SAXParseException);
sub new {
    my ($proto, @parms) = @_;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new(@parms);
    $self->missingParm('-chainedException') if (!$self->{-chainedException});
    $self->{-origException} = $self->{-chainedException};

    my ($message, @st) = split("\n", $self->{-chainedException}->getMessage);
    $self->{-message} = join ("\n  ", ($message, @st));
    if ($self->{-locator}) {
	my $lineCol = $self->getLocationString;
    }
    $self->fillInStackTrace;
    return $self;
}

package W3C::XML::SAXParseException;

1;

__END__

=head1 NAME

W3C::XML::SAXParseException - report XML parsing errors

=head1 SYNOPSIS

  use W3C::XML::SAXParseException;
  sub startElement {
    ...
    $self->{-errorHandler}->warning(
      new W3C::XML::SAXParseException (-message => "big trouble in little China.", 
				       -locator => $self->{DOCUMENT_LOCATOR}));

=head1 DESCRIPTION

Used by XML parsers or subordinate parsers.

This module is part of the W3C::XML CPAN module.

=head1 AUTHOR

Eric Prud\'hommeaux <eric@w3.org>

=head1 SEE ALSO

W3C::XML::XmlParser(3) W3C::XML::SAXException(3) perl(1).

=cut
