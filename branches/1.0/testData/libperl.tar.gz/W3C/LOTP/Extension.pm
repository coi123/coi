#Copyright Massachusetts Institute of technology, 2000.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

use strict;
require Exporter;
require AutoLoader;

$W3C::LOTP::Extension::REVISION = '$Id: Extension.pm,v 1.2 2000/03/23 04:06:15 eric Exp $ ';

package W3C::LOTP::Extension;
use vars qw($VERSION $DSLI @ISA @EXPORT @EXPORT_OK);
@ISA = qw(Exporter AutoLoader); # <annote:implements name="Extendable"/>


use W3C::Util::Exception;
@EXPORT = qw();
@EXPORT_OK = qw();
$VERSION = 0.01;
$DSLI = 'adpO';

#####
# Externally available constants
*W3C::LOTP::Extension::ONE = \ 'one';

sub new {
    my ($proto, @parms) = @_;
    my $class = ref($proto) || $proto;
    my $self;
    if (ref $parms[0] eq 'HASH') {
	$self = $parms[0];
    } elsif (!ref $parms[0] && !(@parms % 2)) {
	$self = {@parms};
    } else {
	&throw(new W3C::Util::Exception(-parameter => $parms[0], -message => $class.' must be constructed with a HASH, not a '.ref $parms[0]));
    }
    eval {
	bless ($self, $class);
    }; if ($@) {
	&throw(new W3C::Util::Exception($@));
    }
    return $self;
}

sub registerNamespaceHandler {
    my ($self, $namespace, $handler) = @_;
    $handler ||= $self;
    $self->{-core}->registerNamespaceHandler($namespace, $handler);
}

# <annote:interface name="Extendable">
sub extendables {
    my ($self) = @_;
    &throw(new W3C::Util::NotImplementedException());
}
# </annote:interface>

1;

__END__

=head1 NAME

W3C::LOTP::Extension - Common LOTP Object Storage

=head1 SYNOPSIS

    use W3C::LOTP::Extension;
    package testLOTPInterface;
    @testLOTPInterface::ISA = qw(W3C::Rdf::RdfApp);

    my $tester = new testLOTPInterface;
    $tester->execute(\@ARGV);

    sub render {
	my ($self) = @_;
	$query = "(ask '((http://www.w3.org/schema/certHTMLv1/access ?x \"acc1\") 
(?y ?x \"http://user1\"))
:collect ?x)" if (!$query);
	my ($nodes2, $messages) = $self->{RDF_DB}->algae($query, $self->{RDF_PARSER}->{REVISION});
    }

=head1 DESCRIPTION

Common LOTP Object Storage.

This module is part of the W3C::LOTP CPAN module suite.

=head1 ARGUMENTS

=item B<@<file>> - read arguments from <file>

=item B<...>

=item B<>

=item B<>

=item B<>

=head1 AUTHOR

Eric Prud\'hommeaux <eric@w3.org>

=head1 SEE ALSO

W3C::LOTP::CGI(3) perl(1).

=cut
