#Copyright Massachusetts Institute of technology, 2000.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

use strict;
require Exporter;
require AutoLoader;

$W3C::LOTP::TransferAdapters::CGI::REVISION = '$Id: CGI.pm,v 1.1 2000/03/12 22:42:12 eric Exp $ ';

package W3C::LOTP::TransferAdapters::CGI;
use vars qw($VERSION $DSLI @ISA @EXPORT @EXPORT_OK);
@ISA = qw(Exporter AutoLoader);

use W3C::LOTP::Core;
use W3C::LOTP::TransferAdapter;
use W3C::Util::Exception;
@ISA = qw(W3C::LOTP::TransferAdapter);
@EXPORT = qw();
@EXPORT_OK = qw();
$VERSION = 0.01;
$DSLI = 'adpO';

#####
# Externally available constants
*W3C::LOTP::TransferAdapters::CGI::ONE = \ 'one';

sub new {
    my ($proto, $ARGV) = @_;
    my $class = ref($proto) || $proto;
    my $self = {};
    bless ($self, $class);
    $self->{CORE} = new W3C::LOTP::Core;
    return $self;
}

sub getCore {
    my ($self) = @_;
    return $self->{CORE};
}

sub handleNUKE {
    my ($self, @args) = @_;
    return $self->{CORE}->handle(@args);
}

1;

__END__

=head1 NAME

W3C::LOTP::TransferAdapters::CGI - LOTP TransferAdapters::CGI Interface

=head1 SYNOPSIS

    use W3C::LOTP::TransferAdapters::CGI;
    package testLOTPInterface;
    @testLOTPInterface::ISA = qw(W3C::Rdf::RdfApp);

    my $tester = new testLOTPInterface;
    $tester->execute(\@ARGV);

    sub render {
	my ($self) = @_;
	$query = "(ask '((http://www.w3.org/schema/certHTMLv1/access ?x \"acc1\") 
(?y ?x \"http://user1\"))
:collect ?x)" if (!$query);
	my ($nodes2, $messages) = $self->{RDF_DB}->algae($query, $self->{RDF_PARSER}->{REVISION});
    }

=head1 DESCRIPTION

LOTP CGI Interface.

This module is part of the W3C::LOTP CPAN module suite.

=head1 ARGUMENTS

=item B<@<file>> - read arguments from <file>

=item B<...>

=item B<>

=item B<>

=item B<>

=head1 AUTHOR

Eric Prud\'hommeaux <eric@w3.org>

=head1 SEE ALSO

W3C::LOTP::Core(3) perl(1).

=cut
