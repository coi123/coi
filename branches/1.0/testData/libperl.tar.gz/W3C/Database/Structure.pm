#Copyright Massachusetts Institute of technology, 1998.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

# $Id: Structure.pm,v 1.3 2004/06/12 05:54:29 eric Exp $

use strict;

package W3C::Database::Structure;
use vars qw($VERSION $REVISION $DSLI @ISA @EXPORT @EXPORT_OK @TODO);
$REVISION = '$Id: Structure.pm,v 1.3 2004/06/12 05:54:29 eric Exp $ ';
@ISA = qw(Exporter);
@EXPORT = qw();
$VERSION = 0.10;
$DSLI = 'adpO';
@TODO = ('', 
	 );

package W3C::Database::Structure::Table;
sub new {
    my ($proto, $name) = @_;
    my $class = ref($proto) || $proto;
    my $self = {NAME => $name, INDEXES => {}, PRIMARY_KEY => undef, FIELDS => {}};
    bless ($self, $class);
    return $self;
}

sub getName {return $_[0]->{NAME}}
sub getFieldNames {return keys %{$_[0]->{FIELDS}}}
sub getFieldByName {return $_[0]->{FIELDS}{$_[1]}}
sub getPrimaryKey {return $_[0]->{PRIMARY_KEY}}

sub addField {$_[0]->{FIELDS}{$_[1]->getName} = $_[1]}
sub addIndex {$_[0]->{INDEXES}{$_[1]->getName} = $_[1]; $_[0]->{PRIMARY_KEY} = $_[1] if($_[1]->isa('W3C::Database::Structure::PrimaryKey'))}
sub toString {
    my ($self, @flags) = @_;

    my @strs;
    my $pkStr = $self->{PRIMARY_KEY} ? $self->{PRIMARY_KEY}->getName : '-none-';
    @strs = ();
    foreach my $fieldName (keys %{$self->{FIELDS}}) {
	push (@strs, $self->{FIELDS}{$fieldName}->toString);
    }
    my $fieldStr = join ("\n         ", @strs);

    @strs = ();
    foreach my $indexName (keys %{$self->{INDEXES}}) {
	push (@strs, $self->{INDEXES}{$indexName}->toString);
    }
    my $indexStr = join ("\n          ", @strs);

    return "$self->{NAME}:\n indexes: $indexStr\n primarky key: $pkStr\n fields: $fieldStr";
}

package W3C::Database::Structure::Field;
sub new {
    my ($proto, $table, $name, $default, $type, $size) = @_;
    my $class = ref($proto) || $proto;
    my $self = {TABLE => $table, NAME => $name, TARGET => undef, DEFAULT => $default, TYPE => $type, SIZE => $size};
    bless ($self, $class);
    return $self;
}

sub getName {return $_[0]->{NAME}}
sub getTable {return $_[0]->{TABLE}}
sub setTarget {$_[0]->{TARGET} = $_[1]}
sub getTarget {return $_[0]->{TARGET}}

sub toString {
    my ($self, @flags) = @_;
    my @fields;
    push (@fields, "$self->{NAME}");
    if ($self->{TARGET}) {
	push (@fields, '-> '.$self->{TARGET}->getTable->getName.'.'.$self->{TARGET}->getName);
    }
    if (defined $self->{DEFAULT}) {
	push (@fields, "[$self->{DEFAULT}] ");
    }
    if (defined $self->{TYPE}) {
	push (@fields, $self->{TYPE});
    }
    if (defined $self->{SIZE}) {
	push (@fields, "[$self->{SIZE}] ");
    }
    return join (' ', @fields);
}

package W3C::Database::Structure::Index;
sub new {
    my ($proto, $table, $name, $sequence, $unique) = @_;
    my $class = ref($proto) || $proto;
    my $self = {TABLE => $table, NAME => $name, SEQUENCE => $sequence, UNIQUE => $unique};
    bless ($self, $class);
    return $self;
}

sub getName {return $_[0]->{NAME}}
sub getTable {return $_[0]->{TABLE}}
sub getSequence {return $_[0]->{SEQUENCE}}

sub toString {
    my ($self, @flags) = @_;
    my $seqStr = join (',', map {$_->getName} @{$self->{SEQUENCE}});
    my $uniqueStr = $self->{UNIQUE} ? 'UNIQUE' : '';
    return "$self->{NAME}:$uniqueStr $seqStr";
}

@W3C::Database::Structure::PrimaryKey::ISA = ('W3C::Database::Structure::Index');

1;

__END__

=head1 NAME

W3C::Database::Structure - Representation of a Database Table Schema

=head1 SYNOPSIS

@@@ sorry, nothing here. Used in W3C::Rdf::SqlDB @@

=head1 DESCRIPTION

This module is part of the W3C::Database CPAN module.

=head1 AUTHOR

Eric Prud'hommeaux <eric@w3.org>

=head1 SEE ALSO

L<W3C::Rdf::SqlDB>

=cut
