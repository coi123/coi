#!/bin/sh

echo a.gdbm: '(../bin/ddb ifg=a.gdbm idelim=: odelim=:)'
../bin/ddb ifg=a.gdbm idelim=: odelim=:

echo b.gdbm: '(../bin/ddb ifg=b.gdbm idelim=: odelim=:)'
../bin/ddb ifg=b.gdbm idelim=: odelim=:

echo diff a and b '(../bin/ddb ifg=a.gdbm idelim=: cfg=b.gdbm cdelim=: op=diff odelim=:)'
../bin/ddb ifg=a.gdbm idelim=: cfg=b.gdbm cdelim=: op=diff odelim=:
echo 'compare with'
cat a2b.diff

echo diffc a and b '(../bin/ddb ifg=a.gdbm idelim=: cfg=b.gdbm cdelim=: op=diffc odelim=:)'
../bin/ddb ifg=a.gdbm idelim=: cfg=b.gdbm cdelim=: op=diffc odelim=:
echo 'compare with'
cat a2b.diffc

echo patch a to make it identical to b '(../bin/ddb ifg=a.gdbm idelim=: cf=a2b.diff cdelim=: op=patch odelim=: |../bin/ddb idelim=: cfg=b.gdbm cdelim=: op=diff odelim=:)'
../bin/ddb ifg=a.gdbm idelim=: cf=a2b.diff cdelim=: op=patch odelim=: |../bin/ddb idelim=: cfg=b.gdbm cdelim=: op=diff odelim=:
echo 'should be empty'

