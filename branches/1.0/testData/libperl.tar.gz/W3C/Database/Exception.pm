#Copyright Massachusetts Institute of technology, 1998.
#Written by Eric Prud'hommeaux for the World Wide Web Consortium

use strict;

require Exporter;
require AutoLoader;

package W3C::Database::Exception;
use W3C::Util::Exception;

use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);
@ISA = qw(W3C::Util::Exception Exporter AutoLoad);
@EXPORT = qw();
@EXPORT_OK = qw();
$VERSION = 0.20;

$W3C::Database::Exception::revision = '$Id: Exception.pm,v 1.7 2004/06/09 09:19:06 eric Exp $ ';

#@W3C::Database::DatabaseException::ISA = qw(W3C::Util::Exception);

sub new {
    my ($proto, @parms) = @_;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new(@parms);
    return $self->missingParm('-database') if (!$self->{-database});
    $self->fillInStackTrace;
    return $self;
}
sub getSpecificMessage {return $_[0]->{-message}.' error in the "'.$_[0]->getDatabase.'" database';}
sub getDatabase {return $_[0]->{-database};}

1;

__END__

=head1 NAME

W3C::Database::Exception - base class for database Exceptions

=head1 SYNOPSIS

    use W3C::Database::Exception;

=head1 DESCRIPTION

Not documented. Pretty standard base class for exceptions related to database access.

This module is part of the W3C::Database CPAN module.

=head1 AUTHOR

Eric Prud'hommeaux <eric@w3.org>

=head1 SEE ALSO

L<W3C::Util::Exception>

=cut
