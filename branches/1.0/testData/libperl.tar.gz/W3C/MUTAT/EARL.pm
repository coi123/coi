package EARL;
use warnings;
use URI::Escape;
use RDFtest;

sub new {
   (my $class, $cloud) = @_;
   
   @Assertions = ();
   $Assertor = '';
   $Tool = '';
   @Description = ();
   
   my $self = {};	
   bless($self, $class);
   return $self;
}

sub maketag {
   my ($self, %params) = @_;
   my $out = '<' . $params{'name'};
   foreach my $included (keys(%{$params{'modify'}})) {
   	$out .= ' ' . $included . '=' . '"' . $params{'modify'}{$included} . '"';
   }
   if ($params{'content'}) {
	$out .= '>' . $params{'content'} . '</' . $params{'name'} . '>';
   } else {
   	$out .= '/>';
   }
   return $out;
}

#make the Assertor a FOAF person - in progress 200501 CMN

sub create_assertor {
 my ($self, $unique_uri, %props) = @_;
 my @temp = ();
 push @temp, $self->maketag(name => 'rdf:type', modify => {'rdf:resource' => $cloud->{ns}{foaf}.'Person'});
 foreach (keys %props) {
   my $val = $props{$_};
   if ($val =~ /@/) { $val = "mailto:$val"; }
   if ($val =~ /http:|mailto:/) {
     push @temp, $self->maketag(name => $cloud->contract($_), modify => {'rdf:resource' => $val});
   } else {
     push @temp, $self->maketag(name => $cloud->contract($_), content => $val);
   }
 }
 $Assertor = $self->maketag(name => 'earl:Assertor', modify => {'rdf:about' => $unique_uri}, content => join "\n", @temp);
}

 sub add_assertion {
   my ($self, %triple) = @_;
 
   $triple{'predicate'} = $cloud->expand($triple{'predicate'});
   
   my @temp = ();
   for my $part (keys %triple) {
     next unless $triple{$part};
     my $val = $triple{$part};
     if ($val =~ /@/) { $val = "mailto:$val"; }
     if ($val =~ /http:|mailto:/) {
       push @temp, $self->maketag(name => $part, 
				  modify => {'rdf:resource' => $val});
     } else {
       push @temp, $self->maketag(name => $part, content => $val);
     }
   }
     my $assertion = $self->maketag(name=>'earl:Assertion', content=>join ("\n", @temp));
     push @Assertions, $assertion;
 }
 sub create_tool {
 	my ($self, $type, $unique_uri, %props) = @_;
 	my @temp = ();
	foreach (keys %props) {
	  my $val = $props{$_};
	  if ($val =~ /http:|mailto:/) {
	    push @temp, $self->maketag(name => $cloud->contract($_), modify => {'rdf:resource' => $val});
	  } else {
	    push @temp, $self->maketag(name => $cloud->contract($_), content => $val);
	  }
	}
 	$Tool = $self->maketag(name=>'earl:'.$type, modify=>{'rdf:about'=>$unique_uri}, content=>join("\n", @temp));
 }

sub add_description {
  my ($self, $name, $hash) = @_;
  my @temp = ();
  foreach $param (keys %$hash) {
    if ($hash->{$param} =~ /^http:/) {
      push @temp, $self->maketag(name=>$cloud->contract($param),
				 modify=>{'rdf:resource'=>$hash->{$param}});
    } else {
      push @temp, $self->maketag(name=>$cloud->contract($param),
				 content=>$hash->{$param});
    }
  }
  return push @Description, $self->maketag(name=>'rdf:Description',
					   modify=>{'rdf:about'=>$name},
					   content=>join("\n", @temp));
}

 sub out {
   ($self) = @_;
   my %xmlns = ();
   foreach $n (keys(%{$cloud->{rev_ns}})) {
     my $name = $cloud->{rev_ns}{$n};
     $xmlns{$name ? "xmlns:$name" : 'xmlns'} = $n; 
   }
   return '<?xml version="1.0" ?>' . $self->maketag(name=>'rdf:RDF',
						    modify=>\%xmlns,
						    content=>join("\n\n", (@Assertions, $Assertor, $Tool, @Description)));
 }

"1";
