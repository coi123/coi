
package RDFtest;

require LWP::Simple;
require RDFcloud;

sub new {
  my ($class, $url) = @_;

  if (!$url) {return;}
  my $content = get_n3_content($url);  
  if (!$content) {return;}
  my $test = RDFcloud->new($content);
  my $earl = $test->{ns}{'earl'};
  $earl =~ s/#/.n3/;
  $content = get_n3_content($earl);
  $test->add($content);
  my $td = $test->{ns}{'td'};
  $td =~ s/#//;
  $content = get_n3_content($td);
  $test->add($content);
  $test->parse;
  my $self = {
	      test => $test,
	     };
  bless($self, $class);  
  return $self;
}

sub get_n3_content {
  my ($url) = @_;
  my $content = LWP::Simple::get($url);
  if (!$content) {return;}
  return $content;
}

sub get {
  my ($self, $TEST_id, $property) = @_;
  return $self->{test}->get_property('earl:TestCase', $TEST_id, $property);
}

sub get_testcase {
  my ($self, $TEST_id) = @_;
  return $self->{test}->get_properties('earl:TestCase', $TEST_id);
}

sub get_unique {
  my ($self, $property) = @_;
  return $self->{test}->get_unique('earl:TestCase', $property);
}

sub size {
  my ($self) = @_;
  return $self->{test}->size('earl:TestCase');
}

sub increment_test {
  my ($self, $TEST_id, %groups) = @_;
  OUT: while (++$TEST_id <= $self->size) {
    last OUT unless %groups;
    foreach $group (keys %groups) {
	next OUT unless (!$groups{$group} or grep $_ eq $self->get($TEST_id, $group), @{$groups{$group}});
      }
    last OUT;
  }
    return $TEST_id;
}

sub get_groups {
  my ($self) = @_;
  my ($names, $properties) = $self->{'test'}->get_incidence('td:GroupProperty');
  return @$names;
}

sub get_result_properties {
  my ($self) = @_;
  my (@labels, @vals) = ();
  my $source = $self->{test}->exists_class('td:ResultProperty') ? 'td' : 'earl';
  my ($names, $properties) = $self->{'test'}->get_incidence($source.':ResultProperty');
  foreach (@$names) {
    $labels{$_} = $properties->{$_}{$self->{'test'}->expand('rdfs:label')};
    push @vals, $_;
  }
  return (\@vals, \%labels);
}

sub get_app_props {
  my ($self, $value) = @_;
  my @cases = $self->{test}->get_filtered_properties ('rdf:Property', 'rdfs:domain', $value) ;
  return @cases;
}

sub get_disp_props {
  my ($self, $value) = @_;
  my @cases = $self->{test}->get_filtered_properties ('td:DisplayedProperty', 'rdfs:domain', $value) ;
  return @cases;
}

