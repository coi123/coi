echo if necessary run this
echo sudo /etc/init.d/httpd stop
sudo java -cp bin/Euler.jar:bin/Euler_Tests.jar euler.Codd $*
