namespace Eulersharp 
{

  /// <summary>
  /// Contains the version
  /// </summary>
  public class Version {

    /// major verion number of this component 
    public const int MAJOR = 1;
    /// minor version number of this component 
    public const int MINOR = 5;
    /// build number of this component 
    public const int BUILD = 94;

  }

}
