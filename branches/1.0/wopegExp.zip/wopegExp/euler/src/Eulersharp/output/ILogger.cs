namespace Eulersharp.Output 
{

  /// <summary>
  /// This interface defines the methods to log a certain message to a log system
  /// </summary>
  public interface ILogger 
  {

    /// <summary>
    /// This method logs a certain message to a log system 
    /// </summary>
    /// <param name="className">the name of the class that initiated the message</param>
    /// <param name="methodName">the method that initiated the log message</param>
    /// <param name="message">the log message</param>
    /// <param name="logLevel">the log level</param>
    void Log(string className, string methodName, string message, Outputter.LOGLEVEL logLevel);

  }

}