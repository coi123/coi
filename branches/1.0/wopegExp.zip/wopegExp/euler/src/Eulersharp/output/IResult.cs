namespace Eulersharp.Output
{

  /// <summary>
  /// This interface specifies methods for reporting the 
  /// result of a test case
  /// </summary>
  public interface IResult 
  {

    /// <summary>
    /// This method reports the result of a test case
    /// </summary>
    /// <param name="testCase">the name of the test case</param>
    /// <param name="result">the result of the test case</param>
    void Result(string testCase, string result);

  }
}