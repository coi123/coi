// $Id: EulerExt.cs 3137 2009-10-20 22:05:55Z josd $

namespace Eulersharp {

using System;
using System.Collections;

/// <summary>Euler extensions</summary>
/// <author>Jos De Roo</author>

public class EulerExt {

  internal Hashtable ns = null;                 // to table namespaces
  internal Hashtable nsp = null;                // to table namespace prefixes
  internal Hashtable kw = null;                 // to table keywords
  internal Hashtable syn = null;                // to table synonyms
  internal Hashtable ocl = null;                // to table classes
  internal Hashtable dds = null;                // to table log:definitiveDocument and Service properties
  internal Hashtable dsg = null;                // to table derived subgoals
  internal int varmax = 0;                      // maximum variable count
  internal String baseURI = "";                 // URI of base process
  internal ArrayList loaded = null;             // to table document/engine pairs
  internal long engine = 1;                     // number of engines
  internal bool se = false;                     // simple entailment
  internal bool pd = false;                     // prepare done

  /// <summary>constructs extensions</summary>

  public EulerExt() {
    ns = new Hashtable();
    nsp = new Hashtable();
    kw = new Hashtable();
    syn = new Hashtable();
    ocl = new Hashtable();
    dds = new Hashtable();
    dsg = new Hashtable();
    ns["e:"] = Euler.E + "#>";
    ns["log:"] = Euler.LOG + "#>";
    ns["math:"] = Euler.MATH + "#>";
    ns["n3:"] = Euler.N3 + "#>";
    ns["owl:"] = Euler.OWL + "#>";
    ns["q:"] = Euler.Q + "#>";
    ns["r:"] = Euler.R + "#>";
    ns["rdf:"] = Euler.RDF + "#>";
    ns["rdfs:"] = Euler.RDFS + "#>";
    ns["list:"] = Euler.LIST + "#>";
    ns["str:"] = Euler.STR + "#>";
    ns["time:"] = Euler.TIME + "#>";
    ns["var:"] = "<http://localhost/var#>";
    ns["xsd:"] = Euler.XSD + "#>";
    ns["fn:"] = "<http://www.w3.org/2005/xpath-functions#>";

    kw["this"] = this;
    kw["is"] = this;
    kw["of"] = this;
    kw["has"] = this;
    kw["a"] = this;
    kw["="] = this;
    kw["=>"] = this;
    kw["think"] = this;
    kw["case"] = this;
    kw["{}"] = this;
    kw["^^"] = this;
    kw["SELECT"] = this;
    kw["CONSTRUCT"] = this;
    kw["FROM"] = this;
    kw["NAMED"] = this;
    kw["UNION"] = this;
    kw["OPTIONAL"] = this;
    kw["FILTER"] = this;
    kw["WHERE"] = this;
  }
}
}
