// $Id: NegativeEntailmentTest_ETC2.cs 1295 2007-05-11 16:52:51Z josd $

namespace Eulersharp.test 
{

  using System;
  using System.IO;
  using System.Reflection;

  /// <summary>
  /// Class to test the euler engine
  /// </summary>
  [NUnit.Framework.TestFixture]
  public class NegativeEntailmentTest_ETC2
  {

    /// <summary>
    /// Code to set up the test
    /// </summary>
    [NUnit.Framework.SetUp]
    public void Init() 
    {
      Outputter.getInstance().initialize("etc2-results-net.n3");
    }

    /// <summary>
    /// Code to shut down the test
    /// </summary>
    [NUnit.Framework.TearDown]
    public void TearDown()
    {
      File.Delete("test.n3");
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void AnnotationProperty_001() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc2[0], "etc2-results-net.n3", "NegativeEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void Class_004() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc2[1], "etc2-results-net.n3", "NegativeEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void Class_005() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc2[2], "etc2-results-net.n3", "NegativeEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I4_6_004() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc2[3], "etc2-results-net.n3", "NegativeEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I4_6_005() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc2[4], "etc2-results-net.n3", "NegativeEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_5_006() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc2[5], "etc2-results-net.n3", "NegativeEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_5_007() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc2[6], "etc2-results-net.n3", "NegativeEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_8_005() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc2[7], "etc2-results-net.n3", "NegativeEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void I5_8_007() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc2[8], "etc2-results-net.n3", "NegativeEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void Ontology_003() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc2[9], "etc2-results-net.n3", "NegativeEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void Restriction_005() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc2[10], "etc2-results-net.n3", "NegativeEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void allValuesFrom_002() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc2[11], "etc2-results-net.n3", "NegativeEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_209() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc2[12], "etc2-results-net.n3", "NegativeEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_902() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc2[13], "etc2-results-net.n3", "NegativeEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void descriptionlogic_904() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc2[14], "etc2-results-net.n3", "NegativeEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void equivalentClass_005() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc2[15], "etc2-results-net.n3", "NegativeEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void equivalentClass_008() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc2[16], "etc2-results-net.n3", "NegativeEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void imports_002() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc2[17], "etc2-results-net.n3", "NegativeEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void miscellaneous_301() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc2[18], "etc2-results-net.n3", "NegativeEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void miscellaneous_302() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc2[19], "etc2-results-net.n3", "NegativeEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

    /// <summary>
    /// Test
    /// </summary>
    [NUnit.Framework.Test]
    public void someValuesFrom_002() 
    {
      Data.executeTest(Data.NegativeEntailmentTests_etc2[20], "etc2-results-net.n3", "NegativeEntailmentTest_ETC2_" + MethodBase.GetCurrentMethod().Name);
    }

  }
}
