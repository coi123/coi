// $Id: Configuration.cs 1295 2007-05-11 16:52:51Z josd $

namespace Eulersharp
{

  using System;

  /// <summary>
  /// This class groups all euler configuration parameters
  /// </summary>
  public class Configuration 
  {

    #region Declarations

    private static object        LOCK     = new object();
    private static Configuration instance = null;

    private bool _proofExplanation = true;
    private bool _think            = false;
    private bool _runLocal         = false;
    private long _steps            = -1;

    #endregion

    #region Constructor

    /// <summary>
    /// This method constructs a configuration object. This constructor is private because this class 
    /// acts as a singleton. The only instance should be retrieved via the getInstance() method
    /// </summary>
    private Configuration() 
    {
    }

    /// <summary>
    /// This method returns the only instance of this class
    /// </summary>
    /// <returns>the only instance of this class</returns>
    public static Configuration GetInstance() 
    {
      lock(LOCK) 
      {
        if (instance == null) 
        {
          instance = new Configuration();
        }
      }
      return instance;
    }

    #endregion

    /// <summary>
    /// Returns the version of this eulersharp engine
    /// </summary>
    public string Version
    {
      get 
      {
        return "" + Eulersharp.Version.MAJOR + "." + Eulersharp.Version.MINOR + "." + Eulersharp.Version.BUILD;
      }
    }

    /// <summary>
    /// Property to specify whether a proof explanation is wanted or not
    /// </summary>
    public bool ProofExplanation 
    {
      get 
      {
        return _proofExplanation;
      }
      set 
      {
        _proofExplanation = value;
      }
    }

    /// <summary>
    /// Property to specify whether all results should be
    /// calculated or not
    /// </summary>
    public bool Think 
    {
      get
      {
        return _think;
      }
      set 
      {
        _think = value;
      }
    }

    /// <summary>
    /// Property to limit the maximal number of steps to be taken by
    /// the proof engine
    /// </summary>
    public long Steps
    {
      get
      {
        return _steps;
      }
      set 
      {
        _steps = value;
      }
    }

    /// <summary>
    /// Property to specify whether the manifests and theories should be
    /// reqeusted from the web or loaded locally
    /// </summary>
    public bool RunLocal
    {
      get
      {
        return _runLocal;
      }
      set
      {
        _runLocal = value;
      }
    }

  }
}
