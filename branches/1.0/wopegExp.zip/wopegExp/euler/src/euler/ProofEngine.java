package euler;

import java.io.*;
import java.util.*;
import ubc.cs.JLog.Foundation.*;

/**
 * Euler proof engine
 * 
 * @author Jos De Roo
 */

public class ProofEngine {

	jPrologAPI api = null;
	ByteArrayOutputStream baos = null;
	PrintWriter pw = null;

	/**
	 * constructs a proof engine
	 */
	public ProofEngine(String[] args) {
		String[] dpargs = new String[args.length + 1];
		dpargs[0] = "--sem";
		System.arraycopy(args, 0, dpargs, 1, args.length);
		String th = EulerRunner.doProof(dpargs);
		baos = new ByteArrayOutputStream();
		pw = new PrintWriter(baos);
		api = new jPrologAPI(Codd.nativeToAscii(Euler.euler + th), null, pw, null, null);
	}
	
	/**
	 * queryProofEngine method
	 * 
	 * @param query
	 *                uri of query
	 * 
	 * @return the proof
	 */
	public String queryProofEngine(String query) {
		String[] args = new String[] {"--semquery","--query",query};
		String q = EulerRunner.doProof(args);
		long t = System.nanoTime();
		Hashtable result = api.query("main(" + q + ").", new Hashtable());
		while (result != null)
			result = api.retry();
		pw.println("#ENDS " + ((System.nanoTime() - t) / 1000000) + " msec");
		pw.flush();
		String a = baos.toString();
		baos.reset();
		return a;
	}

	/**
	 * runProofEngine method
	 * 
	 * @param args
	 *                see --help
	 * 
	 * @return the proof
	 */
	public static String runProofEngine(String[] args) {
		if (args.length == 0 || args[0].equals("--help")) {
			System.err.print("Usage: java euler.ProofEngine <options>* <data>* <query>\n" +
				"<options>\n" +
				"	--nope			no proof explanation\n" +
				"	--no-branch		no branch engine\n" +
				"	--quiet			incomplete e:falseModel explanation\n" +
				"	--quick			do not prove all e:falseModel\n" +
				"	--think			generate e:consistentGives\n" +
				"	--step <count>		set maximimum step count (default 500000)\n" +
				"	--help			show help info\n" +
				"<data>\n" +
				"	<n3_resource>\n" +
				"	--trules <n3_resource>\n" +
				"<query>\n" +
				"	--query <n3_resource>\n" +
				"	--tquery <n3_resource>\n" +
				"	--pass");
			return "";
		}
		
		String[] dpargs = new String[args.length + 2];
		dpargs[0] = "--sem";
		dpargs[1] = "--test";
		System.arraycopy(args, 0, dpargs, 2, args.length);
		return EulerRunner.doProof(dpargs);
	}

	/**
	 * main method
	 * 
	 * @param args
	 *                see --help
	 */
	public static void main(String[] args) {
		System.out.println(runProofEngine(args));
	}
}
