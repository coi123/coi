package euler;

import ubc.cs.JLog.Terms.*;
import ubc.cs.JLog.Foundation.*;
import ubc.cs.JLog.Builtins.*;
import ubc.cs.JLog.Terms.Goals.*;

public class jMap extends jBinaryBuiltinPredicate {

	public jMap(jTerm l, jTerm r) {
		super(l, r, TYPE_BUILTINPREDICATE);
	}

	public String getName() {
		return "map";
	}

	public boolean prove(jBinaryBuiltinPredicateGoal bg) {
		jTerm l = bg.term1.getTerm();
		jTerm r = bg.term2.getTerm();
		jPrologServiceThread pst = (jPrologServiceThread) Thread.currentThread();
		jPrologServices p = pst.getPrologServices();
		if (r.type == TYPE_VARIABLE) {
			Object o = p.getMap().get(l.toString());
			if (o == null)
				return false;
			return r.unify((jTerm)o, bg.unified);
		} else {
			p.getMap().put(l.toString(), r);
			return true;
		}
	}

	public jBinaryBuiltinPredicate duplicate(jTerm l, jTerm r) {
		return new jMap(l, r);
	}
}
