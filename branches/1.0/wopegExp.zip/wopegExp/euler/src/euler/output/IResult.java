// $Id: IResult.java 1537 2007-09-20 21:42:34Z josd $

package euler.output;

public interface IResult {

	/**
	 * This method reports the result of a test case
	 * 
	 * @param testCase
	 *                the name of the test case
	 * @param result
	 *                the result of the test case
	 */
	void result(String testCase, String result);
}
