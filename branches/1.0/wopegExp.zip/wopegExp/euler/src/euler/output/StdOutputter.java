// $Id: StdOutputter.java 1537 2007-09-20 21:42:34Z josd $

package euler.output;

/**
 * This class redirects all output from euler to standard output
 */

public class StdOutputter implements ILogger, IProof, IResult {

	private static final Object LOCK = new Object();

	private static StdOutputter instance = null;

	private int _logLevel = SEVERE; // log everything by default

	/* ***************************************************************** */
	/* ** START : Constructor and Destructor */
	/* ***************************************************************** */

	/**
	 * This method constructs an instance of the StdOutLogger class. This
	 * constructor is private because this class is a singleton. The only
	 * instance of this class should be retrieved via the getInstance()
	 * method.
	 */
	private StdOutputter() {
		Outputter.getInstance().addLogger(this);
		Outputter.getInstance().addProofListener(this);
		Outputter.getInstance().addResultListener(this);
	}

	/**
	 * This class acts as a singleton. getInstance() returns the only
	 * instance of this class.
	 * 
	 * @return the only instance of this class
	 */
	public static StdOutputter getInstance() {
		synchronized (LOCK) {
			if (instance == null) {
				instance = new StdOutputter();
			}
		}
		return instance;
	}

	/**
	 * This method releases the only instance of this class. All internal
	 * state will be cleared.
	 */
	public static void releaseInstance() {
		synchronized (LOCK) {
			if (instance != null) {
				// clear all internal state
				Outputter.getInstance().removeLogger(instance);
				Outputter.getInstance().removeProofListener(instance);
				Outputter.getInstance().removeResultListener(instance);
				// clear instance
				instance = null;
			}
		}
	}

	/* ***************************************************************** */
	/* ** END : Constructor and Destructor */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : Implementation of interface ILogger */
	/* ***************************************************************** */

	/**
	 * This method prints a log message on std out
	 * 
	 * @param className
	 *                the name of the class that initiated the message
	 * @param methodName
	 *                the method that initiated the log message
	 * @param message
	 *                the log message
	 * @param logLevel
	 *                the log level
	 */
	public void log(String className, String methodName, String message, int logLevel) {
		if (logLevel <= _logLevel) {
			System.out.println("LOG:    (" + level2string(logLevel) + ") " + className + "::" + methodName + " => " + message);
		}
	}

	/* ***************************************************************** */
	/* ** END : Implementation of interface ILogger */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : Implementation of interface IResult */
	/* ***************************************************************** */

	/**
	 * This method prints a result on std out.
	 * 
	 * @param testCase
	 *                the name of the test case
	 * @param result
	 *                the result of the test case
	 */
	public void result(String testCase, String result) {
		System.out.println("RESULT: (" + testCase + ") " + result);
	}

	/* ***************************************************************** */
	/* ** END : Implementation of interface IResult */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : Implementation of interface IProof */
	/* ***************************************************************** */

	/**
	 * This method prints a proof on std out.
	 * 
	 * @param testCase
	 *                the name of the test case
	 * @param proof
	 *                the proof (if found)
	 */
	public void proof(String testCase, String proof) {
		System.out.println("PROOF:  (" + testCase + ") " + proof);
	}

	/* ***************************************************************** */
	/* ** END : Implementation of interface IProof */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : Public methods */
	/* ***************************************************************** */

	public void setLogLevel(int logLevel) {
		if (logLevel >= SEVERE && logLevel <= FINEST) {
			_logLevel = logLevel;
		}
	}

	/* ***************************************************************** */
	/* ** END : Public methods */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : Private methods */
	/* ***************************************************************** */

	/**
	 * This method converts a numeric log level to its string representation
	 * 
	 * @param logLevel
	 *                the log level
	 * 
	 * @return the string representation of the given log level
	 */
	private String level2string(int logLevel) {
		switch (logLevel) {
		case 0:
			return "SEVERE";
		case 1:
			return "WARNING";
		case 2:
			return "INFO";
		case 3:
			return "CONFIG";
		case 4:
			return "FINE";
		case 5:
			return "FINER";
		case 6:
			return "FINEST";
		default:
			return "UNKNOWN";
		}
	}

	/* ***************************************************************** */
	/* ** END : Private methods */
	/* ***************************************************************** */

	public static void main(String[] args) {
		StdOutputter.getInstance();
		Outputter.getInstance().log("StdOutputter", "main", "Starting test", ILogger.SEVERE);
		Outputter.getInstance().result("test 1", "success");
		Outputter.getInstance().proof("test 1", "proof");
		Outputter.getInstance().log("StdOutputter", "main", "Stopping test", ILogger.SEVERE);
	}
}
