package euler;

import java.text.*;
import ubc.cs.JLog.Terms.*;
import ubc.cs.JLog.Foundation.*;
import ubc.cs.JLog.Builtins.*;
import ubc.cs.JLog.Terms.Goals.*;

public class jMatches extends jBinaryBuiltinPredicate {

	public jMatches(jTerm l, jTerm r) {
		super(l, r, TYPE_BUILTINPREDICATE);
	}

	public String getName() {
		return "matches";
	}

	public boolean prove(jBinaryBuiltinPredicateGoal bg) {
		jTerm l = bg.term1.getTerm();
		jTerm r = bg.term2.getTerm();
		String m = l.toString();
		String n = r.toString();
		return m.matches(n);
	}

	public jBinaryBuiltinPredicate duplicate(jTerm l, jTerm r) {
		return new jMatches(l, r);
	}
}
