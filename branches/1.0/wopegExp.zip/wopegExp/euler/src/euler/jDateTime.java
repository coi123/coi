package euler;

import java.text.*;
import ubc.cs.JLog.Terms.*;
import ubc.cs.JLog.Foundation.*;
import ubc.cs.JLog.Builtins.*;
import ubc.cs.JLog.Terms.Goals.*;

public class jDateTime extends jBinaryBuiltinPredicate {

	public jDateTime(jTerm l, jTerm r) {
		super(l, r, TYPE_BUILTINPREDICATE);
	}

	public String getName() {
		return "datetime";
	}

	public boolean prove(jBinaryBuiltinPredicateGoal bg) {
		jTerm l = bg.term1.getTerm();
		jTerm r = bg.term2.getTerm();
		String dt = l.toString();
		try {
			jTerm result = new jReal(getValue(dt));
			return r.unify(result, bg.unified);
		} catch (Throwable t) {
			t.printStackTrace();
			return false;
		}
	}

	public jBinaryBuiltinPredicate duplicate(jTerm l, jTerm r) {
		return new jDateTime(l, r);
	}
	
	public static double getValue(String dt) {
		try {
			String localString = dt.substring(0, 19);
			String restString = dt.substring(19);
			String tzString = "00:00";
			boolean tzNegative = false;
			int rl = restString.length();
			if (rl >= 1 && restString.charAt(rl - 1) == 'Z')
				restString = restString.substring(0, rl - 1);
			else if (rl >= 6 && restString.charAt(rl - 6) == '+') {
				tzString = restString.substring(rl - 5);
				restString = restString.substring(0, rl - 6);
			}
			else if (rl >= 6 && restString.charAt(rl - 6) == '-') {
				tzString = restString.substring(rl - 5);
				tzNegative = true;
				restString = restString.substring(0, rl - 6);
			}
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
			long local = df.parse(localString).getTime();
			long offset = df.getTimeZone().getOffset(local);
			int tzh = Integer.parseInt(tzString.substring(0, 2));
			int tzm = Integer.parseInt(tzString.substring(3));
			long tz = tzh * 3600000 + tzm * 60000;
			if (tzNegative)
				tz = -tz;
			double frac = java.lang.Double.parseDouble("0" + restString);
			double t = (local + offset - tz) / 1000 + frac;
			return t;
		} catch (Throwable t) {
			t.printStackTrace();
			throw new RuntimeException();
		}
	}
}
