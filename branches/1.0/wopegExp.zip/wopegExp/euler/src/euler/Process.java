package euler;

import java.io.*;
import java.util.*;

public class Process implements Runnable {

	String[] cm = null;
	String in = null;
	String out = null;
	java.lang.Process pr = null;
	boolean running = false;
	private static String run_dir;

	public Process(String cmd, String inp) {
		StringTokenizer t = new StringTokenizer(cmd);
		cm = new String[t.countTokens()];
		for (int i = 0; t.hasMoreTokens(); i++)
			cm[i] = t.nextToken();
		in = inp;
	}

	public Process(String[] cmd, String inp) {
		cm = cmd;
		in = inp;
	}

	public void execute(long ttl) {
		start();
		try {
			while (isRunning() && ttl > 0) {
				Thread.sleep(5);
				ttl = ttl - 5;
			}
		} catch (Exception e) {
			ttl = 0;
		}
		if (ttl <= 0) {
			stop();
			throw new RuntimeException("No proof found: timeout");
		}
	}

	public void run() {
		try {
			if( run_dir != null)
				pr = Runtime.getRuntime().exec(cm, new String[]{}, new File(run_dir));
			else
				pr = Runtime.getRuntime().exec(cm);
			InputStreamReader isr = new InputStreamReader(pr.getInputStream(), "UTF8");
			BufferedReader br = new BufferedReader(isr);
			BufferedOutputStream bos = new BufferedOutputStream(pr.getOutputStream());
			DataOutputStream dos = new DataOutputStream(bos);
			PrintWriter pwr = new PrintWriter(new OutputStreamWriter(dos, "UTF8"), true);
			DataInputStream des = new DataInputStream(pr.getErrorStream());
			ProcessErr pe = new ProcessErr(des);
			pe.start();
			if (in != null)
				pwr.print(in);
			pwr.close();
			String co = null;
			StringBuffer sb = new StringBuffer();
			while ((co = br.readLine()) != null)
				sb.append(co).append('\n');
			out = sb.toString();
			pr.waitFor();
			Thread.yield();
			//des.close();
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		running = false;
	}

	public void start() {
		new Thread(this).start();
		running = true;
	}

	public void stop() {
		pr.destroy();
		running = false;
	}

	public boolean isRunning() {
		return running;
	}

	public String getOutput() {
		return out;
	}

	/** tell Process in which directory to run */
	public static void setRunDirectory(String run_dir) {
		Process.run_dir = run_dir;
	}
}
