// $Id: PositiveParserTest_etc1.java 1537 2007-09-20 21:42:34Z josd $

package euler.test;

import java.io.File;

// imports from junit.jar
import junit.framework.TestCase;

public class PositiveParserTest_etc1 extends TestCase {

	/* ***************************************************************** */
	/* ** START : Constructor */
	/* ***************************************************************** */

	public PositiveParserTest_etc1(String s) {
		super(s);
	}

	/* ***************************************************************** */
	/* ** END : Constructor */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : protected methods */
	/* ***************************************************************** */

	protected void setUp() {
	}

	protected void tearDown() {
		File f = new File("test.n3");
		f.delete();
	}

	/* ***************************************************************** */
	/* ** END : protected methods */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : test cases */
	/* ***************************************************************** */

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_ampinurl_test001() {
		Data.executeTest(Data.PositiveParserTests_etc1[0], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_datatypes_test001() {
		Data.executeTest(Data.PositiveParserTests_etc1[1], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_datatypes_test002() {
		Data.executeTest(Data.PositiveParserTests_etc1[2], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfcharmodliterals_test001() {
		Data.executeTest(Data.PositiveParserTests_etc1[3], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfcharmoduris_test001() {
		Data.executeTest(Data.PositiveParserTests_etc1[4], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfcharmoduris_test002() {
		Data.executeTest(Data.PositiveParserTests_etc1[5], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfcontainerssyntaxvsschema_test001() {
		Data.executeTest(Data.PositiveParserTests_etc1[6], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfcontainerssyntaxvsschema_test002() {
		Data.executeTest(Data.PositiveParserTests_etc1[7], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfcontainerssyntaxvsschema_test003() {
		Data.executeTest(Data.PositiveParserTests_etc1[8], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfcontainerssyntaxvsschema_test004() {
		Data.executeTest(Data.PositiveParserTests_etc1[9], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfcontainerssyntaxvsschema_test006() {
		Data.executeTest(Data.PositiveParserTests_etc1[10], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfcontainerssyntaxvsschema_test007() {
		Data.executeTest(Data.PositiveParserTests_etc1[11], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfcontainerssyntaxvsschema_test008() {
		Data.executeTest(Data.PositiveParserTests_etc1[12], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfelementnotmandatory_test001() {
		Data.executeTest(Data.PositiveParserTests_etc1[13], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfnsprefixconfusion_test0001() {
		Data.executeTest(Data.PositiveParserTests_etc1[14], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfnsprefixconfusion_test0003() {
		Data.executeTest(Data.PositiveParserTests_etc1[15], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfnsprefixconfusion_test0004() {
		Data.executeTest(Data.PositiveParserTests_etc1[16], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfnsprefixconfusion_test0005() {
		Data.executeTest(Data.PositiveParserTests_etc1[17], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfnsprefixconfusion_test0006() {
		Data.executeTest(Data.PositiveParserTests_etc1[18], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfnsprefixconfusion_test0009() {
		Data.executeTest(Data.PositiveParserTests_etc1[19], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfnsprefixconfusion_test0010() {
		Data.executeTest(Data.PositiveParserTests_etc1[20], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfnsprefixconfusion_test0011() {
		Data.executeTest(Data.PositiveParserTests_etc1[21], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfnsprefixconfusion_test0012() {
		Data.executeTest(Data.PositiveParserTests_etc1[22], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfnsprefixconfusion_test0013() {
		Data.executeTest(Data.PositiveParserTests_etc1[23], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfnsprefixconfusion_test0014() {
		Data.executeTest(Data.PositiveParserTests_etc1[24], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsdifferencebetweenIDandabout_test1() {
		Data.executeTest(Data.PositiveParserTests_etc1[25], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsdifferencebetweenIDandabout_test2() {
		Data.executeTest(Data.PositiveParserTests_etc1[26], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsdifferencebetweenIDandabout_test3() {
		Data.executeTest(Data.PositiveParserTests_etc1[27], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsduplicatememberprops_test001() {
		Data.executeTest(Data.PositiveParserTests_etc1[28], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsemptypropertyelements_test001() {
		Data.executeTest(Data.PositiveParserTests_etc1[29], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsemptypropertyelements_test002() {
		Data.executeTest(Data.PositiveParserTests_etc1[30], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsemptypropertyelements_test003() {
		Data.executeTest(Data.PositiveParserTests_etc1[31], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsemptypropertyelements_test004() {
		Data.executeTest(Data.PositiveParserTests_etc1[32], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsemptypropertyelements_test005() {
		Data.executeTest(Data.PositiveParserTests_etc1[33], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsemptypropertyelements_test006() {
		Data.executeTest(Data.PositiveParserTests_etc1[34], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsemptypropertyelements_test007() {
		Data.executeTest(Data.PositiveParserTests_etc1[35], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsemptypropertyelements_test009() {
		Data.executeTest(Data.PositiveParserTests_etc1[36], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsemptypropertyelements_test010() {
		Data.executeTest(Data.PositiveParserTests_etc1[37], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsemptypropertyelements_test011() {
		Data.executeTest(Data.PositiveParserTests_etc1[38], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsemptypropertyelements_test012() {
		Data.executeTest(Data.PositiveParserTests_etc1[39], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsemptypropertyelements_test013() {
		Data.executeTest(Data.PositiveParserTests_etc1[40], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsemptypropertyelements_test014() {
		Data.executeTest(Data.PositiveParserTests_etc1[41], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsemptypropertyelements_test015() {
		Data.executeTest(Data.PositiveParserTests_etc1[42], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsemptypropertyelements_test016() {
		Data.executeTest(Data.PositiveParserTests_etc1[43], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsemptypropertyelements_test017() {
		Data.executeTest(Data.PositiveParserTests_etc1[44], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsidentityanonresources_test001() {
		Data.executeTest(Data.PositiveParserTests_etc1[45], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsidentityanonresources_test002() {
		Data.executeTest(Data.PositiveParserTests_etc1[46], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsidentityanonresources_test003() {
		Data.executeTest(Data.PositiveParserTests_etc1[47], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsidentityanonresources_test004() {
		Data.executeTest(Data.PositiveParserTests_etc1[48], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsidentityanonresources_test005() {
		Data.executeTest(Data.PositiveParserTests_etc1[49], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsnotidandresourceattr_test001() {
		Data.executeTest(Data.PositiveParserTests_etc1[50], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsnotidandresourceattr_test002() {
		Data.executeTest(Data.PositiveParserTests_etc1[51], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsnotidandresourceattr_test004() {
		Data.executeTest(Data.PositiveParserTests_etc1[52], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsnotidandresourceattr_test005() {
		Data.executeTest(Data.PositiveParserTests_etc1[53], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmspara196_test001() {
		Data.executeTest(Data.PositiveParserTests_etc1[54], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test001() {
		Data.executeTest(Data.PositiveParserTests_etc1[55], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test002() {
		Data.executeTest(Data.PositiveParserTests_etc1[56], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test003() {
		Data.executeTest(Data.PositiveParserTests_etc1[57], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test004() {
		Data.executeTest(Data.PositiveParserTests_etc1[58], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test005() {
		Data.executeTest(Data.PositiveParserTests_etc1[59], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test006() {
		Data.executeTest(Data.PositiveParserTests_etc1[60], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test007() {
		Data.executeTest(Data.PositiveParserTests_etc1[61], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test008() {
		Data.executeTest(Data.PositiveParserTests_etc1[62], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test009() {
		Data.executeTest(Data.PositiveParserTests_etc1[63], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test010() {
		Data.executeTest(Data.PositiveParserTests_etc1[64], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test011() {
		Data.executeTest(Data.PositiveParserTests_etc1[65], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test012() {
		Data.executeTest(Data.PositiveParserTests_etc1[66], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test013() {
		Data.executeTest(Data.PositiveParserTests_etc1[67], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test014() {
		Data.executeTest(Data.PositiveParserTests_etc1[68], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test015() {
		Data.executeTest(Data.PositiveParserTests_etc1[69], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test016() {
		Data.executeTest(Data.PositiveParserTests_etc1[70], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test017() {
		Data.executeTest(Data.PositiveParserTests_etc1[71], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test018() {
		Data.executeTest(Data.PositiveParserTests_etc1[72], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test019() {
		Data.executeTest(Data.PositiveParserTests_etc1[73], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test020() {
		Data.executeTest(Data.PositiveParserTests_etc1[74], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test021() {
		Data.executeTest(Data.PositiveParserTests_etc1[75], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test023() {
		Data.executeTest(Data.PositiveParserTests_etc1[76], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test024() {
		Data.executeTest(Data.PositiveParserTests_etc1[77], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test025() {
		Data.executeTest(Data.PositiveParserTests_etc1[78], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test026() {
		Data.executeTest(Data.PositiveParserTests_etc1[79], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test027() {
		Data.executeTest(Data.PositiveParserTests_etc1[80], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test028() {
		Data.executeTest(Data.PositiveParserTests_etc1[81], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test029() {
		Data.executeTest(Data.PositiveParserTests_etc1[82], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test030() {
		Data.executeTest(Data.PositiveParserTests_etc1[83], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test031() {
		Data.executeTest(Data.PositiveParserTests_etc1[84], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test032() {
		Data.executeTest(Data.PositiveParserTests_etc1[85], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test033() {
		Data.executeTest(Data.PositiveParserTests_etc1[86], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test034() {
		Data.executeTest(Data.PositiveParserTests_etc1[87], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test035() {
		Data.executeTest(Data.PositiveParserTests_etc1[88], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test036() {
		Data.executeTest(Data.PositiveParserTests_etc1[89], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_test037() {
		Data.executeTest(Data.PositiveParserTests_etc1[90], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_warn001() {
		Data.executeTest(Data.PositiveParserTests_etc1[91], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_warn002() {
		Data.executeTest(Data.PositiveParserTests_etc1[92], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsrdfnamesuse_warn003() {
		Data.executeTest(Data.PositiveParserTests_etc1[93], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsreificationrequired_test001() {
		Data.executeTest(Data.PositiveParserTests_etc1[94], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsseqrepresentation_test001() {
		Data.executeTest(Data.PositiveParserTests_etc1[95], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmssyntaxincomplete_test001() {
		Data.executeTest(Data.PositiveParserTests_etc1[96], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmssyntaxincomplete_test002() {
		Data.executeTest(Data.PositiveParserTests_etc1[97], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmssyntaxincomplete_test003() {
		Data.executeTest(Data.PositiveParserTests_etc1[98], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmssyntaxincomplete_test004() {
		Data.executeTest(Data.PositiveParserTests_etc1[99], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsurisubstructure_test001() {
		Data.executeTest(Data.PositiveParserTests_etc1[100], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsxmlliteralnamespaces_test001() {
		Data.executeTest(Data.PositiveParserTests_etc1[101], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsxmlliteralnamespaces_test002() {
		Data.executeTest(Data.PositiveParserTests_etc1[102], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsxmllang_test001() {
		Data.executeTest(Data.PositiveParserTests_etc1[103], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsxmllang_test002() {
		Data.executeTest(Data.PositiveParserTests_etc1[104], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsxmllang_test003() {
		Data.executeTest(Data.PositiveParserTests_etc1[105], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsxmllang_test004() {
		Data.executeTest(Data.PositiveParserTests_etc1[106], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsxmllang_test005() {
		Data.executeTest(Data.PositiveParserTests_etc1[107], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfmsxmllang_test006() {
		Data.executeTest(Data.PositiveParserTests_etc1[108], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfsdomainandrange_test001() {
		Data.executeTest(Data.PositiveParserTests_etc1[109], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_rdfsdomainandrange_test002() {
		Data.executeTest(Data.PositiveParserTests_etc1[110], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_unrecognisedxmlattributes_test001() {
		Data.executeTest(Data.PositiveParserTests_etc1[111], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_unrecognisedxmlattributes_test002() {
		Data.executeTest(Data.PositiveParserTests_etc1[112], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_xmlcanon_test001() {
		Data.executeTest(Data.PositiveParserTests_etc1[113], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_xmlbase_test001() {
		Data.executeTest(Data.PositiveParserTests_etc1[114], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_xmlbase_test002() {
		Data.executeTest(Data.PositiveParserTests_etc1[115], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_xmlbase_test003() {
		Data.executeTest(Data.PositiveParserTests_etc1[116], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_xmlbase_test004() {
		Data.executeTest(Data.PositiveParserTests_etc1[117], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_xmlbase_test006() {
		Data.executeTest(Data.PositiveParserTests_etc1[118], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_xmlbase_test007() {
		Data.executeTest(Data.PositiveParserTests_etc1[119], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_xmlbase_test008() {
		Data.executeTest(Data.PositiveParserTests_etc1[120], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_xmlbase_test009() {
		Data.executeTest(Data.PositiveParserTests_etc1[121], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_xmlbase_test010() {
		Data.executeTest(Data.PositiveParserTests_etc1[122], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_xmlbase_test011() {
		Data.executeTest(Data.PositiveParserTests_etc1[123], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_xmlbase_test013() {
		Data.executeTest(Data.PositiveParserTests_etc1[124], this, "etc1-results-java.n3");
	}

	public void test_etc1_PositiveParserTest_rdftests_rdfcore_xmlbase_test014() {
		Data.executeTest(Data.PositiveParserTests_etc1[125], this, "etc1-results-java.n3");
	}

	/* ***************************************************************** */
	/* ** END : test cases */
	/* ***************************************************************** */
}
