// $Id: ETC5.java 1537 2007-09-20 21:42:34Z josd $

package euler.test;

import java.io.File;

// imports from junit.jar
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class ETC5 extends TestCase {

	/* ***************************************************************** */
	/* ** START : Constructor */
	/* ***************************************************************** */

	public ETC5(String s) {
		super(s);
	}

	/* ***************************************************************** */
	/* ** END : Constructor */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : public static methods */
	/* ***************************************************************** */

	public static Test suite() {
		TestSuite suite = new TestSuite();
		suite.addTestSuite(euler.test.ETC5.class);
		Outputter.getInstance().initialize("etc5-results-java.n3");
		return suite;
	}

	/* ***************************************************************** */
	/* ** END : public static methods */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : protected methods */
	/* ***************************************************************** */

	protected void setUp() {
	}

	protected void tearDown() {
		File f = new File("test.n3");
		f.delete();
	}

	/* ***************************************************************** */
	/* ** END : protected methods */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : test cases */
	/* ***************************************************************** */

	public void test_ETC5_do_etc1() {
		Data.executeTest(Data.etc5[0], this, "etc5-results-java.n3");
	}

	public void test_ETC5_do_etc2() {
		Data.executeTest(Data.etc5[0], this, "etc5-results-java.n3");
	}

	public void test_ETC5_do_etc5() {
		Data.executeTest(Data.etc5[0], this, "etc5-results-java.n3");
	}

	/* ***************************************************************** */
	/* ** END : test cases */
	/* ***************************************************************** */
}
