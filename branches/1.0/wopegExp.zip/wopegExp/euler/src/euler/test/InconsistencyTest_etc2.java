// $Id: InconsistencyTest_etc2.java 1537 2007-09-20 21:42:34Z josd $

package euler.test;

import java.io.File;

// imports from junit.jar
import junit.framework.TestCase;

public class InconsistencyTest_etc2 extends TestCase {

	/* ***************************************************************** */
	/* ** START : Constructor */
	/* ***************************************************************** */

	public InconsistencyTest_etc2(String s) {
		super(s);
	}

	/* ***************************************************************** */
	/* ** END : Constructor */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : protected methods */
	/* ***************************************************************** */

	protected void setUp() {
	}

	protected void tearDown() {
		File f = new File("test.n3");
		f.delete();
	}

	/* ***************************************************************** */
	/* ** END : protected methods */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : test cases */
	/* ***************************************************************** */

	public void test_InconsistencyTest_I4_5_002() {
		Data.executeTest(Data.InconsistencyTests_etc2[0], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_I5_5_003() {
		Data.executeTest(Data.InconsistencyTests_etc2[1], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_I5_5_004() {
		Data.executeTest(Data.InconsistencyTests_etc2[2], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_I5_8_001() {
		Data.executeTest(Data.InconsistencyTests_etc2[3], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_I5_8_003() {
		Data.executeTest(Data.InconsistencyTests_etc2[4], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_Nothing_001() {
		Data.executeTest(Data.InconsistencyTests_etc2[5], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_Restriction_001() {
		Data.executeTest(Data.InconsistencyTests_etc2[6], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_Restriction_002() {
		Data.executeTest(Data.InconsistencyTests_etc2[7], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_Thing_003() {
		Data.executeTest(Data.InconsistencyTests_etc2[8], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_Thing_005() {
		Data.executeTest(Data.InconsistencyTests_etc2[9], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_001() {
		Data.executeTest(Data.InconsistencyTests_etc2[10], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_002() {
		Data.executeTest(Data.InconsistencyTests_etc2[11], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_003() {
		Data.executeTest(Data.InconsistencyTests_etc2[12], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_004() {
		Data.executeTest(Data.InconsistencyTests_etc2[13], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_007() {
		Data.executeTest(Data.InconsistencyTests_etc2[14], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_008() {
		Data.executeTest(Data.InconsistencyTests_etc2[15], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_010() {
		Data.executeTest(Data.InconsistencyTests_etc2[16], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_011() {
		Data.executeTest(Data.InconsistencyTests_etc2[17], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_012() {
		Data.executeTest(Data.InconsistencyTests_etc2[18], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_013() {
		Data.executeTest(Data.InconsistencyTests_etc2[19], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_014() {
		Data.executeTest(Data.InconsistencyTests_etc2[20], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_015() {
		Data.executeTest(Data.InconsistencyTests_etc2[21], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_017() {
		Data.executeTest(Data.InconsistencyTests_etc2[22], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_019() {
		Data.executeTest(Data.InconsistencyTests_etc2[23], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_022() {
		Data.executeTest(Data.InconsistencyTests_etc2[24], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_023() {
		Data.executeTest(Data.InconsistencyTests_etc2[25], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_026() {
		Data.executeTest(Data.InconsistencyTests_etc2[26], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_027() {
		Data.executeTest(Data.InconsistencyTests_etc2[27], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_029() {
		Data.executeTest(Data.InconsistencyTests_etc2[28], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_030() {
		Data.executeTest(Data.InconsistencyTests_etc2[29], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_032() {
		Data.executeTest(Data.InconsistencyTests_etc2[30], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_033() {
		Data.executeTest(Data.InconsistencyTests_etc2[31], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_035() {
		Data.executeTest(Data.InconsistencyTests_etc2[32], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_040() {
		Data.executeTest(Data.InconsistencyTests_etc2[33], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_101() {
		Data.executeTest(Data.InconsistencyTests_etc2[34], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_102() {
		Data.executeTest(Data.InconsistencyTests_etc2[35], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_103() {
		Data.executeTest(Data.InconsistencyTests_etc2[36], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_104() {
		Data.executeTest(Data.InconsistencyTests_etc2[37], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_105() {
		Data.executeTest(Data.InconsistencyTests_etc2[38], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_106() {
		Data.executeTest(Data.InconsistencyTests_etc2[39], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_107() {
		Data.executeTest(Data.InconsistencyTests_etc2[40], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_108() {
		Data.executeTest(Data.InconsistencyTests_etc2[41], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_109() {
		Data.executeTest(Data.InconsistencyTests_etc2[42], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_110() {
		Data.executeTest(Data.InconsistencyTests_etc2[43], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_111() {
		Data.executeTest(Data.InconsistencyTests_etc2[44], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_502() {
		Data.executeTest(Data.InconsistencyTests_etc2[45], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_504() {
		Data.executeTest(Data.InconsistencyTests_etc2[46], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_601() {
		Data.executeTest(Data.InconsistencyTests_etc2[47], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_602() {
		Data.executeTest(Data.InconsistencyTests_etc2[48], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_603() {
		Data.executeTest(Data.InconsistencyTests_etc2[49], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_604() {
		Data.executeTest(Data.InconsistencyTests_etc2[50], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_608() {
		Data.executeTest(Data.InconsistencyTests_etc2[51], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_610() {
		Data.executeTest(Data.InconsistencyTests_etc2[52], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_611() {
		Data.executeTest(Data.InconsistencyTests_etc2[53], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_612() {
		Data.executeTest(Data.InconsistencyTests_etc2[54], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_613() {
		Data.executeTest(Data.InconsistencyTests_etc2[55], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_614() {
		Data.executeTest(Data.InconsistencyTests_etc2[56], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_615() {
		Data.executeTest(Data.InconsistencyTests_etc2[57], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_617() {
		Data.executeTest(Data.InconsistencyTests_etc2[58], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_623() {
		Data.executeTest(Data.InconsistencyTests_etc2[59], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_626() {
		Data.executeTest(Data.InconsistencyTests_etc2[60], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_627() {
		Data.executeTest(Data.InconsistencyTests_etc2[61], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_629() {
		Data.executeTest(Data.InconsistencyTests_etc2[62], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_630() {
		Data.executeTest(Data.InconsistencyTests_etc2[63], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_632() {
		Data.executeTest(Data.InconsistencyTests_etc2[64], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_633() {
		Data.executeTest(Data.InconsistencyTests_etc2[65], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_641() {
		Data.executeTest(Data.InconsistencyTests_etc2[66], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_642() {
		Data.executeTest(Data.InconsistencyTests_etc2[67], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_643() {
		Data.executeTest(Data.InconsistencyTests_etc2[68], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_644() {
		Data.executeTest(Data.InconsistencyTests_etc2[69], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_646() {
		Data.executeTest(Data.InconsistencyTests_etc2[70], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_650() {
		Data.executeTest(Data.InconsistencyTests_etc2[71], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_909() {
		Data.executeTest(Data.InconsistencyTests_etc2[72], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_descriptionlogic_910() {
		Data.executeTest(Data.InconsistencyTests_etc2[73], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_disjointWith_010() {
		Data.executeTest(Data.InconsistencyTests_etc2[74], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_maxCardinality_001() {
		Data.executeTest(Data.InconsistencyTests_etc2[75], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_maxCardinality_002() {
		Data.executeTest(Data.InconsistencyTests_etc2[76], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_miscellaneous_203() {
		Data.executeTest(Data.InconsistencyTests_etc2[77], this, "etc2-results-java.n3");
	}

	public void test_InconsistencyTest_miscellaneous_204() {
		Data.executeTest(Data.InconsistencyTests_etc2[78], this, "etc2-results-java.n3");
	}

	/* ***************************************************************** */
	/* ** END : test cases */
	/* ***************************************************************** */
}
