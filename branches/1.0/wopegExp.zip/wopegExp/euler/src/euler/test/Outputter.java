// $Id: Outputter.java 1537 2007-09-20 21:42:34Z josd $

package euler.test;

import java.io.IOException;
import java.io.FileOutputStream;

public class Outputter {

	private static final Object LOCK = new Object();

	private static Outputter instance = null;

	private Outputter() {
	}

	public static Outputter getInstance() {
		synchronized (LOCK) {
			if (instance == null) {
				instance = new Outputter();
			}
		}
		return instance;
	}

	protected void initialize(String file) {
		try {
			FileOutputStream s = new FileOutputStream(file);
			s
					.write("@prefix r: <http://www.w3.org/2002/03owlt/resultsOntology#>.\n@prefix xsd: <http://www.w3.org/2001/XMLSchema#>.\n@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>.\n@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>.\n@prefix : <#>.\n\n:euler rdfs:comment \"\"\"<a xmlns=\"http://www.w3.org/1999/xhtml\" href=\"http://eulersharp.sourceforge.net/2003/03swap/\">EulerSharp</a>\nis an inference engine supporting logic based proofs.\nIt is a backward-chaining reasoner enhanced with Euler path detection and will tell\nyou whether a given set of facts and rules supports a given conclusion.\nTo parse the manifests and the test documents Jena 2 is used.\"\"\"^^rdf:XMLLiteral;\nrdfs:label \"EulerSharp\";\nrdfs:seeAlso <http://eulersharp.sourceforge.net/2003/03swap/>.\n\n\n"
							.getBytes());
			s.flush();
			s.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

	public void addToResult(String file, String result) {
		try {
			FileOutputStream s = new FileOutputStream(file, true);
			s.write(result.getBytes());
			s.flush();
			s.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

	public void writeProof(String file, String proof) {
		try {
			FileOutputStream s = new FileOutputStream(file, true);
			s.write(proof.getBytes());
			s.flush();
			s.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
}
