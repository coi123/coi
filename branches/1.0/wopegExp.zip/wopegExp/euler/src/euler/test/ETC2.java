// $Id: ETC2.java 1537 2007-09-20 21:42:34Z josd $

package euler.test;

// imports from junit.jar
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class ETC2 extends TestCase {

	/* ***************************************************************** */
	/* ** START : Constructor */
	/* ***************************************************************** */

	public ETC2(String s) {
		super(s);
	}

	/* ***************************************************************** */
	/* ** END : Constructor */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : public static methods */
	/* ***************************************************************** */

	public static Test suite() {
		TestSuite suite = new TestSuite();
		suite.addTestSuite(euler.test.PositiveEntailmentTest_etc2.class);
		suite.addTestSuite(euler.test.NegativeEntailmentTest_etc2.class);
		suite.addTestSuite(euler.test.ConsistencyTest_etc2.class);
		suite.addTestSuite(euler.test.InconsistencyTest_etc2.class);
		suite.addTestSuite(euler.test.ImportEntailmentTest_etc2.class);
		suite.addTestSuite(euler.test.OWLforOWLTest_etc2.class);
		Outputter.getInstance().initialize("etc2-results-java.n3");
		return suite;
	}

	/* ***************************************************************** */
	/* ** END : public static methods */
	/* ***************************************************************** */
}
