// $Id: OWLforOWLTest_etc2.java 1537 2007-09-20 21:42:34Z josd $

package euler.test;

import java.io.File;

// imports from junit.jar
import junit.framework.TestCase;

public class OWLforOWLTest_etc2 extends TestCase {

	/* ***************************************************************** */
	/* ** START : Constructor */
	/* ***************************************************************** */

	public OWLforOWLTest_etc2(String s) {
		super(s);
	}

	/* ***************************************************************** */
	/* ** END : Constructor */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : protected methods */
	/* ***************************************************************** */

	protected void setUp() {
	}

	protected void tearDown() {
		File f = new File("test.n3");
		f.delete();
	}

	/* ***************************************************************** */
	/* ** END : protected methods */
	/* ***************************************************************** */

	/* ***************************************************************** */
	/* ** START : test cases */
	/* ***************************************************************** */

	public void test_OWLforOWLTest_etc2_class_test() {
		Data.executeTest(Data.OWLforOWLTest_etc2[0], this, "etc2-results-java.n3");
	}

	public void test_OWLforOWLTest_etc2_I5_5_test001() {
		Data.executeTest(Data.OWLforOWLTest_etc2[1], this, "etc2-results-java.n3");
	}

	public void test_OWLforOWLTest_etc2_I5_5_test002() {
		Data.executeTest(Data.OWLforOWLTest_etc2[2], this, "etc2-results-java.n3");
	}

	public void test_OWLforOWLTest_etc2_I5_8_test011() {
		Data.executeTest(Data.OWLforOWLTest_etc2[3], this, "etc2-results-java.n3");
	}

	public void test_OWLforOWLTest_etc2_Nothing_test002() {
		Data.executeTest(Data.OWLforOWLTest_etc2[4], this, "etc2-results-java.n3");
	}

	public void test_OWLforOWLTest_etc2_imports_test010() {
		Data.executeTest(Data.OWLforOWLTest_etc2[5], this, "etc2-results-java.n3");
	}

	/* ***************************************************************** */
	/* ** END : test cases */
	/* ***************************************************************** */
}
