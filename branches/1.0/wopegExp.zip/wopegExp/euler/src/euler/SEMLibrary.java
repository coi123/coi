package euler;

import java.net.*;
import java.text.*;
import java.util.*;
import jTrolog.engine.*;
import jTrolog.lib.Library;
import jTrolog.parser.Parser;
import jTrolog.terms.Double;
import jTrolog.terms.*;

public class SEMLibrary extends Library {
	
	public SEMLibrary() {
	}

	public String getTheory() { return

// ----------------------------------
// Skolem Euler Machine -- Jos De Roo
// ----------------------------------

":- op(1200,xfx,axiom).															\n" +
":- op(1199,xfx,'=>').															\n" +
":- op(600,xfy,':').															\n" +

":- dynamic(pfx/2).															\n" +
":- dynamic(flag/1).															\n" +
":- dynamic(brake/0).															\n" +
":- dynamic(limit/1).															\n" +
":- dynamic(scope/1).															\n" +
":- dynamic(tuple/2).															\n" +
":- dynamic(fact/1).															\n" +
":- dynamic(bset/0).															\n" +
":- dynamic(bcnd/2).															\n" +
":- dynamic(bref/2).															\n" +
":- dynamic(bvar/1).															\n" +
":- dynamic(bgot/3).															\n" +
":- dynamic(dom/1).															\n" +
":- dynamic(tabs/1).															\n" +
":- dynamic(goal/0).															\n" +
":- dynamic(false/0).															\n" +
":- dynamic(false/1).															\n" +
":- dynamic(steps/3).															\n" +
":- dynamic(answers/2).															\n" +

"main :-																\n" +
"	write('#Processed by $Id: SEMLibrary.java 2408 2008-09-18 23:33:00Z josd $'), nl,						\n" +
"	write('@keywords is, of, a.'), nl, nl,												\n" +
"	findall(_,(pfx(A,B), write('@prefix '), write(A), write(' '), write(B), write('.'), nl),_),					\n" +
"	(pfx('e:',_) -> true; write('@prefix e: <http://eulersharp.sourceforge.net/2003/03swap/log-rules#>.'), nl),			\n" +
"	(pfx('r:',_) -> true; write('@prefix r: <http://www.w3.org/2000/10/swap/reason#>.'), nl), nl,					\n" +
"	sem(0).																\n" +

"sem(Scp) :-																\n" +
"	(A axiom Z: (Prem => Conc)),													\n" +
"	var(A), nonvar(Prem),														\n" +
"	Prem, \\+Conc,									% ----- euler path detection -----		\n" +
"	ground(Conc), Conc \\= (_;_), Conc \\= goal, Conc \\= false,									\n" +
"	add_conj(Conc), add_step(Z,Prem,Conc), retract(brake), fail									\n" +
"	; brake, (limit(N), Scp < N, Sc is Scp+1, assert(scope(Sc)), sem(Sc); w3(trunk), sem([],0,[],[]); true), !			\n" +
"	; assert(brake), sem(Scp).													\n" +

// ----- Coherent Logic inspired by http://www.cs.vu.nl/~diem/research/ht/CL.pl -----
"sem(Grd,Pnum,Stack,Env) :-														\n" +
"	(A axiom Z: (Prem => Conc)),													\n" +
"	(var(A) -> Gnew = Grd; enabled(A,Grd), next(A,Grd,Gnew)), nonvar(Prem),								\n" +
"	Prem, \\+Conc, (Conc \\= false; \\+false(lf(Prem))),				% ----- euler path detection -----		\n" +
"	(Conc = false -> C = false(lf(Prem)); C = Conc),										\n" +
"	((C = goal; C = false(_), dom(_)) -> end(C,Env)											\n" +
"	; (C = (E;D) -> split(Z,Prem,Gnew,Pnum,[D|Stack],E,Env); memo(Z,Prem,Gnew,Pnum,Stack,C,Env))).					\n" +

"split(Z,Prem,Grd,Pnum,[T|S],C,Env) :-													\n" +
"	memo(Z,Prem,Grd,Pnum,[T|S],C,[C|Env]),												\n" +
"	(T = (E;D) -> split(Z,Prem,Grd,Pnum,[D|S],E,Env); memo(Z,Prem,Grd,Pnum,S,T,[T|Env])).						\n" +

"memo(Z,Prem,Grd,Pnum,Stack,Conc,Env) :-												\n" +
"	(Conc = answer('log:implies'(_,_)) -> Q = all; Q = sk), numbervars(Conc,Pnum,Pnew,Q), del_dom(Conc,C),				\n" +
"	add_conj(Conc), add_step(Z,Prem,C), (sem(Grd,Pnew,Stack,Env) -> true; end(countermodel,Env)),					\n" +
"	del_conj(Conc), del_step(Z,Prem,C), fail; true.											\n" +

"add_conj(C) :-																\n" +
"	C = (A,B) -> assert(A), add_conj(B); assert(C).											\n" +

"del_conj(C) :-																\n" +
"	C = (A,B) -> '$retract'(A), del_conj(B); '$retract'(C).										\n" +

"add_step(A,B,C) :-															\n" +
"	C = (D,E) -> assert(steps(A,B,D)), add_step(A,B,E); assert(steps(A,B,C)).							\n" +

"del_step(A,B,C) :-															\n" +
"	C = (D,E) -> '$retract'(steps(A,B,D)), del_step(A,B,E); '$retract'(steps(A,B,C)).						\n" +

"del_dom(C,A) :-															\n" +
"	C = (dom(_),B) -> del_dom(B,A); C = dom(_) -> A = true; A = C.									\n" +

"ancestor(A,B) :-															\n" +
"	steps(_,C,B), cmember(D,C), (unif(A,D); ancestor(A,D)).										\n" +

"decendent(A,B) :-															\n" +
"	steps(_,C,A), cmember(D,C), (unif(B,D); decendent(D,B)).									\n" +

"cgives(A,B) :-																\n" +
"	\\+steps(_,_,B), !; steps(_,C,B), \\+((cmember(D,C), cmember(E,A), (unif(E,D); \\+cgives(E,D)))).				\n" +

"end(goal,Env) :-															\n" +
"	\\+false(_), !,															\n" +
"	(Env = [] -> w3(trunk); write('[ e:possibleModel '), clist(Env,G), wt(lf(G)), nl,						\n" +
"	write('; r:gives {'), nl, retractall(answers(_,branch)), w3(branch), write('}].'), nl, nl).					\n" +
"end(countermodel,Env) :-														\n" +
"	\\+false(_), !,															\n" +
"	write('[ e:counterModel '), clist(Env,G), wt(lf(G)), write('].'), nl, nl.							\n" +
"end(_,Env) :-																\n" +
"	write('[ e:falseModel '), clist(Env,G), wt(lf(G)), nl, (false(lf(F)),								\n" +
"	write('; e:because [ e:integrityConstraint '), write('{'), wt(lf(F)), write(' => false}'), (cmember(A,F), nl,			\n" +
"	write('  ; e:selected [ e:triple '), wt(lf(A)), nl,										\n" +
"	findall(X,(ancestor(X,A), X \\= true, X \\= atom(_), \\+unif(X,_=.._)),L), clist(L,U), 						\n" +
"	findall(X,(decendent(X,A), X \\= false(_), X \\= answer(_)),M), clist(M,V), 							\n" +
"	findall(X,(false(lf(Y)), cmember(X,Y)),I), list_to_set(I,P), clist(P,Q),							\n" +
"	findall(X,(cmember(X,U), cmember(Y,Q), unif(X,Y)),J), clist(J,R),								\n" +
"	write('    ; e:falseAncestors '), wt(lf(R)), nl,										\n" +
"	findall(X,(cmember(X,V), cmember(Y,Q), unif(X,Y)),K), clist(K,S),								\n" +
"	write('    ; e:falseDecendents '), wt(lf(S)), nl,										\n" +
"	(flag(think) -> findall(X,(steps(_,_,X), X \\= false(_), X \\= answer(_), \\+unif(X,A), cgives(A,X)),N), clist(N,W),		\n" +
"	write('    ; e:consistentGives '), wt(lf(W)), nl; true),									\n" +
"	write('    ]'), fail; true), nl, write('  ]'), nl, fail; true),									\n" +
"	write('; r:gives {'), nl, retractall(answers(_,branch)), w3(branch), write('}].'), nl, nl.					\n" +


// ------------
// proof output
// ------------

"w3(U) :-																\n" +
"	flag(nope), !,															\n" +
"	(steps(_,_,answer(C)), \\+answers(C,_), assert(answers(C,U)), wn(C), fail; nl).							\n" +
"w3(U) :-																\n" +
"	steps(A,B,answer(C)), \\+answers(C,_), assert(answers(C,U)), redent,								\n" +
"	write('[ a r:Proof, r:Conjunction;'), indent, ws,										\n" +
"	wc(A,B,C), write('r:gives {'), indent, ws, wt(C), write('.'), write('}].'), nl, nl, fail; true.					\n" +

"wc(A,B,(C,D)) :- !,															\n" +
"	write('r:component '), wi(A,B,C), write(';'), ws, wc(A,B,D).									\n" +
"wc(A,B,C) :-																\n" +
"	write('r:component '), wi(A,B,C), write(';'), ws.										\n" +

"wi(A,true,C) :- !,															\n" +
"	write('[ a r:Extraction; r:gives {'), numbervars(C,0,_,var), wt(C),								\n" +
"	write('}; r:because [ a r:Parsing; r:source '), wu(A), write(']]').								\n" +
"wi(A,B,C) :-																\n" +
"	write('[ a r:Inference; r:gives {'), numbervars(C,0,_,var), wt(C),								\n" +
"	write('}; r:evidence ('), indent, wr(B), write(');'), ws, dedent,								\n" +
"	write('r:rule [ a r:Extraction; r:because [ a r:Parsing; r:source '), wu(A), write(']]]'), fail; true.				\n" +

"wr(varpred(S,P,O)) :- !,														\n" +
"	U =.. [P,S,O], wr(U).														\n" +
"wr((atom(_),_)) :- !.															\n" +
"wr((X,Y)) :- !,															\n" +
"	wr(X), wr(Y).															\n" +
"wr('='(X,Y)) :- !,															\n" +
"	ws, write('[ a r:Fact; r:gives '), wt(lf('='(X,Y))), write(']').								\n" +
"wr(Z) :-																\n" +
"	steps(X,Y,Z), !, ws, wi(X,Y,Z).													\n" +
"wr(Y) :-																\n" +
"	auri(Y,Z), ws, write('[ a r:Fact; r:gives '), numbervars(Z,0,_,var), wt(lf(Z)), write(']').					\n" +

"wn('{}') :- !.																\n" +
"wn(lf(X)) :- !,															\n" +
"	wt(X), write('.'), nl.														\n" +
"wn(X) :-																\n" +
"	wt(X), write('.'), nl.														\n" +

"wt(X) :-																\n" +
"	number(X), !, write(X).														\n" +
"wt(sk(X)) :- !,															\n" +
"	write('_:sk'), write(X).													\n" +
"wt(all(X)) :- !,															\n" +
"	write('?U'), write(X).														\n" +
"wt(var(X)) :- !,															\n" +
"	write('var:x'), write(X).													\n" +
"wt(fpath(X,Y)) :- !,															\n" +
"	wt(X), write('!'), wt(Y).													\n" +
"wt(bpath(X,Y)) :- !,															\n" +
"	wt(X), write('^'), wt(Y).													\n" +
"wt(tlit(X,Y)) :- !,															\n" +
"	wt(X), write('^^'), wt(Y).													\n" +
"wt(plit(X,Y)) :- !,															\n" +
"	wt(X), write('@'), wt(Y).													\n" +
"wt(lf(('e:true'(_,1),Y))) :- !,													\n" +
"	wt(lf(Y)).															\n" +
"wt(lf((X,Y))) :- !,															\n" +
"	write('{'), wt(X), wf(Y), write('}').												\n" +
"wt(lf(true)) :- !,															\n" +
"	write('{}').															\n" +
"wt(lf(X)) :- !,															\n" +
"	write('{'), wt(X), write('}').													\n" +
"wt((X,Y)) :- !,															\n" +
"	wt(X), write('. '), wt(Y).													\n" +
"wt([]) :- !,																\n" +
"	write('()').															\n" +
"wt([X|Y]) :- !,															\n" +
"	write('('), wt(X), wl(Y), write(')').												\n" +
"wt(varpred(S,P,O)) :- !,														\n" +
"	wt(S), write(' '), wt(P), write(' '), wt(O).											\n" +
"wt(a) :- !,																\n" +
"	write(':a').															\n" +
"wt('rdf:type') :- !,															\n" +
"	write('a').															\n" +
"wt('owl:sameAs') :- !,															\n" +
"	write('=').															\n" +
"wt('log:implies') :- !,														\n" +
"	write('=>').															\n" +
"wt('e:biconditional'([X|Y],Z)) :-													\n" +
"	flag(tquery), !, write('{'), wb(Y), write('_: e:true '), write(Z), write('} => '), wt(X).					\n" +
"wt('e:conditional'([X|Y],Z)) :-													\n" +
"	flag(tquery), !, write('{'), wb(Y), write('_: e:true '), write(Z), write('} => '), wt(X).					\n" +
"wt(X) :-																\n" +
"	functor(X,P,A), (A = 0, (bnode(X,Y) -> write(Y); write(X)), !									\n" +
"	; A = 2, arg(1,X,S), arg(2,X,O), wt(S), write(' '), wt(P), write(' '), wt(O), !							\n" +
"	; X =.. [B|C], write('_: '), wt(B), write(' '), wt(C)).										\n" +

"wf((X,Y)) :- !,															\n" +
"	write('. '), wt(X), wf(Y).													\n" +
"wf(_=..[_,_,_]) :- !.															\n" +
"wf(X) :-																\n" +
"	write('. '), wt(X).														\n" +

"wb([]) :- !.																\n" +
"wb([lf(X)|Y]) :-															\n" +
"	wt(X), write('. '), wb(Y).													\n" +

"wl([]) :- !.																\n" +
"wl([X|Y]) :-																\n" +
"	write(' '), wt(X), wl(Y).													\n" +

"wu(X) :-																\n" +
"	functor(X,_,A), (A = 0 -> write(X); X =.. Y, wt(Y)).										\n" +

"ws:-																	\n" +
"	nl, tabs(A), tab(A).														\n" +

"redent :-																\n" +
"	retractall(tabs(_)), assert(tabs(0)).												\n" +

"indent :-																\n" +
"	retract(tabs(A)), B is A+1, assert(tabs(B)).											\n" +

"dedent :-																\n" +
"	retract(tabs(A)), B is A-1, assert(tabs(B)).											\n" +


// --------
// builtins
// --------

"'e:biconditional'([lf('e:boolean'(A,B))|C],D) :-											\n" +
"	within_scope(1), bnet, bvar(A), bval(B), bcon([lf('e:boolean'(A,B))],C,D).							\n" +

"'e:binaryEntropy'(A,B) :-														\n" +
"	nonvar(A), (A =:= 0 -> B is 0; (A =:= 1 -> B is 0; B is -(A*log(A)+(1-A)*log(1-A))/log(2))).					\n" +

"'e:distinct'(A,B) :-															\n" +
"	nonvar(A), list_to_set(A,B).													\n" +

"'e:findall'([_,S],[A,lf(B),C]) :-													\n" +
"	(var(S) -> S = 1; true), within_scope(S), findall(A,B,C).									\n" +

"'e:graphDifference'(X,Y) :-														\n" +
"	nonvar(X), difference(X,Y).													\n" +

"'e:graphIntersection'(X,Y) :-														\n" +
"	nonvar(X), intersection(X,Y).													\n" +

"'e:label'(A,B) :-															\n" +
"	nonvar(A), substring(A,'var:',_,C), concat(['\"',C,'\"'],B).									\n" +

"'e:length'(A,B) :-															\n" +
"	nonvar(A), length(A,B).														\n" +

"'e:max'(A,B) :-															\n" +
"	nonvar(A), max(A,B).														\n" +

"'e:min'(A,B) :-															\n" +
"	nonvar(A), min(A,B).														\n" +

"'e:optional'(_,lf(A)) :-														\n" +
"	A -> true; true.														\n" +

"'e:pair'(A,[B,C]) :-															\n" +
"	'e:sublist'(A,[B,C]); 'e:sublist'(A,[C,B]).											\n" +

"'e:reflexive'(_,A) :-															\n" +
"	B =.. [A,C,C], (\\+B -> assert(B); true).											\n" +

"'e:reverse'(A,B) :-															\n" +
"	reverse(A,B).															\n" +

"'e:sort'(A,B) :-															\n" +
"	nonvar(A), quicksort(A,'@<',B).													\n" +

"'e:sublist'(A,B) :-															\n" +
"	nonvar(A), append(C,_,A), append(_,B,C).											\n" +

"'e:trace'(_,X) :-															\n" +
"	write('#TRACE '), wt(X), nl.													\n" +

"'e:true'(_,A) :-															\n" +
"	nonvar(A), A =:= 1.0.														\n" +

"'e:tuple'(X,Y) :-															\n" +
"	(tuple(X,Y) -> true														\n" +
"	; findall(Z,tuple(Z,_),L), length(L,N), num_atom(N,A), concat(['var:e',A],X), assert(tuple(X,Y))).				\n" +

"'e:wwwFormEncode'(X,Y) :-														\n" +
"	ground(X), unquote(X,U), url_encode(U,V), concat(['\"',V,'\"'],Y), !								\n" +
"	; ground(Y), unquote(Y,V), url_decode(V,U), concat(['\"',U,'\"'],X).								\n" +

"'fn:resolve-uri'([A,B],C) :-														\n" +
"	ground([A,B]), unquote(A,U), unquote(B,V), ruri(U,V,X), concat(['\"',X,'\"'],C).						\n" +

"'fn:substring-after'([A,B],C) :-													\n" +
"	ground([A,B]), unquote(A,U), unquote(B,V), substring(U,V,_,X), concat(['\"',X,'\"'],C).						\n" +

"'fn:substring-before'([A,B],C) :-													\n" +
"	ground([A,B]), unquote(A,U), unquote(B,V), substring(U,V,X,_), concat(['\"',X,'\"'],C).						\n" +

"'list:append'([A,B],C) :-														\n" +
"	nonvar(A), nonvar(B) ,append(A,B,C).												\n" +

"'list:first'([A|_],A).															\n" +

"'list:in'(A,B) :-															\n" +
"	nonvar(B), member(A,B).														\n" +

"'list:last'(A,B) :-															\n" +
"	nonvar(A), last(A,B).														\n" +

"'list:member'(A,B) :-															\n" +
"	nonvar(A), member(B,A).														\n" +

"'list:rest'([_|B],B).															\n" +

"'log:conjunction'(X,Y) :-														\n" +
"	nonvar(X), conjunction(X,Y).													\n" +

"'log:equalTo'(X,X).															\n" +

"'log:implies'(lf(X),lf(Y)) :-														\n" +
"	(_ axiom _: (X => Y)), X \\= true, Y \\= answer(_), Y \\= goal.									\n" +

"'log:includes'(X,Y) :-															\n" +
"	nonvar(X), nonvar(Y), includes(X,Y).												\n" +

"'log:notEqualTo'(X,Y) :-														\n" +
"	X \\= Y.															\n" +

"'log:notIncludes'(X,Y) :-														\n" +
"	nonvar(X), nonvar(Y), \\+'log:includes'(X,Y).											\n" +

"'log:semantics'(X,Y) :-														\n" +
"	nonvar(X), quri(X,Q), (fact('log:semantics'(Q,Y)), !;										\n" +
"	findall(U,(pfx(X1,X2), concat(['@prefix ',X1,' ',X2,'. '],U)),L), concat(L,W),							\n" +
"	base(B), unquote(Q,Z), concat(['.context ',W],C1), url_encode(C1,C2),								\n" +
"	concat(['.euler --semterm ',B,C2,' ',Z],C3), url_encode(C3,C4), concat([B,C4],V),						\n" +
"	semantics(V,Y), assert(fact('log:semantics'(Q,Y))))										\n" +
"	; nonvar(Y), X = Y, assert(fact('log:semantics'(X,Y))).										\n" +

"'log:uri'(X,Y) :-															\n" +
"	(nonvar(X); ground(Y)), quri(X,Q), !, unquote(Q,U), concat(['\"',U,'\"'],Y);							\n" +
"	unquote(Y,U), concat(['<',U,'>'],X).												\n" +

"'math:absoluteValue'(X,Z) :-														\n" +
"	getnumber(X,U), Z is abs(U).													\n" +

"'math:cos'(X,Z) :-															\n" +
"	getnumber(X,U), Z is cos(U), !; getnumber(Z,W), X is 2*atan(sqrt(1-W*W)/(1+W)).							\n" +

"'math:degrees'(X,Z) :-															\n" +
"	getnumber(X,U), Z is U*180/3.141592653589793, !; getnumber(Z,W), X is W*3.141592653589793/180.					\n" +

"'math:difference'([X,Y],Z) :-														\n" +
"	getnumber(X,U), getnumber(Y,V), Z is U-V.											\n" +

"'math:equalTo'(X,Y) :-															\n" +
"	getnumber(X,U), getnumber(Y,V), U =:= V.											\n" +

"'math:exponentiation'([X,Y],Z) :-													\n" +
"	getnumber(X,U), (getnumber(Y,V), Z is U**V, !; getnumber(Z,W), Y is log(W)/log(U)).						\n" +

"'math:greaterThan'(X,Y) :-														\n" +
"	getnumber(X,U), getnumber(Y,V), U > V.												\n" +

"'math:integerQuotient'([X,Y],Z) :-													\n" +
"	getnumber(X,U), getnumber(Y,V), Z is U//V.											\n" +

"'math:lessThan'(X,Y) :-														\n" +
"	getnumber(X,U), getnumber(Y,V), U < V.												\n" +

"'math:memberCount'(X,Y) :-														\n" +
"	nonvar(X), length(X,Y).														\n" +

"'math:negation'(X,Z) :-														\n" +
"	getnumber(X,U), Z is -U, !; getnumber(Z,W), X is -W.										\n" +

"'math:notEqualTo'(X,Y) :-														\n" +
"	getnumber(X,U), getnumber(Y,V), U =\\= V.											\n" +

"'math:notGreaterThan'(X,Y) :-														\n" +
"	getnumber(X,U), getnumber(Y,V), U =< V.												\n" +

"'math:notLessThan'(X,Y) :-														\n" +
"	getnumber(X,U), getnumber(Y,V), U >= V.												\n" +

"'math:product'(X,Z) :-															\n" +
"	product(X,Z).															\n" +

"'math:quotient'([X,Y],Z) :-														\n" +
"	getnumber(X,U), getnumber(Y,V), Z is 1.0*U/V.											\n" +

"'math:remainder'([X,Y],Z) :-														\n" +
"	getnumber(X,U), getnumber(Y,V), Z is U mod V.											\n" +

"'math:rounded'(X,Z) :-															\n" +
"	getnumber(X,U), Z is round(U).													\n" +

"'math:sin'(X,Z) :-															\n" +
"	getnumber(X,U), Z is sin(U), !; getnumber(Z,W), X is 2*atan(W/(1+sqrt(1-W*W))).							\n" +

"'math:sum'(X,Z) :-															\n" +
"	sum(X,Z).															\n" +

"'math:tan'(X,Z) :-															\n" +
"	getnumber(X,U), Z is sin(U)/cos(U), !; getnumber(Z,W), X is atan(W).								\n" +

"'rdf:first'([X|Y],X) :-														\n" +
"	'rdf:type'([X|Y],'rdf:List').													\n" +

"'rdf:rest'([X|Y],Y) :-															\n" +
"	'rdf:type'([X|Y],'rdf:List').													\n" +

"'str:concatenation'([X,Y],Z) :-													\n" +
"	ground([X,Y]), unquote(X,S), unquote(Y,T), concat(['\"',S,T,'\"'],Z).								\n" +

"'str:contains'(X,Y) :-															\n" +
"	ground([X,Y]), unquote(X,S), unquote(Y,T), contains(S,T).									\n" +

"'str:containsIgnoringCase'(X,Y) :-													\n" +
"	ground([X,Y]), unquote(X,S), unquote(Y,T), to_lower(S,U), to_lower(T,V), contains(U,V).						\n" +

"'str:endsWith'(X,Y) :-															\n" +
"	ground([X,Y]), unquote(X,S), unquote(Y,T), ends_with(S,T).									\n" +

"'str:equalIgnoringCase'(X,Y) :-													\n" +
"	ground([X,Y]), unquote(X,S), unquote(Y,T), to_lower(S,U), to_lower(T,V), U == V.						\n" +

"'str:greaterThan'(X,Y) :-														\n" +
"	ground([X,Y]), X @> Y.														\n" +

"'str:lessThan'(X,Y) :-															\n" +
"	ground([X,Y]), X @< Y.														\n" +

"'str:matches'(X,Y) :-															\n" +
"	ground([X,Y]), unquote(X,S), unquote(Y,T), matches(S,T).									\n" +

"'str:notEqualIgnoringCase'(X,Y) :-													\n" +
"	ground([X,Y]), \\+'str:equalIgnoringCase'(X,Y).											\n" +

"'str:notGreaterThan'(X,Y) :-														\n" +
"	ground([X,Y]), X @=< Y.														\n" +

"'str:notLessThan'(X,Y) :-														\n" +
"	ground([X,Y]), X @>= Y.														\n" +

"'str:notMatches'(X,Y) :-														\n" +
"	ground([X,Y]), \\+'str:matches'(X,Y).												\n" +

"'str:startsWith'(X,Y) :-														\n" +
"	ground([X,Y]), unquote(X,S), unquote(Y,T), starts_with(S,T).									\n" +

"'time:month'(tlit(X,_),Y) :-														\n" +
"	ground(X), unquote(X,U), substring(U,'-',_,V), substring(V,'-',Y,_).								\n" +

"'time:day'(tlit(X,_),Y) :-														\n" +
"	ground(X), unquote(X,U), substring(U,'-',_,V), substring(V,'-',_,Y).								\n" +

"'time:year'(tlit(X,_),Y) :-														\n" +
"	ground(X), unquote(X,U), substring(U,'-',Y,_).											\n" +


// -------
// support
// -------

"base(A) :-																\n" +
"	flag(port(P)), !, concat(['http://localhost:',P,'/'],A).									\n" +
"base('http://localhost/').														\n" +

"auri('log:semantics'(A,B),'log:semantics'(D,B)) :-											\n" +
"	quri(A,D), !.															\n" +
"auri('log:uri'(A,B),'log:uri'(D,B)) :-													\n" +
"	quri(A,D), !.															\n" +
"auri(A,A).																\n" +

"quri(A,A) :-																\n" +
"	atom(A), unquote(A,U), concat(['<',U,'>'],A), !.										\n" +
"quri(A,B) :-																\n" +
"	atom(A), pfx(A,B), !.														\n" +
"quri(A,B) :-																\n" +
"	atom(A), pfx(U,V), starts_with(A,U), qname(A,V,B), !.										\n" +
"quri(lf(A),lf(A)) :-															\n" +
"	nonvar(A).															\n" +

"within_scope(A) :-															\n" +
"	(limit(B) -> (B < A -> retract(limit(B)), assert(limit(A)); true); assert(limit(A))), scope(A), brake.				\n" +

"varpred(S,P,O) :-															\n" +
"	atom(P) -> U =.. [P,S,O], U; steps(_,_,U), U =.. [P,S,O], P \\= false.								\n" +

"unif(varpred(S,P,O),A) :-														\n" +
"	A =.. [P,S,O], !.														\n" +
"unif(A,varpred(S,P,O)) :-														\n" +
"	A =.. [P,S,O], !.														\n" +
"unif(A,A).																\n" +

"clist([],true) :- !.															\n" +
"clist([A],A) :- !.															\n" +
"clist([A|B],(A,C)) :-															\n" +
"	clist(B,C).															\n" +

"cmember(A,(A,_)).															\n" +
"cmember(A,(_,B)) :-															\n" +
"	cmember(A,B).															\n" +
"cmember(A,A) :-															\n" +
"	A \\= (_,_).															\n" +

"conjunction([],'{}') :- !.														\n" +
"conjunction(['{}'],'{}') :- !.														\n" +
"conjunction([lf(X)],lf(X)) :- !.													\n" +
"conjunction(['{}','{}'],'{}') :- !.													\n" +
"conjunction([lf(X),'{}'],lf(X)) :- !.													\n" +
"conjunction(['{}'|Y],Z) :- !,														\n" +
"	conjunction(Y,Z).														\n" +
"conjunction([lf(X)|Y],lf(X)) :-													\n" +
"	conjunction(Y,'{}'), !.														\n" +
"conjunction([lf(X)|Y],lf(Z)) :-													\n" +
"	conjunction(Y,lf(U)), conjoin(X,U,Z).												\n" +

"conjoin((A,B),C,D) :-															\n" +
"	conjoin(B,C,D), includes(lf(D),lf(A)), !.											\n" +
"conjoin((A,B),C,(A,D)) :-														\n" +
"	conjoin(B,C,D), !.														\n" +
"conjoin(A,B,B) :-															\n" +
"	includes(lf(B),lf(A)), !.													\n" +
"conjoin(A,B,(A,B)).															\n" +

"includes('{}','{}') :- !.														\n" +
"includes(lf(_),'{}') :- !.														\n" +
"includes(lf(X),lf(Y)) :-														\n" +
"	unif(X,Y), !.															\n" +
"includes(lf((X,Y)),lf(Z)) :-														\n" +
"	unif(X,Z); includes(lf(Y),lf(Z)).												\n" +
"includes(lf(X),lf((Y,Z))) :-														\n" +
"	includes(lf(X),lf(Y)), includes(lf(X),lf(Z)).											\n" +

"difference(['{}',_],'{}') :- !.													\n" +
"difference([X,'{}'],X) :- !.														\n" +
"difference([lf(X),lf(Y)],Z) :-														\n" +
"	findall(U,(cmember(U,X), \\+((cmember(V,Y), unif(U,V)))),W), (W = [] -> Z = '{}'; clist(W,G), Z = lf(G)).			\n" +

"intersection([X],X) :- !.														\n" +
"intersection(['{}'|_],'{}') :- !.													\n" +
"intersection([_|Y],'{}') :-														\n" +
"	intersection(Y,'{}'), !.													\n" +
"intersection([lf(X)|Y],lf(Z)) :-													\n" +
"	intersection(Y,lf(I)), findall(U,(cmember(U,X), cmember(V,I), unif(U,V)),W), clist(W,Z).					\n" +

"bdelete([],_,[]) :- !.															\n" +
"bdelete([A|B],C,D) :-															\n" +
"	A == C, !, bdelete(B,C,D).													\n" +
"bdelete([A|B],C,[A|D]) :-														\n" +
"	bdelete(B,C,D).															\n" +

"list_to_set([],[]) :- !.														\n" +
"list_to_set([A|B],[A|C]) :-														\n" +
"	bdelete(B,A,D), list_to_set(D,C).												\n" +

"memberchk(A,[A|_]) :- !.														\n" +
"memberchk(A,[_|B]) :-															\n" +
"	memberchk(A,B).															\n" +

"sum([],0) :- !.															\n" +
"sum([A|B],C) :-															\n" +
"	getnumber(A,X), sum(B,D), C is X+D.												\n" +

"product([],1) :- !.															\n" +
"product([A|B],C) :-															\n" +
"	getnumber(A,X), product(B,D), C is X*D.												\n" +

"max([A|B],C) :-															\n" +
"	max(B,A,C).															\n" +

"max([],A,A).																\n" +
"max([A|B],C,D) :-															\n" +
"	A @> C -> max(B,A,D); max(B,C,D).												\n" +

"min([A|B],C) :-															\n" +
"	min(B,A,C).															\n" +

"min([],A,A).																\n" +
"min([A|B],C,D) :-															\n" +
"	A @< C -> min(B,A,D); min(B,C,D).												\n" +

"last([A|B],C) :-															\n" +
"	last(B,A,C).															\n" +

"last([],A,A).																\n" +
"last([A|B],_,C) :-															\n" +
"	last(B,A,C).															\n" +

"inconsistent([lf('e:boolean'(A,'e:T'))|B]) :-												\n" +
"	memberchk(lf('e:boolean'(A,'e:F')),B), !.											\n" +
"inconsistent([lf('e:boolean'(A,'e:F'))|B]) :-												\n" +
"	memberchk(lf('e:boolean'(A,'e:T')),B), !.											\n" +
"inconsistent([_|B]) :-															\n" +
"	inconsistent(B).														\n" +

"bnet :-																\n" +
"	\\+bset, assert(bset), bcln, bcnd([lf('e:boolean'(A,_))|B],_), (\\+bvar(A), assert(bvar(A)); true),				\n" +
"	member(lf('e:boolean'(C,_)),B), \\+bref(C,A), assert(bref(C,A)), \\+bvar(C), assert(bvar(C)), fail; true.			\n" +

"bcln :-																\n" +
"	'e:conditional'([A|B],_), quicksort(B,'@<',C), findall(Y,('e:conditional'([A|X],Y), quicksort(X,'@<',C)),L),			\n" +
"	sum(L,S), length(L,N), Z is S/N, \\+bcnd([A|B],_), assert(bcnd([A|B],Z)), fail; true.						\n" +

"bval('e:T').																\n" +
"bval('e:F').																\n" +

"brel(lf('e:boolean'(A,_)),lf('e:boolean'(B,_))) :-											\n" +
"	bref(A,B), !.															\n" +
"brel(A,lf('e:boolean'(B,_))) :-													\n" +
"	bref(C,B), brel(A,lf('e:boolean'(C,_))).											\n" +

"bpar([],[]) :- !.															\n" +
"bpar([lf('e:boolean'(A,_))|B],[A|C]) :-												\n" +
"	bpar(B,C).															\n" +

"bget(A,B,1.0) :-															\n" +
"	memberchk(A,B), !.														\n" +
"bget(lf('e:boolean'(A,'e:T')),B,0.0) :-												\n" +
"	memberchk(lf('e:boolean'(A,'e:F')),B), !.											\n" +
"bget(lf('e:boolean'(A,'e:F')),B,C) :-													\n" +
"	memberchk(lf('e:boolean'(A,'e:T')),B), !, C is 0.0; !, bget(lf('e:boolean'(A,'e:T')),B,D), C is 1-D.				\n" +
"bget(A,B,C) :-																\n" +
"	bgot(A,B,C) -> true; (member(X,B), brel(A,X), member(G,B),									\n" +
"	findall(Y,(member(Z,[A|B]), brel(G,Z)),[]), bdelete(B,G,H), !,									\n" +
"	bget(G,[A|H],U), bget(A,H,V), bget(G,H,W), (W =:= 0 -> C is V; E is U*V/W, min([E,1.0],C));					\n" +
"	findall([Z,Y],(bcnd([A|O],P), bcon(O,B,Q), Z is P*Q, bpar(O,Y)),L),								\n" +
"	findall(Z,(member([_,Z],L)),N), list_to_set(N,I),										\n" +
"	findall(Z,(member(Y,I), findall(P,(member([P,Y],L)),Q), sum(Q,R), length(Q,S), length(Y,T),					\n" +
"		(Q = [] -> Z is 0.0; D is 2**(T-ceiling(log(S)/log(2))), (D < 1 -> Z is R*D; Z is R))),J),				\n" +
"	(J = [] -> C is 0.0; max(J,C))), assert(bgot(A,B,C)), !.									\n" +

"bcon([],_,1.0) :- !.															\n" +
"bcon(_,B,0.5) :-															\n" +
"	inconsistent(B), !.														\n" +
"bcon([A|B],C,D) :-															\n" +
"	bget(A,C,E), bcon(B,[A|C],F), D is E*F.												\n" +

"numbervars(sk(A),A,B,sk) :- !,														\n" +
"	B is A+1.															\n" +
"numbervars(all(A),A,B,all) :- !,													\n" +
"	B is A+1.															\n" +
"numbervars(var(A),A,B,var) :- !,													\n" +
"	B is A+1.															\n" +
"numbervars(A,B,B,_) :-															\n" +
"	atomic(A), !.															\n" +
"numbervars(A,B,C,Q) :-															\n" +
"	functor(A,_,D), numbervars(0,D,A,B,C,Q).											\n" +

"numbervars(A,A,_,B,B,_) :- !.														\n" +
"numbervars(A,B,C,D,E,Q) :-														\n" +
"	F is A+1, arg(F,C,G), numbervars(G,D,H,Q), numbervars(F,B,C,H,E,Q).								\n" +

"getnumber(A,A) :-															\n" +
"	ground(A), number(A), !.													\n" +
"getnumber(tlit(A,'xsd:dateTime'),B) :- !,												\n" +
"	ground(A), unquote(A,C), datetime(C,B).												\n" +
"getnumber(tlit(A,'xsd:duration'),B) :- !,												\n" +
"	ground(A), unquote(A,C), duration(C,B).												\n" +
"getnumber(plit(A,_),B) :- !,														\n" +
"	ground(A), unquote(A,C), num_atom(B,C).												\n" +
"getnumber(A,B) :-															\n" +
"	ground(A), unquote(A,C), num_atom(B,C).												\n" +

"";
	}

	public boolean to_lower_2(BindingsTable bt, Term s, Term o) {
		String m = Parser.removeApices(((Struct) s).name);
		return bt.unify(o, new StructAtom(m.toLowerCase()));
	}

	public boolean to_upper_2(BindingsTable bt, Term s, Term o) {
		String m = Parser.removeApices(((Struct) s).name);
		return bt.unify(o, new StructAtom(m.toUpperCase()));
	}

	public boolean starts_with_2(BindingsTable bt, Term s, Term o) {
		String m = Parser.removeApices(((Struct) s).name);
		String n = Parser.removeApices(((Struct) o).name);
		return m.startsWith(n);
	}

	public boolean ends_with_2(BindingsTable bt, Term s, Term o) {
		String m = Parser.removeApices(((Struct) s).name);
		String n = Parser.removeApices(((Struct) o).name);
		return m.endsWith(n);
	}

	public boolean contains_2(BindingsTable bt, Term s, Term o) {
		String m = Parser.removeApices(((Struct) s).name);
		String n = Parser.removeApices(((Struct) o).name);
		return m.indexOf(n) != -1;
	}

	public boolean matches_2(BindingsTable bt, Term s, Term o) {
		try {
			String m = Parser.removeApices(((Struct) s).name);
			String n = Parser.removeApices(((Struct) o).name);
			return m.matches(n);
		} catch (Throwable t) {
			t.printStackTrace();
			return false;
		}
	}

	public boolean unquote_2(BindingsTable bt, Term s, Term o) {
		String m = Parser.removeApices(((Struct) s).name);
		return bt.unify(o, new StructAtom(m.substring(1, m.length() - 1)));
	}

	public boolean concat_2(BindingsTable bt, Struct list, Term concat) {
		StringBuffer sb = new StringBuffer();
		while (list.predicateIndicator == Parser.listSignature) {
			Term head = bt.resolve(list.getArg(0));
			sb.append(Parser.removeApices(head.toString()));
			list = (Struct) bt.resolve(list.getArg(1));
		}
		return bt.unify(concat, new StructAtom(sb.toString()));
	}

	public boolean substring_4(BindingsTable bt, Term s, Term t, Term o, Term p) {
		String m = Parser.removeApices(((Struct) s).name);
		String n = Parser.removeApices(((Struct) t).name);
		int i = m.indexOf(n);
		return bt.unify(o, new StructAtom(m.substring(0, i))) && bt.unify(p, new StructAtom(m.substring(i + n.length())));
	}

	public boolean bnode_2(BindingsTable bt, Term s, Term o) {
		String m = Parser.removeApices(((Struct) s).name);
		if (m.startsWith("_:"))
			return bt.unify(o, new StructAtom(m));
		else if (m.startsWith("var:"))
			return bt.unify(o, new StructAtom("_:" + m.substring(4)));
		else
			return false;
	}

	public boolean qname_3(BindingsTable bt, Term s, Term u, Term o) {
		String m = Parser.removeApices(((Struct) s).name);
		String n = Parser.removeApices(((Struct) u).name);
		return bt.unify(o, new StructAtom(n.substring(0, n.length() - 1) + m.substring(m.indexOf(':') + 1) + '>'));
	}

	public boolean ruri_3(BindingsTable bt, Term s, Term u, Term o) {
		try {
			String m = Parser.removeApices(((Struct) s).name);
			String n = Parser.removeApices(((Struct) u).name);
			return bt.unify(o, new StructAtom(new URL(new URL(n), m).toString()));
		} catch (Throwable t) {
			t.printStackTrace();
			return false;
		}
	}

	public boolean web_2(BindingsTable bt, Term u, Term c) {
		try {
			String s = new Euler().fromWeb(((Struct) u).name);
			return bt.unify(c, new StructAtom(s));
		} catch (Throwable t) {
			return false;
		}
	}

	public boolean semantics_2(BindingsTable bt, Term u, Term c) {
		try {
			String s = new Euler().fromWeb(((Struct) u).name);
			s = s.substring(0, s.lastIndexOf('.'));
			return bt.unify(c, new Parser(s, engine).nextTerm(false));
		} catch (Throwable t) {
			return bt.unify(c, new StructAtom("fail"));
		}
	}

	public boolean url_encode_2(BindingsTable bt, Term s, Term o) {
		try {
			String m = Parser.removeApices(((Struct) s).name);
			return bt.unify(o, new StructAtom(URLEncoder.encode(m, "UTF-8")));
		} catch (Throwable t) {
			t.printStackTrace();
			return false;
		}
	}

	public boolean url_decode_2(BindingsTable bt, Term s, Term o) {
		try {
			String m = Parser.removeApices(((Struct) s).name);
			return bt.unify(o, new StructAtom(URLDecoder.decode(m, "UTF-8")));
		} catch (Throwable t) {
			t.printStackTrace();
			return false;
		}
	}

	public boolean datetime_2(BindingsTable bt, Term s, Term o) {
		try {
			String dt = Parser.removeApices(((Struct) s).name);
			String localString = dt.substring(0, 19);
			String restString = dt.substring(19);
			String tzString = "00:00";
			boolean tzNegative = false;
			int rl = restString.length();
			if (rl >= 1 && restString.charAt(rl - 1) == 'Z')
				restString = restString.substring(0, rl - 1);
			if (rl >= 6 && restString.charAt(rl - 6) == '+') {
				tzString = restString.substring(rl - 5);
				restString = restString.substring(0, rl - 6);
			}
			if (rl >= 6 && restString.charAt(rl - 6) == '-') {
				tzString = restString.substring(rl - 5);
				tzNegative = true;
				restString = restString.substring(0, rl - 6);
			}
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
			long local = df.parse(localString).getTime();
			long offset = df.getTimeZone().getOffset(local);
			int tzh = Integer.parseInt(tzString.substring(0, 2));
			int tzm = Integer.parseInt(tzString.substring(3));
			long tz = tzh * 3600000 + tzm * 60000;
			if (tzNegative)
				tz = -tz;
			double frac = java.lang.Double.parseDouble("0" + restString);
			double t = (local + offset - tz) / 1000 + frac;
			return bt.unify(o, new Double(t));
		} catch (Throwable t) {
			t.printStackTrace();
			return false;
		}
	}

	public boolean duration_2(BindingsTable bt, Term s, Term o) {
		try {
			String d = Parser.removeApices(((Struct) s).name);
			int years = 0;
			int months = 0;
			int days = 0;
			int hours = 0;
			int minutes = 0;
			double seconds = 0.0;
			boolean isNegative = false;
			int start = 0;
			if (d.startsWith("-")) {
				isNegative = true;
				++start;
			}
			if (d.indexOf('P') != start)
				throw new IllegalArgumentException(d);
			++start;
			int end = d.indexOf('Y');
			if (end >= 0) {
				String yearsString = d.substring(start, end);
				years = Integer.parseInt(yearsString);
				start = end + 1;
			}
			end = d.indexOf('M');
			int time = d.indexOf('T');
			if (end >= 0 && (time == -1 || time > end)) {
				String monthsString = d.substring(start, end);
				months = Integer.parseInt(monthsString);
				start = end + 1;
			}
			end = d.indexOf('D');
			if (end >= 0) {
				String daysString = d.substring(start, end);
				days = Integer.parseInt(daysString);
				start = end + 1;
			}
			if (start != d.length()) {
				if (d.charAt(start) != 'T')
					throw new IllegalArgumentException(d);
				++start;
				if (start == d.length())
					throw new IllegalArgumentException(d);
				end = d.indexOf('H');
				if (end >= 0) {
					String hoursString = d.substring(start, end);
					hours = Integer.parseInt(hoursString);
					start = end + 1;
				}
				end = d.indexOf('M');
				if (end >= 0) {
					String minString = d.substring(start, end);
					minutes = Integer.parseInt(minString);
					start = end + 1;
				}
				end = d.indexOf('S');
				if (end >= 0) {
					String secString = d.substring(start, end);
					seconds = java.lang.Double.parseDouble(secString);
				}
			}
			double t = years * 31556926 + months * 2629744 + days * 86400 + hours * 3600 + minutes * 60 + seconds;
			if (isNegative)
				t = -t;
			return bt.unify(o, new Double(t));
		} catch (Throwable t) {
			t.printStackTrace();
			return false;
		}
	}
}

