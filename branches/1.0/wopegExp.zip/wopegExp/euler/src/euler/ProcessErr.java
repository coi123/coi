package euler;

import java.io.*;

public class ProcessErr implements Runnable {

	DataInputStream dis = null;

	public ProcessErr(DataInputStream pe) {
		dis = pe;
	}

	public void run() {
		try {
			String co = null;
			while (dis != null && (co = dis.readLine()) != null)
				System.err.println(co);
		} catch (Exception e) {
			//e.printStackTrace();
		}
	}

	public void start() {
		new Thread(this).start();
	}
}
