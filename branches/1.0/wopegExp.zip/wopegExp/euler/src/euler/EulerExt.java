package euler;

import java.util.Vector;
import java.util.Hashtable;

public class EulerExt {

	Hashtable ns = null;	// to table namespaces
	Hashtable nsp = null;	// to table namespace prefixes
	Hashtable kw = null;	// to table keywords
	Hashtable syn = null;	// to table synonyms
	Hashtable ocl = null;	// to table classes
	Hashtable dds = null;	// to table log:definitiveDocument and Service
	Hashtable dsg = null;	// to table derived subgoals
	int varmax = 0;		// maximum variable count
	String baseURI = "";	// URI of base process
	Vector loaded = null;	// to table document/engine pairs
	long engine = 1;	// number of engines
	boolean se = false;	// simple entailment
	boolean pd = false;	// prepare done
	boolean kc = false;	// keep consequent

	public EulerExt() {
		ns = new Hashtable();
		nsp = new Hashtable();
		kw = new Hashtable();
		syn = new Hashtable();
		ocl = new Hashtable();
		dds = new Hashtable();
		dsg = new Hashtable();
		ns.put("e:", Euler.E + "#>");
		ns.put("log:", Euler.LOG + "#>");
		ns.put("math:", Euler.MATH + "#>");
		ns.put("n3:", Euler.N3 + "#>");
		ns.put("owl:", Euler.OWL + "#>");
		ns.put("q:", Euler.Q + "#>");
		ns.put("r:", Euler.R + "#>");
		ns.put("rdf:", Euler.RDF + "#>");
		ns.put("rdfs:", Euler.RDFS + "#>");
		ns.put("list:", Euler.LIST + "#>");
		ns.put("str:", Euler.STR + "#>");
		ns.put("time:", Euler.TIME + "#>");
		ns.put("var:", "<http://localhost/var#>");
		ns.put("xsd:", Euler.XSD + "#>");
		ns.put("fn:", "<http://www.w3.org/2005/xpath-functions#>");

		kw.put("this", this);
		kw.put("is", this);
		kw.put("of", this);
		kw.put("has", this);
		kw.put("a", this);
		kw.put("=", this);
		kw.put("=>", this);
		kw.put("think", this);
		kw.put("case", this);
		kw.put("{}", this);
		kw.put("^^", this);
		kw.put("true", this);
		kw.put("false", this);
		kw.put("SELECT", this);
		kw.put("CONSTRUCT", this);
		kw.put("FROM", this);
		kw.put("NAMED", this);
		kw.put("UNION", this);
		kw.put("OPTIONAL", this);
		kw.put("FILTER", this);
		kw.put("WHERE", this);
	}
}
