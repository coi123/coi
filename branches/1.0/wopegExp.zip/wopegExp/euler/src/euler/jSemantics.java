package euler;

import ubc.cs.JLog.Terms.*;
import ubc.cs.JLog.Foundation.*;
import ubc.cs.JLog.Builtins.*;
import ubc.cs.JLog.Terms.Goals.*;
import ubc.cs.JLog.Parser.*;

public class jSemantics extends jBinaryBuiltinPredicate {

	public jSemantics(jTerm l, jTerm r) {
		super(l, r, TYPE_BUILTINPREDICATE);
	}

	public String getName() {
		return "semantics";
	}

	public boolean prove(jBinaryBuiltinPredicateGoal bg) {
		jTerm l = bg.term1.getTerm();
		jTerm r = bg.term2.getTerm();
		String u = l.toString();
		try {
			String s = Codd.nativeToAscii(new Euler().fromWeb(u));
			if (s.startsWith("null"))
				s = "fail.";
			jPrologServiceThread pst = (jPrologServiceThread) Thread.currentThread();
			jPrologServices p = pst.getPrologServices();
			pParseStream parser = new pParseStream(s, p.getKnowledgeBase(), p.getPredicateRegistry(), p
					.getOperatorRegistry());
			jTerm result = parser.parseTerm();
			return r.unify(result, bg.unified);
		} catch (Throwable t) {
			t.printStackTrace();
			return false;
		}
	}

	public jBinaryBuiltinPredicate duplicate(jTerm l, jTerm r) {
		return new jSemantics(l, r);
	}
}
