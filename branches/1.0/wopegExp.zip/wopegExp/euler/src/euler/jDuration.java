package euler;

import ubc.cs.JLog.Terms.*;
import ubc.cs.JLog.Foundation.*;
import ubc.cs.JLog.Builtins.*;
import ubc.cs.JLog.Terms.Goals.*;

public class jDuration extends jBinaryBuiltinPredicate {

	public jDuration(jTerm l, jTerm r) {
		super(l, r, TYPE_BUILTINPREDICATE);
	}

	public String getName() {
		return "duration";
	}

	public boolean prove(jBinaryBuiltinPredicateGoal bg) {
		jTerm l = bg.term1.getTerm();
		jTerm r = bg.term2.getTerm();
		String d = l.toString();
		try {
			jTerm result = new jReal(getValue(d));
			return r.unify(result, bg.unified);
		} catch (Throwable t) {
			t.printStackTrace();
			return false;
		}
	}

	public jBinaryBuiltinPredicate duplicate(jTerm l, jTerm r) {
		return new jDuration(l, r);
	}

	public static double getValue(String d) {
		try {
			int years = 0;
			int months = 0;
			int days = 0;
			int hours = 0;
			int minutes = 0;
			double seconds = 0.0;
			boolean isNegative = false;
			int start = 0;
			if (d.startsWith("-")) {
				isNegative = true;
				++start;
			}
			if (d.indexOf('P') != start)
				throw new IllegalArgumentException(d);
			++start;
			int end = d.indexOf('Y');
			if (end >= 0) {
				String yearsString = d.substring(start, end);
				years = Integer.parseInt(yearsString);
				start = end + 1;
			}
			end = d.indexOf('M');
			int time = d.indexOf('T');
			if (end >= 0 && (time == -1 || time > end)) {
				String monthsString = d.substring(start, end);
				months = Integer.parseInt(monthsString);
				start = end + 1;
			}
			end = d.indexOf('D');
			if (end >= 0) {
				String daysString = d.substring(start, end);
				days = Integer.parseInt(daysString);
				start = end + 1;
			}
			if (start != d.length()) {
				if (d.charAt(start) != 'T')
					throw new IllegalArgumentException(d);
				++start;
				if (start == d.length())
					throw new IllegalArgumentException(d);
				end = d.indexOf('H');
				if (end >= 0) {
					String hoursString = d.substring(start, end);
					hours = Integer.parseInt(hoursString);
					start = end + 1;
				}
				end = d.indexOf('M');
				if (end >= 0) {
					String minString = d.substring(start, end);
					minutes = Integer.parseInt(minString);
					start = end + 1;
				}
				end = d.indexOf('S');
				if (end >= 0) {
					String secString = d.substring(start, end);
					seconds = java.lang.Double.parseDouble(secString);
				}
			}
			double t = years * 31556926 + months * 2629744 + days * 86400 + hours * 3600 + minutes * 60 + seconds;
			if (isNegative)
				t = -t;
			return t;
		} catch (Throwable t) {
			t.printStackTrace();
			throw new RuntimeException();
		}
	}
}
